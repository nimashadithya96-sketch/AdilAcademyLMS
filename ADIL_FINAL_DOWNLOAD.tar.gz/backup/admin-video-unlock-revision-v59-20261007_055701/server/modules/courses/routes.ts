import { and, asc, count, desc, eq, inArray } from "drizzle-orm";
import crypto from "node:crypto";
import express, { Router } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import {
  auditLogs,
  courseSections,
  courses,
  enrollments,
  lessonProgress,
  lessonQuizAttempts,
  lessons,
  networkAccounts,
  paymentRequests,
  quizAttempts,
  quizQuestions,
  quizzes,
  users,
  videoAccessOverrides
} from "../../../db/schema";
import { HttpError, requireAuthenticatedUser, requireRole } from "../../lib/auth";
import { asyncRoute } from "../../lib/http";
import { deletePrivateFile, downloadPrivateFile, uploadPrivateFile } from "../../services/storage";
import { ensureRevisionEligibilityState } from "../revision/student-service"; // ADIL_STUDENT_REVISION_V46

export const courseRouter = Router();

const courseInput = z.object({
  slug: z.string().trim().min(3).max(120).regex(/^[a-z0-9-]+$/),
  title: z.string().trim().min(3).max(180),
  shortDescription: z.string().trim().min(10).max(400),
  description: z.string().trim().max(10000).optional(),
  price: z.coerce.number().positive(),
  points: z.coerce.number().int().min(0).default(0),
  halfPaymentLessonLimit: z.coerce.number().int().min(0).max(10000).default(7),
  currency: z.string().trim().length(3).default("LKR"),
  isPublished: z.boolean().default(false)
});

const DAILY_NEW_LESSON_LIMIT = 3;
const ADMIN_VIDEO_UNLOCK_MARKER = "ADIL_ADMIN_VIDEO_UNLOCK_V1";
const LESSON_PASS_PERCENT = 75;

function colomboDateKey(value: Date) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Colombo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(value);
  const get = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

type LessonGateReason = "PAYMENT" | "DAILY_LIMIT" | "PREVIOUS_QA" | null;

async function hasAllVideoUnlock(
  db: ReturnType<typeof requireDatabase>,
  userId: string,
  courseId: string
) {
  const [override] = await db
    .select({ unlockAllVideos: videoAccessOverrides.unlockAllVideos })
    .from(videoAccessOverrides)
    .where(and(eq(videoAccessOverrides.userId, userId), eq(videoAccessOverrides.courseId, courseId)))
    .limit(1);
  return override?.unlockAllVideos === true;
}

async function buildLessonGate(
  db: ReturnType<typeof requireDatabase>,
  userId: string,
  courseId: string,
  access: { accessLevel: "FULL" | "HALF"; halfPaymentLessonLimit: number },
  orderedLessons?: Array<{ id: string; sectionId: string; position: number }>
) {
  const allVideosUnlocked = await hasAllVideoUnlock(db, userId, courseId);
  let courseLessons = orderedLessons;
  if (!courseLessons) {
    const sections = await db
      .select({ id: courseSections.id, position: courseSections.position })
      .from(courseSections)
      .where(eq(courseSections.courseId, courseId))
      .orderBy(asc(courseSections.position));
    const sectionOrder = new Map(sections.map((section, index) => [section.id, index]));
    const unordered = sections.length
      ? await db
          .select({ id: lessons.id, sectionId: lessons.sectionId, position: lessons.position })
          .from(lessons)
          .where(inArray(lessons.sectionId, sections.map((section) => section.id)))
          .orderBy(asc(lessons.position))
      : [];
    courseLessons = [...unordered].sort((a, b) =>
      (sectionOrder.get(a.sectionId) ?? 0) - (sectionOrder.get(b.sectionId) ?? 0) ||
      a.position - b.position
    );
  }

  const lessonIds = courseLessons.map((lesson) => lesson.id);
  const attempts = lessonIds.length
    ? await db
        .select({
          lessonId: lessonQuizAttempts.lessonId,
          scorePercent: lessonQuizAttempts.scorePercent,
          completedAt: lessonQuizAttempts.completedAt
        })
        .from(lessonQuizAttempts)
        .where(and(eq(lessonQuizAttempts.userId, userId), inArray(lessonQuizAttempts.lessonId, lessonIds)))
    : [];

  const firstPassAtByLesson = new Map<string, Date>();
  for (const attempt of attempts) {
    if (!attempt.completedAt || (attempt.scorePercent ?? 0) < LESSON_PASS_PERCENT) continue;
    const existing = firstPassAtByLesson.get(attempt.lessonId);
    if (!existing || attempt.completedAt.getTime() < existing.getTime()) {
      firstPassAtByLesson.set(attempt.lessonId, attempt.completedAt);
    }
  }
  const passedLessonIds = new Set(firstPassAtByLesson.keys());
  const todayKey = colomboDateKey(new Date());
  const passedTodayIds = new Set(
    [...firstPassAtByLesson.entries()]
      .filter(([, firstPassedAt]) => colomboDateKey(firstPassedAt) === todayKey)
      .map(([lessonId]) => lessonId)
  );

  const paymentLimit = allVideosUnlocked
    ? courseLessons.length
    : access.accessLevel === "FULL"
      ? courseLessons.length
      : Math.min(courseLessons.length, access.halfPaymentLessonLimit);
  const firstNotPassedIndex = courseLessons.findIndex((lesson, index) =>
    index < paymentLimit && !passedLessonIds.has(lesson.id)
  );
  const nextLessonIndex = firstNotPassedIndex === -1 ? paymentLimit : firstNotPassedIndex;
  const dailyLimitReached = !allVideosUnlocked && passedTodayIds.size >= DAILY_NEW_LESSON_LIMIT;

  const byLessonId = new Map<string, { locked: boolean; reason: LessonGateReason; qaPassed: boolean }>();
  courseLessons.forEach((lesson, index) => {
    const qaPassed = passedLessonIds.has(lesson.id);
    if (allVideosUnlocked) {
      byLessonId.set(lesson.id, { locked: false, reason: null, qaPassed });
      return;
    }
    if (index >= paymentLimit) {
      byLessonId.set(lesson.id, { locked: true, reason: "PAYMENT", qaPassed });
      return;
    }
    if (qaPassed) {
      byLessonId.set(lesson.id, { locked: false, reason: null, qaPassed: true });
      return;
    }
    if (index === nextLessonIndex) {
      byLessonId.set(lesson.id, {
        locked: dailyLimitReached,
        reason: dailyLimitReached ? "DAILY_LIMIT" : null,
        qaPassed: false
      });
      return;
    }
    byLessonId.set(lesson.id, { locked: true, reason: "PREVIOUS_QA", qaPassed: false });
  });

  return {
    byLessonId,
    dailyLimit: DAILY_NEW_LESSON_LIMIT,
    passedToday: passedTodayIds.size,
    remainingToday: Math.max(0, DAILY_NEW_LESSON_LIMIT - passedTodayIds.size),
    nextLessonIndex,
    paymentLimit,
    allVideosUnlocked
  };
}

async function courseAccess(db: ReturnType<typeof requireDatabase>, userId: string, courseId: string) {
  const [payment] = await db.select({ status: paymentRequests.status })
    .from(paymentRequests)
    .where(and(eq(paymentRequests.userId, userId), eq(paymentRequests.courseId, courseId), inArray(paymentRequests.status, ["PARTIAL", "APPROVED"])))
    .orderBy(desc(paymentRequests.createdAt)).limit(1);
  const [course] = await db.select({ halfPaymentLessonLimit: courses.halfPaymentLessonLimit }).from(courses).where(eq(courses.id, courseId)).limit(1);
  return { accessLevel: payment?.status === "APPROVED" ? "FULL" as const : "HALF" as const, halfPaymentLessonLimit: course?.halfPaymentLessonLimit ?? 0 };
}

const sectionInput = z.object({
  courseId: z.string().uuid(),
  title: z.string().trim().min(2).max(180),
  position: z.coerce.number().int().min(1)
});

const lessonInput = z.object({
  sectionId: z.string().uuid(),
  title: z.string().trim().min(2).max(180),
  content: z.string().trim().max(30000).optional(),
  videoProvider: z.enum(["youtube", "vimeo"]).optional(),
  videoId: z.string().trim().max(200).optional(),
  durationSeconds: z.coerce.number().int().min(0).default(0),
  position: z.coerce.number().int().min(1),
  isPreview: z.boolean().default(false)
});

const progressInput = z.object({
  enrollmentId: z.string().uuid(),
  lessonId: z.string().uuid(),
  elapsedSeconds: z.coerce.number().int().min(1).max(15),
  durationSeconds: z.coerce.number().int().min(10).max(86400)
});

// ADIL_RESUME_POSITION_V29
const resumePositionInput = z.object({
  enrollmentId: z.string().uuid(),
  lessonId: z.string().uuid(),
  currentTimeSeconds: z.coerce.number().min(0).max(86400),
  durationSeconds: z.coerce.number().int().min(0).max(86400).optional()
});
const quizInput = z.object({
  courseId: z.string().uuid(),
  title: z.string().trim().min(3).max(180),
  passingPercent: z.coerce.number().int().min(1).max(100).default(70),
  position: z.coerce.number().int().min(1),
  isPublished: z.boolean().default(false)
});
const questionInput = z.object({
  quizId: z.string().uuid(),
  question: z.string().trim().min(3).max(2000),
  options: z.array(z.string().trim().min(1).max(1000)).min(2).max(8),
  correctOption: z.coerce.number().int().min(0),
  explanation: z.string().trim().max(3000).optional(),
  position: z.coerce.number().int().min(1)
});
const attemptInput = z.object({
  answers: z.array(z.coerce.number().int().min(0)).max(200)
});
const courseUpdateInput = courseInput.partial().refine((value) => Object.keys(value).length > 0);
const sectionUpdateInput = sectionInput.omit({ courseId: true }).partial().refine((value) => Object.keys(value).length > 0);
const lessonUpdateInput = lessonInput.omit({ sectionId: true }).partial().refine((value) => Object.keys(value).length > 0);

courseRouter.get(
  "/courses",
  asyncRoute(async (_request, response) => {
    const db = requireDatabase();
    const items = await db
      .select({
        id: courses.id,
        slug: courses.slug,
        title: courses.title,
        shortDescription: courses.shortDescription,
        description: courses.description,
        price: courses.price,
        currency: courses.currency,
        language: courses.language,
        thumbnailUrl: courses.thumbnailUrl
        ,halfPaymentLessonLimit: courses.halfPaymentLessonLimit
      })
      .from(courses)
      .where(eq(courses.isPublished, true))
      .orderBy(asc(courses.createdAt));
    response.json({ courses: items });
  })
);

courseRouter.get(
  "/courses/:slug",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [course] = await db
      .select()
      .from(courses)
      .where(
        and(
          eq(courses.slug, String(request.params.slug)),
          eq(courses.isPublished, true)
        )
      )
      .limit(1);
    if (!course) {
      response.status(404).json({ message: "Course not found." });
      return;
    }

    const sections = await db
      .select()
      .from(courseSections)
      .where(eq(courseSections.courseId, course.id))
      .orderBy(asc(courseSections.position));
    const sectionIds = new Set(sections.map((section) => section.id));
    const allLessons = sectionIds.size
      ? await db
          .select({
            id: lessons.id,
            sectionId: lessons.sectionId,
            title: lessons.title,
            durationSeconds: lessons.durationSeconds,
            position: lessons.position,
            isPreview: lessons.isPreview
          })
          .from(lessons)
          .where(inArray(lessons.sectionId, [...sectionIds]))
          .orderBy(asc(lessons.position))
      : [];

    const [{ enrolledStudents }] = await db.select({ enrolledStudents: count() })
      .from(enrollments)
      .where(and(eq(enrollments.courseId, course.id), eq(enrollments.status, "ACTIVE")));
    response.json({
      course,
      enrolledStudents,
      sections: sections.map((section) => ({
        ...section,
        lessons: allLessons.filter(
          (lesson) => lesson.sectionId === section.id
        )
      }))
    });
  })
);

courseRouter.get(
  "/courses/:id/thumbnail",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [course] = await db.select({ key: courses.thumbnailUrl }).from(courses)
      .where(eq(courses.id, String(request.params.id))).limit(1);
    if (!course?.key) { response.status(404).json({ message: "Course image not found." }); return; }
    const extension = course.key.split(".").pop()?.toLowerCase();
    response.type(extension === "png" ? "image/png" : extension === "webp" ? "image/webp" : "image/jpeg")
      .set("Cache-Control", "public, max-age=3600")
      .send(await downloadPrivateFile(course.key));
  })
);

courseRouter.get(
  "/student/enrollments",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db
      .select({
        enrollmentId: enrollments.id,
        status: enrollments.status,
        enrolledAt: enrollments.enrolledAt,
        completedAt: enrollments.completedAt,
        courseId: courses.id,
        slug: courses.slug,
        title: courses.title,
        shortDescription: courses.shortDescription,
        thumbnailUrl: courses.thumbnailUrl
      })
      .from(enrollments)
      .innerJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.userId, user.id))
      .orderBy(asc(enrollments.enrolledAt));
    response.json({ enrollments: await Promise.all(items.map(async (item) => ({ ...item, ...(await courseAccess(db, user.id, item.courseId)) }))) });
  })
);

courseRouter.get(
  "/student/dashboard-summary",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [account] = await db.select().from(networkAccounts).where(
      and(
        eq(networkAccounts.ownerUserId, user.id),
        eq(networkAccounts.isMainAccount, true)
      )
    ).limit(1);
    const [enrollment] = await db.select({
      id: enrollments.id,
      status: enrollments.status,
      courseId: enrollments.courseId,
      courseTitle: courses.title,
      halfPaymentLessonLimit: courses.halfPaymentLessonLimit
    }).from(enrollments)
      .innerJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.userId, user.id))
      .orderBy(asc(enrollments.enrolledAt)).limit(1);

    if (!enrollment) {
      response.json({
        enrollmentStatus: "NOT_ENROLLED",
        enrollmentId: null,
        courseTitle: null,
        totalLessons: 0,
        completedLessons: 0,
        progressPercent: 0,
        quizAverage: null,
        accountNumber: account ? `${account.prefix}${account.numericPart}` : null,
        accountStatus: account?.status ?? null,
        modules: [],
        recentActivity: []
      });
      return;
    }

    const access = await courseAccess(db, user.id, enrollment.courseId);
    const sections = await db.select({ id: courseSections.id, title: courseSections.title, position: courseSections.position })
      .from(courseSections).where(eq(courseSections.courseId, enrollment.courseId)).orderBy(asc(courseSections.position));
    const sectionIds = sections.map((item) => item.id);
    const unorderedLessons = sectionIds.length
      ? await db.select({ id: lessons.id, title: lessons.title, sectionId: lessons.sectionId, position: lessons.position }).from(lessons)
          .where(inArray(lessons.sectionId, sectionIds)).orderBy(asc(lessons.position))
      : [];
    const sectionOrder = new Map(sections.map((section, index) => [section.id, index]));
    const courseLessons = [...unorderedLessons].sort((a, b) =>
      (sectionOrder.get(a.sectionId) ?? 0) - (sectionOrder.get(b.sectionId) ?? 0) || a.position - b.position
    );
    const lessonOrder = new Map(courseLessons.map((lesson, index) => [lesson.id, index]));
    const learningAccessActive = enrollment.status === "ACTIVE" || enrollment.status === "COMPLETED";
    const unlockedLimit = learningAccessActive
      ? access.accessLevel === "FULL" ? courseLessons.length : access.halfPaymentLessonLimit
      : 0;
    const progress = await db.select().from(lessonProgress)
      .where(eq(lessonProgress.enrollmentId, enrollment.id))
      .orderBy(asc(lessonProgress.updatedAt));
    const completed = progress.filter((item) => item.progressPercent === 100);
    const progressByLesson = new Map(progress.map((item) => [item.lessonId, item.progressPercent]));
    const attempts = await db.select({ score: quizAttempts.scorePercent })
      .from(quizAttempts).innerJoin(quizzes, eq(quizAttempts.quizId, quizzes.id))
      .where(and(eq(quizAttempts.userId, user.id), eq(quizzes.courseId, enrollment.courseId)));
    const quizAverage = attempts.length
      ? Math.round(attempts.reduce((sum, item) => sum + item.score, 0) / attempts.length)
      : null;
    const lessonTitles = new Map(courseLessons.map((item) => [item.id, item.title]));
    const completedIds = new Set(completed.map((item) => item.lessonId));
    const lessonGate = await buildLessonGate(db, user.id, enrollment.courseId, access, courseLessons);
    const modules = sections.map((section) => {
      const moduleLessons = courseLessons.filter((lesson) => lesson.sectionId === section.id);
      const moduleCompleted = moduleLessons.filter((lesson) => completedIds.has(lesson.id)).length;
      return {
        title: section.title,
        totalLessons: moduleLessons.length,
        completedLessons: moduleCompleted,
        progressPercent: moduleLessons.length
          ? Math.round((moduleCompleted / moduleLessons.length) * 100)
          : 0,
        lessons: moduleLessons.map((lesson) => {
          const gate = lessonGate.byLessonId.get(lesson.id);
          return {
            id: lesson.id,
            title: lesson.title,
            locked: gate?.locked ?? true,
            lockReason: gate?.reason ?? null,
            qaPassed: gate?.qaPassed ?? false,
            progressPercent: progressByLesson.get(lesson.id) ?? 0
          };
        })
      };
    });
    const recentActivity = [...progress].reverse().slice(0, 3).map((item) => ({
      title: lessonTitles.get(item.lessonId) ?? "Course lesson",
      detail: item.progressPercent === 100 ? "Completed" : `${item.progressPercent}% watched`
    }));

    response.json({
      enrollmentStatus: enrollment.status,
      enrollmentId: enrollment.id,
      courseTitle: enrollment.courseTitle,
      totalLessons: courseLessons.length,
      completedLessons: completed.length,
      progressPercent: courseLessons.length
        ? Math.round((completed.length / courseLessons.length) * 100)
        : 0,
      quizAverage,
      accountNumber: account ? `${account.prefix}${account.numericPart}` : null,
      accountStatus: account?.status ?? null,
      accessLevel: access.accessLevel,
      halfPaymentLessonLimit: access.halfPaymentLessonLimit,
      unlockedLessons: unlockedLimit,
      dailyLessonLimit: lessonGate.dailyLimit,
      lessonsPassedToday: lessonGate.passedToday,
      lessonsRemainingToday: lessonGate.remainingToday,
      allVideosUnlocked: lessonGate.allVideosUnlocked,
      modules,
      recentActivity
    });
  })
);

courseRouter.get(
  "/student/lessons/:id",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const lessonId = String(request.params.id);
    const [record] = await db
      .select({
        enrollmentId: enrollments.id,
        enrollmentStatus: enrollments.status,
        courseId: courses.id,
        courseTitle: courses.title,
        moduleId: courseSections.id,
        moduleTitle: courseSections.title,
        lessonId: lessons.id,
        lessonTitle: lessons.title,
        videoProvider: lessons.videoProvider,
        videoId: lessons.videoId,
        content: lessons.content,
        durationSeconds: lessons.durationSeconds
      })
      .from(lessons)
      .innerJoin(courseSections, eq(lessons.sectionId, courseSections.id))
      .innerJoin(courses, eq(courseSections.courseId, courses.id))
      .innerJoin(
        enrollments,
        and(eq(enrollments.courseId, courses.id), eq(enrollments.userId, user.id))
      )
      .where(
        and(
          eq(lessons.id, lessonId),
          inArray(enrollments.status, ["ACTIVE", "COMPLETED"])
        )
      )
      .limit(1);

    if (!record) throw new HttpError(404, "Active course lesson එක හමු නොවුණා.");

    const access = await courseAccess(db, user.id, record.courseId);
    const sections = await db
      .select({ id: courseSections.id, position: courseSections.position })
      .from(courseSections)
      .where(eq(courseSections.courseId, record.courseId))
      .orderBy(asc(courseSections.position));
    const sectionOrder = new Map(sections.map((section, index) => [section.id, index]));
    const orderedLessons = sections.length
      ? await db
          .select({ id: lessons.id, sectionId: lessons.sectionId, position: lessons.position })
          .from(lessons)
          .where(inArray(lessons.sectionId, sections.map((section) => section.id)))
          .orderBy(asc(lessons.position))
      : [];
    orderedLessons.sort((a, b) =>
      (sectionOrder.get(a.sectionId) ?? 0) - (sectionOrder.get(b.sectionId) ?? 0) ||
      a.position - b.position
    );
    const lessonIndex = orderedLessons.findIndex((item) => item.id === record.lessonId);
    if (lessonIndex < 0) throw new HttpError(404, "Lesson එක course එක තුළ හමු නොවුණා.");
    const lessonGate = await buildLessonGate(db, user.id, record.courseId, access, orderedLessons);
    if (!lessonGate.allVideosUnlocked && access.accessLevel === "HALF" && lessonIndex >= access.halfPaymentLessonLimit) {
      throw new HttpError(403, "Balance payment approval is required to unlock this lesson.");
    }
    const gate = lessonGate.byLessonId.get(record.lessonId);
    if (gate?.locked) {
      if (gate.reason === "DAILY_LIMIT") {
        throw new HttpError(403, "අද දින videos 3 සීමාව සම්පූර්ණයි. ඊළඟ lesson එක හෙට unlock වේ.");
      }
      if (gate.reason === "PREVIOUS_QA") {
        throw new HttpError(403, "කලින් lesson එක සම්පූර්ණ කර Q & A එකෙන් 75% හෝ වැඩි score එකක් ගත් පසු මේ lesson එක unlock වේ.");
      }
      throw new HttpError(403, "Balance payment approval is required to unlock this lesson.");
    }

    const [progress] = await db
      .select({
        progressPercent: lessonProgress.progressPercent,
        watchedSeconds: lessonProgress.watchedSeconds,
        resumeSeconds: lessonProgress.resumeSeconds,
        detectedDurationSeconds: lessonProgress.detectedDurationSeconds
      })
      .from(lessonProgress)
      .where(
        and(
          eq(lessonProgress.enrollmentId, record.enrollmentId),
          eq(lessonProgress.lessonId, record.lessonId)
        )
      )
      .limit(1);

    response.json({
      enrollmentId: record.enrollmentId,
      accessLevel: access.accessLevel,
      lesson: {
        id: record.lessonId,
        title: record.lessonTitle,
        moduleTitle: record.moduleTitle,
        courseTitle: record.courseTitle,
        videoProvider: record.videoProvider,
        videoId: record.videoId,
        content: record.content,
        durationSeconds: record.durationSeconds || progress?.detectedDurationSeconds || 0,
        watchedSeconds: progress?.watchedSeconds ?? 0,
        resumeSeconds: progress?.resumeSeconds ?? 0,
        progressPercent: progress?.progressPercent ?? 0
      }
    });
  })
);

courseRouter.post(
  "/student/progress",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = progressInput.parse(request.body);
    const db = requireDatabase();

    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(
        and(
          eq(enrollments.id, input.enrollmentId),
          eq(enrollments.userId, user.id),
          inArray(enrollments.status, ["ACTIVE", "COMPLETED"])
        )
      )
      .limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }

    const [lesson] = await db
      .select({
        id: lessons.id,
        courseId: courseSections.courseId,
        durationSeconds: lessons.durationSeconds
      })
      .from(lessons)
      .innerJoin(courseSections, eq(lessons.sectionId, courseSections.id))
      .where(eq(lessons.id, input.lessonId))
      .limit(1);
    if (!lesson || lesson.courseId !== enrollment.courseId) {
      response.status(400).json({ message: "Lesson is not in this course." });
      return;
    }

    const access = await courseAccess(db, user.id, enrollment.courseId);
    const sections = await db
      .select({ id: courseSections.id, position: courseSections.position })
      .from(courseSections)
      .where(eq(courseSections.courseId, enrollment.courseId))
      .orderBy(asc(courseSections.position));
    const sectionOrder = new Map(sections.map((section, index) => [section.id, index]));
    const unorderedLessons = sections.length
      ? await db
          .select({ id: lessons.id, sectionId: lessons.sectionId, position: lessons.position })
          .from(lessons)
          .where(inArray(lessons.sectionId, sections.map((section) => section.id)))
          .orderBy(asc(lessons.position))
      : [];
    const orderedLessons = [...unorderedLessons].sort((a, b) =>
      (sectionOrder.get(a.sectionId) ?? 0) - (sectionOrder.get(b.sectionId) ?? 0) ||
      a.position - b.position
    );
    const lessonIndex = orderedLessons.findIndex((item) => item.id === input.lessonId);
    if (lessonIndex < 0) throw new HttpError(404, "Lesson එක course එක තුළ හමු නොවුණා.");
    const lessonGate = await buildLessonGate(db, user.id, enrollment.courseId, access, orderedLessons);
    if (!lessonGate.allVideosUnlocked && access.accessLevel === "HALF" && lessonIndex >= access.halfPaymentLessonLimit) {
      throw new HttpError(403, "Balance payment approval is required to unlock this lesson.");
    }
    const gate = lessonGate.byLessonId.get(input.lessonId);
    if (gate?.locked) {
      if (gate.reason === "DAILY_LIMIT") {
        throw new HttpError(403, "අද දින videos 3 සීමාව සම්පූර්ණයි. ඊළඟ lesson එක හෙට unlock වේ.");
      }
      if (gate.reason === "PREVIOUS_QA") {
        throw new HttpError(403, "කලින් lesson එකේ Q & A එකෙන් 75% හෝ වැඩි score එකක් ගත් පසු මේ lesson එක unlock වේ.");
      }
      throw new HttpError(403, "Balance payment approval is required to unlock this lesson.");
    }

    let effectiveDurationSeconds = lesson.durationSeconds > 0
      ? lesson.durationSeconds
      : input.durationSeconds;

    if (lesson.durationSeconds <= 0) {
      const [updatedLesson] = await db
        .update(lessons)
        .set({ durationSeconds: input.durationSeconds })
        .where(eq(lessons.id, lesson.id))
        .returning({ durationSeconds: lessons.durationSeconds });
      effectiveDurationSeconds = updatedLesson?.durationSeconds ?? input.durationSeconds;
    }

    const [current] = await db
      .select()
      .from(lessonProgress)
      .where(
        and(
          eq(lessonProgress.enrollmentId, input.enrollmentId),
          eq(lessonProgress.lessonId, input.lessonId)
        )
      )
      .limit(1);

    const now = new Date();
    const elapsedWallSeconds = current?.lastHeartbeatAt
      ? Math.max(0, Math.floor((now.getTime() - current.lastHeartbeatAt.getTime()) / 1000))
      : input.elapsedSeconds;
    const acceptedSeconds = current?.progressPercent === 100
      ? 0
      : Math.min(input.elapsedSeconds, Math.max(0, elapsedWallSeconds + 2));
    const restoredWatchedSeconds = current
      ? Math.max(
          current.watchedSeconds,
          Math.floor((current.progressPercent / 100) * effectiveDurationSeconds)
        )
      : 0;
    const watchedSeconds = Math.min(
      effectiveDurationSeconds,
      restoredWatchedSeconds + acceptedSeconds
    );
    const completed = current?.progressPercent === 100 ||
      watchedSeconds >= Math.max(1, effectiveDurationSeconds - 2);
    const progressPercent = completed
      ? 100
      : Math.max(
          current?.progressPercent ?? 0,
          Math.min(99, Math.floor((watchedSeconds / effectiveDurationSeconds) * 100))
        );
    const completedAt = completed
      ? current?.completedAt ?? now
      : null;

    const [saved] = await db
      .insert(lessonProgress)
      .values({
        enrollmentId: input.enrollmentId,
        lessonId: input.lessonId,
        progressPercent,
        watchedSeconds,
        detectedDurationSeconds: effectiveDurationSeconds,
        lastHeartbeatAt: now,
        completedAt,
        updatedAt: now
      })
      .onConflictDoUpdate({
        target: [lessonProgress.enrollmentId, lessonProgress.lessonId],
        set: {
          progressPercent,
          watchedSeconds,
          detectedDurationSeconds: effectiveDurationSeconds,
          lastHeartbeatAt: now,
          completedAt,
          updatedAt: now
        }
      })
      .returning();

    const revisionUnlock = progressPercent >= 100
      ? await ensureRevisionEligibilityState(db, user.id)
      : null;
    response.json({
      progress: saved,
      acceptedSeconds,
      durationSeconds: effectiveDurationSeconds,
      revisionUnlock: revisionUnlock
        ? { newlyUnlocked: revisionUnlock.newlyUnlocked, eligible: revisionUnlock.eligibility.eligible }
        : null
    });
  })
);


// ADIL_RESUME_POSITION_V29
courseRouter.post(
  "/student/resume-position",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = resumePositionInput.parse(request.body);
    const db = requireDatabase();

    const [enrollment] = await db
      .select({ id: enrollments.id, courseId: enrollments.courseId })
      .from(enrollments)
      .where(and(
        eq(enrollments.id, input.enrollmentId),
        eq(enrollments.userId, user.id),
        inArray(enrollments.status, ["ACTIVE", "COMPLETED"])
      ))
      .limit(1);
    if (!enrollment) throw new HttpError(403, "Active enrollment required.");

    const [lesson] = await db
      .select({ id: lessons.id, courseId: courseSections.courseId, durationSeconds: lessons.durationSeconds })
      .from(lessons)
      .innerJoin(courseSections, eq(lessons.sectionId, courseSections.id))
      .where(eq(lessons.id, input.lessonId))
      .limit(1);
    if (!lesson || lesson.courseId !== enrollment.courseId) {
      throw new HttpError(400, "Lesson is not in this course.");
    }

    const duration = Math.max(0, lesson.durationSeconds || input.durationSeconds || 0);
    const safePosition = Math.max(0, Math.floor(
      duration > 0 ? Math.min(input.currentTimeSeconds, duration) : input.currentTimeSeconds
    ));
    const now = new Date();

    const [saved] = await db
      .insert(lessonProgress)
      .values({
        enrollmentId: input.enrollmentId,
        lessonId: input.lessonId,
        resumeSeconds: safePosition,
        detectedDurationSeconds: duration,
        updatedAt: now
      })
      .onConflictDoUpdate({
        target: [lessonProgress.enrollmentId, lessonProgress.lessonId],
        set: { resumeSeconds: safePosition, updatedAt: now }
      })
      .returning({ resumeSeconds: lessonProgress.resumeSeconds });

    response.json({ resumeSeconds: saved?.resumeSeconds ?? safePosition });
  })
);

courseRouter.get(
  "/student/quizzes/:id",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [quiz] = await db
      .select()
      .from(quizzes)
      .where(
        and(
          eq(quizzes.id, String(request.params.id)),
          eq(quizzes.isPublished, true)
        )
      )
      .limit(1);
    if (!quiz) {
      response.status(404).json({ message: "Quiz not found." });
      return;
    }
    const [enrollment] = await db
      .select({ id: enrollments.id })
      .from(enrollments)
      .where(
        and(
          eq(enrollments.userId, user.id),
          eq(enrollments.courseId, quiz.courseId),
          eq(enrollments.status, "ACTIVE")
        )
      )
      .limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }
    const questions = await db
      .select({
        id: quizQuestions.id,
        question: quizQuestions.question,
        options: quizQuestions.options,
        position: quizQuestions.position
      })
      .from(quizQuestions)
      .where(eq(quizQuestions.quizId, quiz.id))
      .orderBy(asc(quizQuestions.position));
    response.json({ quiz, questions });
  })
);

courseRouter.post(
  "/student/quizzes/:id/attempts",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = attemptInput.parse(request.body);
    const db = requireDatabase();
    const [quiz] = await db
      .select()
      .from(quizzes)
      .where(
        and(
          eq(quizzes.id, String(request.params.id)),
          eq(quizzes.isPublished, true)
        )
      )
      .limit(1);
    if (!quiz) {
      response.status(404).json({ message: "Quiz not found." });
      return;
    }
    const [enrollment] = await db
      .select({ id: enrollments.id })
      .from(enrollments)
      .where(
        and(
          eq(enrollments.userId, user.id),
          eq(enrollments.courseId, quiz.courseId),
          eq(enrollments.status, "ACTIVE")
        )
      )
      .limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }
    const questions = await db
      .select()
      .from(quizQuestions)
      .where(eq(quizQuestions.quizId, quiz.id))
      .orderBy(asc(quizQuestions.position));
    if (questions.length === 0 || input.answers.length !== questions.length) {
      response.status(400).json({ message: "Answer every quiz question." });
      return;
    }
    const correct = questions.reduce(
      (total, question, index) =>
        total + (input.answers[index] === question.correctOption ? 1 : 0),
      0
    );
    const scorePercent = Math.round((correct / questions.length) * 100);
    const passed = scorePercent >= quiz.passingPercent;
    const [attempt] = await db
      .insert(quizAttempts)
      .values({
        quizId: quiz.id,
        userId: user.id,
        answers: input.answers,
        scorePercent,
        passed
      })
      .returning();
    response.status(201).json({
      attempt,
      explanations: questions.map((question) => ({
        questionId: question.id,
        correctOption: question.correctOption,
        explanation: question.explanation
      }))
    });
  })
);

courseRouter.post(
  "/admin/quizzes",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = quizInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(quizzes).values(input).returning();
    response.status(201).json({ quiz: created });
  })
);

courseRouter.post(
  "/admin/quiz-questions",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = questionInput.parse(request.body);
    if (input.correctOption >= input.options.length) {
      response.status(400).json({ message: "Correct option is out of range." });
      return;
    }
    const db = requireDatabase();
    const [created] = await db
      .insert(quizQuestions)
      .values(input)
      .returning();
    response.status(201).json({ question: created });
  })
);

courseRouter.post(
  "/admin/courses",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = courseInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db
      .insert(courses)
      .values({
        ...input,
        price: input.price.toFixed(2)
      })
      .returning();
    response.status(201).json({ course: created });
  })
);

const adminVideoUnlockInput = z.object({
  userId: z.string().uuid(),
  courseId: z.string().uuid(),
  unlocked: z.boolean()
});

courseRouter.get(
  "/admin/video-unlock/search",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const sr = String(request.query.sr ?? "").trim().toUpperCase().replace(/\s+/g, "");
    if (!/^SR\d+$/.test(sr)) throw new HttpError(400, "Valid SR number එකක් type කරන්න. උදා: SR527694");
    const numericPart = Number(sr.slice(2));

    const [student] = await db
      .select({
        userId: users.id,
        name: users.displayName,
        email: users.email,
        phone: users.phone,
        isActive: users.isActive,
        accountStatus: networkAccounts.status
      })
      .from(networkAccounts)
      .innerJoin(users, eq(users.id, networkAccounts.ownerUserId))
      .where(and(
        eq(networkAccounts.prefix, "SR"),
        eq(networkAccounts.numericPart, numericPart),
        eq(networkAccounts.isMainAccount, true)
      ))
      .limit(1);

    if (!student) throw new HttpError(404, "මෙම SR number එකට student account එකක් හමු නොවීය.");

    const enrollmentRows = await db
      .select({
        courseId: courses.id,
        courseTitle: courses.title,
        enrollmentStatus: enrollments.status
      })
      .from(enrollments)
      .innerJoin(courses, eq(courses.id, enrollments.courseId))
      .where(eq(enrollments.userId, student.userId))
      .orderBy(asc(enrollments.enrolledAt));

    const overrideRows = await db
      .select({ courseId: videoAccessOverrides.courseId, unlockAllVideos: videoAccessOverrides.unlockAllVideos })
      .from(videoAccessOverrides)
      .where(eq(videoAccessOverrides.userId, student.userId));
    const overrideByCourse = new Map(overrideRows.map((item) => [item.courseId, item.unlockAllVideos]));

    response.json({
      student: {
        ...student,
        accountNumber: sr,
        enrollments: enrollmentRows.map((item) => ({
          ...item,
          allVideosUnlocked: overrideByCourse.get(item.courseId) === true
        }))
      }
    });
  })
);

courseRouter.post(
  "/admin/video-unlock",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = adminVideoUnlockInput.parse(request.body);
    const db = requireDatabase();

    const [enrollment] = await db
      .select({ id: enrollments.id })
      .from(enrollments)
      .where(and(eq(enrollments.userId, input.userId), eq(enrollments.courseId, input.courseId)))
      .limit(1);
    if (!enrollment) throw new HttpError(404, "Studentට මෙම course enrollment එකක් නැහැ.");

    const [account] = await db
      .select({ numericPart: networkAccounts.numericPart })
      .from(networkAccounts)
      .where(and(
        eq(networkAccounts.ownerUserId, input.userId),
        eq(networkAccounts.prefix, "SR"),
        eq(networkAccounts.isMainAccount, true)
      ))
      .limit(1);
    if (!account) throw new HttpError(404, "Student SR account එක හමු නොවීය.");

    await db
      .insert(videoAccessOverrides)
      .values({
        userId: input.userId,
        courseId: input.courseId,
        unlockAllVideos: input.unlocked,
        grantedBy: admin.id,
        updatedAt: new Date()
      })
      .onConflictDoUpdate({
        target: [videoAccessOverrides.userId, videoAccessOverrides.courseId],
        set: {
          unlockAllVideos: input.unlocked,
          grantedBy: admin.id,
          updatedAt: new Date()
        }
      });

    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: input.unlocked ? "ALL_VIDEOS_UNLOCKED" : "VIDEO_LIMITS_RESTORED",
      entityType: "STUDENT_COURSE_ACCESS",
      entityId: input.userId,
      metadata: { courseId: input.courseId, accountNumber: "SR" + account.numericPart, unlocked: input.unlocked }
    });

    response.json({
      success: true,
      unlocked: input.unlocked,
      message: input.unlocked
        ? "මෙම studentට සියලු videos unlock කළා."
        : "මෙම studentට normal Daily 3 + Q & A unlock rules නැවත enable කළා."
    });
  })
);

courseRouter.get(
  "/admin/courses",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const courseItems = await db.select().from(courses).orderBy(asc(courses.createdAt));
    const result = await Promise.all(courseItems.map(async (course) => {
      const sections = await db.select().from(courseSections)
        .where(eq(courseSections.courseId, course.id)).orderBy(asc(courseSections.position));
      const sectionIds = sections.map((section) => section.id);
      const lessonItems = sectionIds.length ? await db.select().from(lessons)
        .where(inArray(lessons.sectionId, sectionIds)).orderBy(asc(lessons.position)) : [];
      return { ...course, sections: sections.map((section) => ({
        ...section,
        lessons: lessonItems.filter((lesson) => lesson.sectionId === section.id)
      })) };
    }));
    response.json({ courses: result });
  })
);

courseRouter.patch(
  "/admin/courses/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const input = courseUpdateInput.parse(request.body);
    const db = requireDatabase();
    const { price, ...courseChanges } = input;
    const [course] = await db.update(courses).set({
      ...courseChanges,
      ...(price !== undefined ? { price: price.toFixed(2) } : {}),
      updatedAt: new Date()
    }).where(eq(courses.id, String(request.params.id))).returning();
    if (!course) { response.status(404).json({ message: "Course not found." }); return; }
    response.json({ course });
  })
);

courseRouter.put(
  "/admin/courses/:id/thumbnail",
  express.raw({ type: ["image/jpeg", "image/png", "image/webp"], limit: "5mb" }),
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    if (!Buffer.isBuffer(request.body) || request.body.length < 10) {
      response.status(400).json({ message: "Course cover image එකක් තෝරන්න." }); return;
    }
    const db = requireDatabase();
    const [existing] = await db.select({ id: courses.id, previousKey: courses.thumbnailUrl }).from(courses)
      .where(eq(courses.id, String(request.params.id))).limit(1);
    if (!existing) { response.status(404).json({ message: "Course not found." }); return; }
    const mime = request.headers["content-type"] ?? "image/jpeg";
    const extension = mime.includes("png") ? "png" : mime.includes("webp") ? "webp" : "jpg";
    const key = `course-thumbnails/${existing.id}-${crypto.randomBytes(6).toString("hex")}.${extension}`;
    await uploadPrivateFile(key, request.body);
    await db.update(courses).set({ thumbnailUrl: key, updatedAt: new Date() }).where(eq(courses.id, existing.id));
    if (existing.previousKey && existing.previousKey !== key) {
      deletePrivateFile(existing.previousKey).catch((error) => console.warn("Old course cover cleanup failed", error));
    }
    response.json({ thumbnailUrl: `/api/courses/${existing.id}/thumbnail?v=${Date.now()}` });
  })
);

courseRouter.delete(
  "/admin/courses/:id/thumbnail",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const [existing] = await db.select({ id: courses.id, key: courses.thumbnailUrl }).from(courses)
      .where(eq(courses.id, String(request.params.id))).limit(1);
    if (!existing) { response.status(404).json({ message: "Course not found." }); return; }

    await db.update(courses).set({ thumbnailUrl: null, updatedAt: new Date() }).where(eq(courses.id, existing.id));
    if (existing.key) {
      deletePrivateFile(existing.key).catch((error) => console.warn("Course cover file cleanup failed", error));
    }
    response.json({ message: "Course cover photo removed.", thumbnailUrl: null });
  })
);

courseRouter.post(
  "/admin/course-sections",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = sectionInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db
      .insert(courseSections)
      .values(input)
      .returning();
    response.status(201).json({ section: created });
  })
);

courseRouter.delete(
  "/admin/course-sections/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const sectionId = String(request.params.id);

    const [existing] = await db
      .select({ id: courseSections.id })
      .from(courseSections)
      .where(eq(courseSections.id, sectionId))
      .limit(1);

    if (!existing) {
      response.status(404).json({ message: "Module not found." });
      return;
    }

    const resources = await db
      .select({ resourceObjectKey: lessons.resourceObjectKey })
      .from(lessons)
      .where(eq(lessons.sectionId, sectionId));

    await db
      .delete(courseSections)
      .where(eq(courseSections.id, sectionId));

    for (const item of resources) {
      if (item.resourceObjectKey) {
        deletePrivateFile(item.resourceObjectKey).catch((error) =>
          console.warn("Module lesson resource cleanup failed", error)
        );
      }
    }

    response.json({
      success: true,
      message: "Module permanently deleted."
    });
  })
);

courseRouter.post(
  "/admin/lessons",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = lessonInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(lessons).values(input).returning();
    response.status(201).json({ lesson: created });
  })
);

courseRouter.patch(
  "/admin/course-sections/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = sectionUpdateInput.parse(request.body);
    const db = requireDatabase();
    const [section] = await db.update(courseSections).set(input)
      .where(eq(courseSections.id, String(request.params.id))).returning();
    if (!section) { response.status(404).json({ message: "Section not found." }); return; }
    response.json({ section });
  })
);

courseRouter.patch(
  "/admin/lessons/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = lessonUpdateInput.parse(request.body);
    const db = requireDatabase();
    const [lesson] = await db.update(lessons).set(input)
      .where(eq(lessons.id, String(request.params.id))).returning();
    if (!lesson) { response.status(404).json({ message: "Lesson not found." }); return; }
    response.json({ lesson });
  })
);

courseRouter.delete(
  "/admin/lessons/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const lessonId = String(request.params.id);

    const [existing] = await db
      .select({
        id: lessons.id,
        sectionId: lessons.sectionId,
        resourceObjectKey: lessons.resourceObjectKey
      })
      .from(lessons)
      .where(eq(lessons.id, lessonId))
      .limit(1);

    if (!existing) {
      response.status(404).json({ message: "Lesson not found." });
      return;
    }

    const [deleted] = await db
      .delete(lessons)
      .where(eq(lessons.id, lessonId))
      .returning();

    if (existing.resourceObjectKey) {
      deletePrivateFile(existing.resourceObjectKey).catch((error) =>
        console.warn("Lesson resource cleanup failed", error)
      );
    }

    const [remainingLesson] = await db
      .select({ id: lessons.id })
      .from(lessons)
      .where(eq(lessons.sectionId, existing.sectionId))
      .limit(1);

    let removedEmptyModule = false;

    if (!remainingLesson) {
      await db
        .delete(courseSections)
        .where(eq(courseSections.id, existing.sectionId));

      removedEmptyModule = true;
    }

    response.json({
      success: true,
      message: removedEmptyModule
        ? "Lesson and empty module permanently deleted."
        : "Lesson permanently deleted.",
      lesson: deleted,
      removedEmptyModule
    });
  })
);

