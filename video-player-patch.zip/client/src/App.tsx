import {
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type ReactNode
} from "react";
import {
  ArrowRight,
  Award,
  BarChart3,
  Bell,
  Camera,
  BookOpen,
  Check,
  ChevronRight,
  CircleDollarSign,
  CreditCard,
  GraduationCap,
  LayoutDashboard,
  Eye,
  EyeOff,
  LockKeyhole,
  LogOut,
  Menu,
  MessageCircle,
  Bot,
  Headphones,
  Send,
  Moon,
  Network,
  Play,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Sun,
  TrendingUp,
  Target,
  Trophy,
  UserCheck,
  Users,
  Wallet,
  X
} from "lucide-react";
import {
  Link,
  Navigate,
  Route,
  Routes,
  useNavigate
} from "react-router-dom";
import type {
  DemoUser,
  PlatformOverview,
  StudentDashboardSummary,
  UserRole
} from "../../shared/platform";
import { sriLankaLocations, sriLankaProvinces } from "./sri-lanka-locations";

const courseModules = [
  {
    number: "01",
    title: "Crypto Foundations",
    text: "Blockchain, wallets, exchanges සහ Binance account security."
  },
  {
    number: "02",
    title: "Spot Trading",
    text: "Market orders, limit orders සහ disciplined trade execution."
  },
  {
    number: "03",
    title: "Technical Analysis",
    text: "Market structure, candlesticks, indicators සහ entry planning."
  },
  {
    number: "04",
    title: "Risk Management",
    text: "Position sizing, stop loss සහ capital protection systems."
  },
  {
    number: "05",
    title: "Futures Trading",
    text: "Leverage, margin, liquidation සහ controlled futures strategies."
  },
  {
    number: "06",
    title: "Trading Psychology",
    text: "Consistency, journal keeping සහ professional decision making."
  }
];

const defaultOverview: PlatformOverview = {
  course: {
    title: "Crypto Trading — Zero to Pro",
    language: "සිංහල",
    modules: 6,
    access: "Lifetime course access"
  },
  features: [],
  paymentMethods: ["Bank Transfer", "Binance Pay / USDT"]
};

function extractVideoId(provider: string | null | undefined, rawValue: string | null | undefined) {
  const value = rawValue?.trim();
  if (!value) return "";
  const normalizedProvider = provider === "vimeo" ? "vimeo" : "youtube";
  const candidate = /^https?:\/\//i.test(value) ? value : value.includes(".") ? `https://${value}` : "";

  if (candidate) {
    try {
      const url = new URL(candidate);
      const host = url.hostname.toLowerCase().replace(/^www\./, "");
      const parts = url.pathname.split("/").filter(Boolean);
      if (normalizedProvider === "vimeo" || host.endsWith("vimeo.com")) {
        const id = [...parts].reverse().find((part) => /^\d+$/.test(part));
        if (id) return id;
      }
      if (host === "youtu.be") return parts[0] ?? "";
      if (host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com")) {
        if (url.pathname === "/watch") return url.searchParams.get("v") ?? "";
        const markerIndex = parts.findIndex((part) => ["embed", "shorts", "live"].includes(part));
        if (markerIndex >= 0) return parts[markerIndex + 1] ?? "";
      }
    } catch {
      return "";
    }
  }

  if (normalizedProvider === "vimeo") return /^\d+$/.test(value) ? value : "";
  return /^[A-Za-z0-9_-]{6,}$/.test(value) ? value : "";
}

function buildVideoEmbedUrl(provider: string | null | undefined, rawValue: string | null | undefined) {
  const id = extractVideoId(provider, rawValue);
  if (!id) return "";
  return provider === "vimeo"
    ? `https://player.vimeo.com/video/${encodeURIComponent(id)}`
    : `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?rel=0`;
}

function Logo() {
  return (
    <Link className="brand" to="/" aria-label="Adil Academy home">
      <span className="brand-mark">
        <span>A</span>
      </span>
      <span className="brand-copy">
        <strong>ADIL</strong>
        <small>ACADEMY</small>
      </span>
    </Link>
  );
}

function PublicHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="public-header">
      <div className="nav-shell">
        <Logo />
        <button
          className="menu-button"
          type="button"
          aria-label="Toggle menu"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
        <nav className={open ? "nav-links nav-open" : "nav-links"}>
          <a href="#course" onClick={() => setOpen(false)}>
            පාඨමාලාව
          </a>
          <a href="#platform" onClick={() => setOpen(false)}>
            වේදිකාව
          </a>
          <Link to="/login" className="nav-login" onClick={() => setOpen(false)}>
            Login
          </Link>
          <Link
            to="/login"
            className="button button-small"
            onClick={() => setOpen(false)}
          >
            දැන් ආරම්භ කරන්න
          </Link>
        </nav>
      </div>
    </header>
  );
}

type PublicCourseDetail = {
  course: { title: string; shortDescription: string; price: string; currency: string; language: string };
  enrolledStudents: number;
  sections: Array<{ id: string; title: string; lessons: Array<{ id: string; title: string }> }>;
};
type PublicCourseCard = { id: string; slug: string; title: string; shortDescription: string; price: string; currency: string; thumbnailUrl: string | null };

function HeroCourseCard({ detail }: { detail: PublicCourseDetail | null }) {
  return (
    <div className="hero-preview" aria-label="Course enrollment information">
      <div className="preview-glow" />
      <div className="preview-top">
        <div>
          <span className="eyebrow">ADIL ACADEMY COURSE</span>
          <h3>{detail?.course.title ?? "Crypto Trading — Zero to Pro"}</h3>
        </div>
        <span className="avatar"><GraduationCap size={20} /></span>
      </div>
      <div className="progress-card">
        <div className="progress-card-copy">
          <span>LEARN • GROW • ACHIEVE</span>
          <strong>ඉලක්කයක් ඇතිව ආරම්භ කරන්න. විනයෙන් ඉදිරියට යන්න. ඔබේ හොඳම අනුවාදය ගොඩනගන්න.</strong>
        </div>
        <Link to="/login" className="continue-button"><ArrowRight size={15} /> දැන් ලියාපදිංචි වන්න</Link>
      </div>
      <div className="preview-stats">
        <div>
          <Users size={19} /><span>Enrolled students</span><strong>{detail?.enrolledStudents ?? 0}</strong>
        </div>
        <div>
          <ShieldCheck size={19} /><span>Student portal</span><strong>Secure</strong>
        </div>
        <div>
          <Award size={19} /><span>Learning</span><strong>Progress tracked</strong>
        </div>
      </div>
    </div>
  );
}

function LegacyTradingHomePage() {
  const [overview, setOverview] =
    useState<PlatformOverview>(defaultOverview);
  const [courseDetail, setCourseDetail] = useState<PublicCourseDetail | null>(null);
  const [publicCourses, setPublicCourses] = useState<PublicCourseCard[]>([]);

  useEffect(() => {
    fetch("/api/public/overview")
      .then((response) => response.json())
      .then(setOverview)
      .catch(() => undefined);
    fetch("/api/courses/crypto-trading-zero-to-pro-sinhala")
      .then((response) => response.ok ? response.json() : null)
      .then((data) => setCourseDetail(data as PublicCourseDetail | null))
      .catch(() => undefined);
    fetch("/api/courses").then((response) => response.ok ? response.json() : { courses: [] })
      .then((data: { courses?: PublicCourseCard[] }) => setPublicCourses(data.courses ?? []))
      .catch(() => undefined);
  }, []);

  return (
    <div className="site">
      <PublicHeader />
      <main>
        <section className="hero">
          <div className="hero-grid" />
          <div className="hero-orb hero-orb-one" />
          <div className="hero-orb hero-orb-two" />
          <div className="section-shell hero-layout">
            <div className="hero-copy">
              <span className="pill">
                <Sparkles size={15} />
                SRI LANKA'S SINHALA CRYPTO LEARNING PLATFORM
              </span>
              <h1>
                Trade කරන්න කලින්
                <span>හරියට ඉගෙනගන්න.</span>
              </h1>
              <p>
                Crypto Trading ගැන කිසිම දැනුමක් නැති තැනින්, disciplined
                trader කෙනෙක් දක්වා යන සම්පූර්ණ learning path එක සරල
                සිංහලෙන්.
              </p>
              <div className="hero-actions">
                <Link to="/login" className="button button-primary">
                  Admission Form
                  <ArrowRight size={18} />
                </Link>
                <Link to="/cco-main" className="button button-ghost">
                  <UserCheck size={17} />
                  CCO Main Account
                </Link>
                <a className="button button-ghost" href="#course">
                  <BookOpen size={17} />
                  Course Details
                </a>
              </div>
              <div className="trust-row">
                <span>
                  <Check size={15} /> Sinhala-first learning
                </span>
                <span>
                  <Check size={15} /> {overview.course.language}
                </span>
                <span>
                  <Check size={15} /> {overview.course.access}
                </span>
              </div>
            </div>
            <HeroCourseCard detail={courseDetail} />
          </div>
        </section>

        <section className="proof-strip">
          <div className="section-shell proof-grid">
            <div>
              <strong>Zero → Pro</strong>
              <span>Structured learning path</span>
            </div>
            <div>
              <strong>Secure</strong>
              <span>Paid student access</span>
            </div>
            <div>
              <strong>24/7</strong>
              <span>Student dashboard access</span>
            </div>
            <div>
              <strong>100%</strong>
              <span>Sinhala explanations</span>
            </div>
          </div>
        </section>

        <section className="section public-course-catalog" id="available-courses">
          <div className="section-shell">
            <div className="section-heading">
              <span className="eyebrow">ADIL ACADEMY COURSES</span>
              <h2>ඔබට ගැළපෙන පාඨමාලාව තෝරන්න.</h2>
              <p>Admin panel එකෙන් publish කරන සියලුම පාඨමාලා මෙහි පෙන්වයි.</p>
            </div>
            <div className="public-course-grid">
              {publicCourses.map((item) => <article className="public-course-card" key={item.id}>
                <div className="public-course-cover">{item.thumbnailUrl ? <img src={`/api/courses/${item.id}/thumbnail`} alt={`${item.title} course cover`} /> : <BookOpen size={38} />}</div>
                <div className="public-course-body"><span className="eyebrow">ONLINE COURSE</span><h3>{item.title}</h3><p>{item.shortDescription}</p><div><strong>{item.currency} {Number(item.price).toLocaleString()}</strong><Link to="/login" className="button button-primary">Apply now <ArrowRight size={16} /></Link></div></div>
              </article>)}
              {!publicCourses.length && <p className="catalog-empty">Published courses loading...</p>}
            </div>
          </div>
        </section>

        <section className="section course-section" id="course">
          <div className="section-shell">
            <div className="section-heading">
              <span className="eyebrow">COMPLETE LEARNING PATH</span>
              <h2>අනුමාන නොකර, පිළිවෙළට ඉගෙනගන්න.</h2>
              <p>
                Beginner knowledge සිට professional risk discipline දක්වා,
                අවශ්‍ය සෑම කොටසක්ම එක learning system එකකින්.
              </p>
            </div>
            <div className="module-grid">
              {courseModules.map((module) => (
                <article className="module-card" key={module.number}>
                  <span className="module-number">{module.number}</span>
                  <div className="module-icon">
                    {module.number === "01" && <GraduationCap />}
                    {module.number === "02" && <BarChart3 />}
                    {module.number === "03" && <TrendingUp />}
                    {module.number === "04" && <ShieldCheck />}
                    {module.number === "05" && <CircleDollarSign />}
                    {module.number === "06" && <Sparkles />}
                  </div>
                  <h3>{module.title}</h3>
                  <p>{module.text}</p>
                  <span className="card-link">
                    Module details <ChevronRight size={16} />
                  </span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section platform-section" id="platform">
          <div className="section-shell platform-layout">
            <div className="platform-copy">
              <span className="eyebrow">MORE THAN A VIDEO COURSE</span>
              <h2>ඔබේ සම්පූර්ණ learning journey එක එකම dashboard එකක.</h2>
              <p>
                Lessons බලන්න, progress track කරන්න, payments සහ certificates
                manage කරන්න—mobile හෝ desktop ඕනෑම device එකකින්.
              </p>
              <div className="feature-list">
                {[
                  "Secure student-only video lessons",
                  "Lesson progress සහ quiz tracking",
                  "Bank Transfer / Binance Pay verification",
                  "Completion certificates සහ notifications"
                ].map((feature) => (
                  <div key={feature}>
                    <span>
                      <Check size={16} />
                    </span>
                    {feature}
                  </div>
                ))}
              </div>
              <Link to="/login" className="text-link">
                Dashboard preview බලන්න <ArrowRight size={17} />
              </Link>
            </div>
            <div className="platform-panel">
              <div className="panel-sidebar">
                <Logo />
                <span className="active-line">
                  <LayoutDashboard size={17} /> Overview
                </span>
                <span>
                  <BookOpen size={17} /> My Course
                </span>
                <span>
                  <Award size={17} /> Certificates
                </span>
                <span>
                  <CreditCard size={17} /> Payments
                </span>
              </div>
              <div className="panel-main">
                <span className="mini-label">WEEKLY ACTIVITY</span>
                <div className="chart-bars">
                  {[34, 58, 43, 76, 61, 88, 72].map((height, index) => (
                    <span key={index} style={{ height: height + "%" }} />
                  ))}
                </div>
                <div className="panel-course-row">
                  <span className="course-play">
                    <Play size={16} fill="currentColor" />
                  </span>
                  <div>
                    <strong>Risk Management Formula</strong>
                    <span>Module 04 • Lesson 03</span>
                  </div>
                  <span className="course-time">18 min</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section cta-section">
          <div className="section-shell">
            <div className="cta-card">
              <div>
                <span className="eyebrow">START WITH KNOWLEDGE</span>
                <h2>ඔබේ Crypto learning journey එක අදම ආරම්භ කරන්න.</h2>
                <p>
                  Learn with structure. Trade with discipline. Protect your
                  capital.
                </p>
              </div>
              <Link to="/login" className="button button-light">
                Student Dashboard
                <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <footer className="site-footer">
        <div className="section-shell footer-grid">
          <div>
            <Logo />
            <p>
              සිංහලෙන් Crypto Trading ඉගෙනගන්න විශ්වාසදායක learning platform
              එක.
            </p>
          </div>
          <div>
            <strong>Platform</strong>
            <a href="#course">Course</a>
            <Link to="/login">Student Login</Link>
          </div>
          <div>
            <strong>Support</strong>
            <a href="#platform">How it works</a>
            <a href="#course">FAQ</a>
            <a href="mailto:support@adilacademy.com">Contact</a>
          </div>
          <div>
            <strong>Legal</strong>
            <span>Terms & Conditions</span>
            <span>Privacy Policy</span>
            <span>Risk Disclosure</span>
          </div>
        </div>
        <div className="section-shell footer-bottom">
          <span>© 2026 Adil Academy. All rights reserved.</span>
          <span>Education only. Trading profits are not guaranteed.</span>
        </div>
      </footer>
    </div>
  );
}

function formatCoursePrice(course: PublicCourseCard) {
  const amount = Number(course.price);
  if (!Number.isFinite(amount) || amount <= 0) return "Contact for pricing";
  return `${course.currency || "LKR"} ${amount.toLocaleString("en-LK")}`;
}

function AcademyPublicHeader() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="academy-public-header">
      <div className="section-shell academy-nav">
        <Link to="/" className="academy-brand" aria-label="Adil Academy home">
          <Logo />
        </Link>
        <button
          type="button"
          className="academy-menu-button"
          aria-label="Open navigation"
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((value) => !value)}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
        <nav className={menuOpen ? "academy-nav-links is-open" : "academy-nav-links"}>
          <a href="#available-courses" onClick={() => setMenuOpen(false)}>Courses</a>
          <a href="#why-adil" onClick={() => setMenuOpen(false)}>Why Adil</a>
          <a href="#how-it-works" onClick={() => setMenuOpen(false)}>How it works</a>
          <a href="#academy-faq" onClick={() => setMenuOpen(false)}>FAQ</a>
          <Link to="/login" onClick={() => setMenuOpen(false)}>Login</Link>
          <a className="button button-primary academy-nav-cta" href="#available-courses" onClick={() => setMenuOpen(false)}>
            Explore courses <ArrowRight size={17} />
          </a>
        </nav>
      </div>
    </header>
  );
}

function HomePage() {
  const [publicCourses, setPublicCourses] = useState<PublicCourseCard[]>([]);
  const [courseQuery, setCourseQuery] = useState("");
  const [coursesLoading, setCoursesLoading] = useState(true);
  const [selectedCourse, setSelectedCourse] = useState<PublicCourseCard | null>(null);

  useEffect(() => {
    fetch("/api/courses")
      .then((response) => response.ok ? response.json() : { courses: [] })
      .then((data: { courses?: PublicCourseCard[] }) => setPublicCourses(data.courses ?? []))
      .catch(() => setPublicCourses([]))
      .finally(() => setCoursesLoading(false));
  }, []);

  useEffect(() => {
    if (!selectedCourse) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedCourse(null);
    };
    document.body.classList.add("academy-modal-open");
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.classList.remove("academy-modal-open");
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [selectedCourse]);

  const normalizedQuery = courseQuery.trim().toLowerCase();
  const filteredCourses = publicCourses.filter((course) =>
    `${course.title} ${course.shortDescription}`.toLowerCase().includes(normalizedQuery)
  );
  const featuredCourses = publicCourses.slice(0, 3);

  return (
    <div className="academy-home">
      <AcademyPublicHeader />
      <main>
        <section className="academy-hero">
          <div className="academy-hero-glow academy-hero-glow-one" />
          <div className="academy-hero-glow academy-hero-glow-two" />
          <div className="section-shell academy-hero-shell">
            <div className="academy-hero-copy">
              <span className="academy-kicker">
                <Sparkles size={16} />
                LEARN • GROW • ACHIEVE
              </span>
              <h1 className="academy-hero-title">
                <span>Learn Today.</span>
                <span className="academy-hero-title-accent">Grow Every Day.</span>
                <span>Build Your Future.</span>
              </h1>
              <p>
                ඔබේ ඉලක්කයට ගැළපෙන පාඨමාලා සහ නිවැරදි මඟපෙන්වීම සමඟ
                සාර්ථක අනාගතයක් ගොඩනඟන්න.
              </p>
              <div className="academy-hero-actions">
                <a className="button button-primary" href="#available-courses">
                  පාඨමාලා බලන්න <ArrowRight size={18} />
                </a>
                <Link className="button button-secondary" to="/login">
                  <GraduationCap size={18} /> Student portal
                </Link>
              </div>
              <div className="academy-trust-row" aria-label="Platform benefits">
                <span><Check size={16} /> Structured learning</span>
                <span><ShieldCheck size={16} /> Secure access</span>
                <span><TrendingUp size={16} /> Progress tracking</span>
              </div>
            </div>

            <div className="academy-hub-card">
              <div className="academy-hub-orbit academy-hub-orbit-one" />
              <div className="academy-hub-orbit academy-hub-orbit-two" />
              <div className="academy-hub-header">
                <div>
                  <span>ADIL ACADEMY</span>
                  <h2>Explore Our Courses</h2>
                </div>
                <div className="academy-hub-icon"><BookOpen size={24} /></div>
              </div>
              <div className="academy-hub-list">
                {coursesLoading ? (
                  <div className="academy-hub-empty">Courses loading...</div>
                ) : featuredCourses.length ? featuredCourses.map((course, index) => (
                  <button
                    type="button"
                    className="academy-hub-course"
                    key={course.id}
                    onClick={() => setSelectedCourse(course)}
                  >
                    <span className="academy-hub-number">{String(index + 1).padStart(2, "0")}</span>
                    <span className="academy-hub-course-copy">
                      <strong>{course.title}</strong>
                      <small>{formatCoursePrice(course)}</small>
                    </span>
                    <ChevronRight size={18} />
                  </button>
                )) : (
                  <div className="academy-hub-empty">
                    <BookOpen size={25} />
                    New courses will appear here after publication.
                  </div>
                )}
              </div>
              <div className="academy-hub-footer">
                <span><span className="academy-live-dot" /> Learning platform online</span>
                {publicCourses.length > 0 && <strong>{publicCourses.length} course{publicCourses.length === 1 ? "" : "s"}</strong>}
              </div>
            </div>
          </div>
        </section>

        <section className="academy-section academy-courses-section" id="available-courses">
          <div className="section-shell academy-section-shell">
            <div className="academy-section-heading">
              <div>
                <span className="academy-eyebrow">COURSE CATALOG</span>
                <h2>ඔබට ගැළපෙන පාඨමාලාව සොයාගන්න</h2>
                <p>Admin විසින් publish කරන සියලු පාඨමාලා මෙහි ස්වයංක්‍රීයව පෙන්වයි.</p>
              </div>
              <label className="academy-course-search">
                <Search size={20} />
                <input
                  value={courseQuery}
                  onChange={(event) => setCourseQuery(event.target.value)}
                  placeholder="Course name හෝ subject එක search කරන්න"
                  aria-label="Search courses"
                />
              </label>
            </div>

            {coursesLoading ? (
              <div className="academy-empty-state">
                <BookOpen size={28} />
                <h3>Course catalog loading...</h3>
              </div>
            ) : filteredCourses.length ? (
              <div className="academy-course-grid">
                {filteredCourses.map((course) => (
                  <article className="academy-course-card" key={course.id}>
                    <div className="academy-course-image">
                      {course.thumbnailUrl ? (
                        <img src={course.thumbnailUrl} alt="" />
                      ) : (
                        <div className="academy-course-placeholder"><GraduationCap size={42} /></div>
                      )}
                      <span>Adil Academy course</span>
                    </div>
                    <div className="academy-course-body">
                      <div className="academy-course-title-row">
                        <h3>{course.title}</h3>
                        <span className="academy-course-icon"><BookOpen size={18} /></span>
                      </div>
                      <p>{course.shortDescription || "A structured Adil Academy learning experience."}</p>
                      <div className="academy-course-meta">
                        <span>Course fee</span>
                        <strong>{formatCoursePrice(course)}</strong>
                      </div>
                      <div className="academy-course-actions">
                        <button type="button" className="button button-secondary" onClick={() => setSelectedCourse(course)}>
                          Course details
                        </button>
                        <Link className="button button-primary" to="/login">
                          Apply now <ArrowRight size={17} />
                        </Link>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <div className="academy-empty-state">
                <Search size={28} />
                <h3>{publicCourses.length ? "Matching course එකක් හමු නොවීය." : "Published courses තවම නැහැ."}</h3>
                <p>{publicCourses.length ? "වෙනත් course name එකක් search කරන්න." : "Admin panel එකෙන් publish කළ පසු courses මෙහි පෙන්වයි."}</p>
              </div>
            )}
          </div>
        </section>

        <section className="academy-section academy-benefits-section" id="why-adil">
          <div className="section-shell academy-section-shell">
            <div className="academy-section-heading academy-section-heading-centered">
              <div>
                <span className="academy-eyebrow">WHY ADIL ACADEMY</span>
                <h2>ඉගෙනීම පැහැදිලි, ආරක්ෂිත සහ ඉලක්කගත කරමු</h2>
                <p>Course එකක් මිලදී ගැනීමේ සිට completion දක්වා එකම professional experience එකක්.</p>
              </div>
            </div>
            <div className="academy-benefits-grid">
              <article className="academy-benefit-card">
                <div><Target size={23} /></div>
                <span>01</span>
                <h3>Goal-focused learning</h3>
                <p>සෑම පාඨමාලාවක්ම පැහැදිලි learning path එකක් සහ measurable progress එකක් සමඟ.</p>
              </article>
              <article className="academy-benefit-card">
                <div><GraduationCap size={23} /></div>
                <span>02</span>
                <h3>One student portal</h3>
                <p>Lessons, progress, payments සහ certificates එකම dashboard එකකින් manage කරන්න.</p>
              </article>
              <article className="academy-benefit-card">
                <div><ShieldCheck size={23} /></div>
                <span>03</span>
                <h3>Verified access</h3>
                <p>Payment verification සහ secure login workflow සමඟ නිවැරදි learnerට පමණක් access.</p>
              </article>
              <article className="academy-benefit-card">
                <div><Headphones size={23} /></div>
                <span>04</span>
                <h3>Learning support</h3>
                <p>Course journey එක අතරතුර අවශ්‍ය මඟපෙන්වීම සඳහා support experience එකක්.</p>
              </article>
            </div>
          </div>
        </section>

        <section className="academy-section academy-journey-section" id="how-it-works">
          <div className="section-shell academy-journey-shell">
            <div className="academy-journey-copy">
              <span className="academy-eyebrow">HOW IT WORKS</span>
              <h2>ඔබේ learning journey එක steps තුනකින් අරඹන්න</h2>
              <p>Course එක තෝරා, application එක submit කර, approval ලැබුණු පසු secure student portal එකෙන් ඉගෙනීම අරඹන්න.</p>
              <Link className="button button-primary" to="/login">
                Start your application <ArrowRight size={18} />
              </Link>
            </div>
            <div className="academy-steps">
              <article className="academy-step">
                <span>01</span>
                <div><Search size={22} /></div>
                <h3>Choose a course</h3>
                <p>ඔබේ goal එකට සහ budget එකට ගැළපෙන course එක තෝරන්න.</p>
              </article>
              <article className="academy-step">
                <span>02</span>
                <div><CreditCard size={22} /></div>
                <h3>Submit application</h3>
                <p>අවශ්‍ය details සහ payment proof එක secure form එකෙන් යවන්න.</p>
              </article>
              <article className="academy-step">
                <span>03</span>
                <div><Play size={22} /></div>
                <h3>Start learning</h3>
                <p>Approval පසු login වී lessons සහ progress එක access කරන්න.</p>
              </article>
            </div>
          </div>
        </section>

        <section className="academy-section academy-platform-section">
          <div className="section-shell academy-platform-shell">
            <div className="academy-platform-copy">
              <span className="academy-eyebrow">STUDENT EXPERIENCE</span>
              <h2>ඔබ ඉගෙනගන්න හැමදේම එක dashboard එකක</h2>
              <p>Course access, lesson progress, payments සහ certificates පැහැදිලිව manage කළ හැකි mobile-friendly learning environment එකක්.</p>
              <ul>
                <li><Check size={17} /> Personal course library</li>
                <li><Check size={17} /> Lesson-by-lesson progress</li>
                <li><Check size={17} /> Payment and access status</li>
                <li><Check size={17} /> Certificate readiness</li>
              </ul>
            </div>
            <div className="academy-platform-preview">
              <div className="academy-preview-topbar">
                <div><Logo /></div>
                <span>Student dashboard</span>
                <span className="academy-preview-avatar">ST</span>
              </div>
              <div className="academy-preview-body">
                <div className="academy-preview-sidebar">
                  <span className="is-active"><LayoutDashboard size={17} /> Overview</span>
                  <span><BookOpen size={17} /> My courses</span>
                  <span><BarChart3 size={17} /> Progress</span>
                  <span><Award size={17} /> Certificates</span>
                </div>
                <div className="academy-preview-content">
                  <span className="academy-preview-label">CONTINUE LEARNING</span>
                  <h3>Your active course</h3>
                  <p>Next lesson ready to continue</p>
                  <div className="academy-preview-progress"><span /></div>
                  <div className="academy-preview-stats">
                    <div><strong>Progress</strong><span>Tracked</span></div>
                    <div><strong>Access</strong><span>Secure</span></div>
                    <div><strong>Support</strong><span>Available</span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="academy-section academy-faq-section" id="academy-faq">
          <div className="section-shell academy-faq-shell">
            <div className="academy-faq-intro">
              <span className="academy-eyebrow">FREQUENTLY ASKED QUESTIONS</span>
              <h2>ඔබට අවශ්‍ය පිළිතුරු</h2>
              <p>Enrollment කිරීමට පෙර වැදගත් මූලික තොරතුරු මෙතැනින් බලන්න.</p>
            </div>
            <div className="academy-faq-list">
              <details>
                <summary>Course එකකට apply කරන්නේ කොහොමද?<ChevronRight size={18} /></summary>
                <p>Course card එකේ Apply now හෝ Admission Form button එක භාවිත කර details සහ payment proof submit කරන්න.</p>
              </details>
              <details>
                <summary>Payment කළ විගස course access ලැබෙනවාද?<ChevronRight size={18} /></summary>
                <p>Admin payment details verify කර approval ලබාදුන් පසු secure student access activate වේ.</p>
              </details>
              <details>
                <summary>මගේ course progress බලන්නේ කොහොමද?<ChevronRight size={18} /></summary>
                <p>Login වූ පසු Student Dashboard එකෙන් lessons, progress සහ certificate status බලන්න පුළුවන්.</p>
              </details>
              <details>
                <summary>Course lessons public website එකෙන් බලන්න පුළුවන්ද?<ChevronRight size={18} /></summary>
                <p>Public page එකේ sales information පමණක් පෙන්වයි. Lessons සඳහා approved student account එකක් අවශ්‍යයි.</p>
              </details>
            </div>
          </div>
        </section>

        <section className="academy-section academy-final-cta">
          <div className="section-shell">
            <div className="academy-cta-card">
              <div>
                <span className="academy-eyebrow">YOUR NEXT STEP</span>
                <h2>අදම ඔබේ අලුත් learning journey එක අරඹන්න.</h2>
                <p>Available courses අතරින් ඔබට ගැළපෙන එක තෝරා application එක submit කරන්න.</p>
              </div>
              <div>
                <a className="button button-primary" href="#available-courses">Explore courses <ArrowRight size={18} /></a>
                <Link className="button button-secondary" to="/login">Login</Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="academy-footer">
        <div className="section-shell academy-footer-grid">
          <div className="academy-footer-brand">
            <Logo />
            <p>Professional digital learning experiences for ambitious students.</p>
          </div>
          <div>
            <strong>Explore</strong>
            <a href="#available-courses">Courses</a>
            <a href="#why-adil">Why Adil</a>
            <a href="#how-it-works">How it works</a>
          </div>
          <div>
            <strong>Access</strong>
            <Link to="/login">Student login</Link>
            <Link to="/cco-main">CCO main access</Link>
            <a href="#academy-faq">FAQ</a>
          </div>
          <div>
            <strong>Support</strong>
            <a href="#academy-faq">Help center</a>
            <a href="mailto:adilacademy65@gmail.com">adilacademy65@gmail.com</a>
          </div>
        </div>
        <div className="section-shell academy-footer-bottom">
          <span>© 2026 Adil Academy. All rights reserved.</span>
          <span>Learn with purpose. Grow with confidence.</span>
        </div>
      </footer>

      {selectedCourse && (
        <div className="academy-course-modal-backdrop" role="presentation" onMouseDown={() => setSelectedCourse(null)}>
          <section
            className="academy-course-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="academy-course-modal-title"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <button type="button" className="academy-modal-close" aria-label="Close course details" onClick={() => setSelectedCourse(null)}>
              <X size={21} />
            </button>
            <div className="academy-modal-cover">
              {selectedCourse.thumbnailUrl ? (
                <img src={selectedCourse.thumbnailUrl} alt="" />
              ) : (
                <GraduationCap size={54} />
              )}
            </div>
            <div className="academy-modal-content">
              <span className="academy-eyebrow">COURSE DETAILS</span>
              <h2 id="academy-course-modal-title">{selectedCourse.title}</h2>
              <p>{selectedCourse.shortDescription || "A structured Adil Academy learning experience."}</p>
              <div className="academy-modal-price">
                <span>Course fee</span>
                <strong>{formatCoursePrice(selectedCourse)}</strong>
              </div>
              <div className="academy-modal-note">
                <ShieldCheck size={19} />
                Lesson content is available only after payment verification and account approval.
              </div>
              <div className="academy-modal-actions">
                <Link className="button button-primary" to="/login">
                  Apply for this course <ArrowRight size={18} />
                </Link>
                <button type="button" className="button button-secondary" onClick={() => setSelectedCourse(null)}>Close</button>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

function CcoMainApplicationPage() {
  const [payId, setPayId] = useState(""); const [validated, setValidated] = useState<{name:string;email:string;phone:string;amount:number}|null>(null);
  const [message, setMessage] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function validate(event: FormEvent<HTMLFormElement>) { event.preventDefault(); setBusy(true); setError(""); try { const response=await fetch("/api/public/cco-main/validate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({payId})}); const data=await response.json(); if(!response.ok)throw new Error(data.message||"Pay ID invalid."); setValidated(data); } catch(e){setError(e instanceof Error?e.message:"Pay ID validate කළ නොහැක.")} finally{setBusy(false)} }
  async function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); const form=new FormData(event.currentTarget); const slip=form.get("proof") as File; if(!slip?.size){setError("Bank slip එක තෝරන්න.");return} setBusy(true);setError("");try{const body=Object.fromEntries(Array.from(form.entries()).filter(([key])=>key!=="proof"));const response=await fetch("/api/public/cco-main/applications",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...body,payId})});const data=await response.json();if(!response.ok)throw new Error(data.message||"Application submit failed.");const proof=await fetch(`/api/public/cco-main/applications/${data.applicationId}/proof`,{method:"PUT",headers:{"Content-Type":slip.type,"X-Registration-Token":data.registrationToken},body:slip});const result=await proof.json();if(!proof.ok)throw new Error(result.message||"Slip upload failed.");setMessage(`✓ Application submitted successfully. Reserved account: ${data.accountNumber}. Admin payment slip එක check කර නිවැරදි නම් පැය 24ක් ඇතුළත email එකට OTP code එකක් එවනු ඇත. OTP ලැබුණු පසු Login → Verify OTP වෙත ගොස් OTP සහ නව password එක ඇතුළත් කරන්න.`)}catch(e){setError(e instanceof Error?e.message:"Application submit failed.")}finally{setBusy(false)}}
  const names=validated?.name.trim().split(/\s+/)??[];
  return <div className="cco-main-public"><PublicHeader/><main className="section-shell"><div className="cco-main-intro"><span className="pill"><UserCheck/> COURSE-INDEPENDENT CONSULTING</span><h1>CCO Main Account</h1><p>Course එකකට සම්බන්ධ නොවී Adil Academy consultant කෙනෙකු වීමට Admin ලබාදුන් special Pay ID එක භාවිත කරන්න.</p></div>{message?<section className="cco-main-success"><Check/><h2>Submission successful</h2><p>{message}</p><Link className="button button-primary" to="/login">Verify OTP / Login <ArrowRight/></Link></section>:!validated?<form className="cco-main-card" onSubmit={validate}><span className="eyebrow">STEP 01</span><h2>Special Pay ID verify කරන්න</h2><label>CCO Main Pay ID<input value={payId} onChange={e=>setPayId(e.target.value.toUpperCase())} placeholder="CCO-YYYYMMDD-XXXXXXXX" required/></label>{error&&<p className="form-error">{error}</p>}<button className="button button-primary" disabled={busy}>{busy?"Checking...":"Continue"}<ArrowRight/></button></form>:<form className="cco-main-card cco-main-details" onSubmit={submit}><div><span className="eyebrow">STEP 02</span><h2>Consultant details & payment proof</h2><p><strong>{payId}</strong> · Required amount: <strong>Rs. {validated.amount.toLocaleString()}</strong></p></div><div className="cco-form-grid"><label>First name<input name="firstName" defaultValue={names[0]??""} required/></label><label>Last name<input name="lastName" defaultValue={names.slice(1).join(" ")} required/></label><label>Email<input name="email" type="email" value={validated.email} readOnly/></label><label>Phone<input name="phone" defaultValue={validated.phone} required/></label><label>Date of birth<input name="dateOfBirth" type="date" required/></label><label>NIC / Passport<input name="nicOrPassport" required/></label><label className="wide">Address line 1<input name="addressLine1" required/></label><label className="wide">Address line 2<input name="addressLine2"/></label><label>Province<input name="province" required/></label><label>District<input name="district" required/></label><label>City<input name="city" required/></label><label>Bank reference<input name="transactionReference" value={payId} readOnly/></label><label className="wide">Bank slip (JPG, PNG, WebP or PDF)<input name="proof" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required/></label></div>{error&&<p className="form-error">{error}</p>}<button className="button button-primary" disabled={busy}>{busy?"Submitting...":"Submit CCO Main application"}<ArrowRight/></button></form>}</main></div>;
}

const roleOptions: {
  role: UserRole;
  title: string;
  description: string;
  icon: ReactNode;
}[] = [
  {
    role: "student",
    title: "Student",
    description: "Course, progress සහ certificates",
    icon: <GraduationCap />
  },
  {
    role: "consultant",
    title: "Consultant",
    description: "Accounts, network සහ income",
    icon: <Network />
  },
  {
    role: "staff",
    title: "Staff",
    description: "Payments සහ students",
    icon: <UserCheck />
  },
  {
    role: "admin",
    title: "Super Admin",
    description: "Complete platform control",
    icon: <ShieldCheck />
  }
];

function LoginPage({ onLogin }: { onLogin: (user: DemoUser) => void }) {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "register" | "verify">(
    "login"
  );
  const [busyRole, setBusyRole] = useState<UserRole | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [proof, setProof] = useState<File | null>(null);
  const [courses, setCourses] = useState<{ id: string; title: string; price: string; currency: string }[]>([]);
  const [form, setForm] = useState({
    displayName: "",
    email: "",
    phone: "",
    password: "",
    nicOrPassport: "",
    address: "",
    dateOfBirth: "",
    courseId: "",
    method: "BANK_TRANSFER",
    paidAmount: "",
    transactionReference: "",
    payId: "",
    otp: ""
  });

  useEffect(() => {
    fetch("/api/courses").then((response) => response.json()).then((data: { courses?: typeof courses }) => {
      const items = data.courses ?? [];
      setCourses(items);
    }).catch(() => setCourses([]));
  }, []);

  async function enterDemo(role: UserRole) {
    setBusyRole(role);
    setError("");
    try {
      const response = await fetch("/api/auth/demo-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role })
      });
      if (!response.ok) throw new Error("Preview login failed.");
      const data = (await response.json()) as { user: DemoUser };
      onLogin(data.user);
      navigate("/dashboard");
    } catch {
      setError("Preview එක විවෘත කළ නොහැක. Server එක නැවත run කරන්න.");
    } finally {
      setBusyRole(null);
    }
  }

  async function submitAccount(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      if (mode === "register") {
        if (!proof) throw new Error("Payment slip එක තෝරන්න.");
        const response = await fetch("/api/auth/apply", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            displayName: form.displayName, email: form.email, phone: form.phone,
            nicOrPassport: form.nicOrPassport, courseId: form.courseId,
            payId: form.payId,
            transactionReference: form.payId
          })
        });
        const application = await response.json() as { applicationId?: string; registrationToken?: string; paymentCode?: string; message?: string };
        if (!response.ok || !application.applicationId || !application.registrationToken) throw new Error(application.message || "Application failed.");
        const upload = await fetch(`/api/auth/applications/${application.applicationId}/proof`, {
          method: "PUT", headers: { "Content-Type": proof.type, "X-Registration-Token": application.registrationToken }, body: proof
        });
        const uploadData = await upload.json() as { message?: string; confirmationEmailSent?: boolean };
        if (!upload.ok) throw new Error(uploadData.message || "Payment proof upload failed.");
        setNotice(`Application එක සාර්ථකයි (${application.paymentCode}). ${uploadData.confirmationEmailSent ? "Confirmation email එක යවා ඇත." : "Details save වී ඇත; confirmation email එක යැවීමට නොහැකි විය."} Admin approve කළ පසු OTP එක ලැබේ.`);
        setForm((current) => ({ ...current, password: "", otp: "" }));
        setShowPassword(false);
        setMode("verify");
        return;
      }
      const response = await fetch(mode === "verify" ? "/api/auth/verify" : "/api/auth/login", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mode === "verify" ? { email: form.email, code: form.otp, password: form.password } : { email: form.email, password: form.password })
      });
      const data = (await response.json()) as {
        user?: DemoUser;
        message?: string;
      };
      if (!response.ok || !data.user) {
        throw new Error(data.message || "Account request failed.");
      }
      onLogin(data.user);
      navigate("/dashboard");
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Account request failed."
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function resendOtp() {
    setError("");
    const response = await fetch("/api/auth/resend-otp", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: form.email }) });
    const data = await response.json() as { message?: string };
    if (!response.ok) setError(data.message || "OTP resend failed.");
    else setNotice(data.message || "OTP sent.");
  }

  return (
    <div className="login-page">
      <div className="login-brand-panel">
        <Link to="/" className="login-back">
          <ArrowRight size={17} /> Home වෙත
        </Link>
        <Logo />
        <div className="login-brand-copy">
          <span className="pill">
            <LockKeyhole size={15} /> SECURE LEARNING PLATFORM
          </span>
          <h1>Learn. Grow. Lead.</h1>
          <p>
            Student learning සිට consultant business management දක්වා Adil
            Academy එකම digital platform එකක.
          </p>
        </div>
        <div className="login-quote">
          <ShieldCheck />
          <div>
            <strong>Protected access</strong>
            <span>Role-based dashboards සහ secure student content.</span>
          </div>
        </div>
      </div>
      <div className="login-form-panel">
        <div className="login-card">
          <div className="auth-tabs">
            {[
              ["login", "Login"],
              ["register", "Apply"],
              ["verify", "Verify OTP"]
            ].map(([value, label]) => (
              <button
                key={value}
                type="button"
                className={mode === value ? "active" : ""}
                onClick={() => {
                  setMode(value as typeof mode);
                  setForm((current) => ({ ...current, password: "", otp: "" }));
                  setShowPassword(false);
                  setError("");
                  setNotice("");
                }}
              >
                {label}
              </button>
            ))}
          </div>
          <>
              <span className="eyebrow">
                {mode === "register" ? "STUDENT ADMISSION" : mode === "verify" ? "EMAIL VERIFICATION" : "WELCOME BACK"}
              </span>
              <h2>
                {mode === "register" ? "Admission form එක" : mode === "verify" ? "OTP verify කරන්න" : "Login වෙන්න"}
              </h2>
              <p>
                {mode === "register"
                  ? "Details සහ payment proof submit කරන්න. Admin approval පසු OTP email එක ලැබේ."
                  : mode === "verify"
                    ? "Payment approve වූ පසු email එකට ලැබුණු OTP එක දමා permanent password එක සකස් කරන්න."
                  : "ඔබගේ Adil Academy account එකට secure ලෙස ඇතුළු වෙන්න."}
              </p>
              <form className="auth-form" onSubmit={submitAccount}>
                {mode === "register" && (
                  <>
                    <label className="auth-wide">
                      පාඨමාලාව / පන්තිය තෝරන්න
                      <select required value={form.courseId} onChange={(event) => setForm({ ...form, courseId: event.target.value })}>
                        <option value="">පාඨමාලාවක් තෝරන්න</option>
                        {courses.map((course) => <option key={course.id} value={course.id}>{course.title}</option>)}
                      </select>
                    </label>
                    {form.courseId && <>
                    <label>
                      සම්පූර්ණ නම
                      <input
                        required
                        minLength={2}
                        value={form.displayName}
                        onChange={(event) =>
                          setForm({ ...form, displayName: event.target.value })
                        }
                        placeholder="ඔබගේ නම"
                        autoComplete="name"
                      />
                    </label>
                    <label>
                      දුරකථන අංකය
                      <input
                        value={form.phone}
                        onChange={(event) =>
                          setForm({ ...form, phone: event.target.value })
                        }
                        placeholder="+94 7X XXX XXXX"
                        autoComplete="tel"
                      />
                    </label>
                    <label>NIC / Passport<input required value={form.nicOrPassport} onChange={(event) => setForm({ ...form, nicOrPassport: event.target.value })} placeholder="NIC හෝ Passport අංකය" /></label>
                    <label>Email<input required type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="name@example.com" autoComplete="email" /></label>
                    <label className="auth-wide">Pay ID / Bank Reference<input required value={form.payId} onChange={(event) => setForm({ ...form, payId: event.target.value.toUpperCase() })} placeholder="ADIL-PAY-YYYYMMDD-XXXXXX" /><small>Email එකට ලැබුණු Pay ID එක bank payment Reference ලෙසත් මෙහිත් වෙනසක් නොකර දාන්න.</small></label>
                    <label className="auth-wide">Payment slip<input required type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={(event) => setProof(event.target.files?.[0] ?? null)} /></label>
                    </>}
                  </>
                )}
                {mode !== "register" && <label>
                  Email
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={(event) =>
                      setForm({ ...form, email: event.target.value })
                    }
                    placeholder="name@example.com"
                    autoComplete="email"
                  />
                </label>}
                {mode === "verify" && <label className="auth-wide">OTP code<input required inputMode="numeric" pattern="[0-9]{6}" maxLength={6} value={form.otp} onChange={(event) => setForm({ ...form, otp: event.target.value.replace(/\D/g, "") })} placeholder="6-digit OTP" /></label>}
                {mode !== "register" && <label>
                  Password
                  <span className="password-input-wrap">
                    <input
                      required
                      minLength={8}
                      type={showPassword ? "text" : "password"}
                      value={form.password}
                      onChange={(event) => setForm({ ...form, password: event.target.value })}
                      placeholder="••••••••"
                      autoComplete={mode === "verify" ? "new-password" : "current-password"}
                      data-lpignore={mode === "verify" ? "true" : undefined}
                      data-1p-ignore={mode === "verify" ? "true" : undefined}
                    />
                    <button type="button" className="password-visibility" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? "Password සඟවන්න" : "Password පෙන්වන්න"} title={showPassword ? "Password සඟවන්න" : "Password පෙන්වන්න"}>
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </span>
                </label>}
                {mode === "verify" && (
                  <small className="password-hint">
                    අකුරු 8+, uppercase, lowercase සහ number එකක් අවශ්‍යයි.
                  </small>
                )}
                {mode === "verify" && <button className="otp-resend" type="button" onClick={() => void resendOtp()}>OTP එක නැවත යවන්න</button>}
                <button
                  type="submit"
                  className="button button-primary auth-submit"
                  disabled={submitting}
                >
                  {submitting
                    ? "Please wait..."
                    : mode === "register"
                      ? "Application submit කරන්න"
                      : mode === "verify" ? "Verify කර Login වෙන්න" : "Login"}
                  {!submitting && <ArrowRight size={17} />}
                </button>
              </form>
            </>
          {notice && <p className="form-success">{notice}</p>}
          {error && <p className="form-error">{error}</p>}
          <div className="login-note">
            <LockKeyhole size={15} />
            Password සහ session data secure server-side authentication එකකින්
            ආරක්ෂා වේ.
          </div>
        </div>
      </div>
    </div>
  );
}

const dashboardNav: Record<
  UserRole,
  { label: string; icon: ReactNode }[]
> = {
  student: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "My Course", icon: <BookOpen /> },
    { label: "Progress", icon: <BarChart3 /> },
    { label: "Q & A", icon: <Target /> },
    { label: "Certificates", icon: <Award /> },
    { label: "Payments", icon: <CreditCard /> },
    { label: "Balance Payment", icon: <Wallet /> }
  ],
  consultant: [
    { label: "My Profile", icon: <Camera /> },
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "Admission Heroes", icon: <Trophy /> },
    { label: "CCO Academy", icon: <GraduationCap /> },
    { label: "My Students", icon: <Users /> },
    { label: "Student Registration", icon: <UserCheck /> },
    { label: "My Accounts", icon: <UserCheck /> },
    { label: "Service Accounts", icon: <CircleDollarSign /> },
    { label: "CCO Activation", icon: <CreditCard /> },
    { label: "Network", icon: <Network /> },
    { label: "Income", icon: <Wallet /> }
    ,{ label: "Customer Support", icon: <Headphones /> }
  ],
  staff: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "Payments", icon: <CreditCard /> },
    { label: "Students", icon: <Users /> },
    { label: "Consultants", icon: <UserCheck /> },
    { label: "Reports", icon: <BarChart3 /> }
    ,{ label: "Customer Support", icon: <Headphones /> }
  ],
  admin: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "Course", icon: <BookOpen /> },
    { label: "Students", icon: <Users /> },
    { label: "Payments", icon: <CreditCard /> },
    { label: "CCO Activations", icon: <UserCheck /> },
    { label: "CCO Main Buy", icon: <CircleDollarSign /> },
    { label: "Network", icon: <Network /> },
    { label: "Commissions", icon: <CircleDollarSign /> },
    { label: "Settings", icon: <Settings /> }
    ,{ label: "Customer Support", icon: <Headphones /> }
  ]
};

function MetricCard({
  label,
  value,
  note,
  icon,
  onClick
}: {
  label: string;
  value: string;
  note: string;
  icon: ReactNode;
  onClick?: () => void;
}) {
  return (
    <article className={`metric-card ${onClick ? "metric-card-clickable" : ""}`} onClick={onClick} role={onClick ? "button" : undefined} tabIndex={onClick ? 0 : undefined} onKeyDown={(event) => { if (onClick && (event.key === "Enter" || event.key === " ")) onClick(); }}>
      <span className="metric-icon">{icon}</span>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{note}</small>
    </article>
  );
}

function StudentDashboard() {
  const [summary, setSummary] = useState<StudentDashboardSummary | null>(null);
  const [loadError, setLoadError] = useState(false);
  useEffect(() => {
    fetch("/api/student/dashboard-summary")
      .then(async (response) => {
        if (!response.ok) throw new Error("Summary request failed");
        return response.json() as Promise<StudentDashboardSummary>;
      })
      .then(setSummary)
      .catch(() => setLoadError(true));
  }, []);

  if (loadError) {
    return <section className="dash-card"><h3>Dashboard data load කළ නොහැක</h3><p>Page එක refresh කරන්න.</p></section>;
  }
  if (!summary) {
    return <section className="dash-card"><h3>Dashboard loading...</h3></section>;
  }
  const enrolled = summary.enrollmentStatus !== "NOT_ENROLLED";
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Course Progress"
          value={`${summary.progressPercent}%`}
          note={`${summary.completedLessons} of ${summary.totalLessons} lessons`}
          icon={<TrendingUp />}
        />
        <MetricCard
          label="Learning Streak"
          value={summary.completedLessons ? "Active" : "0 days"}
          note={summary.completedLessons ? "Learning started" : "No activity yet"}
          icon={<Sparkles />}
        />
        <MetricCard
          label="Quiz Average"
          value={summary.quizAverage === null ? "—" : `${summary.quizAverage}%`}
          note={summary.quizAverage === null ? "No quiz attempts" : "Quiz performance"}
          icon={<Award />}
        />
        <MetricCard
          label="Account"
          value={summary.accountNumber ?? "Not assigned"}
          note={summary.accountStatus ?? "Payment pending"}
          icon={<UserCheck />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card dash-course-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">{enrolled ? "CONTINUE LEARNING" : "COURSE ACCESS LOCKED"}</span>
              <h3>{summary.courseTitle ?? "Payment approval required"}</h3>
            </div>
            <span>{summary.progressPercent}%</span>
          </div>
          <div className="course-visual">
            <span className="course-visual-icon">
              <ShieldCheck />
            </span>
            <div>
              <span>{enrolled ? "YOUR COURSE" : "NOT ENROLLED"}</span>
              <strong>{enrolled ? "ඔබ නතර කළ තැනින් ඉගෙනීම දිගටම කරගෙන යන්න" : "Full payment එක Admin approve කළ පසු lessons unlock වේ"}</strong>
            </div>
            <button type="button" disabled={!enrolled}>
              <Play fill="currentColor" />
            </button>
          </div>
          <div className="progress-track large">
            <span style={{ width: `${summary.progressPercent}%` }} />
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>Recent activity</h3>
            <button type="button">View all</button>
          </div>
          <div className="activity-list">
            {summary.recentActivity.length ? summary.recentActivity.map((activity) => (
              <div key={`${activity.title}-${activity.detail}`}>
                <span className="activity-dot completed"><Check /></span>
                <p><strong>{activity.title}</strong><small>{activity.detail}</small></p>
              </div>
            )) : <p>No learning activity yet.</p>}
          </div>
        </section>
      </div>
    </>
  );
}

type ConsultantDashboardData = {
  mainAccountNumber: string | null;
  totalIncome: number;
  totalPaid: number;
  upcomingIncome: number;
  availableBalance: number;
  directStudents: number;
  leftPoints: number;
  rightPoints: number;
  accounts: Array<{
    id: string; number: string; status: string; isMain: boolean;
    leftAvailable: number; rightAvailable: number;
    stageOneAchieved: boolean; stageTwoAchieved: boolean;
    nextStage: string; nextPayout: number; income: number;
  }>;
  slots: Array<{
    position: number; number: string; status: string; isMain: boolean; accountId: string | null;
  }>;
  earningChart: Record<"daily" | "weekly" | "monthly", {
    points: Array<{ key: string; label: string; amount: number }>;
    current: number; previous: number; bestAmount: number; bestLabel: string; changePercent: number;
  }>;
};

function ConsultantDashboard({ onOpen }: { onOpen: (module: string) => void }) {
  const [data, setData] = useState<ConsultantDashboardData | null>(null);
  const [earningPeriod, setEarningPeriod] = useState<"daily" | "weekly" | "monthly">("daily");
  const [loadError, setLoadError] = useState(false);
  useEffect(() => {
    fetch("/api/consultant/cco-dashboard")
      .then(async (response) => {
        if (!response.ok) throw new Error("CCO dashboard request failed");
        return response.json() as Promise<ConsultantDashboardData>;
      })
      .then(setData)
      .catch(() => setLoadError(true));
  }, []);
  if (loadError) return <section className="dash-card"><h3>CCO data load කළ නොහැක</h3><p>Page එක refresh කර නැවත උත්සාහ කරන්න.</p></section>;
  if (!data) return <section className="dash-card"><h3>CCO dashboard loading...</h3></section>;
  const dashboardData = data;
  const money = (value: number) => `Rs. ${value.toLocaleString()}`;
  const main = data.accounts.find((account) => account.isMain) ?? data.accounts[0];
  const trend = data.earningChart?.[earningPeriod];
  const maxChartValue = Math.max(1, ...(trend?.points.map((point) => point.amount) ?? [0]));
  const periodName = earningPeriod === "daily" ? "Today" : earningPeriod === "weekly" ? "This week" : "This month";
  const comparisonText = !trend ? "" : trend.previous === 0 && trend.current === 0 ? "No earnings yet" : trend.changePercent >= 0 ? `${trend.changePercent}% higher than previous` : `${Math.abs(trend.changePercent)}% lower than previous`;
  const nextAccountPosition = data.slots.find((item) => !item.accountId)?.position;
  function networkNode(position: number) {
    const slot = dashboardData.slots.find((item) => item.position === position); if (!slot) return null;
    const summary = dashboardData.accounts.find((item) => item.number === slot.number); const active = Boolean(slot.accountId);
    return <div className={`cco-network-node ${active ? "active" : position === nextAccountPosition ? "next" : "locked"}`}>
      <span className="cco-node-position">{position === 1 ? "MAIN" : `ACCOUNT ${position}`}</span>
      <strong>{slot.number}</strong>
      <small>{active ? "ACTIVE" : position === nextAccountPosition ? "NEXT TO BUY" : "LOCKED"}</small>
      {active && <div className="cco-point-pair"><span><b>P</b> LEFT <strong>{summary?.leftAvailable ?? 0}</strong></span><span><b>P</b> RIGHT <strong>{summary?.rightAvailable ?? 0}</strong></span></div>}
    </div>;
  }
  return (
    <>
      <ConsultantAdmissionTargets />
      {trend && <section className="dash-card earning-chart-card">
        <div className="earning-chart-heading">
          <div><span className="eyebrow">EARNING CHART</span><h3>Your income momentum</h3><p>Previous performance එක පරදවා අලුත් personal best එකක් ලබාගන්න.</p></div>
          <div className="earning-period-tabs">
            {(["daily", "weekly", "monthly"] as const).map((period) => <button type="button" key={period} className={earningPeriod === period ? "active" : ""} onClick={() => setEarningPeriod(period)}>{period[0].toUpperCase() + period.slice(1)}</button>)}
          </div>
        </div>
        <div className="earning-comparison-grid">
          <div><small>{periodName}</small><strong>{money(trend.current)}</strong><span className={trend.changePercent >= 0 ? "positive" : "negative"}>{comparisonText}</span></div>
          <div><small>Previous period</small><strong>{money(trend.previous)}</strong><span>Comparison baseline</span></div>
          <div className="personal-best"><small>Personal best</small><strong>{money(trend.bestAmount)}</strong><span>{trend.bestLabel}</span></div>
        </div>
        <div className="earning-bars" aria-label={`${earningPeriod} earnings chart`}>
          {trend.points.map((point, index) => <div className="earning-bar-column" key={point.key} title={`${point.label}: ${money(point.amount)}`}>
            <span className="earning-bar-value">{point.amount ? point.amount >= 1000 ? `${Math.round(point.amount / 100) / 10}k` : point.amount : ""}</span>
            <div className={`earning-bar ${index === trend.points.length - 1 ? "current" : ""}`} style={{ height: `${Math.max(point.amount ? 8 : 2, (point.amount / maxChartValue) * 100)}%` }} />
            <small>{point.label}</small>
          </div>)}
        </div>
        <p className="earning-motivation">{trend.current >= trend.bestAmount && trend.current > 0 ? "🔥 New personal best! මේ momentum එක දිගටම තබාගන්න." : `ඔබගේ best ${earningPeriod} income එක පරදවන්න තවත් ${money(Math.max(0, trend.bestAmount - trend.current))} අවශ්‍යයි.`}</p>
      </section>}
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">BINARY NETWORK</span>
              <h3>{data.mainAccountNumber ?? "No CN account"}</h3>
            </div>
            <span className="status-badge success">CCO ACTIVE</span>
          </div>
          <div className="cco-seven-tree">
            <div className="cco-tree-root">{networkNode(1)}</div>
            <div className="cco-tree-level level-two"><div>{networkNode(2)}</div><div>{networkNode(3)}</div></div>
            <div className="cco-tree-level level-three"><div>{networkNode(4)}</div><div>{networkNode(6)}</div><div>{networkNode(7)}</div><div>{networkNode(5)}</div></div>
            <div className="cco-tree-legend"><span><i className="active" /> Active account</span><span><i className="next" /> Next to buy</span><span><i /> Locked</span></div>
          </div>
          {main && <p className="workspace-note">Next cycle: <strong>{main.nextStage}</strong> → {money(main.nextPayout)}</p>}
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <div><span className="eyebrow">7-NUMBER BLOCK</span><h3>My CCO accounts</h3></div>
            <span>{data.accounts.length}/7 active</span>
          </div>
          <div className="account-list">
            {data.slots.map((slot) => { const nextPosition = data.slots.find((item) => !item.accountId)?.position; const available = slot.position === nextPosition; return <button type="button" className={`account-list-item ${available ? "available" : !slot.accountId ? "locked" : ""}`} key={slot.position} onClick={() => { if (slot.accountId) return; if (available) onOpen("CCO Activation"); else window.alert(`මුලින් ${data.slots.find((item) => item.position === nextPosition)?.number ?? "previous account"} activate කරන්න.`); }}>
              <span className={`account-badge ${slot.accountId ? "" : "muted"}`}>{slot.isMain ? "MAIN" : String(slot.position).padStart(2, "0")}</span>
              <p><strong>{slot.number}</strong><small>{slot.accountId ? "Commission cycle enabled" : available ? "Available to buy now" : `Locked • Activate account ${nextPosition} first`}</small></p>
              <span className={`status-badge ${slot.accountId ? "success" : available ? "success" : ""}`}>{slot.accountId ? slot.status : available ? "BUY NOW" : "LOCKED"}</span>
            </button>})}
          </div>
        </section>
      </div>
    </>
  );
}

type ServiceAccount = {
  id: string; position: number; number: string; username: string; status: string;
  leftPoints: number; rightPoints: number;
  weeklyFlush: null | { cycleKey: string; periodStart: string; periodEnd: string; stage: string; matchedPairs: number; leftBefore: number; rightBefore: number; leftFlushed: number; rightFlushed: number; amount: number };
};
type ServiceAccountActivity = { id:string; beneficiaryAccountIds:string[]; beneficiaryAccountNumbers:string[]; side:"LEFT"|"RIGHT"; studentName:string; studentEmail:string; studentPhone:string|null; studentAccountNumber:string|null; paymentCode:string; paidAmount:number; totalAmount:number; paymentType:"FULL"|"HALF"; paymentStatus:string; pointAwarded:boolean; pointCount:number; createdAt:string };

type ConsultantStudent = {
  id: string; firstName: string; lastName: string; email: string; phone: string; dateOfBirth: string;
  province: string; district: string; city: string; side: "LEFT" | "RIGHT"; status: string;
  payId: string; payIdExpiresAt: string; courseTitle: string; paymentCode: string | null;
  paidAmount: number | null; totalAmount: number | null; accountNumber: string | null; accountStatus: string | null; createdAt: string;
};

function ConsultantMyStudentsWorkspace() {
  const [students, setStudents] = useState<ConsultantStudent[]>([]);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("ALL");
  const [selected, setSelected] = useState<ConsultantStudent | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { fetch("/api/consultant/student-registrations").then(async (response) => {
    const body = await response.json(); if (!response.ok) throw new Error(body.message ?? "Students load failed"); return body;
  }).then((body) => setStudents(body.registrations)).catch((reason) => setError(reason instanceof Error ? reason.message : "Students load failed")); }, []);
  const normalized = query.trim().toLowerCase();
  const visible = students.filter((student) => (status === "ALL" || student.status === status) && (!normalized || [student.accountNumber, student.payId, student.paymentCode, student.firstName, student.lastName, student.email, student.phone].some((value) => value?.toLowerCase().includes(normalized))));
  const statusLabel = (value: string) => ({ AWAITING_PAYMENT: "Awaiting Payment", PAYMENT_SUBMITTED: "Payment Submitted", PAYMENT_REVIEW: "Payment Review", ACTIVE: "Active", REJECTED: "Rejected" }[value] ?? value.replaceAll("_", " "));
  const statusClass = (value: string) => value === "ACTIVE" ? "success" : value === "REJECTED" ? "danger" : "warning";
  return <section className="dash-card workspace-card my-students-workspace">
    <div className="workspace-heading"><div><span className="eyebrow">REAL STUDENT DIRECTORY</span><h2>My Students</h2><p>ඔබ register කළ students, payments, SR accounts සහ access status.</p></div><span className="student-total-badge">{students.length} students</span></div>
    <div className="student-directory-tools"><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search: SR number, Pay ID, name, email or phone" /><select value={status} onChange={(event) => setStatus(event.target.value)}><option value="ALL">All statuses</option><option value="AWAITING_PAYMENT">Awaiting payment</option><option value="PAYMENT_REVIEW">Payment review</option><option value="ACTIVE">Active</option><option value="REJECTED">Rejected</option></select></div>
    {error && <p className="form-error">{error}</p>}
    <div className="student-directory-table"><div className="student-directory-head"><span>STUDENT</span><span>ACCOUNT / PAY ID</span><span>PLACEMENT</span><span>STATUS</span><span>DETAILS</span></div>
      {visible.map((student) => <div className="student-directory-row" key={student.id}><div><strong>{student.firstName} {student.lastName}</strong><small>{student.email}<br />{student.phone}</small></div><div><strong>{student.accountNumber ?? "SR pending"}</strong><small>{student.payId}<br />{student.courseTitle}</small></div><div><span className={`side-badge ${student.side.toLowerCase()}`}>{student.side}</span><small>{student.city}, {student.district}</small></div><div><span className={`status-badge ${statusClass(student.status)}`}>{statusLabel(student.status)}</span></div><button type="button" className="icon-detail-button" onClick={() => setSelected(student)} aria-label={`View ${student.firstName} details`}><Eye /></button></div>)}
      {!visible.length && <p className="service-account-empty">ගැළපෙන student record එකක් හමු නොවීය.</p>}
    </div>
    {selected && <div className="service-flush-overlay" onClick={() => setSelected(null)}><div className="service-flush-modal student-detail-modal" onClick={(event) => event.stopPropagation()}><button type="button" className="modal-close" onClick={() => setSelected(null)}><X /></button><span className="eyebrow">STUDENT PROFILE</span><h3>{selected.firstName} {selected.lastName}</h3><span className={`status-badge ${statusClass(selected.status)}`}>{statusLabel(selected.status)}</span><div className="student-detail-grid"><p><small>SR Account</small><strong>{selected.accountNumber ?? "Pending"}</strong></p><p><small>Pay ID</small><strong>{selected.payId}</strong></p><p><small>Email</small><strong>{selected.email}</strong></p><p><small>Phone</small><strong>{selected.phone}</strong></p><p><small>Course</small><strong>{selected.courseTitle}</strong></p><p><small>Placement</small><strong>{selected.side}</strong></p><p><small>Payment</small><strong>{selected.paidAmount === null ? "Not submitted" : `Rs. ${selected.paidAmount.toLocaleString()} / ${selected.totalAmount?.toLocaleString()}`}</strong></p><p><small>Registered</small><strong>{new Date(selected.createdAt).toLocaleDateString("en-LK")}</strong></p></div></div></div>}
  </section>;
}

function ConsultantServiceAccountsWorkspace() {
  const [accounts, setAccounts] = useState<ServiceAccount[]>([]);
  const [activity, setActivity] = useState<ServiceAccountActivity[]>([]);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<ServiceAccount | null>(null);
  const [detailSide, setDetailSide] = useState<"LEFT" | "RIGHT" | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { fetch("/api/consultant/service-accounts").then(async (response) => {
    const body = await response.json(); if (!response.ok) throw new Error(body.message ?? "Service accounts load failed"); return body;
  }).then((body) => { setAccounts(body.accounts); setActivity(body.activity ?? []); }).catch((reason) => setError(reason instanceof Error ? reason.message : "Service accounts load failed")); }, []);
  const normalized = query.trim().toLowerCase();
  const visible = accounts.filter((account) => !normalized || account.number.toLowerCase().includes(normalized) || account.username.toLowerCase().includes(normalized));
  const visibleIds = new Set(visible.map((account) => account.id));
  const sideActivity = detailSide ? activity.filter((item) => item.side === detailSide && item.beneficiaryAccountIds.some((id) => visibleIds.has(id))) : [];
  const date = (value: string) => new Date(value).toLocaleDateString("en-LK", { year: "numeric", month: "short", day: "numeric" });
  return <section className="dash-card workspace-card service-accounts-workspace">
    <div className="workspace-heading"><div><span className="eyebrow">CONSULTANT POINT CONTROL</span><h2>Service Accounts</h2><p>ඔබ මිලදීගත් සෑම CN account එකකම points සහ weekly flush profit පරීක්ෂා කරන්න.</p></div></div>
    <div className="service-account-search"><label>SEARCH SERVICE ACCOUNT</label><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="CN number හෝ username එක ඇතුළත් කරන්න" /></div>
    {error && <p className="form-error">{error}</p>}
    <div className="service-account-table">
      <div className="service-account-head"><span>NO.</span><span>ID</span><span>USERNAME</span><span>LEFT SIDE</span><span>RIGHT SIDE</span><span>DETAILS</span></div>
      {visible.map((account) => <div className="service-account-row" key={account.id}>
        <span data-label="NO.">{String(account.position).padStart(2, "0")}</span><strong data-label="ID">{account.number}</strong><span data-label="USERNAME">{account.username}</span>
        <span data-label="LEFT SIDE" className="point-pill">{account.leftPoints} P</span><span data-label="RIGHT SIDE" className="point-pill">{account.rightPoints} P</span>
        <button type="button" className="icon-detail-button" aria-label={`${account.number} weekly profit details`} onClick={() => setSelected(account)}><Eye /></button>
      </div>)}
      {!visible.length && <p className="service-account-empty">ගැළපෙන service account එකක් හමු නොවීය.</p>}
    </div>
    <div className="service-side-options">
      <button type="button" className={detailSide === "LEFT" ? "active left" : "left"} onClick={() => setDetailSide("LEFT")}><span>LEFT SIDE DETAIL</span><strong>{activity.filter((item) => item.side === "LEFT").length} payments</strong><small>Left branch students & consultant network</small><ChevronRight /></button>
      <button type="button" className={detailSide === "RIGHT" ? "active right" : "right"} onClick={() => setDetailSide("RIGHT")}><span>RIGHT SIDE DETAIL</span><strong>{activity.filter((item) => item.side === "RIGHT").length} payments</strong><small>Right branch students & consultant network</small><ChevronRight /></button>
    </div>
    {detailSide && <div className="side-activity-panel"><div className="side-activity-title"><div><span className="eyebrow">{detailSide} BRANCH</span><h3>{detailSide} Side Details</h3><p>Search කළ service accounts වලට පහළින් පැමිණි payment සහ point records.</p></div><button type="button" onClick={() => setDetailSide(null)}><X /></button></div><div className="side-activity-list">
      {sideActivity.map((item) => <article key={item.id} className={`side-payment-record ${item.paymentType.toLowerCase()}`}><div className="side-payment-person"><span>{item.studentName.slice(0,2).toUpperCase()}</span><p><strong>{item.studentName}</strong><small>{item.studentAccountNumber ?? "SR pending"} • {item.studentEmail}<br />{item.studentPhone ?? "No phone"}</small></p></div><div><small>POINT ROUTE</small><strong>{item.beneficiaryAccountNumbers.join(" → ")}</strong><span className={`side-badge ${item.side.toLowerCase()}`}>{item.side}</span></div><div><small>PAYMENT</small><strong>Rs. {item.paidAmount.toLocaleString()}</strong><span className={`payment-type-badge ${item.paymentType.toLowerCase()}`}>{item.paymentType} PAYMENT</span></div><div><small>POINT STATUS</small><strong>+1 P × {item.beneficiaryAccountNumbers.length} ACCOUNTS</strong><span>{new Date(item.createdAt).toLocaleDateString("en-LK")}</span></div></article>)}
      {!sideActivity.length && <p className="service-account-empty">මෙම side එකට payment records තවම නැහැ.</p>}
    </div></div>}
    {selected && <div className="service-flush-overlay" onClick={() => setSelected(null)}><div className="service-flush-modal" onClick={(event) => event.stopPropagation()}>
      <button type="button" className="modal-close" onClick={() => setSelected(null)}><X /></button><span className="eyebrow">WEEKLY FLUSH PROFIT</span><h3>{selected.number}</h3><p>{selected.username}ගේ service account breakdown එක</p>
      {selected.weeklyFlush ? <><div className="flush-period"><span>{date(selected.weeklyFlush.periodStart)}</span><ArrowRight /><span>{date(selected.weeklyFlush.periodEnd)}</span></div>
        <div className="flush-stats"><div><small>Stage</small><strong>{selected.weeklyFlush.stage}</strong></div><div><small>Matched pairs</small><strong>{selected.weeklyFlush.matchedPairs}</strong></div><div><small>Left flushed</small><strong>{selected.weeklyFlush.leftFlushed} P</strong></div><div><small>Right flushed</small><strong>{selected.weeklyFlush.rightFlushed} P</strong></div></div>
        <div className="flush-profit"><span>This week profit</span><strong>Rs. {selected.weeklyFlush.amount.toLocaleString()}</strong></div></> : <div className="flush-no-data"><strong>No completed flush this week</strong><p>Commission cycle calculate කළ පසු මෙහි profit breakdown එක පෙන්වයි.</p></div>}
    </div></div>}
  </section>;
}

type AdminOverviewData = {
  students: number;
  consultants: number;
  pendingPayments: number;
  pendingApplications: number;
  activeAccounts: number;
  commissionCycleCount: number;
};

type AdminPaymentView = StudentPaymentView & {
  userId: string; createdAt: string; accountNumber?: string | null;
  student?: { name: string; email: string; phone: string | null } | null;
  placementConsultant?: {
    id: string; name: string; email: string; phone: string | null;
    accountNumber: string; side: "LEFT" | "RIGHT" | null;
  } | null;
};

type AdminBalancePaymentView = {
  id: string; amount: string; status: string; transactionReference: string; hasProof: boolean; reviewNote?: string | null;
  student: { name: string; email: string; phone: string | null };
  course: { id: string; title: string }; originalPaymentCode: string; createdAt: string;
};

function AdminDashboard({ onOpen }: { onOpen: (module: string) => void }) {
  const [overview, setOverview] = useState<AdminOverviewData | null>(null);
  const [payments, setPayments] = useState<AdminPaymentView[]>([]);
  useEffect(() => {
    Promise.all([fetch("/api/admin/overview"), fetch("/api/admin/payments")])
      .then(async ([overviewResponse, paymentResponse]) => {
        if (!overviewResponse.ok || !paymentResponse.ok) throw new Error("Admin data failed");
        setOverview(await overviewResponse.json() as AdminOverviewData);
        const data = await paymentResponse.json() as { payments: AdminPaymentView[] };
        setPayments(data.payments);
      }).catch(() => undefined);
  }, []);
  if (!overview) return <section className="dash-card"><h3>Admin data loading...</h3></section>;
  return (
    <>
      <div className="metrics-grid">
        <MetricCard label="Total Students" value={String(overview.students)} note="Click to view & search" icon={<Users />} onClick={() => onOpen("Students")} />
        <MetricCard label="Pending Payments" value={String(overview.pendingPayments)} note="Click to verify" icon={<CreditCard />} onClick={() => onOpen("Payments")} />
        <MetricCard label="Consultants" value={String(overview.consultants)} note="Click to view & search" icon={<Network />} onClick={() => onOpen("Consultants")} />
        <MetricCard label="Active Accounts" value={String(overview.activeAccounts)} note="Click to search SR/CN" icon={<UserCheck />} onClick={() => onOpen("Network")} />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading"><div><span className="eyebrow">REAL-TIME DATA</span><h3>Latest payments</h3></div></div>
          <div className="payment-table">
            <div className="table-head"><span>Payment ID</span><span>Method</span><span>Amount</span><span>Status</span></div>
            {payments.slice(0, 5).map((item) => (
              <div className="table-row" key={item.id}>
                <span>{item.paymentCode}</span><span>{item.method.replaceAll("_", " ")}</span>
                <strong>Rs. {Number(item.paidAmount).toLocaleString()}</strong><span className="status-badge">{item.status.replaceAll("_", " ")}</span>
              </div>
            ))}
            {!payments.length && <p>No payment requests yet.</p>}
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading"><h3>Platform status</h3></div>
          <div className="activity-list">
            <div><span className="activity-dot completed"><Check /></span><p><strong>{overview.activeAccounts} active accounts</strong><small>Database verified</small></p></div>
            <div><span className="activity-dot"><CircleDollarSign /></span><p><strong>{overview.commissionCycleCount} commission cycles</strong><small>Recorded cycles</small></p></div>
          </div>
        </section>
      </div>
    </>
  );
}

function OperationsDashboard({ role }: { role: "staff" | "admin" }) {
  const isAdmin = role === "admin";
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Total Students"
          value="1,248"
          note="+64 this month"
          icon={<Users />}
        />
        <MetricCard
          label="Pending Payments"
          value="18"
          note="Needs review"
          icon={<CreditCard />}
        />
        <MetricCard
          label={isAdmin ? "Active Consultants" : "Open Tickets"}
          value={isAdmin ? "126" : "12"}
          note={isAdmin ? "+8 this month" : "4 high priority"}
          icon={isAdmin ? <Network /> : <Bell />}
        />
        <MetricCard
          label="Course Completion"
          value="72%"
          note="Across all students"
          icon={<GraduationCap />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">ACTION REQUIRED</span>
              <h3>Payment verification</h3>
            </div>
            <button type="button">View queue</button>
          </div>
          <div className="payment-table">
            <div className="table-head">
              <span>Student</span>
              <span>Method</span>
              <span>Amount</span>
              <span>Status</span>
            </div>
            {[
              ["Sahan Jay", "Bank", "Rs. 50,000", "Review"],
              ["Ishara M.", "USDT", "154 USDT", "Review"],
              ["Dulani K.", "Bank", "Rs. 25,000", "Partial"]
            ].map((row) => (
              <div className="table-row" key={row[0]}>
                <span>{row[0]}</span>
                <span>{row[1]}</span>
                <strong>{row[2]}</strong>
                <span
                  className={
                    row[3] === "Partial"
                      ? "status-badge warning"
                      : "status-badge"
                  }
                >
                  {row[3]}
                </span>
              </div>
            ))}
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>{isAdmin ? "Friday commission cycle" : "Student activity"}</h3>
            <button type="button">Details</button>
          </div>
          {isAdmin ? (
            <div className="cycle-card">
              <span className="cycle-icon">
                <CircleDollarSign />
              </span>
              <strong>2026-W29</strong>
              <p>126 accounts ready for calculation</p>
              <div className="cycle-progress">
                <span>
                  <small>Estimated payout</small>
                  <strong>Rs. 684,500</strong>
                </span>
                <span className="status-badge success">Scheduled</span>
              </div>
              <button type="button" className="button button-primary full">
                Review cycle
              </button>
            </div>
          ) : (
            <div className="activity-list">
              <div>
                <span className="activity-dot completed">
                  <Check />
                </span>
                <p>
                  <strong>32 lessons completed</strong>
                  <small>Today across all students</small>
                </p>
              </div>
              <div>
                <span className="activity-dot">
                  <Users />
                </span>
                <p>
                  <strong>8 new registrations</strong>
                  <small>Waiting for payments</small>
                </p>
              </div>
            </div>
          )}
        </section>
      </div>
    </>
  );
}

const workspaceData: Record<
  string,
  {
    title: string;
    description: string;
    action: string;
    rows: [string, string, string][];
  }
> = {
  "student:My Course": {
    title: "Crypto Trading — Zero to Pro",
    description: "ඔබට active course lessons සහ learning resources.",
    action: "Continue lesson",
    rows: [
      ["Module 01", "Crypto Foundations", "Completed"],
      ["Module 02", "Spot Trading", "Completed"],
      ["Module 03", "Technical Analysis", "86%"],
      ["Module 04", "Risk Management", "In progress"],
      ["Module 05", "Futures Trading", "Locked"],
      ["Module 06", "Trading Psychology", "Locked"]
    ]
  },
  "student:Progress": {
    title: "Learning Progress",
    description: "Lessons, quizzes සහ course completion summary.",
    action: "View report",
    rows: [
      ["Lessons completed", "24 of 36", "68%"],
      ["Quiz average", "86 points", "Good"],
      ["Learning time", "18h 42m", "This course"],
      ["Current streak", "12 days", "Active"]
    ]
  },
  "student:Certificates": {
    title: "Certificates",
    description: "Course requirements complete වූ පසු certificate නිකුත් වේ.",
    action: "Requirements",
    rows: [
      ["Crypto Trading — Zero to Pro", "68% complete", "Not issued"],
      ["Required quiz average", "Minimum 70%", "Passed"],
      ["All lessons", "24 of 36", "Pending"]
    ]
  },
  "student:Payments": {
    title: "Payment History",
    description: "Bank Transfer සහ USDT payment verification status.",
    action: "New payment",
    rows: [
      ["PAY-20260716-A31F", "Bank Transfer", "Approved"],
      ["Course access", "Rs. 50,000", "Active"],
      ["Payment proof", "bank-slip.webp", "Verified"]
    ]
  },
  "consultant:My Students": {
    title: "My Students",
    description: "ඔබ තෝරාගත් CN account හරහා පැමිණි admissions.",
    action: "Register student",
    rows: [
      ["Sahan Jay", "SR527701 • LEFT", "Active"],
      ["Ishara M.", "SR527702 • RIGHT", "Active"],
      ["Dulani K.", "Payment pending", "Review"],
      ["Nuwan P.", "SR527710 • LEFT", "Active"]
    ]
  },
  "consultant:CCO Academy": {
    title: "CCO Academy",
    description: "Consultant onboarding, student handling, registrations, payments සහ commission rules සඳහා training LMS.",
    action: "Start training",
    rows: [
      ["Module 01", "Adil Academy CCO Introduction", "Ready"],
      ["Module 02", "Student Registration & Pay ID", "Ready"],
      ["Module 03", "SR/CN, LEFT/RIGHT & Ethics", "Ready"],
      ["Module 04", "1:1, 2:2 and 3:3 Rules", "Ready"]
    ]
  },
  "consultant:Student Registration": {
    title: "Student Registration",
    description: "Student details, payment choice, placement account සහ LEFT/RIGHT side submit කරන්න.",
    action: "New registration",
    rows: [
      ["Step 01", "Student identity & contact", "Required"],
      ["Step 02", "Course, payment & Pay ID", "Required"],
      ["Step 03", "CN account and LEFT/RIGHT", "Required"]
    ]
  },
  "consultant:My Accounts": {
    title: "SR/CN Accounts",
    description: "Main account සහ purchased consultant accounts.",
    action: "Account details",
    rows: [
      ["CN527695", "Main account", "Active"],
      ["CN527706", "Account 02", "Active"],
      ["Available accounts", "2 of 7 used", "5 slots"]
    ]
  },
  "consultant:Network": {
    title: "Binary Network",
    description: "LEFT/RIGHT placements සහ account ownership view.",
    action: "Expand tree",
    rows: [
      ["CN527695", "Main account", "Root"],
      ["SR527701", "Direct LEFT", "18,500 PV"],
      ["SR527702", "Direct RIGHT", "15,000 PV"],
      ["Carry forward", "Left 3,500", "Active"]
    ]
  },
  "consultant:Income": {
    title: "Income & Wallet",
    description: "Weekly commissions, wallet ledger සහ payout requests.",
    action: "Request payout",
    rows: [
      ["Available balance", "Rs. 22,500", "Ready"],
      ["Repeatable 3:3 cycle", "Rs. 8,000", "Account based"],
      ["Last payout", "Rs. 15,000", "Paid"],
      ["Next release", "Friday", "Scheduled"]
    ]
  },
  "staff:Payments": {
    title: "Payment Verification Queue",
    description: "Payment proof බලලා approve, partial හෝ reject කරන්න.",
    action: "Open queue",
    rows: [
      ["PAY-20260716-F29A", "Bank • Rs. 50,000", "Review"],
      ["PAY-20260716-C11B", "USDT • 154", "Review"],
      ["PAY-20260715-92AC", "Bank • Rs. 25,000", "Partial"]
    ]
  },
  "staff:Students": {
    title: "Student Management",
    description: "Accounts, enrollments, course access සහ status.",
    action: "Add student",
    rows: [
      ["Active students", "1,248", "Current"],
      ["New this month", "64", "+12%"],
      ["Pending admission", "18", "Review"],
      ["Suspended", "3", "Attention"]
    ]
  },
  "staff:Consultants": {
    title: "Consultant Applications",
    description: "Interviews සහ approval preparation.",
    action: "Review applications",
    rows: [
      ["Pending applications", "14", "New"],
      ["Interview stage", "6", "Scheduled"],
      ["Approved this month", "8", "Complete"]
    ]
  },
  "staff:Reports": {
    title: "Operations Reports",
    description: "Students, payments සහ course activity reports.",
    action: "Export report",
    rows: [
      ["Monthly admissions", "64 students", "July"],
      ["Approved revenue", "Rs. 3,200,000", "July"],
      ["Completion rate", "72%", "Current"]
    ]
  },
  "admin:Students": {
    title: "All Students",
    description: "Complete student and access administration.",
    action: "Manage students",
    rows: [
      ["Total students", "1,248", "Active platform"],
      ["Paid enrollments", "1,106", "88.6%"],
      ["Course completed", "798", "64%"]
    ]
  },
  "admin:Payments": {
    title: "Payments & Admissions",
    description: "Verification, approvals, refunds සහ audit records.",
    action: "Payment queue",
    rows: [
      ["Pending review", "18", "Action required"],
      ["Approved today", "12", "Rs. 600,000"],
      ["Partial payments", "7", "No points"],
      ["Rejected", "2", "Proof mismatch"]
    ]
  },
  "admin:Network": {
    title: "Network Administration",
    description: "SR/CN ownership, placement integrity සහ point balances.",
    action: "Open network",
    rows: [
      ["Active SR accounts", "1,122", "Students"],
      ["Active CN accounts", "184", "Consultants"],
      ["Unplaced accounts", "0", "Healthy"],
      ["90-day resets", "4", "This month"]
    ]
  },
  "admin:Commissions": {
    title: "Commissions & Payouts",
    description: "Friday cycles, approvals, wallets සහ payout ledger.",
    action: "Calculate cycle",
    rows: [
      ["Current cycle", "2026-W29", "Scheduled"],
      ["Estimated payout", "Rs. 684,500", "126 accounts"],
      ["Payout requests", "21", "Pending"],
      ["Ledger integrity", "No duplicates", "Healthy"]
    ]
  },
  "admin:Settings": {
    title: "Platform Settings",
    description: "Business rules, account limits සහ system configuration.",
    action: "Save settings",
    rows: [
      ["Account sequence", "Next 527711", "Protected"],
      ["Max CN accounts", "7 per consultant", "Configurable"],
      ["Commission day", "Friday", "Asia/Colombo"],
      ["Inactivity reset", "90 days", "Enabled"]
    ]
  }
};

type StudentPaymentView = {
  id: string;
  paymentCode: string;
  method: string;
  totalAmount: string;
  paidAmount: string;
  status: string;
  hasProof: boolean;
  transactionReference?: string | null;
};

type StudentCertificateView = {
  courseTitle: string;
  certificate: {
    certificateCode: string;
    issuedAt: string;
    revokedAt: string | null;
  };
};

type StudentBalanceView = {
  eligible: boolean;
  originalPaymentId?: string;
  courseId?: string;
  courseTitle?: string;
  halfPaymentLessonLimit?: number;
  outstandingAmount: number;
  request: null | { id: string; status: string; transactionReference: string; hasProof: boolean; reviewNote?: string | null };
};

function StudentBalancePaymentWorkspace() {
  const [data, setData] = useState<StudentBalanceView | null>(null);
  const [reference, setReference] = useState("");
  const [proof, setProof] = useState<File | null>(null);
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);
  async function load() {
    const response = await fetch("/api/student/balance-payment");
    if (!response.ok) { setMessage("Balance payment details load කළ නොහැක."); return; }
    setData(await response.json() as StudentBalanceView);
  }
  useEffect(() => { void load(); }, []);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!proof) { setMessage("Payment slip එක තෝරන්න."); return; }
    setSaving(true); setMessage("");
    const create = await fetch("/api/student/balance-payments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ transactionReference: reference }) });
    const created = await create.json().catch(() => ({})) as { request?: { id: string }; message?: string };
    if (!create.ok || !created.request) { setMessage(created.message ?? "Balance payment request submit වුණේ නැහැ."); setSaving(false); return; }
    const upload = await fetch(`/api/student/balance-payments/${created.request.id}/proof`, { method: "PUT", headers: { "Content-Type": proof.type }, body: proof });
    const uploaded = await upload.json().catch(() => ({})) as { message?: string };
    setMessage(upload.ok ? "Balance payment proof එක Admin review සඳහා submit කළා." : uploaded.message ?? "Slip upload failed.");
    if (upload.ok) { setReference(""); setProof(null); await load(); }
    setSaving(false);
  }
  if (!data) return <section className="dash-card workspace-card"><h3>Balance payment loading...</h3></section>;
  const canSubmit = data.eligible && (!data.request || data.request.status === "REJECTED");
  return <section className="dash-card workspace-card">
    <div className="workspace-heading"><div><span className="eyebrow">COURSE BALANCE</span><h2>Balance Payment</h2><p>Half payment එකේ ඉතිරි මුදල ගෙවා සියලු lessons unlock කරන්න.</p></div></div>
    <div className="metrics-grid"><MetricCard label="Amount due" value={`Rs. ${Number(data.outstandingAmount).toLocaleString()}`} note={data.courseTitle ?? "No outstanding course balance"} icon={<Wallet />} /><MetricCard label="Current access" value={data.eligible ? `${data.halfPaymentLessonLimit ?? 0} lessons` : "Fully paid"} note={data.eligible ? "Half-payment lesson access" : "No balance is due"} icon={<BookOpen />} /></div>
    {data.request && <p className={`status-badge ${data.request.status === "REJECTED" ? "warning" : "success"}`}>Latest request: {data.request.status.replaceAll("_", " ")}{data.request.reviewNote ? ` — ${data.request.reviewNote}` : ""}</p>}
    {canSubmit && <form className="course-admin-form" onSubmit={submit}>
      <label>Bank / transaction reference<input value={reference} onChange={(event) => setReference(event.target.value)} required minLength={3} /></label>
      <label>Payment slip<input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={(event) => setProof(event.target.files?.[0] ?? null)} required /></label>
      <button className="button button-primary" disabled={saving} type="submit">{saving ? "Submitting..." : "Submit balance payment"}</button>
    </form>}
    {message && <p className="form-error">{message}</p>}
  </section>;
}

type StudentQaCatalog = {
  courses: Array<{
    id: string;
    title: string;
    modules: Array<{
      id: string;
      title: string;
      position: number;
      lessons: Array<{
        id: string;
        title: string;
        position: number;
        questionCount: number;
        attemptNumber: number;
        completedAttempt: boolean;
        scorePercent: number | null;
      }>;
    }>;
  }>;
};

type StudentQaQuestion = {
  id: string;
  question: string;
  options: string[];
  position: number;
  answer: null | {
    selectedOption: number;
    isCorrect: boolean;
    correctOption: number;
    explanation: string | null;
  };
};

type StudentQaDetail = {
  lesson: {
    id: string;
    title: string;
    moduleTitle: string;
    courseTitle: string;
    videoProvider: string | null;
    videoId: string | null;
    durationSeconds: number;
  };
  questions: StudentQaQuestion[];
  attempt: null | {
    id: string;
    attemptNumber: number;
    scorePercent: number | null;
    completedAt: string | null;
  };
  answeredCount: number;
  canStart: boolean;
  retake: {
    eligible: boolean;
    watchedSeconds: number;
    requiredSeconds: number;
    progressPercent: number;
  };
};

function StudentQAndAWorkspace() {
  const [catalog, setCatalog] = useState<StudentQaCatalog>({ courses: [] });
  const [detail, setDetail] = useState<StudentQaDetail | null>(null);
  const [selectedLessonId, setSelectedLessonId] = useState("");
  const [expandedQuestionId, setExpandedQuestionId] = useState("");
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [watching, setWatching] = useState(false);
  const [message, setMessage] = useState("");
  const watchTickBusy = useRef(false);

  async function loadCatalog() {
    const response = await fetch("/api/student/q-and-a");
    const data = await response.json().catch(() => ({ courses: [] })) as StudentQaCatalog & { message?: string };
    if (!response.ok) throw new Error(data.message ?? "Q & A load failed.");
    setCatalog(data);
  }

  async function loadLesson(lessonId: string) {
    const response = await fetch(`/api/student/q-and-a/lessons/${lessonId}`);
    const data = await response.json().catch(() => ({})) as StudentQaDetail & { message?: string };
    if (!response.ok || !data.lesson) throw new Error(data.message ?? "Lesson quiz load failed.");
    setDetail(data);
  }

  useEffect(() => {
    loadCatalog().catch((error: Error) => setMessage(error.message)).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!watching || !selectedLessonId || !detail?.attempt?.completedAt || detail.retake.eligible) return;
    const timer = window.setInterval(async () => {
      if (document.hidden || watchTickBusy.current) return;
      watchTickBusy.current = true;
      try {
        const response = await fetch(`/api/student/q-and-a/lessons/${selectedLessonId}/watch`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ elapsedSeconds: 5 })
        });
        if (response.ok) await loadLesson(selectedLessonId);
      } finally {
        watchTickBusy.current = false;
      }
    }, 5000);
    return () => window.clearInterval(timer);
  }, [watching, selectedLessonId, detail?.attempt?.completedAt, detail?.retake.eligible]);

  async function openLesson(lessonId: string) {
    setSelectedLessonId(lessonId); setExpandedQuestionId(""); setMessage(""); setWatching(false); setWorking(true);
    try { await loadLesson(lessonId); } catch (error) { setDetail(null); setMessage(error instanceof Error ? error.message : "Quiz load failed."); }
    setWorking(false);
  }

  async function startAttempt() {
    if (!selectedLessonId) return;
    setWorking(true); setMessage("");
    const response = await fetch(`/api/student/q-and-a/lessons/${selectedLessonId}/attempts`, { method: "POST" });
    const data = await response.json().catch(() => ({})) as { message?: string };
    if (!response.ok) setMessage(data.message ?? "Quiz start කළ නොහැක.");
    else { setWatching(false); await Promise.all([loadLesson(selectedLessonId), loadCatalog()]); }
    setWorking(false);
  }

  async function answerQuestion(questionId: string, selectedOption: number) {
    if (!detail?.attempt || detail.attempt.completedAt) return;
    setWorking(true); setMessage("");
    const response = await fetch(`/api/student/q-and-a/attempts/${detail.attempt.id}/answers`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionId, selectedOption })
    });
    const data = await response.json().catch(() => ({})) as { message?: string };
    if (!response.ok) setMessage(data.message ?? "Answer save කළ නොහැක.");
    else await Promise.all([loadLesson(selectedLessonId), loadCatalog()]);
    setWorking(false);
  }

  const completed = Boolean(detail?.attempt?.completedAt);
  const score = detail?.attempt?.scorePercent ?? 0;
  const resultBand = score < 50 ? "red" : score < 75 ? "orange" : "green";
  const resultEmoji = score < 50 ? "😢" : score < 75 ? "😐" : "😊";
  const videoUrl = buildVideoEmbedUrl(detail?.lesson.videoProvider, detail?.lesson.videoId);

  if (loading) return <section className="dash-card workspace-card"><h3>Q & A loading...</h3></section>;

  return <section className="dash-card workspace-card qa-workspace">
    <div className="workspace-heading"><div><span className="eyebrow">SINHALA KNOWLEDGE CHECK</span><h2>Q & A</h2><p>ඔබ අවසන් කළ පාඩම්වල දැනුම පරීක්ෂා කරන්න. සෑම පිළිතුරක්ම පළමු වරට තෝරාගත් පසු lock වේ.</p></div></div>
    {message && <p className="form-error">{message}</p>}
    <div className="qa-layout">
      <aside className="qa-catalog" aria-label="Completed lesson quizzes">
        {!catalog.courses.length && <div className="workspace-note"><strong>තවම Q & A නැහැ.</strong><p>Lesson එක 100% අවසන් කළ පසු එහි quiz මෙහි පෙන්වයි.</p></div>}
        {catalog.courses.map((course) => <div key={course.id} className="qa-course">
          <h3>{course.title}</h3>
          {course.modules.map((module) => <div key={module.id} className="qa-module">
            <strong>{module.title}</strong>
            {module.lessons.map((lesson) => <button key={lesson.id} type="button" className={`qa-lesson-button ${selectedLessonId === lesson.id ? "active" : ""}`} onClick={() => void openLesson(lesson.id)}>
              <span>{lesson.title}<small>{lesson.questionCount} ප්‍රශ්න · Attempt {Math.max(1, lesson.attemptNumber || 1)}</small></span>
              <span>{lesson.scorePercent === null ? "Open" : `${lesson.scorePercent}%`}</span>
            </button>)}
          </div>)}
        </div>)}
      </aside>

      <div className="qa-main">
        {!detail && <div className="qa-empty"><Target /><h3>අවසන් කළ පාඩමක් තෝරන්න</h3><p>එම video පාඩමට අදාළ සිංහල ප්‍රශ්න මෙහි විවෘත වේ.</p></div>}
        {detail && <>
          <div className="qa-lesson-heading"><div><span className="eyebrow">{detail.lesson.moduleTitle}</span><h3>{detail.lesson.title}</h3><p>{detail.lesson.courseTitle} · {detail.questions.length} ප්‍රශ්න</p></div>{detail.attempt && <span className="status-badge success">Attempt {detail.attempt.attemptNumber}</span>}</div>
          {!detail.questions.length && <div className="workspace-note"><strong>මෙම පාඩමට ප්‍රශ්න තවම publish කර නැහැ.</strong><p>Admin Course panel එකෙන් Sinhala questions එකතු කළ හැක.</p></div>}
          {detail.questions.length > 0 && !detail.attempt && <div className="qa-start-card"><LockKeyhole /><div><h3>එක් පිළිතුරක් පමණයි</h3><p>පිළිතුරක් තෝරාගත් පසු නැවත වෙනස් කළ නොහැක.</p></div><button className="button button-primary" disabled={working || !detail.canStart} onClick={() => void startAttempt()}>Quiz එක අරඹන්න</button></div>}
          {detail.attempt && <div className="qa-question-list">
            {detail.questions.map((question, questionIndex) => {
              const expanded = expandedQuestionId === question.id;
              return <article className={`qa-question ${question.answer ? "locked" : ""} ${expanded ? "open" : ""}`} key={question.id}>
                <button className="qa-question-summary" type="button" onClick={() => setExpandedQuestionId(expanded ? "" : question.id)}>
                  <span className="qa-question-number">{String(questionIndex + 1).padStart(2, "0")}</span>
                  <span className="qa-question-copy"><small>ප්‍රශ්නය {questionIndex + 1}</small><strong>{question.question}</strong></span>
                  <span className="qa-question-icon">{question.answer ? <LockKeyhole /> : <ChevronRight />}</span>
                </button>
                {expanded && <div className="qa-options">
                  {question.options.map((option, optionIndex) => {
                    const answer = question.answer;
                    const isSelected = answer?.selectedOption === optionIndex;
                    const isCorrect = answer?.correctOption === optionIndex;
                    const optionClass = answer
                      ? isSelected && answer.isCorrect ? "selected-correct"
                        : isSelected ? "selected-wrong"
                          : isCorrect ? "correct-reveal" : ""
                      : "";
                    return <button key={`${question.id}-${optionIndex}`} className={`qa-option ${optionClass}`} type="button" disabled={working || Boolean(answer) || completed} onClick={() => void answerQuestion(question.id, optionIndex)}>
                      <span>{String.fromCharCode(65 + optionIndex)}</span><strong>{option}</strong>{answer && isCorrect && <Check />}
                    </button>;
                  })}
                  {question.answer && <div className={`qa-answer-note ${question.answer.isCorrect ? "correct" : "wrong"}`}><strong>{question.answer.isCorrect ? "නිවැරදියි!" : "පිළිතුර වැරදියි."}</strong>{question.answer.explanation && <p>{question.answer.explanation}</p>}</div>}
                </div>}
              </article>;
            })}
          </div>}

          {completed && <div className={`qa-result-banner qa-result-${resultBand}`}>
            <span className="qa-emoji" aria-hidden="true">{resultEmoji}</span><div><span>මෙම පාඩමේ දැනුම් මට්ටම</span><strong>{score}%</strong><p>{score < 50 ? "Video පාඩම නැවත හොඳින් බලන්න." : score < 75 ? "හොඳ උත්සාහයක් — තවත් ටිකක් පුහුණු වෙමු." : "විශිෂ්ටයි! පාඩම හොඳින් අවබෝධ කරගෙන ඇත."}</p></div>
          </div>}

          {completed && <div className="qa-rewatch">
            <div><span className="eyebrow">RETAKE ACCESS</span><h3>Video එක අවම 50%ක් නැවත බලන්න</h3><p>Quiz එක නැවත කිරීමට same video එකෙන් අවශ්‍ය කොටස නැවත සම්පූර්ණ කරන්න.</p></div>
            {videoUrl ? <div className="qa-video"><iframe src={videoUrl} title={`${detail.lesson.title} video`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen /></div> : <div className="workspace-note"><strong>Video එක තවම සම්බන්ධ කර නැහැ.</strong><p>Admin විසින් Video ID සහ duration එක add කළ යුතුයි.</p></div>}
            <div className="qa-progress-row"><div><span>Rewatch progress</span><strong>{detail.retake.progressPercent}%</strong></div><div className="qa-progress"><span style={{ width: `${detail.retake.progressPercent}%` }} /></div><small>{Math.floor(detail.retake.watchedSeconds / 60)} / {Math.ceil(detail.retake.requiredSeconds / 60)} minutes</small></div>
            <div className="qa-rewatch-actions">
              {videoUrl && !detail.retake.eligible && <button type="button" className="button button-ghost" onClick={() => setWatching((current) => !current)}>{watching ? "Tracking නවත්වන්න" : "Rewatch tracking අරඹන්න"}</button>}
              <button type="button" className="button button-primary" disabled={working || !detail.retake.eligible} onClick={() => void startAttempt()}>{detail.retake.eligible ? "Quiz එක නැවත කරන්න" : "50% සම්පූර්ණ කළ පසු unlock වේ"}</button>
            </div>
          </div>}
        </>}
      </div>
    </div>
  </section>;
}

type StudentLessonDetail = {
  enrollmentId: string;
  accessLevel: "HALF" | "FULL";
  lesson: {
    id: string;
    title: string;
    moduleTitle: string;
    courseTitle: string;
    videoProvider: string | null;
    videoId: string | null;
    content: string | null;
    durationSeconds: number;
    progressPercent: number;
  };
};

function StudentCourseWorkspace({
  summary,
  onSummaryUpdate
}: {
  summary: StudentDashboardSummary;
  onSummaryUpdate: (value: StudentDashboardSummary) => void;
}) {
  const [detail, setDetail] = useState<StudentLessonDetail | null>(null);
  const [selectedLessonId, setSelectedLessonId] = useState("");
  const [loadingLesson, setLoadingLesson] = useState(false);
  const [savingProgress, setSavingProgress] = useState(false);
  const [message, setMessage] = useState("");
  const canLearn = summary.enrollmentStatus === "ACTIVE" || summary.enrollmentStatus === "COMPLETED";
  const firstUnlockedLesson = summary.modules
    .flatMap((module) => module.lessons ?? [])
    .find((lesson) => !lesson.locked);

  async function openLesson(lessonId: string) {
    setSelectedLessonId(lessonId);
    setLoadingLesson(true);
    setMessage("");
    const response = await fetch(`/api/student/lessons/${lessonId}`);
    const data = await response.json().catch(() => ({})) as StudentLessonDetail & { message?: string };
    if (!response.ok || !data.lesson) {
      setDetail(null);
      setMessage(data.message ?? "Lesson එක load කළ නොහැක.");
    } else {
      setDetail(data);
    }
    setLoadingLesson(false);
  }

  useEffect(() => {
    if (canLearn && !selectedLessonId && firstUnlockedLesson) void openLesson(firstUnlockedLesson.id);
  }, [canLearn, selectedLessonId, firstUnlockedLesson?.id]);

  async function saveProgress(progressPercent: number) {
    if (!detail) return;
    setSavingProgress(true);
    setMessage("");
    const response = await fetch("/api/student/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        enrollmentId: detail.enrollmentId,
        lessonId: detail.lesson.id,
        progressPercent
      })
    });
    const data = await response.json().catch(() => ({})) as { message?: string };
    if (!response.ok) {
      setMessage(data.message ?? "Lesson progress save කළ නොහැක.");
    } else {
      setDetail({
        ...detail,
        lesson: { ...detail.lesson, progressPercent }
      });
      const summaryResponse = await fetch("/api/student/dashboard-summary");
      if (summaryResponse.ok) onSummaryUpdate(await summaryResponse.json() as StudentDashboardSummary);
      setMessage(progressPercent === 100 ? "පාඩම Completed ලෙස save කළා. දැන් Q & A tab එකෙන් ප්‍රශ්න කරන්න පුළුවන්." : "Progress save කළා.");
    }
    setSavingProgress(false);
  }

  const videoUrl = buildVideoEmbedUrl(detail?.lesson.videoProvider, detail?.lesson.videoId);
  const durationMinutes = detail ? Math.max(0, Math.ceil(detail.lesson.durationSeconds / 60)) : 0;

  return <section className="dash-card workspace-card student-course-workspace">
    <div className="workspace-heading">
      <div>
        <span className="eyebrow">ADIL ACADEMY LEARNING PORTAL</span>
        <h2>{summary.courseTitle ?? "Course access pending"}</h2>
        <p>{summary.accessLevel === "HALF"
          ? `Half payment access යටතේ පළමු lessons ${summary.halfPaymentLessonLimit ?? 0} පමණක් unlock වී ඇත.`
          : "Module එකක් තෝරා lesson video එක බලන්න."}</p>
      </div>
      <span className="status-badge success">{summary.progressPercent}% COMPLETE</span>
    </div>

    {!canLearn ? <div className="workspace-note">
      <strong>Course access තවම active නැහැ.</strong>
      <p>Payment approval සම්පූර්ණ වූ පසු lesson videos මෙහි පෙන්වයි.</p>
    </div> : <div className="student-course-layout">
      <aside className="student-course-catalog">
        {summary.modules.map((module, moduleIndex) => <div className="student-course-module" key={`${module.title}-${moduleIndex}`}>
          <div className="student-course-module-heading">
            <span>MODULE {String(moduleIndex + 1).padStart(2, "0")}</span>
            <strong>{module.title}</strong>
            <small>{module.completedLessons}/{module.totalLessons} completed</small>
          </div>
          <div className="student-course-lessons">
            {(module.lessons ?? []).map((lesson, lessonIndex) => <button
              type="button"
              key={lesson.id}
              className={`${selectedLessonId === lesson.id ? "active" : ""} ${lesson.locked ? "locked" : ""}`}
              disabled={lesson.locked}
              onClick={() => void openLesson(lesson.id)}
            >
              <span className="student-course-lesson-icon">
                {lesson.locked ? <LockKeyhole size={15} /> : lesson.progressPercent === 100 ? <Check size={15} /> : <Play size={15} />}
              </span>
              <span>
                <b>{lessonIndex + 1}. {lesson.title}</b>
                <small>{lesson.locked ? "Balance payment required" : lesson.progressPercent === 100 ? "Completed" : lesson.progressPercent ? `${lesson.progressPercent}% watched` : "Ready to watch"}</small>
              </span>
              <ChevronRight size={15} />
            </button>)}
          </div>
        </div>)}
      </aside>

      <div className="student-course-player">
        {loadingLesson ? <div className="qa-empty"><BookOpen size={36} /><h3>Lesson loading...</h3></div> : !detail ? <div className="qa-empty"><Play size={38} /><h3>Lesson එකක් තෝරන්න</h3><p>වම් පැත්තේ unlocked lesson එක click කරන්න.</p></div> : <>
          <div className="student-course-player-heading">
            <div>
              <span className="eyebrow">{detail.lesson.moduleTitle}</span>
              <h3>{detail.lesson.title}</h3>
              <p>{durationMinutes ? `Video duration: ${durationMinutes} minutes` : "Video duration එක තවම set කර නැහැ."}</p>
            </div>
            <span className={`status-badge ${detail.lesson.progressPercent === 100 ? "success" : "warning"}`}>
              {detail.lesson.progressPercent === 100 ? "COMPLETED" : "IN PROGRESS"}
            </span>
          </div>

          {videoUrl ? <div className="student-lesson-video">
            <iframe
              src={videoUrl}
              title={`${detail.lesson.title} video`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            />
          </div> : <div className="workspace-note">
            <strong>Video link එක හඳුනාගත නොහැක.</strong>
            <p>Admin panel එකේ YouTube/Vimeo URL එක හෝ Video ID එක නිවැරදිව add කරන්න.</p>
          </div>}

          {detail.lesson.content && <div className="student-lesson-note">
            <span className="eyebrow">LESSON NOTE</span>
            <p>{detail.lesson.content}</p>
          </div>}

          <div className="student-lesson-progress">
            <div>
              <span>Lesson progress</span>
              <strong>{detail.lesson.progressPercent}%</strong>
            </div>
            <div className="progress-track large"><span style={{ width: `${detail.lesson.progressPercent}%` }} /></div>
            <button
              type="button"
              className="button button-primary"
              disabled={savingProgress || detail.lesson.progressPercent === 100 || !videoUrl}
              onClick={() => void saveProgress(100)}
            >
              <Check size={17} />
              {savingProgress ? "Saving..." : detail.lesson.progressPercent === 100 ? "Lesson completed" : "Video බැලූ පසු lesson එක complete කරන්න"}
            </button>
          </div>
        </>}
      </div>
    </div>}
    {message && <p className={message.includes("Completed") ? "workspace-note" : "form-error"}>{message}</p>}
  </section>;
}

function StudentFeatureWorkspace({ module }: { module: string }) {
  const [summary, setSummary] = useState<StudentDashboardSummary | null>(null);
  const [payments, setPayments] = useState<StudentPaymentView[]>([]);
  const [certificates, setCertificates] = useState<StudentCertificateView[]>([]);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    Promise.all([
      fetch("/api/student/dashboard-summary"),
      fetch("/api/student/payments"),
      fetch("/api/student/certificates")
    ]).then(async ([summaryResponse, paymentsResponse, certificatesResponse]) => {
      if (!summaryResponse.ok || !paymentsResponse.ok || !certificatesResponse.ok) {
        throw new Error("Student workspace request failed");
      }
      const summaryData = await summaryResponse.json() as StudentDashboardSummary;
      const paymentData = await paymentsResponse.json() as { payments: StudentPaymentView[] };
      const certificateData = await certificatesResponse.json() as { certificates: StudentCertificateView[] };
      setSummary(summaryData);
      setPayments(paymentData.payments);
      setCertificates(certificateData.certificates);
    }).catch(() => setFailed(true)).finally(() => setLoading(false));
  }, []);

  if (module === "Q & A") return <StudentQAndAWorkspace />;
  if (module === "Balance Payment") return <StudentBalancePaymentWorkspace />;

  if (loading) return <section className="dash-card workspace-card"><h3>Loading...</h3></section>;
  if (failed || !summary) return <section className="dash-card workspace-card"><h3>Data load කළ නොහැක</h3><p>Page එක refresh කරන්න.</p></section>;
  if (module === "My Course") return <StudentCourseWorkspace summary={summary} onSummaryUpdate={setSummary} />;

  let title = module;
  let description = "ඔබගේ සැබෑ account data සහ course activity.";
  let rows: [string, string, string][] = [];
  if (module === "My Course") {
    title = summary.courseTitle ?? "Course access pending";
    description = summary.enrollmentStatus === "NOT_ENROLLED"
      ? "Full payment එක Admin approve කළ පසු course lessons unlock වේ."
      : "ඔබගේ active course modules සහ progress.";
    rows = summary.modules.length
      ? summary.modules.map((item, index) => [
          `Module ${String(index + 1).padStart(2, "0")}`,
          item.title,
          item.progressPercent === 100 ? "Completed" : item.progressPercent ? `${item.progressPercent}%` : "Not started"
        ])
      : [["Course access", "Payment approval required", "Locked"]];
    if (summary.accessLevel === "HALF") description = `Half payment access: පළමු lessons ${summary.halfPaymentLessonLimit ?? 0} පමණක් unlock වී ඇත. Balance Payment approve වූ පසු සියල්ල unlock වේ.`;
  } else if (module === "Progress") {
    title = "Learning Progress";
    rows = [
      ["Lessons completed", `${summary.completedLessons} of ${summary.totalLessons}`, `${summary.progressPercent}%`],
      ["Quiz average", summary.quizAverage === null ? "No attempts" : `${summary.quizAverage}%`, summary.quizAverage === null ? "Not started" : "Recorded"],
      ["Recent activity", summary.recentActivity.length ? `${summary.recentActivity.length} updates` : "No activity", summary.recentActivity.length ? "Active" : "Not started"],
      ["Course access", summary.courseTitle ?? "Not enrolled", summary.enrollmentStatus]
    ];
  } else if (module === "Certificates") {
    title = "Certificates";
    description = "සියලු lessons සහ required quizzes complete කළ පසු certificate නිකුත් වේ.";
    rows = certificates.length
      ? certificates.map((item) => [item.courseTitle, item.certificate.certificateCode, item.certificate.revokedAt ? "Revoked" : "Issued"])
      : [
          [summary.courseTitle ?? "Crypto Trading — Zero to Pro", `${summary.progressPercent}% complete`, "Not issued"],
          ["All lessons", `${summary.completedLessons} of ${summary.totalLessons}`, summary.progressPercent === 100 ? "Completed" : "Pending"],
          ["Quiz result", summary.quizAverage === null ? "No attempts" : `${summary.quizAverage}%`, summary.quizAverage !== null && summary.quizAverage >= 70 ? "Passed" : "Pending"]
        ];
  } else if (module === "Payments") {
    title = "Payment History";
    description = "ඔබ submit කළ Bank Transfer සහ USDT payments පමණක් මෙහි පෙන්වයි.";
    rows = payments.length
      ? payments.map((item) => [
          item.paymentCode,
          `${item.method.replaceAll("_", " ")} • Rs. ${Number(item.paidAmount).toLocaleString()}`,
          item.status.replaceAll("_", " ")
        ])
      : [["No payments", "Payment request එකක් තවම submit කර නැහැ", "Empty"]];
  }

  return (
    <section className="dash-card workspace-card">
      <div className="workspace-heading">
        <div>
          <span className="eyebrow">ADIL ACADEMY STUDENT PORTAL</span>
          <h2>{title}</h2>
          <p>{description}</p>
        </div>
      </div>
      <div className="workspace-list">
        <div className="workspace-list-head"><span>Item</span><span>Details</span><span>Status</span></div>
        {rows.map((row, index) => (
          <div className="workspace-list-row" key={`${row[0]}-${index}`}>
            <strong>{row[0]}</strong><span>{row[1]}</span><span className="status-badge success">{row[2]}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

type AdminStudentView = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  nicOrPassport: string | null;
  address: string | null;
  dateOfBirth: string | null;
  isActive: boolean;
  emailVerifiedAt: string | null;
  passwordSetAt: string | null;
  createdAt: string;
  enrollment: { status: string; courseTitle: string } | null;
  account: { number: string; status: string } | null;
  latestPayment: { status: string; paidAmount: string; totalAmount: string; paymentCode: string } | null;
};

type AdminConsultantView = {
  id: string; name: string; email: string; phone: string | null;
  isActive: boolean; createdAt: string;
  accounts: Array<{ number: string; prefix: string; numericPart: number; status: string }>;
};
type AdminConsultantProfile = {
  consultant: AdminConsultantView & { nicOrPassport: string | null; address: string | null; dateOfBirth: string | null };
  accounts: Array<{ id: string; number: string; status: string; isMainAccount: boolean }>;
  financials: { totalIncome: number; pendingIncome: number; availableBalance: number; weeklyPayable: number; requestedPayouts: number; totalPaid: number };
  bankDetails: null | { bankName: string; branchName: string; accountHolderName: string; accountNumber: string; updatedAt: string };
  recentPayouts: Array<{ id: string; amount: string; status: string; createdAt: string }>;
};

type AdminAccountView = {
  id: string; number: string; prefix: string; numericPart: number; status: string;
  isMainAccount: boolean; ownerId: string; ownerName: string; ownerEmail: string; ownerPhone: string | null;
  ownerRole: UserRole;
  learningPortalEnabled: boolean;
};

type AdminCourseView = {
  id: string; title: string; slug: string; shortDescription: string; description: string | null;
  price: string; currency: string; points: number; isPublished: boolean; thumbnailUrl: string | null; halfPaymentLessonLimit: number;
  sections: Array<{ id: string; title: string; position: number; lessons: Array<{
    id: string; title: string; position: number; videoProvider: string | null; videoId: string | null; content: string | null; durationSeconds: number;
  }> }>;
};

type AdminQuizQuestion = {
  id: string;
  lessonId: string;
  question: string;
  options: string[];
  correctOption: number;
  explanation: string | null;
  position: number;
  isPublished: boolean;
};

const emptyQuizEditor = {
  question: "",
  options: ["", "", "", "", ""],
  correctOption: 0,
  explanation: "",
  position: 1,
  isPublished: true
};

function LessonQuizManager({ courses }: { courses: AdminCourseView[] }) {
  const lessons = courses.flatMap((course) => course.sections.flatMap((section) => section.lessons.map((lesson) => ({
    ...lesson,
    courseTitle: course.title,
    moduleTitle: section.title
  }))));
  const [lessonId, setLessonId] = useState("");
  const [questions, setQuestions] = useState<AdminQuizQuestion[]>([]);
  const [editor, setEditor] = useState({ ...emptyQuizEditor, options: [...emptyQuizEditor.options] });
  const [editingId, setEditingId] = useState("");
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);

  async function loadQuestions(targetLessonId = lessonId) {
    if (!targetLessonId) { setQuestions([]); return; }
    const response = await fetch(`/api/admin/lessons/${targetLessonId}/q-and-a`);
    const data = await response.json().catch(() => ({ questions: [] })) as { questions: AdminQuizQuestion[]; message?: string };
    if (!response.ok) { setMessage(data.message ?? "Questions load failed."); return; }
    setQuestions(data.questions);
  }

  useEffect(() => { if (!lessonId && lessons[0]?.id) setLessonId(lessons[0].id); }, [lessonId, lessons]);
  useEffect(() => { void loadQuestions(lessonId); }, [lessonId]);

  function resetEditor(nextPosition = questions.length + 1) {
    setEditingId("");
    setEditor({ ...emptyQuizEditor, position: nextPosition, options: [...emptyQuizEditor.options] });
  }

  function editQuestion(question: AdminQuizQuestion) {
    setEditingId(question.id);
    setEditor({
      question: question.question,
      options: [...question.options],
      correctOption: question.correctOption,
      explanation: question.explanation ?? "",
      position: question.position,
      isPublished: question.isPublished
    });
  }

  async function saveQuestion(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!lessonId || editor.options.some((option) => !option.trim())) return;
    setSaving(true); setMessage("");
    const response = await fetch(editingId ? `/api/admin/lesson-q-and-a/${editingId}` : `/api/admin/lessons/${lessonId}/q-and-a`, {
      method: editingId ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question: editor.question.trim(),
        options: editor.options.map((option) => option.trim()),
        correctOption: editor.correctOption,
        explanation: editor.explanation.trim() || null,
        position: editor.position,
        isPublished: editor.isPublished
      })
    });
    const data = await response.json().catch(() => ({})) as { message?: string };
    if (!response.ok) setMessage(data.message ?? "Question save failed.");
    else { await loadQuestions(lessonId); resetEditor(editingId ? editor.position : questions.length + 2); setMessage(editingId ? "Question updated." : "Sinhala question published."); }
    setSaving(false);
  }

  async function archiveQuestion(questionId: string) {
    if (!window.confirm("මෙම question එක student Q & A එකෙන් ඉවත් කරන්නද?")) return;
    const response = await fetch(`/api/admin/lesson-q-and-a/${questionId}`, { method: "DELETE" });
    setMessage(response.ok ? "Question archived." : "Question archive failed.");
    if (response.ok) await loadQuestions(lessonId);
  }

  const selectedLesson = lessons.find((lesson) => lesson.id === lessonId);
  return <section className="qa-admin">
    <div className="workspace-heading"><div><span className="eyebrow">LESSON Q & A MANAGER</span><h3>Sinhala Quiz Questions</h3><p>සෑම lesson video එකකටම පිළිතුරු 5ක් සහිත ප්‍රශ්න publish කරන්න.</p></div></div>
    {!lessons.length ? <div className="workspace-note"><strong>Quiz එකක් සෑදීමට lesson එකක් add කරන්න.</strong></div> : <>
      <label className="qa-lesson-select">Course / module / lesson<select value={lessonId} onChange={(event) => { setLessonId(event.target.value); resetEditor(1); }}>
        {lessons.map((lesson) => <option value={lesson.id} key={lesson.id}>{lesson.courseTitle} — {lesson.moduleTitle} — {lesson.title}</option>)}
      </select></label>
      {selectedLesson && <div className="workspace-note"><strong>{selectedLesson.title}</strong><p>Video duration: {selectedLesson.durationSeconds ? `${Math.ceil(selectedLesson.durationSeconds / 60)} minutes` : "not set — retake tracking සඳහා duration එක add කරන්න"}</p></div>}
      <form className="qa-question-editor" onSubmit={saveQuestion}>
        <label className="wide">සිංහල ප්‍රශ්නය<textarea value={editor.question} onChange={(event) => setEditor({ ...editor, question: event.target.value })} required minLength={5} /></label>
        {editor.options.map((option, index) => <label key={index}>පිළිතුර {index + 1}<input value={option} onChange={(event) => { const options = [...editor.options]; options[index] = event.target.value; setEditor({ ...editor, options }); }} required /></label>)}
        <label>නිවැරදි පිළිතුර<select value={editor.correctOption} onChange={(event) => setEditor({ ...editor, correctOption: Number(event.target.value) })}>{editor.options.map((_, index) => <option value={index} key={index}>පිළිතුර {index + 1}</option>)}</select></label>
        <label>Position<input type="number" min="1" value={editor.position} onChange={(event) => setEditor({ ...editor, position: Number(event.target.value) })} required /></label>
        <label className="wide">පිළිතුරේ පැහැදිලි කිරීම (optional)<textarea value={editor.explanation} onChange={(event) => setEditor({ ...editor, explanation: event.target.value })} /></label>
        <label className="check-label"><input type="checkbox" checked={editor.isPublished} onChange={(event) => setEditor({ ...editor, isPublished: event.target.checked })} /> Studentට publish කරන්න</label>
        <div className="qa-editor-actions"><button type="submit" className="button button-primary" disabled={saving}>{saving ? "Saving..." : editingId ? "Update question" : "Publish question"}</button>{editingId && <button type="button" className="button button-ghost" onClick={() => resetEditor()}>Cancel edit</button>}</div>
      </form>
      {message && <p className="form-error">{message}</p>}
      <div className="qa-admin-list">{questions.map((question, index) => <article key={question.id}><span>{index + 1}</span><div><strong>{question.question}</strong><small>{question.isPublished ? "Published" : "Archived"} · Correct: {question.options[question.correctOption]}</small></div><button type="button" onClick={() => editQuestion(question)}>Edit</button><button type="button" onClick={() => void archiveQuestion(question.id)}>Archive</button></article>)}{!questions.length && <p>මෙම lesson එකට questions තවම add කර නැහැ.</p>}</div>
    </>}
  </section>;
}

function CourseManagementWorkspace() {
  const [courses, setCourses] = useState<AdminCourseView[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState("");
  const [message, setMessage] = useState("");
  const [creating, setCreating] = useState(false);
  const [sectionTitle, setSectionTitle] = useState("");
  const [lesson, setLesson] = useState({ sectionId: "", title: "", videoProvider: "youtube", videoId: "", content: "", durationMinutes: "" });
  const course = courses.find((item) => item.id === selectedCourseId) ?? courses[0];
  async function load() {
    const response = await fetch("/api/admin/courses");
    if (response.ok) {
      const items = ((await response.json()) as { courses: AdminCourseView[] }).courses;
      setCourses(items);
      setSelectedCourseId((current) => current || items[0]?.id || "");
    }
  }
  useEffect(() => { void load(); }, []);
  async function createCourse(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setCreating(true); setMessage("");
    const form = new FormData(event.currentTarget);
    const title = String(form.get("newTitle") ?? "").trim();
    const slugBase = title.toLowerCase().normalize("NFKD").replace(/[^a-z0-9\s-]/g, "").trim().replace(/\s+/g, "-").replace(/-+/g, "-");
    const response = await fetch("/api/admin/courses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
      title, slug: slugBase || `course-${Date.now()}`, shortDescription: String(form.get("newShortDescription") ?? ""),
      description: String(form.get("newDescription") ?? ""), price: Number(form.get("newPrice")), halfPaymentLessonLimit: Number(form.get("newHalfLimit") ?? 7), currency: "LKR", points: 0, isPublished: true
    }) });
    const data = await response.json().catch(() => ({})) as { course?: AdminCourseView; message?: string };
    if (!response.ok || !data.course) { setMessage(data.message ?? "Course add failed."); setCreating(false); return; }
    const image = form.get("newThumbnail");
    if (image instanceof File && image.size > 0) {
      const upload = await fetch(`/api/admin/courses/${data.course.id}/thumbnail`, { method: "PUT", headers: { "Content-Type": image.type }, body: image });
      if (!upload.ok) setMessage("Course එක add වුණා. Cover photo upload වුණේ නැහැ.");
    }
    event.currentTarget.reset(); setSelectedCourseId(data.course.id); await load();
    setMessage((current) => current || "New course එක publish කර සාර්ථකව add කළා."); setCreating(false);
  }
  async function uploadThumbnail(file: File) {
    if (!course) return;
    const response = await fetch(`/api/admin/courses/${course.id}/thumbnail`, { method: "PUT", headers: { "Content-Type": file.type }, body: file });
    setMessage(response.ok ? "Course cover photo updated." : "Cover photo upload failed.");
    if (response.ok) await load();
  }
  async function saveCourse(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!course) return;
    const form = new FormData(event.currentTarget);
    const response = await fetch(`/api/admin/courses/${course.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: String(form.get("title")), shortDescription: String(form.get("shortDescription")),
        description: String(form.get("description")), price: Number(form.get("price")),
        halfPaymentLessonLimit: Number(form.get("halfPaymentLessonLimit")),
        isPublished: form.get("isPublished") === "on"
      })
    });
    setMessage(response.ok ? "Course details saved." : "Course save failed.");
    if (response.ok) await load();
  }
  async function addSection(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!course || !sectionTitle.trim()) return;
    const response = await fetch("/api/admin/course-sections", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ courseId: course.id, title: sectionTitle, position: course.sections.length + 1 }) });
    setMessage(response.ok ? "Module added." : "Module add failed."); setSectionTitle(""); if (response.ok) await load();
  }
  async function addLesson(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!lesson.sectionId || !lesson.title.trim()) return;
    const section = course?.sections.find((item) => item.id === lesson.sectionId);
    const response = await fetch("/api/admin/lessons", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
      sectionId: lesson.sectionId, title: lesson.title, videoProvider: lesson.videoId ? lesson.videoProvider : undefined,
      videoId: lesson.videoId || undefined, content: lesson.content || undefined, durationSeconds: Math.max(0, Number(lesson.durationMinutes || 0) * 60),
      position: (section?.lessons.length ?? 0) + 1, isPreview: false
    }) });
    setMessage(response.ok ? "Lesson added." : "Lesson add failed.");
    if (response.ok) { setLesson({ sectionId: lesson.sectionId, title: "", videoProvider: "youtube", videoId: "", content: "", durationMinutes: "" }); await load(); }
  }
  async function renameSection(section: AdminCourseView["sections"][number]) {
    const title = window.prompt("Module title", section.title); if (!title?.trim()) return;
    const response = await fetch(`/api/admin/course-sections/${section.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title }) });
    if (response.ok) await load();
  }
  async function editLesson(item: AdminCourseView["sections"][number]["lessons"][number]) {
    const title = window.prompt("Lesson title", item.title); if (!title?.trim()) return;
    const videoId = window.prompt("YouTube/Vimeo Video ID (හිස්ව තැබිය හැක)", item.videoId ?? "");
    const durationMinutes = window.prompt("Video duration (minutes)", String(Math.ceil((item.durationSeconds || 0) / 60)));
    const response = await fetch(`/api/admin/lessons/${item.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title, videoId: videoId || undefined, videoProvider: videoId ? (item.videoProvider ?? "youtube") : undefined, durationSeconds: Math.max(0, Number(durationMinutes || 0) * 60) }) });
    if (response.ok) await load();
  }
  if (!course && !courses.length) return <section className="dash-card workspace-card"><h3>Course data loading...</h3></section>;
  return <section className="dash-card workspace-card course-manager">
    <div className="workspace-heading"><div><span className="eyebrow">MULTI-COURSE MANAGEMENT</span><h2>Courses, Photos & Lessons</h2><p>Course name එක type කර photo එකක් සමඟ add කළාම Home page සහ Admission form එකට ස්වයංක්‍රීයව එකතු වේ.</p></div></div>
    {message && <p className="form-error">{message}</p>}
    <form className="course-create-card" onSubmit={createCourse}>
      <div><span className="eyebrow">ADD A NEW COURSE</span><h3>නව පාඨමාලාවක් එකතු කරන්න</h3></div>
      <label>Course name<input name="newTitle" placeholder="උදා: Forex Trading Masterclass" required minLength={3} /></label>
      <label>Price (LKR)<input name="newPrice" type="number" min="1" placeholder="25000" required /></label>
      <label>Half-payment lesson limit<input name="newHalfLimit" type="number" min="0" defaultValue="7" required /></label>
      <label className="wide">Short description<input name="newShortDescription" placeholder="Course card එකේ පෙන්වන කෙටි විස්තරය" required minLength={10} /></label>
      <label className="wide">Full description<textarea name="newDescription" placeholder="පාඨමාලාව ගැන සම්පූර්ණ විස්තරය" /></label>
      <label className="wide">Course cover photo<input name="newThumbnail" type="file" accept="image/jpeg,image/png,image/webp" /></label>
      <button className="button button-primary" disabled={creating} type="submit">{creating ? "Adding..." : "Add & publish course"}</button>
    </form>
    <div className="course-selector" aria-label="Select a course">{courses.map((item) => <button type="button" className={item.id === course?.id ? "active" : ""} key={item.id} onClick={() => setSelectedCourseId(item.id)}>{item.thumbnailUrl && <img src={`/api/courses/${item.id}/thumbnail`} alt="" />}<span>{item.title}<small>{item.isPublished ? "Published" : "Draft"}</small></span></button>)}</div>
    {course && <>
    <div className="course-current-heading"><div>{course.thumbnailUrl ? <img src={`/api/courses/${course.id}/thumbnail`} alt={`${course.title} cover`} /> : <span><BookOpen /></span>}</div><div><span className="eyebrow">EDIT SELECTED COURSE</span><h3>{course.title}</h3><label className="button button-ghost">Change cover photo<input type="file" hidden accept="image/jpeg,image/png,image/webp" onChange={(event) => { const file = event.target.files?.[0]; if (file) void uploadThumbnail(file); }} /></label></div></div>
    <form className="course-admin-form" onSubmit={saveCourse}>
      <label>Course title<input name="title" defaultValue={course.title} required /></label>
      <label>Price (LKR)<input name="price" type="number" defaultValue={course.price} required /></label>
      <label>Half-payment lesson limit<input name="halfPaymentLessonLimit" type="number" min="0" defaultValue={course.halfPaymentLessonLimit} required /></label>
      <label className="wide">Short description<input name="shortDescription" defaultValue={course.shortDescription} required /></label>
      <label className="wide">Full description<textarea name="description" defaultValue={course.description ?? ""} /></label>
      <label className="check-label"><input name="isPublished" type="checkbox" defaultChecked={course.isPublished} /> Public sales page එකේ publish කරන්න</label>
      <button className="button button-primary" type="submit">Save course</button>
    </form>
    <form className="course-inline-form" onSubmit={addSection}><input value={sectionTitle} onChange={(e) => setSectionTitle(e.target.value)} placeholder="New module title" required /><button className="button button-primary" type="submit">Add module</button></form>
    <form className="course-admin-form" onSubmit={addLesson}>
      <label>Module<select value={lesson.sectionId} onChange={(e) => setLesson({ ...lesson, sectionId: e.target.value })} required><option value="">Select module</option>{course.sections.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
      <label>Lesson title<input value={lesson.title} onChange={(e) => setLesson({ ...lesson, title: e.target.value })} required /></label>
      <label>Video provider<select value={lesson.videoProvider} onChange={(e) => setLesson({ ...lesson, videoProvider: e.target.value })}><option value="youtube">YouTube</option><option value="vimeo">Vimeo</option></select></label>
      <label>YouTube/Vimeo URL or Video ID<input value={lesson.videoId} onChange={(e) => setLesson({ ...lesson, videoId: e.target.value })} placeholder="https://youtu.be/... හෝ Video ID" /></label>
      <label>Video duration (minutes)<input type="number" min="0" value={lesson.durationMinutes} onChange={(e) => setLesson({ ...lesson, durationMinutes: e.target.value })} placeholder="උදා: 12" /></label>
      <label className="wide">Lesson notes<textarea value={lesson.content} onChange={(e) => setLesson({ ...lesson, content: e.target.value })} /></label>
      <button className="button button-primary" type="submit">Add lesson</button>
    </form>
    <div className="course-content-list">{course.sections.map((section) => <div key={section.id} className="course-module-admin"><div><strong>{section.title}</strong><button type="button" onClick={() => void renameSection(section)}>Rename</button></div>{section.lessons.map((item) => <button type="button" key={item.id} onClick={() => void editLesson(item)}><span>{item.title}</span><small>{item.videoId ? `${item.videoProvider}: ${item.videoId}` : "Video not added"}</small></button>)}{!section.lessons.length && <p>No lessons yet.</p>}</div>)}</div>
    <LessonQuizManager courses={courses} />
    </>}
  </section>;
}

function AdminFeatureWorkspace({ module }: { module: string }) {
  const [students, setStudents] = useState<AdminStudentView[]>([]);
  const [payments, setPayments] = useState<AdminPaymentView[]>([]);
  const [balancePayments, setBalancePayments] = useState<AdminBalancePaymentView[]>([]);
  const [consultants, setConsultants] = useState<AdminConsultantView[]>([]);
  const [accounts, setAccounts] = useState<AdminAccountView[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [consultantProfile, setConsultantProfile] = useState<AdminConsultantProfile | null>(null);
  const [paymentFilter, setPaymentFilter] = useState<"FULL" | "HALF" | "BALANCE">("FULL");
  const [controlledAccount, setControlledAccount] = useState<AdminAccountView | null>(null);
  const [showStudentRegistration, setShowStudentRegistration] = useState(false);

  async function refresh() {
    setLoading(true);
    try {
      await fetch("/api/admin/accounts/repair", { method: "POST" });
      const [studentResponse, paymentResponse, balanceResponse, consultantResponse, accountResponse] = await Promise.all([
        fetch("/api/admin/students"), fetch("/api/admin/payments"),
        fetch("/api/admin/balance-payments"),
        fetch("/api/admin/consultants"), fetch("/api/admin/accounts")
      ]);
      if (!studentResponse.ok || !paymentResponse.ok || !balanceResponse.ok || !consultantResponse.ok || !accountResponse.ok) throw new Error("Admin workspace failed");
      setStudents(((await studentResponse.json()) as { students: AdminStudentView[] }).students);
      setPayments(((await paymentResponse.json()) as { payments: AdminPaymentView[] }).payments);
      setBalancePayments(((await balanceResponse.json()) as { requests: AdminBalancePaymentView[] }).requests);
      setConsultants(((await consultantResponse.json()) as { consultants: AdminConsultantView[] }).consultants);
      setAccounts(((await accountResponse.json()) as { accounts: AdminAccountView[] }).accounts);
    } catch {
      setMessage("Admin data load කළ නොහැක.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void refresh(); }, []);
  useEffect(() => { setSearch(""); setShowStudentRegistration(false); }, [module]);
  const query = search.trim().toLowerCase().replaceAll(" ", "");
  const matches = (...values: Array<string | number | null | undefined>) => !query || values.some((value) => String(value ?? "").toLowerCase().replaceAll(" ", "").includes(query));
  const searchBox = <input className="admin-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search: SR/CN number, name, email or phone" />;

  async function setStudentStatus(student: AdminStudentView) {
    const response = await fetch(`/api/admin/students/${student.id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !student.isActive })
    });
    const result = await response.json() as { message?: string };
    setMessage(response.ok ? `Student ${student.isActive ? "suspended" : "activated"}.` : result.message ?? "Student status update failed.");
    if (response.ok) await refresh();
  }

  async function removeStudent(student: AdminStudentView) {
    const label = `${student.account?.number ?? "No SR"} • ${student.name}`;
    if (!window.confirm(`${label} permanently remove කරන්නද?\n\nCourse access, login, progress සහ personal details ඉවත් වේ. Financial audit history පමණක් anonymized ලෙස තබා ගනී. මේ action එක undo කළ නොහැක.`)) return;
    const confirmationEmail = window.prompt(`Confirm කිරීමට student email එක type කරන්න:\n${student.email}`);
    if (confirmationEmail === null) return;
    if (confirmationEmail.trim().toLowerCase() !== student.email.toLowerCase()) {
      setMessage("Email එක නොගැළපේ. Student remove කළේ නැහැ.");
      return;
    }
    const response = await fetch(`/api/admin/students/${student.id}/remove`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirmationEmail: confirmationEmail.trim() })
    });
    const result = await response.json() as { message?: string };
    setMessage(response.ok ? result.message ?? "Student removed." : result.message ?? "Student removal failed.");
    if (response.ok) await refresh();
  }

  async function reviewPayment(payment: AdminPaymentView, status: "APPROVED" | "PARTIAL" | "REJECTED") {
    if (status === "APPROVED") {
      const consultant = payment.placementConsultant;
      const placement = consultant
        ? `${consultant.name} • ${consultant.accountNumber} • ${consultant.side ?? "SIDE NOT SET"}`
        : "Direct consultant / placement details නැහැ";
      if (!window.confirm(`${payment.paymentCode} APPROVE කරන්නද?\n\nStudent: ${payment.student?.name ?? "Unknown"}\nAmount: Rs. ${Number(payment.paidAmount).toLocaleString()} / ${Number(payment.totalAmount).toLocaleString()}\nConsultant: ${placement}\n\nFull payment point එක ඉහත CN account side එකට යයි.`)) return;
    }
    const response = await fetch(`/api/admin/payments/${payment.id}/review`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    const result = await response.json() as { message?: string; otpEmailSent?: boolean };
    setMessage(response.ok ? (status === "APPROVED" ? `Payment approved. ${result.otpEmailSent ? "OTP email sent." : "OTP email failed—check EMAIL_APP_PASSWORD."}` : `Payment ${status.toLowerCase()}.`) : result.message ?? "Payment review failed.");
    if (response.ok) await refresh();
  }
  async function repairPaymentPoint(payment: AdminPaymentView) {
    if (!window.confirm(`${payment.paymentCode} full payment point එක missing නම් registered LEFT/RIGHT side එකට add කරන්නද?`)) return;
    const response = await fetch(`/api/admin/payments/${payment.id}/repair-point`, { method: "POST" });
    const result = await response.json() as { message?: string };
    setMessage(result.message ?? (response.ok ? "Point checked." : "Point repair failed."));
    if (response.ok) await refresh();
  }
  async function undoPaymentRejection(payment: AdminPaymentView) {
    if (!window.confirm(`${payment.paymentCode} rejection එක undo කර නැවත review කිරීමට යවන්නද?`)) return;
    const response = await fetch(`/api/admin/payments/${payment.id}/undo-rejection`, { method: "POST" });
    const result = await response.json() as { message?: string };
    setMessage(result.message ?? (response.ok ? "Rejection undone." : "Undo rejection failed."));
    if (response.ok) await refresh();
  }

  async function openProof(payment: AdminPaymentView) {
    const response = await fetch(`/api/admin/payments/${payment.id}/proof`);
    if (!response.ok) { setMessage("Payment proof එකක් නැහැ."); return; }
    const url = URL.createObjectURL(await response.blob());
    window.open(url, "_blank", "noopener,noreferrer");
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }
  async function openBalanceProof(payment: AdminBalancePaymentView) {
    const response = await fetch(`/api/admin/balance-payments/${payment.id}/proof`);
    if (!response.ok) { setMessage("Balance payment proof එකක් නැහැ."); return; }
    const url = URL.createObjectURL(await response.blob()); window.open(url, "_blank", "noopener,noreferrer"); setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }
  async function reviewBalancePayment(payment: AdminBalancePaymentView, status: "APPROVED" | "REJECTED") {
    if (!window.confirm(`${payment.student.name}ගේ Rs. ${Number(payment.amount).toLocaleString()} balance payment එක ${status === "APPROVED" ? "approve" : "reject"} කරන්නද?`)) return;
    const response = await fetch(`/api/admin/balance-payments/${payment.id}/review`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    const result = await response.json().catch(() => ({})) as { message?: string };
    setMessage(response.ok ? (status === "APPROVED" ? "Balance approved: FULLY PAID, all lessons unlocked, protected point processed." : "Balance payment rejected. Student can submit again.") : result.message ?? "Balance review failed.");
    if (response.ok) await refresh();
  }
  async function openConsultantProfile(consultant: AdminConsultantView) {
    setMessage("");
    const response = await fetch(`/api/admin/consultants/${consultant.id}/financial-profile`);
    const data = await response.json() as AdminConsultantProfile & { message?: string };
    if (!response.ok) { setMessage(data.message ?? "Consultant details load failed."); return; }
    setConsultantProfile(data);
  }

  async function enableCco(account: AdminAccountView) {
    if (!window.confirm(`${account.number} account එක CCO account එකක් කර CN${account.numericPart} ලෙස වෙනස් කරන්නද?`)) return;
    const response = await fetch(`/api/admin/accounts/${account.id}/enable-cco`, { method: "POST" });
    const result = await response.json() as { message?: string };
    setMessage(response.ok ? (result.message ?? "CCO enabled.") : (result.message ?? "CCO enable කිරීම අසාර්ථකයි."));
    if (response.ok) await refresh();
  }

  async function disableCco(account: AdminAccountView) {
    if (!window.confirm(`${account.number} account එකේ CCO access disable කර SR${account.numericPart} ලෙස නැවත වෙනස් කරන්නද?`)) return;
    const response = await fetch(`/api/admin/accounts/${account.id}/disable-cco`, { method: "POST" });
    const result = await response.json() as { message?: string };
    setMessage(response.ok ? (result.message ?? "CCO disabled.") : (result.message ?? "CCO disable කිරීම අසාර්ථකයි."));
    if (response.ok) await refresh();
  }
  async function setLearningPortal(account: AdminAccountView) {
    const enabled = !account.learningPortalEnabled;
    const response = await fetch(`/api/admin/users/${account.ownerId}/learning-portal`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ enabled }) });
    const result = await response.json() as { message?: string }; setMessage(result.message ?? "Portal permission update failed.");
    if (response.ok) { setControlledAccount({ ...account, learningPortalEnabled: enabled }); await refresh(); }
  }

  if (loading) return <section className="dash-card workspace-card"><h3>Admin data loading...</h3></section>;
  if (module === "Students") {
    if (showStudentRegistration) {
      return <AdminStudentRegistrationWorkspace
        onClose={() => setShowStudentRegistration(false)}
        onCreated={async () => {
          setShowStudentRegistration(false);
          setMessage("Student registration saved සහ Pay ID email එක යවා ඇත.");
          await refresh();
        }}
      />;
    }
    return <section className="dash-card workspace-card">
      <div className="workspace-heading"><div><span className="eyebrow">REAL STUDENT DATA</span><h2>Student Management</h2><p>Registered accounts, payments, enrollment සහ SR status.</p></div><button type="button" className="button button-primary" onClick={() => { setMessage(""); setShowStudentRegistration(true); }}>Register New Student</button></div>
      {searchBox}
      {message && <p className="form-error">{message}</p>}
      <div className="workspace-list">
        <div className="workspace-list-head"><span>Student</span><span>Access & account</span><span>Action</span></div>
        {students.filter((student) => matches(student.name, student.email, student.phone, student.nicOrPassport, student.account?.number)).map((student) => <div className="workspace-list-row" key={student.id}>
          <strong>{student.name}<small>{student.email}<br />{student.phone ?? "No phone"} • {student.nicOrPassport ?? "No NIC"}<br />{student.dateOfBirth ?? "No DOB"} • {student.address ?? "No address"}</small></strong>
          <span>{student.account?.number ?? "No SR"}<br />{student.emailVerifiedAt ? "EMAIL VERIFIED" : student.latestPayment?.status === "APPROVED" ? "AWAITING OTP" : student.latestPayment?.status ?? "PAYMENT PENDING"}</span>
          <span className="admin-row-actions">
            {student.isActive ? <button type="button" className="status-badge warning" onClick={() => void setStudentStatus(student)}>Suspend</button> : !student.emailVerifiedAt ? <button type="button" className="status-badge" disabled title="Student email OTP verification එක අවසන් කළ යුතුයි">Waiting for OTP</button> : !student.passwordSetAt ? <button type="button" className="status-badge" disabled title="Student password එක set කළ යුතුයි">Waiting for password</button> : <button type="button" className="status-badge success" onClick={() => void setStudentStatus(student)}>Activate</button>}
            <button type="button" className="danger-action" onClick={() => void removeStudent(student)}>Remove Student</button>
          </span>
        </div>)}
        {!students.length && <p>No students registered.</p>}
      </div>
    </section>;
  }
  if (module === "Payments") {
    const searchedPayments = payments.filter((payment) => matches(payment.paymentCode, payment.accountNumber, payment.student?.name, payment.student?.email, payment.student?.phone, payment.placementConsultant?.name, payment.placementConsultant?.accountNumber));
    const fullPayments = searchedPayments.filter((payment) => Number(payment.paidAmount) >= Number(payment.totalAmount));
    const halfPayments = searchedPayments.filter((payment) => Number(payment.paidAmount) < Number(payment.totalAmount));
    const visiblePayments = paymentFilter === "FULL" ? fullPayments : paymentFilter === "HALF" ? halfPayments : [];
    const visibleBalances = balancePayments.filter((payment) => matches(payment.originalPaymentCode, payment.transactionReference, payment.student.name, payment.student.email, payment.student.phone, payment.course.title));
    return <section className="dash-card workspace-card">
      <div className="workspace-heading"><div><span className="eyebrow">PAYMENT VERIFICATION</span><h2>Payments & Admissions</h2><p>Proof බලලා full payment පමණක් approve කරන්න.</p></div></div>
      {searchBox}
      <div className="payment-filter-tabs" role="tablist" aria-label="Payment type">
        <button type="button" className={paymentFilter === "FULL" ? "active" : ""} onClick={() => setPaymentFilter("FULL")}>Full Payments <span>{fullPayments.length}</span></button>
        <button type="button" className={paymentFilter === "HALF" ? "active" : ""} onClick={() => setPaymentFilter("HALF")}>Half Payments <span>{halfPayments.length}</span></button>
        <button type="button" className={paymentFilter === "BALANCE" ? "active" : ""} onClick={() => setPaymentFilter("BALANCE")}>Balance Payments <span>{visibleBalances.length}</span></button>
      </div>
      {message && <p className="form-error">{message}</p>}
      <div className="workspace-list">
        <div className="workspace-list-head"><span>Payment</span><span>Amount</span><span>Actions</span></div>
        {paymentFilter !== "BALANCE" && visiblePayments.map((payment) => <div className="workspace-list-row" key={payment.id}>
          <strong>{payment.paymentCode}<small>{payment.accountNumber ?? "No SR"} • {payment.student?.name ?? "Student"}<br />Pay ID: {payment.transactionReference ?? "MISSING"}<br />{payment.method.replaceAll("_", " ")} • {payment.status}<br />Consultant: {payment.placementConsultant ? `${payment.placementConsultant.name} • ${payment.placementConsultant.accountNumber} • ${payment.placementConsultant.side ?? "SIDE NOT SET"}` : "Direct / Not assigned"}</small></strong>
          <span>Rs. {Number(payment.paidAmount).toLocaleString()} / {Number(payment.totalAmount).toLocaleString()}</span>
          <span className="admin-row-actions">
            <button type="button" onClick={() => void openProof(payment)}>Proof</button>
            {!['APPROVED','REJECTED','REFUNDED'].includes(payment.status) && <>
              {Number(payment.paidAmount) >= Number(payment.totalAmount)
                ? <button type="button" onClick={() => void reviewPayment(payment, "APPROVED")}>Approve Full</button>
                : <button type="button" onClick={() => void reviewPayment(payment, "PARTIAL")}>Confirm Half</button>}
              <button type="button" onClick={() => void reviewPayment(payment, "REJECTED")}>Reject</button>
            </>}
            {payment.status === "APPROVED" && <button type="button" onClick={() => void repairPaymentPoint(payment)}>Check / Add Point</button>}
            {payment.status === "REJECTED" && <button type="button" onClick={() => void undoPaymentRejection(payment)}>Undo Rejection</button>}
          </span>
        </div>)}
        {paymentFilter === "BALANCE" && visibleBalances.map((payment) => <div className="workspace-list-row" key={payment.id}>
          <strong>{payment.originalPaymentCode}<small>{payment.student.name} • {payment.student.email}<br />{payment.course.title}<br />Reference: {payment.transactionReference}<br />Status: {payment.status.replaceAll("_", " ")}</small></strong>
          <span>Rs. {Number(payment.amount).toLocaleString()}</span>
          <span className="admin-row-actions"><button type="button" onClick={() => void openBalanceProof(payment)}>Proof</button>{["PENDING", "UNDER_REVIEW"].includes(payment.status) && <><button type="button" onClick={() => void reviewBalancePayment(payment, "APPROVED")}>Approve Balance</button><button type="button" onClick={() => void reviewBalancePayment(payment, "REJECTED")}>Reject</button></>}</span>
        </div>)}
        {paymentFilter !== "BALANCE" && !visiblePayments.length && <p>{paymentFilter === "FULL" ? "Full payment requests නැහැ." : "Half payment requests නැහැ."}</p>}
        {paymentFilter === "BALANCE" && !visibleBalances.length && <p>Balance payment requests නැහැ.</p>}
      </div>
    </section>;
  }
  if (module === "Consultants") {
    return <section className="dash-card workspace-card">
      <div className="workspace-heading"><div><span className="eyebrow">CONSULTANT DIRECTORY</span><h2>Consultants</h2><p>Consultant details සහ ඔවුන්ගේ SR/CN accounts.</p></div></div>
      {searchBox}
      {message && <p className="form-error">{message}</p>}
      {consultantProfile && <div className="consultant-profile-panel">
        <div className="consultant-profile-title"><div><span className="eyebrow">FINANCIAL PROFILE</span><h3>{consultantProfile.consultant.name}</h3><p>{consultantProfile.accounts.map((item) => item.number).join(" • ")}</p></div><button type="button" onClick={() => setConsultantProfile(null)}><X /></button></div>
        <div className="consultant-financial-grid">
          <MetricCard label="Total Income" value={`Rs. ${consultantProfile.financials.totalIncome.toLocaleString()}`} note="Lifetime commission" icon={<CircleDollarSign />} />
          <MetricCard label="Pending Income" value={`Rs. ${consultantProfile.financials.pendingIncome.toLocaleString()}`} note="Awaiting weekly release" icon={<Wallet />} />
          <MetricCard label="Week-end Payable" value={`Rs. ${consultantProfile.financials.weeklyPayable.toLocaleString()}`} note="Expected release amount" icon={<TrendingUp />} />
          <MetricCard label="Available Balance" value={`Rs. ${consultantProfile.financials.availableBalance.toLocaleString()}`} note={`Requested: Rs. ${consultantProfile.financials.requestedPayouts.toLocaleString()}`} icon={<CreditCard />} />
        </div>
        <div className="consultant-detail-grid"><div><h4>Personal details</h4><p><strong>Email</strong>{consultantProfile.consultant.email}</p><p><strong>Phone</strong>{consultantProfile.consultant.phone ?? "Not added"}</p><p><strong>NIC</strong>{consultantProfile.consultant.nicOrPassport ?? "Not added"}</p><p><strong>Address</strong>{consultantProfile.consultant.address ?? "Not added"}</p></div>
          <div><h4>Bank details</h4>{consultantProfile.bankDetails ? <><p><strong>Bank</strong>{consultantProfile.bankDetails.bankName}</p><p><strong>Branch</strong>{consultantProfile.bankDetails.branchName}</p><p><strong>Account holder</strong>{consultantProfile.bankDetails.accountHolderName}</p><p><strong>Account number</strong>{consultantProfile.bankDetails.accountNumber}</p></> : <p>Consultant bank details තවම add කර නැහැ.</p>}</div></div>
      </div>}
      <div className="workspace-list"><div className="workspace-list-head"><span>Consultant</span><span>Accounts</span><span>Status</span></div>
        {consultants.filter((consultant) => matches(consultant.name, consultant.email, consultant.phone, ...consultant.accounts.map((account) => account.number))).map((consultant) => <div className="workspace-list-row" key={consultant.id}>
          <strong>{consultant.name}<small>{consultant.email}<br />{consultant.phone ?? "No phone"}</small></strong>
          <span>{consultant.accounts.map((account) => account.number).join(", ") || "No accounts"}</span>
          <span className="admin-row-actions"><span className={`status-badge ${consultant.isActive ? "success" : "warning"}`}>{consultant.isActive ? "ACTIVE" : "SUSPENDED"}</span><button type="button" onClick={() => void openConsultantProfile(consultant)}>View details</button></span>
        </div>)}
      </div>
    </section>;
  }
  if (module === "Network") {
    return <section className="dash-card workspace-card">
      <div className="workspace-heading"><div><span className="eyebrow">ACCOUNT DIRECTORY</span><h2>Active & Reserved Accounts</h2><p>SR/CN number එකෙන් account owner සොයන්න.</p></div></div>
      {searchBox}
      {message && <p className={message.toLowerCase().includes("success") || message.toLowerCase().includes("already") ? "form-success" : "form-error"}>{message}</p>}
      {controlledAccount && <div className="network-control-panel"><div className="network-control-title"><div><span className="eyebrow">OWNER CONTROL</span><h3>{controlledAccount.ownerName}</h3><p>{controlledAccount.ownerEmail} · {controlledAccount.ownerPhone ?? "No phone"}</p></div><button type="button" onClick={() => setControlledAccount(null)}><X /></button></div><div className="owner-account-directory"><span className="eyebrow">OWNER ACCOUNTS</span>{accounts.filter(item => item.ownerId === controlledAccount.ownerId).sort((a,b) => Number(b.isMainAccount)-Number(a.isMainAccount) || a.numericPart-b.numericPart).map(item => <div key={item.id}><strong>{item.number}<small>{item.isMainAccount ? "MAIN ACCOUNT" : "SERVICE / CHILD ACCOUNT"}</small></strong><span className={`status-badge ${item.status === "ACTIVE" ? "success" : "warning"}`}>{item.status}</span></div>)}</div><div className="network-control-actions"><div><strong>Learning Portal switch</strong><small>Consultantට student course portal වෙත switch වීමට අවසරය.</small><button type="button" className={`status-badge ${controlledAccount.learningPortalEnabled ? "warning" : "success"}`} onClick={() => void setLearningPortal(controlledAccount)}>{controlledAccount.learningPortalEnabled ? "Disable Learning Portal" : "Enable Learning Portal"}</button></div><div><strong>CCO access</strong><small>Main account consultant access පමණක් පාලනය කරන්න.</small>{controlledAccount.prefix === "CN" && controlledAccount.ownerRole === "consultant" ? <button type="button" className="status-badge warning" onClick={() => void disableCco(controlledAccount)}>Suspend CCO</button> : controlledAccount.prefix === "SR" && controlledAccount.ownerRole === "student" ? <button type="button" className="status-badge success" disabled={controlledAccount.status !== "ACTIVE"} onClick={() => void enableCco(controlledAccount)}>Enable CCO</button> : <span className="status-badge">Not available</span>}</div></div></div>}
      <div className="workspace-list"><div className="workspace-list-head"><span>Account</span><span>Owner</span><span>Status / CCO</span></div>
        {accounts.filter((account) => account.isMainAccount && matches(account.number, account.ownerName, account.ownerEmail, account.ownerPhone, ...accounts.filter(item => item.ownerId === account.ownerId).map(item => item.number))).map((account) => <div className="workspace-list-row" key={account.id}>
          <strong>{account.number}<small>{account.isMainAccount ? "Main account" : "Child account"}</small></strong>
          <span>{account.ownerName}<br />{account.ownerEmail}<br />{account.ownerPhone ?? "No phone"}</span>
          <span className="admin-row-actions">
            <span className={`status-badge ${account.status === "ACTIVE" ? "success" : "warning"}`}>{account.status}</span>
            <button type="button" onClick={() => setControlledAccount(account)}>Control</button>
          </span>
        </div>)}
      </div>
    </section>;
  }
  return <FeatureWorkspace role="admin" module={module} />;
}

type AdmissionTargetsData={targets:Record<"daily"|"weekly"|"monthly",number>;progress:Record<"daily"|"weekly"|"monthly",number>;achieved:Record<"daily"|"weekly"|"monthly",boolean>};
function ConsultantAdmissionTargets(){const[data,setData]=useState<AdmissionTargetsData|null>(null);const[saving,setSaving]=useState(false);const[message,setMessage]=useState("");const load=()=>fetch("/api/consultant/admission-targets").then(r=>{if(!r.ok)throw Error();return r.json()}).then(setData).catch(()=>setMessage("Admission targets load කළ නොහැක."));useEffect(()=>{void load()},[]);const periods=["daily","weekly","monthly"] as const;const save=async()=>{if(!data)return;setSaving(true);try{const r=await fetch("/api/consultant/admission-targets",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(data.targets)});if(!r.ok)throw Error();setMessage("Targets saved successfully.");load()}catch{setMessage("Targets save කළ නොහැක.")}finally{setSaving(false)}};if(!data)return <section className="dash-card"><h3>Admission targets loading...</h3></section>;return <section className="dash-card admission-target-card"><div className="target-heading"><div><span className="eyebrow">ADMISSION TARGETS</span><h3>Set your next goal</h3><p>Daily, weekly සහ monthly admission targets සටහන් කර progress එක බලන්න.</p></div><Target/></div>{Object.values(data.achieved).some(Boolean)&&<div className="target-win-banner"><Trophy/><div><strong>Congratulations! Target achieved!</strong><span>ඔබ Admission Heroes – Target Winners අතරට එක්වී ඇත.</span></div></div>}<div className="target-grid">{periods.map(period=>{const target=data.targets[period],progress=data.progress[period],percent=target?Math.min(100,Math.round(progress/target*100)):0;return <label className={data.achieved[period]?"achieved":""} key={period}><span>{period[0].toUpperCase()+period.slice(1)} target</span><div><strong>{progress}</strong><small> / {target||"—"} admissions</small></div><input type="number" min="0" max="10000" value={target} onChange={e=>setData({...data,targets:{...data.targets,[period]:Math.max(0,Number(e.target.value)||0)}})}/><div className="target-progress"><i style={{width:`${percent}%`}}/></div><small>{data.achieved[period]?"🏆 Target achieved":`${percent}% completed`}</small></label>})}</div><div className="target-actions"><button className="button button-primary" type="button" disabled={saving} onClick={()=>void save()}>{saving?"Saving...":"Save admission targets"}</button>{message&&<span>{message}</span>}</div></section>}

type Hero={id:string;name:string;accountNumber:string|null;photoUrl:string|null;counts:Record<"daily"|"weekly"|"monthly",number>;wins:string[]};
function HeroAvatar({hero}:{hero:Hero}){return hero.photoUrl?<img className="hero-avatar" src={hero.photoUrl} alt={`${hero.name} profile`}/>:<span className="hero-avatar fallback">{hero.name.split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase()}</span>}
function AdmissionHeroesWorkspace(){const[data,setData]=useState<{targetWinners:Hero[];weeklyChampions:Hero[];monthlyChampions:Hero[]}|null>(null);const[tab,setTab]=useState<"winners"|"weekly"|"monthly">("winners");useEffect(()=>{fetch("/api/consultant/admission-heroes").then(r=>{if(!r.ok)throw Error();return r.json()}).then(setData).catch(()=>setData({targetWinners:[],weeklyChampions:[],monthlyChampions:[]}))},[]);const list=tab==="winners"?data?.targetWinners:tab==="weekly"?data?.weeklyChampions:data?.monthlyChampions;return <section className="dash-card heroes-card"><div className="heroes-heading"><div><span className="eyebrow">ADMISSION HEROES</span><h2>Champions & Target Winners</h2><p>Approved full-payment admissions අනුව live leaderboard එක.</p></div><Trophy/></div><div className="heroes-tabs"><button className={tab==="winners"?"active":""} onClick={()=>setTab("winners")}>Target Winners</button><button className={tab==="weekly"?"active":""} onClick={()=>setTab("weekly")}>Weekly Top 5</button><button className={tab==="monthly"?"active":""} onClick={()=>setTab("monthly")}>Monthly Top 10</button></div><div className="heroes-list">{!data?<p>Leaderboard loading...</p>:list?.length?list.map((hero,index)=><article key={hero.id}><span className="hero-rank">#{index+1}</span><HeroAvatar hero={hero}/><div><strong>{hero.name}</strong><small>{hero.accountNumber??"Consultant"}</small></div><div className="hero-score">{tab==="winners"?<><strong>{hero.wins.map(x=>x[0].toUpperCase()+x.slice(1)).join(" · ")}</strong><small>Target achieved</small></>:<><strong>{hero.counts[tab]}</strong><small>admissions</small></>}</div></article>):<div className="heroes-empty"><Trophy/><strong>No winners yet</strong><span>First qualifying consultant මෙහි පෙන්වයි.</span></div>}</div></section>}

function ConsultantProfileWorkspace(){const[profile,setProfile]=useState<{name:string;email:string;phone:string|null;photoUrl:string|null}|null>(null);const[message,setMessage]=useState("");const[uploading,setUploading]=useState(false);useEffect(()=>{fetch("/api/consultant/profile").then(r=>r.json()).then(setProfile)},[]);const remove=async()=>{if(!window.confirm("Profile photo එක ඉවත් කරන්නද?"))return;setUploading(true);try{const r=await fetch("/api/consultant/profile-photo",{method:"DELETE"});if(!r.ok)throw Error();setProfile(current=>current?{...current,photoUrl:null}:current);setMessage("Profile photo removed.")}catch{setMessage("Profile photo remove කළ නොහැක.")}finally{setUploading(false)}};const upload=async(file?:File)=>{if(!file)return;if(!file.type.match(/^image\/(jpeg|png|webp)$/)){setMessage("JPG, PNG හෝ WEBP image එකක් තෝරන්න.");return}setUploading(true);try{const r=await fetch("/api/consultant/profile-photo",{method:"PUT",headers:{"Content-Type":file.type},body:file});if(!r.ok)throw Error();const result=await r.json();setProfile(current=>current?{...current,photoUrl:result.photoUrl}:current);setMessage("Profile photo updated successfully.")}catch{setMessage("Profile photo upload කළ නොහැක.")}finally{setUploading(false)}};return <section className="dash-card profile-workspace"><span className="eyebrow">MY PROFILE</span><h2>Consultant profile</h2><p>Admission Heroes leaderboard එකේ පෙන්වන photo එක update කරන්න.</p>{profile?<div className="profile-editor">{profile.photoUrl?<img src={profile.photoUrl} alt={profile.name}/>:<span>{profile.name.slice(0,2).toUpperCase()}</span>}<div><h3>{profile.name}</h3><p>{profile.email}<br/>{profile.phone??"Phone not added"}</p><label className="button button-primary">{uploading?"Uploading...":"Choose profile photo"}<input type="file" accept="image/jpeg,image/png,image/webp" disabled={uploading} onChange={e=>void upload(e.target.files?.[0])}/></label>{profile.photoUrl&&<button className="button profile-remove-button" type="button" disabled={uploading} onClick={()=>void remove()}>Remove photo</button>}<small>Maximum 5 MB · JPG, PNG or WEBP</small></div></div>:<p>Profile loading...</p>}{message&&<p className="workspace-note">{message}</p>}</section>}

type ConsultantIncomeSummary = {
  availableBalance:number; pendingBalance:number; directIncome:number; serviceIncome:number; totalIncome:number;
  lastPayout:null|{amount:number;paidAt:string|null}; nextSettlementAt:string;
  ledger:Array<{id:string;entryType:string;amount:number;note:string|null;createdAt:string}>;
};

function ConsultantIncomeWorkspace(){
  const[data,setData]=useState<ConsultantIncomeSummary|null>(null);const[failed,setFailed]=useState(false);
  const money=(value:number)=>`Rs. ${value.toLocaleString()}`;
  useEffect(()=>{fetch("/api/consultant/income-summary").then(async r=>{if(!r.ok)throw Error();return r.json()}).then(setData).catch(()=>setFailed(true))},[]);
  const label=(type:string)=>({DIRECT_ADMISSION_INCOME:"Direct admission",COMMISSION_PENDING:"Friday service commission",COMMISSION_RELEASED:"Commission released",MANUAL_BANK_PAYOUT:"Bank payout",FRIDAY_PAYOUT_RESERVED:"Friday payout"}[type]??type.replaceAll("_"," "));
  if(failed)return <section className="dash-card workspace-card"><h3>Income data load කළ නොහැක</h3><p>Page එක refresh කරන්න.</p></section>;
  if(!data)return <section className="dash-card workspace-card"><h3>Income data loading...</h3></section>;
  return <section className="dash-card workspace-card"><div className="workspace-heading"><div><span className="eyebrow">REAL WALLET & LEDGER</span><h2>Income & Wallet</h2><p>Direct admissions, Friday service commissions සහ සැබෑ payout history.</p></div></div>
    <div className="commission-total-grid"><MetricCard label="Total Income" value={money(data.totalIncome)} note="Lifetime direct + service income" icon={<TrendingUp/>}/><MetricCard label="Pending Payout" value={money(data.pendingBalance)} note="Admin bank transfer සඳහා" icon={<Wallet/>}/><MetricCard label="Direct Income" value={money(data.directIncome)} note="Approved direct admissions" icon={<Users/>}/><MetricCard label="Service Income" value={money(data.serviceIncome)} note="Completed Friday settlements" icon={<CircleDollarSign/>}/></div>
    <div className="payout-guide"><strong>Next Friday settlement</strong><span>{new Date(data.nextSettlementAt).toLocaleString("en-LK",{timeZone:"Asia/Colombo",dateStyle:"full",timeStyle:"short"})}</span></div>
    <div className="workspace-list"><div className="workspace-list-head"><span>Transaction</span><span>Amount</span><span>Date</span></div>{data.ledger.length?data.ledger.map(item=><div className="workspace-list-row" key={item.id}><strong>{label(item.entryType)}<small>{item.note??"Verified system record"}</small></strong><span className={item.amount<0?"status-badge warning":"status-badge success"}>{item.amount<0?"−":"+"} Rs. {Math.abs(item.amount).toLocaleString()}</span><span>{new Date(item.createdAt).toLocaleString("en-LK",{timeZone:"Asia/Colombo"})}</span></div>):<div className="workspace-list-row"><strong>No income records yet</strong><span>Rs. 0</span><span>—</span></div>}</div>
    <p className="workspace-note">Last payout: {data.lastPayout?`${money(data.lastPayout.amount)} • ${data.lastPayout.paidAt?new Date(data.lastPayout.paidAt).toLocaleString("en-LK",{timeZone:"Asia/Colombo"}):"Paid"}`:"No completed payout yet"}</p>
  </section>;
}

type SupportMessage = { id: string; senderType: string; body: string; createdAt: string };
type SupportConversation = { id: string; channel: string; status: string; visitorName: string | null; visitorEmail: string | null; assignedTo: string | null; agentName?: string | null; lastMessageAt: string };

function SupportAgentWorkspace() {
  const [queue, setQueue] = useState<SupportConversation[]>([]); const [active, setActive] = useState<SupportConversation | null>(null); const [messages, setMessages] = useState<SupportMessage[]>([]); const [text, setText] = useState(""); const [notice, setNotice] = useState("");
  async function loadQueue() { const response = await fetch("/api/support/queue"); if (response.ok) setQueue(((await response.json()) as { conversations: SupportConversation[] }).conversations); }
  async function loadMessages(id: string) { const response = await fetch(`/api/support/conversations/${id}/messages`); if (response.ok) { const data = await response.json() as { conversation: SupportConversation; messages: SupportMessage[] }; setActive(data.conversation); setMessages(data.messages); } }
  useEffect(() => { const beat = () => void fetch("/api/support/heartbeat", { method: "POST" }); beat(); void loadQueue(); const timer = window.setInterval(() => { beat(); void loadQueue(); if (active) void loadMessages(active.id); }, 5000); return () => window.clearInterval(timer); }, [active?.id]);
  async function claim(item: SupportConversation) { const response = await fetch(`/api/support/conversations/${item.id}/claim`, { method: "POST" }); const data = await response.json() as { message?: string }; if (!response.ok) { setNotice(data.message ?? "Chat claim කළ නොහැක."); await loadQueue(); return; } setNotice("Customer chat එක ඔබට assign විය."); await loadMessages(item.id); await loadQueue(); }
  async function send(event: FormEvent) { event.preventDefault(); if (!active || !text.trim()) return; const value = text; setText(""); const response = await fetch(`/api/support/conversations/${active.id}/messages`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: value }) }); if (response.ok) await loadMessages(active.id); }
  async function closeChat() { if (!active || !window.confirm("මෙම support chat එක close කරන්නද?")) return; const response = await fetch(`/api/support/conversations/${active.id}/close`, { method: "POST" }); if (response.ok) { setActive(null); setMessages([]); await loadQueue(); } }
  return <section className="dash-card support-agent-workspace"><div className="workspace-heading"><div><span className="eyebrow">LIVE CUSTOMER CARE</span><h2>Support Queue</h2><p>Waiting customer කෙනෙකුට උදව් කිරීමට I CAN HELP ඔබන්න.</p></div><span className="status-badge success">Online</span></div>{notice && <p className="workspace-note">{notice}</p>}<div className="support-agent-layout"><div className="support-queue"><h3>Waiting & My chats</h3>{queue.map(item=><article key={item.id} className={active?.id===item.id?"active":""}><div><strong>{item.visitorName||"Visitor"}</strong><small>{item.status} • {new Date(item.lastMessageAt).toLocaleTimeString()}</small></div>{item.status==="WAITING"?<button type="button" className="button button-primary" onClick={()=>void claim(item)}>I CAN HELP</button>:<button type="button" className="button button-secondary" onClick={()=>void loadMessages(item.id)}>Open chat</button>}</article>)}{!queue.length&&<p>දැනට waiting customers නැහැ.</p>}</div><div className="support-agent-chat">{active?<><div className="support-chat-heading"><div><strong>{active.visitorName||"Visitor"}</strong><small>{active.visitorEmail||"Private visitor"}</small></div><button type="button" onClick={()=>void closeChat()}>Close chat</button></div><div className="support-message-list">{messages.map(item=><div key={item.id} className={`support-message ${item.senderType.toLowerCase()}`}><span>{item.body}</span><small>{new Date(item.createdAt).toLocaleTimeString()}</small></div>)}</div><form className="support-send" onSubmit={send}><input value={text} onChange={event=>setText(event.target.value)} placeholder="සිංහලෙන් පිළිතුර ලියන්න..." maxLength={1500}/><button type="submit" aria-label="Send"><Send/></button></form></>:<div className="support-chat-empty"><Headphones/><h3>Chat එකක් තෝරන්න</h3><p>Customerගේ details claim කළ guideට සහ Adminට පමණක් පෙනේ.</p></div>}</div></div></section>;
}

function CustomerSupportWidget() {
  const [open,setOpen]=useState(false); const [step,setStep]=useState<"choose"|"details"|"chat">("choose"); const [mode,setMode]=useState<"FAQ"|"HUMAN">("FAQ"); const [conversation,setConversation]=useState<{id:string;token:string;status:string}|null>(()=>{try{return JSON.parse(window.localStorage.getItem("adil-support-chat")||"null") as {id:string;token:string;status:string}|null}catch{return null}}); const [messages,setMessages]=useState<SupportMessage[]>([]); const [text,setText]=useState(""); const [error,setError]=useState(""); const [starting,setStarting]=useState(false);
  async function load(){if(!conversation)return;const response=await fetch(`/api/public/support/conversations/${conversation.id}?token=${encodeURIComponent(conversation.token)}`);if(response.status===404){window.localStorage.removeItem("adil-support-chat");setConversation(null);setStep("choose");return}if(response.ok){const data=await response.json() as {conversation:SupportConversation;messages:SupportMessage[]};setMessages(data.messages);if(data.conversation.status==="CLOSED") setError("මෙම chat එක අවසන්. New chat එකක් ආරම්භ කළ හැක.");}}
  useEffect(()=>{if(conversation){setStep("chat");void load();const timer=window.setInterval(()=>void load(),3000);return()=>window.clearInterval(timer)}},[conversation?.id]);
  async function create(event:FormEvent<HTMLFormElement>){event.preventDefault();if(starting)return;setError("");setStarting(true);try{const form=new FormData(event.currentTarget);const response=await fetch("/api/public/support/conversations",{method:"POST",headers:{"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify({mode,name:String(form.get("name")||""),email:String(form.get("email")||"")||undefined})});const contentType=response.headers.get("content-type")||"";const data=contentType.includes("application/json")?await response.json() as {id?:string;token?:string;status?:string;message?:string}:{};if(!response.ok||!data.id||!data.token){setError(data.message||`Support chat ආරම්භ කළ නොහැක. (Error ${response.status})`);return}const next={id:data.id,token:data.token,status:data.status||"OPEN"};window.localStorage.setItem("adil-support-chat",JSON.stringify(next));setConversation(next);setStep("chat");}catch{setError("Server එක සමඟ සම්බන්ධ විය නොහැක. තත්පර කිහිපයකින් නැවත උත්සාහ කරන්න.");}finally{setStarting(false)}}
  async function send(event:FormEvent){event.preventDefault();if(!conversation||!text.trim())return;const value=text;setText("");const response=await fetch(`/api/public/support/conversations/${conversation.id}/messages`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:conversation.token,message:value})});if(response.ok)await load();else{const data=await response.json() as {message?:string};setError(data.message||"Message යැවිය නොහැක.");}}
  function reset(){window.localStorage.removeItem("adil-support-chat");setConversation(null);setMessages([]);setError("");setStep("choose");}
  return <div className="customer-support-widget"><button type="button" className="support-floating-button" onClick={()=>setOpen(value=>!value)}><MessageCircle/><span>Customer Care</span></button>{open&&<div className="customer-support-panel"><header><div><strong>Adil Academy Support</strong><small>සිංහල Customer Care</small></div><button type="button" onClick={()=>setOpen(false)}><X/></button></header>{step==="choose"&&<div className="support-choice"><h3>ඔබට අවශ්‍ය සහාය තෝරන්න</h3><button type="button" onClick={()=>{setError("");setMode("FAQ");setStep("details")}}><Bot/><span><strong>Free FAQ Bot</strong><small>ක්ෂණික සිංහල පිළිතුරු • 24/7</small></span></button><button type="button" onClick={()=>{setError("");setMode("HUMAN");setStep("details")}}><Headphones/><span><strong>Personal Guide</strong><small>Online consultant / Admin සමඟ chat</small></span></button></div>}{step==="details"&&<form className="support-details" onSubmit={create}><h3>{mode==="FAQ"?"FAQ Bot":"Human Support"}</h3><label>ඔබගේ නම<input name="name" required minLength={2} maxLength={100}/></label><label>Email (optional)<input name="email" type="email"/></label>{error&&<p className="form-error" role="alert">{error}</p>}<button className="button button-primary" type="submit" disabled={starting}>{starting?"Starting chat...":"Start chat"} {!starting&&<ArrowRight/>}</button><button type="button" disabled={starting} onClick={()=>{setError("");setStep("choose")}}>Back</button></form>}{step==="chat"&&<div className="customer-chat"><div className="support-message-list">{messages.map(item=><div key={item.id} className={`support-message ${item.senderType.toLowerCase()}`}><span>{item.body}</span><small>{new Date(item.createdAt).toLocaleTimeString()}</small></div>)}</div>{error&&<p className="form-error">{error}</p>}<form className="support-send" onSubmit={send}><input value={text} onChange={event=>setText(event.target.value)} placeholder="ඔබගේ ප්‍රශ්නය ලියන්න..." maxLength={1500}/><button type="submit"><Send/></button></form><button type="button" className="support-new-chat" onClick={reset}>New chat</button></div>}</div>}</div>;
}

type CcoMainAdminApplication={id:string;firstName:string;lastName:string;email:string;phone:string;nicOrPassport:string;dateOfBirth:string;addressLine1:string;addressLine2:string|null;province:string;district:string;city:string;status:string;payId:string;amount:number;accountNumber:string;createdAt:string};
function AdminCcoMainBuyWorkspace(){
  const[applications,setApplications]=useState<CcoMainAdminApplication[]>([]);const[message,setMessage]=useState("");const[error,setError]=useState("");const[busy,setBusy]=useState(false);
  const load=async()=>{try{const response=await fetch("/api/admin/cco-main/applications");const data=await response.json();if(!response.ok)throw new Error(data.message);setApplications(data.applications??[])}catch(e){setError(e instanceof Error?e.message:"CCO Main applications load failed.")}};
  useEffect(()=>{void load()},[]);
  const issue=async(event:FormEvent<HTMLFormElement>)=>{event.preventDefault();setBusy(true);setError("");setMessage("");const form=new FormData(event.currentTarget);try{const response=await fetch("/api/admin/cco-main/pay-ids",{method:"POST",headers:{"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify(Object.fromEntries(form.entries()))});const raw=await response.text();let data:{message?:string;payId?:string;emailSent?:boolean}={};if(raw){try{data=JSON.parse(raw) as typeof data}catch{throw new Error(`Server එක JSON response එකක් ලබා දුන්නේ නැහැ (HTTP ${response.status}). App එක restart කර නැවත උත්සාහ කරන්න.`)}}if(!response.ok)throw new Error(data.message||`Pay ID create failed (HTTP ${response.status}).`);if(!data.payId)throw new Error(`Server එක හිස් response එකක් ලබා දුන්නා (HTTP ${response.status}). App එක restart කරන්න.`);setMessage(`Special Pay ID: ${data.payId} · ${data.emailSent?"Email sent":"Email send failed—copy and send manually"}`);event.currentTarget.reset()}catch(e){setError(e instanceof Error?e.message:"Pay ID create failed.")}finally{setBusy(false)}};
  const proof=async(item:CcoMainAdminApplication)=>{const response=await fetch(`/api/admin/cco-main/applications/${item.id}/proof`);if(!response.ok){setError("Proof load failed.");return}const url=URL.createObjectURL(await response.blob());window.open(url,"_blank","noopener,noreferrer");setTimeout(()=>URL.revokeObjectURL(url),60000)};
  const review=async(item:CcoMainAdminApplication,status:"APPROVED"|"REJECTED")=>{if(!window.confirm(`${item.accountNumber} · ${item.firstName} ${item.lastName}\nRs. ${item.amount.toLocaleString()}\n\n${status} කරන්නද?`))return;const response=await fetch(`/api/admin/cco-main/applications/${item.id}/review`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})});const data=await response.json();setMessage(data.message??"");if(!response.ok)setError(data.message??"Review failed.");else if(status==="APPROVED")setMessage(`${data.message} ${data.otpEmailSent?"OTP email sent.":"OTP email failed—EMAIL_APP_PASSWORD check කරන්න."}`);await load()};
  const undo=async(item:CcoMainAdminApplication)=>{const response=await fetch(`/api/admin/cco-main/applications/${item.id}/undo`,{method:"POST"});const data=await response.json();response.ok?setMessage(data.message):setError(data.message);await load()};
  return <div className="cco-main-admin"><section className="dash-card workspace-card"><span className="eyebrow">SPECIAL CONSULTANT ACCESS</span><h2>CCO Main Buy</h2><p>Course එකක් නොමැති consultant candidate කෙනෙකුට one-time Pay ID එකක් issue කරන්න.</p><form className="cco-main-issue" onSubmit={issue}><label>Full name<input name="name" required/></label><label>Email<input name="email" type="email" required/></label><label>Phone<input name="phone" required/></label><label>Amount (LKR)<input name="amount" type="number" defaultValue="5000" min="1" required/></label><button className="button button-primary" disabled={busy}>Issue & Email Pay ID</button></form>{message&&<p className="form-success">{message}</p>}{error&&<p className="form-error">{error}</p>}</section><section className="dash-card workspace-card"><span className="eyebrow">PAYMENT REVIEW</span><h2>CCO Main Applications</h2><div className="cco-main-admin-list">{applications.length?applications.map(item=><article key={item.id}><div><strong>{item.accountNumber} · {item.firstName} {item.lastName}</strong><span>{item.email} · {item.phone}</span><span>{item.nicOrPassport} · {item.city}, {item.district}, {item.province}</span><small>{item.payId} · Rs. {item.amount.toLocaleString()} · {item.status}</small></div><div className="row-actions"><button onClick={()=>void proof(item)}>Proof</button>{item.status==="UNDER_REVIEW"&&<><button className="success" onClick={()=>void review(item,"APPROVED")}>Approve & Send OTP</button><button onClick={()=>void review(item,"REJECTED")}>Reject</button></>}{item.status==="REJECTED"&&<button onClick={()=>void undo(item)}>Undo rejection</button>}</div></article>):<p>No CCO Main applications yet.</p>}</div></section></div>;
}
function FeatureWorkspace({
  role,
  module
}: {
  role: UserRole;
  module: string;
}) {
  if (["consultant", "staff", "admin"].includes(role) && module === "Customer Support") return <SupportAgentWorkspace />;
  if (role === "student") return <StudentFeatureWorkspace module={module} />;
  if (role === "consultant" && module === "Student Registration") return <ConsultantStudentRegistration />;
  if (role === "consultant" && module === "My Students") return <ConsultantMyStudentsWorkspace />;
  if (role === "consultant" && module === "My Accounts") return <ConsultantBankDetailsWorkspace />;
  if (role === "consultant" && module === "Service Accounts") return <ConsultantServiceAccountsWorkspace />;
  if (role === "consultant" && module === "Admission Heroes") return <AdmissionHeroesWorkspace />;
  if (role === "consultant" && module === "My Profile") return <ConsultantProfileWorkspace />;
  if (role === "consultant" && module === "Income") return <ConsultantIncomeWorkspace />;
  if (role === "consultant" && module === "CCO Activation") return <ConsultantCcoActivationWorkspace />;
  if (role === "admin" && module === "Course") return <CourseManagementWorkspace />;
  if (role === "admin" && module === "Commissions") return <AdminCommissionWorkspace />;
  if (role === "admin" && module === "CCO Activations") return <AdminCcoActivationWorkspace />;
  if (role === "admin" && module === "CCO Main Buy") return <AdminCcoMainBuyWorkspace />;
  if (role === "admin" && ["Students", "Payments", "Consultants", "Network"].includes(module)) return <AdminFeatureWorkspace module={module} />;
  const data = workspaceData[role + ":" + module];
  if (!data) {
    return (
      <section className="dash-card workspace-empty">
        <Settings />
        <h3>{module}</h3>
        <p>මෙම module එක සඳහා permissions අනුව content load වේ.</p>
      </section>
    );
  }
  return (
    <section className="dash-card workspace-card">
      <div className="workspace-heading">
        <div>
          <span className="eyebrow">ADIL ACADEMY CONTROL PANEL</span>
          <h2>{data.title}</h2>
          <p>{data.description}</p>
        </div>
        <button type="button" className="button button-primary">
          {data.action}
          <ArrowRight size={16} />
        </button>
      </div>
      <div className="workspace-list">
        <div className="workspace-list-head">
          <span>Item</span>
          <span>Details</span>
          <span>Status</span>
        </div>
        {data.rows.map((row) => (
          <div className="workspace-list-row" key={row[0]}>
            <strong>{row[0]}</strong>
            <span>{row[1]}</span>
            <span className="status-badge success">{row[2]}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

type CcoActivationConfig = {
  bankDetails: null | { bankName?: string; branchName?: string; accountHolderName?: string; accountNumber?: string };
  prices: Record<string, number>;
  consultant?: { name: string; phone: string | null; mainAccountNumber: string | null };
  activeAccounts?: Array<{ id: string; number: string }>;
  slots?: Array<{ position: number; numericPart: number; number: string; status: string; purchaseState: "ACTIVE" | "TRIAL_ACTIVE" | "PENDING" | "AVAILABLE" | "LOCKED"; price: number; trialPrice: number; trialExpiresAt: string | null; parentAccountId: string | null; parentAccountNumber: string; side: "LEFT" | "RIGHT" }>;
};
type CcoActivationView = { id: string; slotPosition: number; requestedNumericPart: number; parentAccountId: string; parentAccountNumber?: string; side: "LEFT" | "RIGHT"; activationMode: "FULL" | "TRIAL"; amount: string; transactionReference: string; seniorConsultantName: string | null; status: string; hasProof: boolean; createdAt: string; trialExpiresAt?: string | null; consultantName?: string; consultantEmail?: string; consultantPhone?: string | null; reviewNote?: string | null };

function ConsultantCcoActivationWorkspace() {
  const [config, setConfig] = useState<CcoActivationConfig | null>(null); const [requests, setRequests] = useState<CcoActivationView[]>([]);
  const [slot, setSlot] = useState(""); const [activationMode, setActivationMode] = useState<"FULL" | "TRIAL">("FULL"); const [busy, setBusy] = useState(false); const [message, setMessage] = useState(""); const [error, setError] = useState(""); const [warning, setWarning] = useState("");
  async function load() { const [configResponse, requestResponse] = await Promise.all([fetch("/api/consultant/cco-activation-config"), fetch("/api/consultant/cco-activations")]); if (!configResponse.ok || !requestResponse.ok) throw new Error(); const nextConfig = await configResponse.json() as CcoActivationConfig; setConfig(nextConfig); const available = nextConfig.slots?.find((item) => item.purchaseState === "AVAILABLE"); setSlot(available ? String(available.position) : ""); setRequests(((await requestResponse.json()) as { requests: CcoActivationView[] }).requests); }
  useEffect(() => { void load().catch(() => setError("CCO activation details load කළ නොහැක.")); }, []);
  async function copy(value: string) { await navigator.clipboard.writeText(value); setMessage("Copied successfully."); }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const formElement = event.currentTarget; setBusy(true); setMessage(""); setError("");
    try {
      const form = new FormData(formElement); const proof = form.get("proof") as File;
      if (!selected?.parentAccountId || !selected.side) throw new Error("Selected account placement details load වී නැහැ. Page එක refresh කර නැවත උත්සාහ කරන්න.");
      if (!String(form.get("transactionReference") ?? "").trim()) throw new Error("Transaction reference එක ඇතුළත් කරන්න.");
      if (!proof?.size) throw new Error("Bank slip file එක තෝරන්න.");
      const response = await fetch("/api/consultant/cco-activations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ slotPosition: Number(form.get("slotPosition")), activationMode, parentAccountId: form.get("parentAccountId"), side: form.get("side"), amount: Number(form.get("amount")), transactionReference: form.get("transactionReference"), seniorConsultantName: form.get("seniorConsultantName") || undefined }) });
      const responseText = await response.text(); let data: { request?: { id: string }; message?: string } = {}; try { data = responseText ? JSON.parse(responseText) as typeof data : {}; } catch { data.message = responseText.slice(0, 300); }
      if (!response.ok || !data.request) throw new Error(data.message ?? `Activation request save failed (${response.status}).`);
      const proofResponse = await fetch(`/api/consultant/cco-activations/${data.request.id}/proof`, { method: "PUT", headers: { "Content-Type": proof.type || "application/octet-stream" }, body: proof });
      const proofText = await proofResponse.text(); let proofMessage = ""; try { proofMessage = proofText ? (JSON.parse(proofText) as { message?: string }).message ?? "" : ""; } catch { proofMessage = proofText.slice(0, 300); }
      if (!proofResponse.ok) throw new Error(proofMessage || `Slip upload failed (${proofResponse.status}).`);
      setMessage("Request සහ payment slip සාර්ථකව submit විය. Admin review notification යවා ඇත."); formElement.reset(); setActivationMode("FULL"); await load();
    } catch (submitError) {
      const detail = submitError instanceof Error ? submitError.message : "Unknown submission error";
      setError(detail); window.alert(`CCO activation request submit වූයේ නැහැ:\n\n${detail}`);
    } finally { setBusy(false); }
  }
  const selected = config?.slots?.find((item) => String(item.position) === slot);
  const nextAvailable = config?.slots?.find((item) => item.purchaseState === "AVAILABLE");
  function chooseAccount(item: NonNullable<CcoActivationConfig["slots"]>[number]) {
    if (item.purchaseState === "AVAILABLE") { setSlot(String(item.position)); setWarning(""); return; }
    if (item.purchaseState === "PENDING") setWarning(`${item.number} payment request එක Admin review කරමින් පවතී.`);
    else if (item.purchaseState === "TRIAL_ACTIVE") setWarning(`${item.number} trial account එක ${item.trialExpiresAt ? new Date(item.trialExpiresAt).toLocaleDateString() : "30 days"} දක්වා active. එය අවසන් වනතුරු ඊළඟ account එක unlock නොවේ.`);
    else if (item.purchaseState === "ACTIVE") setWarning(`${item.number} දැනටමත් active account එකකි.`);
    else setWarning(nextAvailable ? `මුලින් ${nextAvailable.number} (Account ${nextAvailable.position}) මිලදීගෙන activate කරන්න.` : "දැනට මිලදීගත හැකි account එකක් නැහැ.");
  }
  return <section className="dash-card workspace-card cco-activation-workspace"><div className="workspace-heading"><div><span className="eyebrow">RESERVED ACCOUNT PURCHASE</span><h2>CCO Account Activation</h2><p>Bank transfer එකෙන් පසු slip එක submit කර reserved CN account එක activate කිරීමට ඉල්ලන්න.</p></div></div>
    {message && <p className="form-success">{message}</p>}{error && <p className="form-error">{error}</p>}{warning && <p className="activation-warning">⚠ {warning}</p>}
    <div className="activation-slot-grid">{config?.slots?.map((item) => <button type="button" key={item.position} className={`activation-slot-card ${item.purchaseState.toLowerCase()} ${slot === String(item.position) ? "selected" : ""}`} onClick={() => chooseAccount(item)}><span>ACCOUNT {item.position}</span><strong>{item.number}</strong><small>{item.purchaseState === "AVAILABLE" ? `AVAILABLE TO BUY • Rs. ${item.price.toLocaleString()}` : item.purchaseState === "PENDING" ? "PAYMENT UNDER REVIEW" : item.purchaseState === "TRIAL_ACTIVE" ? `30-DAY TRIAL ACTIVE • Until ${item.trialExpiresAt ? new Date(item.trialExpiresAt).toLocaleDateString() : "expiry"}` : item.purchaseState === "ACTIVE" ? "ACTIVE" : `LOCKED • Buy ${nextAvailable?.number ?? "previous account"} first`}</small></button>)}</div>
    <div className="academy-bank-box"><div><span className="eyebrow">ADIL ACADEMY ADMIN BANK DETAILS</span><h3>{config?.bankDetails?.bankName ?? "Bank details pending"}</h3></div>{config?.bankDetails ? <div className="bank-copy-grid">{[["Branch", config.bankDetails.branchName], ["Account holder", config.bankDetails.accountHolderName], ["Account number", config.bankDetails.accountNumber]].map(([label, value]) => <div key={label}><p><small>{label}</small><strong>{value}</strong></p><button type="button" onClick={() => void copy(String(value ?? ""))}>Copy</button></div>)}</div> : <p>Admin bank details configure කළ පසු මෙහි පෙන්වයි.</p>}</div>
    <form className="consultant-registration-form activation-request-form" onSubmit={submit} noValidate>
      <fieldset><legend>Consultant & account</legend><label>Consultant name<input value={config?.consultant?.name ?? ""} readOnly /></label><label>Main CN<input value={config?.consultant?.mainAccountNumber ?? ""} readOnly /></label><label>Phone<input value={config?.consultant?.phone ?? "Not added"} readOnly /></label><label>Selected account<input value={selected?.number ?? "Click AVAILABLE account above"} readOnly /></label><input type="hidden" name="slotPosition" value={selected?.position ?? ""} /></fieldset>
      <fieldset><legend>Placement & payment</legend><label>Fixed parent CN<input value={selected?.parentAccountNumber ?? "Automatically assigned"} readOnly /></label><input type="hidden" name="parentAccountId" value={selected?.parentAccountId ?? ""} /><label>Fixed side<input value={selected?.side ?? "Automatically assigned"} readOnly /></label><input type="hidden" name="side" value={selected?.side ?? ""} /><div className="payment-choice-wide"><span>Required amount</span><div className="activation-payment-choices"><button type="button" className={activationMode === "FULL" ? "selected" : ""} onClick={() => setActivationMode("FULL")} disabled={!selected}><strong>{selected ? `${selected.price.toLocaleString()} LKR` : "Full price"}</strong><small>FULL ACCOUNT • Permanent activation</small></button><button type="button" className={activationMode === "TRIAL" ? "selected" : ""} onClick={() => setActivationMode("TRIAL")} disabled={!selected}><strong>5,000 LKR</strong><small>30-DAY TRIAL • Auto suspend after one month</small></button></div><input type="hidden" name="amount" value={selected ? (activationMode === "TRIAL" ? selected.trialPrice : selected.price) : ""} /></div><label>Transaction reference<input name="transactionReference" required disabled={!selected} /></label><label>Senior consultant (optional)<input name="seniorConsultantName" disabled={!selected} /></label><label>Bank slip<input name="proof" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required disabled={!selected} /></label></fieldset>
      {error && <p className="form-error activation-submit-error">{error}</p>}
      <button className="button button-primary registration-submit" type="submit" disabled={busy || !config?.bankDetails || !selected}>{busy ? "Submitting..." : selected ? `Submit ${selected.number} Activation Request` : "Select the available account first"}</button>
    </form>
    <div className="workspace-list"><div className="workspace-list-head"><span>Requested account</span><span>Payment</span><span>Status</span></div>{requests.map((item) => <div className="workspace-list-row" key={item.id}><strong>CN{item.requestedNumericPart}<small>Account {item.slotPosition} • {item.side} • {item.activationMode}</small></strong><span>Rs. {Number(item.amount).toLocaleString()}<br />{item.transactionReference}</span><span className={`status-badge ${item.status === "APPROVED" ? "success" : item.status === "REJECTED" || item.status === "EXPIRED" ? "warning" : ""}`}>{item.status}</span></div>)}</div>
  </section>;
}

function AdminCcoActivationWorkspace() {
  const [config, setConfig] = useState<CcoActivationConfig | null>(null); const [requests, setRequests] = useState<CcoActivationView[]>([]); const [message, setMessage] = useState(""); const [error, setError] = useState("");
  async function load() { const [configResponse, requestResponse] = await Promise.all([fetch("/api/admin/cco-activation-config"), fetch("/api/admin/cco-activations")]); if (!configResponse.ok || !requestResponse.ok) throw new Error(); setConfig(await configResponse.json() as CcoActivationConfig); setRequests(((await requestResponse.json()) as { requests: CcoActivationView[] }).requests); }
  useEffect(() => { void load().catch(() => setError("CCO activation admin data load කළ නොහැක.")); }, []);
  async function saveConfig(event: FormEvent<HTMLFormElement>) { event.preventDefault(); const form = new FormData(event.currentTarget); const prices = Object.fromEntries([2,3,4,5,6,7].map((position) => [String(position), Number(form.get(`price${position}`))])); const response = await fetch("/api/admin/cco-activation-config", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ bankDetails: { bankName: form.get("bankName"), branchName: form.get("branchName"), accountHolderName: form.get("accountHolderName"), accountNumber: form.get("accountNumber") }, prices }) }); const data = await response.json() as { message?: string }; setMessage(response.ok ? data.message ?? "Saved." : "Settings save failed."); if (response.ok) await load(); }
  async function proof(item: CcoActivationView) { const response = await fetch(`/api/admin/cco-activations/${item.id}/proof`); if (!response.ok) { setError("Slip load failed."); return; } const url = URL.createObjectURL(await response.blob()); window.open(url, "_blank", "noopener,noreferrer"); setTimeout(() => URL.revokeObjectURL(url), 60000); }
  async function review(item: CcoActivationView, status: "APPROVED" | "REJECTED") { const note = status === "REJECTED" ? window.prompt("Reject reason") ?? "" : "Payment verified by Admin"; if (status === "APPROVED" && !window.confirm(`${item.consultantName} • CN${item.requestedNumericPart}\nPlan: ${item.activationMode === "TRIAL" ? "30-DAY TRIAL" : "FULL / PERMANENT"}\nParent: ${item.parentAccountNumber} ${item.side}\nAmount: Rs. ${Number(item.amount).toLocaleString()}\n\nApprove & activate කරන්නද?`)) return; const response = await fetch(`/api/admin/cco-activations/${item.id}/review`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status, note }) }); const data = await response.json() as { message?: string }; if (response.ok) { setMessage(data.message ?? "Reviewed."); await load(); } else setError(data.message ?? "Review failed."); }
  return <section className="dash-card workspace-card cco-activation-admin"><div className="workspace-heading"><div><span className="eyebrow">ACCOUNT ACTIVATION CONTROL</span><h2>CCO Activations</h2><p>Bank slip, amount සහ placement verify කර reserved accounts activate කරන්න.</p></div></div>{message && <p className="form-success">{message}</p>}{error && <p className="form-error">{error}</p>}
    <details className="activation-settings"><summary>Adil Academy bank details & account prices</summary><form className="bank-details-form" onSubmit={saveConfig}><label>Bank name<input name="bankName" defaultValue={config?.bankDetails?.bankName ?? ""} required /></label><label>Branch<input name="branchName" defaultValue={config?.bankDetails?.branchName ?? ""} required /></label><label>Account holder<input name="accountHolderName" defaultValue={config?.bankDetails?.accountHolderName ?? ""} required /></label><label>Account number<input name="accountNumber" defaultValue={config?.bankDetails?.accountNumber ?? ""} required /></label>{[2,3,4,5,6,7].map((position) => <label key={position}>{position}th account price<input name={`price${position}`} type="number" defaultValue={config?.prices?.[String(position)] ?? (position < 4 ? 20000 : 15000)} required /></label>)}<button className="button button-primary" type="submit">Save activation settings</button></form></details>
    <div className="workspace-list"><div className="workspace-list-head"><span>Consultant / Account</span><span>Payment & Placement</span><span>Actions</span></div>{requests.map((item) => <div className="workspace-list-row" key={item.id}><strong>{item.consultantName}<small>{item.consultantEmail}<br />{item.consultantPhone ?? "No phone"}<br />Requested: CN{item.requestedNumericPart}</small></strong><span><b>{item.activationMode === "TRIAL" ? "30-DAY TRIAL" : "FULL / PERMANENT"}</b><br />Rs. {Number(item.amount).toLocaleString()} • {item.transactionReference}<br />Parent: {item.parentAccountNumber} • {item.side}<br />Senior: {item.seniorConsultantName || "Not added"}<br /><span className={`status-badge ${item.status === "APPROVED" ? "success" : ""}`}>{item.status}</span></span><span className="admin-row-actions"><button type="button" disabled={!item.hasProof} onClick={() => void proof(item)}>View Slip</button>{item.status === "PENDING" && <><button type="button" onClick={() => void review(item, "APPROVED")}>Approve & Activate</button><button type="button" onClick={() => void review(item, "REJECTED")}>Reject</button></>}</span></div>)}</div>
  </section>;
}

type ConsultantPayoutSummary = { id: string; name: string; email: string; accounts: string[]; directIncome: number; serviceGroupIncome: number; totalIncome: number; pendingBalance: number; availableBalance: number; fridayPayable: number; bankDetailsReady: boolean; bankSummary: string | null; bankDetails: null | { bankName: string; branchName: string; accountHolderName: string; accountNumber: string } };

function currentWeekKey() {
  const date = new Date(); const start = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((date.getTime() - start.getTime()) / 86400000) + start.getUTCDay() + 1) / 7);
  return `${date.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

function AdminCommissionWorkspace() {
  const [rows, setRows] = useState<ConsultantPayoutSummary[]>([]); const [totalPayable, setTotalPayable] = useState(0); const [totalIncome, setTotalIncome] = useState(0);
  const [payoutReminder, setPayoutReminder] = useState<null | { payoutDate?: string; dueAt?: string; completedAt?: string | null }>(null);
  const [message, setMessage] = useState(""); const [busyId, setBusyId] = useState<string | null>(null);
  async function load() { const response = await fetch("/api/admin/consultant-payout-summary"); if (!response.ok) { setMessage("Payout summary load failed."); return; } const data = await response.json() as { consultants: ConsultantPayoutSummary[]; totalFridayPayable: number; totalIncome: number; payoutReminder?: typeof payoutReminder }; setRows(data.consultants); setTotalPayable(data.totalFridayPayable); setTotalIncome(data.totalIncome); setPayoutReminder(data.payoutReminder ?? null); }
  useEffect(() => { void load(); }, []);
  async function copyText(value: string, label: string) { await navigator.clipboard.writeText(value); setMessage(`${label} copy විය.`); }
  async function payAndClear(item: ConsultantPayoutSummary) { if (!window.confirm(`${item.name} (${item.accounts.join(", ")}) වෙත Rs. ${item.fridayPayable.toLocaleString()} bank transfer එක SUCCESS ද?\n\nOK කළ පසු weekly balance එක Rs. 0 වේ.`)) return; setBusyId(item.id); setMessage(""); const response = await fetch(`/api/admin/consultants/${item.id}/pay-and-clear`, { method: "POST" }); const data = await response.json() as { message?: string; amount?: number; consultantName?: string }; setMessage(response.ok ? `${data.consultantName} සඳහා Rs. ${Number(data.amount).toLocaleString()} PAID කර balance එක clear විය.` : data.message ?? "Payment clear කිරීම අසාර්ථකයි."); setBusyId(null); if (response.ok) await load(); }
  return <section className="dash-card workspace-card commission-admin"><div className="workspace-heading"><div><span className="eyebrow">FRIDAY COMMISSION CONTROL</span><h2>Consultant Payouts & Ranking</h2><p>Direct admission, service-group income සහ සියලු CCO accounts එකතුව.</p></div></div>
    {payoutReminder && !payoutReminder.completedAt && totalPayable > 0 && <div className="friday-payout-alert"><strong>⚠ FRIDAY PAYOUTS PENDING</strong><span>{rows.filter((item) => item.fridayPayable > 0).length} consultants සඳහා Rs. {totalPayable.toLocaleString()} manual bank transfers තවම සම්පූර්ණ කර නැහැ.</span><small>සෑම transfer එකක්ම SUCCESS වූ පසු අදාළ row එකේ “Paid & Clear Balance” ඔබන්න.</small></div>}
    {payoutReminder?.completedAt && totalPayable <= 0 && <p className="form-success">✓ Friday consultant payments සියල්ල සම්පූර්ණයි.</p>}
    <div className="commission-total-grid"><MetricCard label="All-time Consultant Income" value={`Rs. ${totalIncome.toLocaleString()}`} note="Direct + service group" icon={<TrendingUp />} /><MetricCard label="This Friday Payable" value={`Rs. ${totalPayable.toLocaleString()}`} note={`${rows.filter((item) => item.fridayPayable > 0).length} consultants`} icon={<Wallet />} /></div>
    <div className="payout-guide"><strong>Simple manual payout</strong><span>Bank details copy කරන්න → banking app එකෙන් full amount යවන්න → Success වූ පසු පමණක් “Paid & Clear Balance” ඔබන්න.</span></div>
    {message && <p className="form-success">{message}</p>}
    <div className="workspace-list payout-list"><div className="workspace-list-head"><span>Rank / Consultant</span><span>Bank transfer details</span><span>Payable / Action</span></div>{rows.map((item, index) => <div className="workspace-list-row" key={item.id}><strong>#{index + 1} • {item.name}<small>{item.accounts.join(", ") || "No CN"}<br />{item.email}<br />Income: Rs. {item.totalIncome.toLocaleString()}</small></strong><span>{item.bankDetails ? <><b>{item.bankDetails.bankName} — {item.bankDetails.branchName}</b><br />{item.bankDetails.accountHolderName}<br />{item.bankDetails.accountNumber}<div className="copy-actions"><button type="button" onClick={() => void copyText(`${item.bankDetails!.bankName}\n${item.bankDetails!.branchName}\n${item.bankDetails!.accountHolderName}\n${item.bankDetails!.accountNumber}`, "Bank details")}>Copy Bank Details</button><button type="button" onClick={() => void copyText(String(item.fridayPayable), "Amount")}>Copy Amount</button></div></> : <strong>BANK DETAILS MISSING</strong>}</span><span><strong>Rs. {item.fridayPayable.toLocaleString()}</strong><small>Full weekly balance</small><button className="button button-primary pay-clear-button" type="button" disabled={busyId === item.id || item.fridayPayable <= 0 || !item.bankDetails} onClick={() => void payAndClear(item)}>{busyId === item.id ? "Clearing..." : item.fridayPayable > 0 ? "Paid & Clear Balance" : "Balance Clear"}</button></span></div>)}</div>
  </section>;
}

function ConsultantBankDetailsWorkspace() {
  const [details, setDetails] = useState<null | { bankName: string; branchName: string; accountHolderName: string; accountNumberLast4: string }>(null);
  const [accounts, setAccounts] = useState<ConsultantAccountOption[]>([]);
  const [message, setMessage] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { Promise.all([fetch("/api/consultant/bank-details"), fetch("/api/consultant/accounts")]).then(async ([bankResponse, accountResponse]) => {
    if (!bankResponse.ok || !accountResponse.ok) throw new Error();
    setDetails(((await bankResponse.json()) as { bankDetails: typeof details }).bankDetails);
    setAccounts(((await accountResponse.json()) as { accounts: ConsultantAccountOption[] }).accounts);
  }).catch(() => setError("Account details load කළ නොහැක.")); }, []);
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage(""); setError(""); const form = new FormData(event.currentTarget);
    const response = await fetch("/api/consultant/bank-details", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ bankName: form.get("bankName"), branchName: form.get("branchName"), accountHolderName: form.get("accountHolderName"), accountNumber: form.get("accountNumber") }) });
    const data = await response.json() as { message?: string; bankDetails?: typeof details };
    if (response.ok) { setDetails(data.bankDetails ?? null); setMessage("Bank details securely saved. Adminට payout verification සඳහා දැන් මෙය පෙන්වයි."); (event.currentTarget.elements.namedItem("accountNumber") as HTMLInputElement).value = ""; }
    else setError(data.message ?? "Bank details save failed."); setBusy(false);
  }
  return <section className="dash-card workspace-card bank-details-workspace"><div className="workspace-heading"><div><span className="eyebrow">CCO ACCOUNT PROFILE</span><h2>My Accounts & Bank Details</h2><p>ඔබගේ CN accounts සහ commission payout සඳහා verified bank details.</p></div></div>
    <div className="consultant-account-chips">{accounts.map(({ account }) => <span key={account.id}><strong>{account.prefix}{account.numericPart}</strong><small>{account.status}</small></span>)}</div>
    {details && <p className="saved-bank-summary"><ShieldCheck /> Saved: {details.bankName} • {details.branchName} • Account ending {details.accountNumberLast4}</p>}
    {message && <p className="form-success">{message}</p>}{error && <p className="form-error">{error}</p>}
    <form className="bank-details-form" onSubmit={save}><label>Bank name<input name="bankName" required defaultValue={details?.bankName ?? ""} /></label><label>Branch name<input name="branchName" required defaultValue={details?.branchName ?? ""} /></label><label>Account holder name<input name="accountHolderName" required defaultValue={details?.accountHolderName ?? ""} /></label><label>Account number<input name="accountNumber" required autoComplete="off" placeholder={details ? `Saved account ending ${details.accountNumberLast4} — enter again to update` : "Bank account number"} /></label><button className="button button-primary" type="submit" disabled={busy}>{busy ? "Saving..." : details ? "Update bank details" : "Save bank details"}</button></form>
    <p className="registration-note">Account number encrypted කර database එකේ save වේ. Payout process කරන authorized Adminට පමණක් සම්පූර්ණ අංකය බැලිය හැක.</p>
  </section>;
}

type ConsultantAccountOption = { account: { id: string; prefix: string; numericPart: number; status: string } };
type CourseOption = { id: string; title: string; price: string; currency: string };
type AdminStudentRegistrationOptions = {
  courses: CourseOption[];
  accounts: Array<{
    id: string;
    number: string;
    numericPart: number;
    ownerId: string;
    ownerName: string;
    ownerEmail: string;
  }>;
};

function AdminStudentRegistrationWorkspace({
  onClose,
  onCreated
}: {
  onClose: () => void;
  onCreated: () => Promise<void>;
}) {
  const [options, setOptions] = useState<AdminStudentRegistrationOptions>({ courses: [], accounts: [] });
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [withoutNic, setWithoutNic] = useState(false);
  const [province, setProvince] = useState("");
  const [district, setDistrict] = useState("");
  const [selectedCourseId, setSelectedCourseId] = useState("");
  const [paymentPlan, setPaymentPlan] = useState<"FULL" | "HALF">("FULL");
  const [assignmentType, setAssignmentType] = useState<"DIRECT" | "CONSULTANT">("DIRECT");
  const selectedCourse = options.courses.find((course) => course.id === selectedCourseId);
  const districts = province && sriLankaLocations[province] ? Object.keys(sriLankaLocations[province]) : [];
  const cities = province && district && sriLankaLocations[province]?.[district] ? sriLankaLocations[province][district] : [];

  useEffect(() => {
    fetch("/api/admin/student-registration-options")
      .then(async (response) => {
        const data = await response.json().catch(() => ({})) as Partial<AdminStudentRegistrationOptions> & { message?: string };
        if (!response.ok) throw new Error(data.message ?? "Registration options load failed.");
        setOptions({ courses: data.courses ?? [], accounts: data.accounts ?? [] });
      })
      .catch((reason: unknown) => setError(reason instanceof Error ? reason.message : "Registration options load failed."))
      .finally(() => setLoading(false));
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setError(""); setMessage("");
    const form = new FormData(event.currentTarget);
    const payload: Record<string, unknown> = {
      firstName: form.get("firstName"), lastName: form.get("lastName"), email: form.get("email"), phone: form.get("phone"),
      dateOfBirth: form.get("dateOfBirth"), nicOrPassport: form.get("nicOrPassport") || undefined, withoutNic,
      addressLine1: form.get("addressLine1"), addressLine2: form.get("addressLine2") || undefined,
      province: form.get("province"), district: form.get("district"), city: form.get("city"),
      courseId: selectedCourseId, paymentPlan, assignmentType
    };
    if (assignmentType === "CONSULTANT") {
      payload.parentAccountId = form.get("parentAccountId");
      payload.side = form.get("side");
    }
    const response = await fetch("/api/admin/student-registrations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => ({})) as { message?: string; payId?: string };
    if (response.ok) {
      setMessage(`Registration saved. ${data.payId ?? "Pay ID"} studentගේ email එකට යවා ඇත.`);
      await onCreated();
    } else {
      setError(data.message ?? `Registration failed (HTTP ${response.status}).`);
    }
    setBusy(false);
  }

  return <section className="dash-card workspace-card consultant-registration admin-student-registration">
    <div className="workspace-heading">
      <div><span className="eyebrow">ADMIN • STUDENT ONBOARDING</span><h2>Register New Student</h2><p>Academy Direct admission එකක් හෝ consultant CN placement එකක් ලෙස student register කරන්න.</p></div>
      <button type="button" className="button button-secondary" onClick={onClose}>Back to Students</button>
    </div>
    {loading && <p className="registration-note">Courses සහ active consultant accounts load වෙමින් පවතී...</p>}
    {message && <p className="form-success">{message}</p>}{error && <p className="form-error">{error}</p>}
    {!loading && <form className="consultant-registration-form" onSubmit={submit}>
      <fieldset><legend>Admission ownership</legend>
        <div className="payment-choice-wide admin-assignment-choice">
          <span>Admission type</span>
          <div className="activation-payment-choices">
            <button type="button" className={assignmentType === "DIRECT" ? "selected" : ""} onClick={() => setAssignmentType("DIRECT")}><strong>Academy Direct</strong><small>ADMIN ADMISSION • NO CONSULTANT POINT</small></button>
            <button type="button" className={assignmentType === "CONSULTANT" ? "selected" : ""} onClick={() => setAssignmentType("CONSULTANT")}><strong>Assign Consultant</strong><small>CN ACCOUNT • LEFT / RIGHT</small></button>
          </div>
        </div>
        {assignmentType === "CONSULTANT" && <>
          <label>Consultant account<select name="parentAccountId" required><option value="">Active CN account තෝරන්න</option>{options.accounts.map((account) => <option key={account.id} value={account.id}>{account.number} — {account.ownerName} ({account.ownerEmail})</option>)}</select></label>
          <label>Placement side<select name="side" required><option value="">LEFT / RIGHT තෝරන්න</option><option value="LEFT">LEFT</option><option value="RIGHT">RIGHT</option></select></label>
        </>}
        <p className="registration-note">{assignmentType === "DIRECT" ? "මෙය Academy Direct admission එකකි. Consultant point සහ direct commission එකක් නිර්මාණය නොවේ." : "Full payment approve වූ පසු තෝරාගත් CN account side එකට student placement සහ point එක process වේ."}</p>
      </fieldset>
      <fieldset><legend>Personal information</legend>
        <label>First name<input name="firstName" required minLength={2} /></label><label>Last name<input name="lastName" required minLength={2} /></label>
        <label>Email<input name="email" type="email" required autoComplete="off" /></label><label>Phone number<input name="phone" type="tel" placeholder="+94 7X XXX XXXX" required /></label>
        <label>Date of birth<input name="dateOfBirth" type="date" max={new Date().toISOString().slice(0, 10)} required /></label><label>NIC / Passport<input name="nicOrPassport" disabled={withoutNic} required={!withoutNic} /></label>
        <label className="registration-check"><input type="checkbox" checked={withoutNic} onChange={(event) => setWithoutNic(event.target.checked)} /> Student without a NIC</label>
      </fieldset>
      <fieldset><legend>Residence information</legend>
        <label className="wide">Address line 1<input name="addressLine1" required /></label><label className="wide">Address line 2<input name="addressLine2" /></label>
        <label>Country<input value="Sri Lanka" readOnly /></label><label>Province (search)<input name="province" list="admin-sri-lanka-provinces" value={province} onChange={(event) => { setProvince(event.target.value); setDistrict(""); }} placeholder="Search province..." autoComplete="off" required /><datalist id="admin-sri-lanka-provinces">{sriLankaProvinces.map((item) => <option value={item} key={item} />)}</datalist></label>
        <label>District (search)<input name="district" list="admin-sri-lanka-districts" value={district} onChange={(event) => setDistrict(event.target.value)} placeholder={province ? "Search district..." : "Select province first"} disabled={!sriLankaLocations[province]} autoComplete="off" required /><datalist id="admin-sri-lanka-districts">{districts.map((item) => <option value={item} key={item} />)}</datalist></label>
        <label>City (search)<input name="city" list="admin-sri-lanka-cities" placeholder={district ? "Search city..." : "Select district first"} disabled={!cities.length} autoComplete="off" required /><datalist id="admin-sri-lanka-cities">{cities.map((item) => <option value={item} key={item} />)}</datalist></label>
      </fieldset>
      <fieldset><legend>Course & payment</legend>
        <label className="wide">Course<select required value={selectedCourseId} onChange={(event) => { setSelectedCourseId(event.target.value); setPaymentPlan("FULL"); }}><option value="">Course එක තෝරන්න</option>{options.courses.map((course) => <option key={course.id} value={course.id}>{course.title} — {course.currency} {Number(course.price).toLocaleString()}</option>)}</select></label>
        {selectedCourse && <div className="payment-choice-wide"><span>Payment plan</span><div className="activation-payment-choices"><button type="button" className={paymentPlan === "FULL" ? "selected" : ""} onClick={() => setPaymentPlan("FULL")}><strong>{Number(selectedCourse.price).toLocaleString()} LKR</strong><small>FULL PAYMENT</small></button>{Number(selectedCourse.price) === 15000 && <button type="button" className={paymentPlan === "HALF" ? "selected" : ""} onClick={() => setPaymentPlan("HALF")}><strong>10,000 LKR</strong><small>HALF PAYMENT</small></button>}</div></div>}
        <label>Medium<input value="සිංහල" readOnly /></label><label>Class format<input value="Online LMS" readOnly /></label>
      </fieldset>
      <div className="registration-flow"><strong>Secure workflow</strong><span>Registration → Pay ID email → Bank reference & proof → Admin payment approval → OTP → Password → Course access</span></div>
      <button className="button button-primary registration-submit" type="submit" disabled={busy || !selectedCourseId}>{busy ? "Sending Pay ID..." : "Register Student & Send Pay ID"}<ArrowRight size={17} /></button>
    </form>}
  </section>;
}

function ConsultantStudentRegistration() {
  const [accounts, setAccounts] = useState<ConsultantAccountOption[]>([]);
  const [courses, setCourses] = useState<CourseOption[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [withoutNic, setWithoutNic] = useState(false);
  const [province, setProvince] = useState("");
  const [district, setDistrict] = useState("");
  const [selectedCourseId, setSelectedCourseId] = useState("");
  const [paymentPlan, setPaymentPlan] = useState<"FULL" | "HALF">("FULL");
  const selectedCourse = courses.find((course) => course.id === selectedCourseId);
  const districts = province && sriLankaLocations[province] ? Object.keys(sriLankaLocations[province]) : [];
  const cities = province && district && sriLankaLocations[province]?.[district] ? sriLankaLocations[province][district] : [];
  useEffect(() => {
    Promise.all([fetch("/api/consultant/accounts"), fetch("/api/courses")]).then(async ([accountResponse, courseResponse]) => {
      if (!accountResponse.ok || !courseResponse.ok) throw new Error();
      setAccounts(((await accountResponse.json()) as { accounts: ConsultantAccountOption[] }).accounts.filter((item) => item.account.prefix === "CN" && item.account.status === "ACTIVE"));
      setCourses(((await courseResponse.json()) as { courses: CourseOption[] }).courses ?? []);
    }).catch(() => setError("Accounts සහ courses load කළ නොහැක."));
  }, []);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(""); setMessage("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/consultant/student-registrations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
      firstName: form.get("firstName"), lastName: form.get("lastName"), email: form.get("email"), phone: form.get("phone"),
      dateOfBirth: form.get("dateOfBirth"), nicOrPassport: form.get("nicOrPassport") || undefined, withoutNic,
      addressLine1: form.get("addressLine1"), addressLine2: form.get("addressLine2") || undefined,
      province: form.get("province"), district: form.get("district"), city: form.get("city"),
      courseId: form.get("courseId"), paymentPlan: form.get("paymentPlan"), parentAccountId: form.get("parentAccountId"), side: form.get("side")
    }) });
    const data = await response.json() as { message?: string; payIdSent?: boolean };
    if (response.ok) { setMessage(`Registration saved. ${paymentPlan === "HALF" ? "Half payment — Rs. 10,000" : `Full payment — Rs. ${Number(selectedCourse?.price ?? 0).toLocaleString()}`} ලෙස Pay ID එක studentගේ email එකට යවා ඇත.`); event.currentTarget.reset(); setWithoutNic(false); setProvince(""); setDistrict(""); setSelectedCourseId(""); setPaymentPlan("FULL"); }
    else setError(data.message ?? "Registration failed.");
    setBusy(false);
  }
  return <section className="dash-card workspace-card consultant-registration">
    <div className="workspace-heading"><div><span className="eyebrow">CCO • STUDENT ONBOARDING</span><h2>Student Registration</h2><p>Student details එකවර save කර secure Pay ID එක studentගේ email එකට යවන්න.</p></div></div>
    {message && <p className="form-success">{message}</p>}{error && <p className="form-error">{error}</p>}
    <form className="consultant-registration-form" onSubmit={submit}>
      <fieldset><legend>Personal information</legend>
        <label>First name<input name="firstName" required minLength={2} /></label><label>Last name<input name="lastName" required minLength={2} /></label>
        <label>Email<input name="email" type="email" required /></label><label>Phone number<input name="phone" type="tel" placeholder="+94 7X XXX XXXX" required /></label>
        <label>Date of birth<input name="dateOfBirth" type="date" max={new Date().toISOString().slice(0, 10)} required /></label><label>NIC / Passport<input name="nicOrPassport" disabled={withoutNic} required={!withoutNic} /></label>
        <label className="registration-check"><input type="checkbox" checked={withoutNic} onChange={(event) => setWithoutNic(event.target.checked)} /> Student without a NIC</label>
      </fieldset>
      <fieldset><legend>Consultant placement</legend>
        <label>Registered by<select name="parentAccountId" required><option value="">CN account තෝරන්න</option>{accounts.map(({ account }) => <option key={account.id} value={account.id}>{account.prefix}{account.numericPart}</option>)}</select></label>
        <label>Placement side<select name="side" required><option value="">LEFT / RIGHT තෝරන්න</option><option value="LEFT">LEFT</option><option value="RIGHT">RIGHT</option></select></label>
        <p className="registration-note">තෝරාගත් CN account එකේ හිස් LEFT හෝ RIGHT position එක payment approve වූ පසු studentට ලබාදේ.</p>
      </fieldset>
      <fieldset><legend>Residence information</legend>
        <label className="wide">Address line 1<input name="addressLine1" required /></label><label className="wide">Address line 2<input name="addressLine2" /></label>
        <label>Country<input value="Sri Lanka" readOnly /></label><label>Province (search)<input name="province" list="sri-lanka-provinces" value={province} onChange={(event) => { setProvince(event.target.value); setDistrict(""); }} placeholder="Search province..." autoComplete="off" required /><datalist id="sri-lanka-provinces">{sriLankaProvinces.map((item) => <option value={item} key={item} />)}</datalist></label>
        <label>District (search)<input name="district" list="sri-lanka-districts" value={district} onChange={(event) => setDistrict(event.target.value)} placeholder={province ? "Search district..." : "Select province first"} disabled={!sriLankaLocations[province]} autoComplete="off" required /><datalist id="sri-lanka-districts">{districts.map((item) => <option value={item} key={item} />)}</datalist></label><label>City (search)<input name="city" list="sri-lanka-cities" placeholder={district ? "Search city..." : "Select district first"} disabled={!cities.length} autoComplete="off" required /><datalist id="sri-lanka-cities">{cities.map((item) => <option value={item} key={item} />)}</datalist></label>
      </fieldset>
      <fieldset><legend>Course information</legend>
        <label className="wide">Course<select name="courseId" required value={selectedCourseId} onChange={(event) => { setSelectedCourseId(event.target.value); setPaymentPlan("FULL"); }}><option value="">Course එක තෝරන්න</option>{courses.map((course) => <option key={course.id} value={course.id}>{course.title} — {course.currency} {Number(course.price).toLocaleString()}</option>)}</select></label>
        {selectedCourse && <div className="payment-choice-wide"><span>Payment plan</span><div className="activation-payment-choices"><button type="button" className={paymentPlan === "FULL" ? "selected" : ""} onClick={() => setPaymentPlan("FULL")}><strong>{Number(selectedCourse.price).toLocaleString()} LKR</strong><small>FULL PAYMENT</small></button>{Number(selectedCourse.price) === 15000 && <button type="button" className={paymentPlan === "HALF" ? "selected" : ""} onClick={() => setPaymentPlan("HALF")}><strong>10,000 LKR</strong><small>HALF PAYMENT</small></button>}</div><input type="hidden" name="paymentPlan" value={paymentPlan} /></div>}
        <label>Medium<input value="සිංහල" readOnly /></label><label>Class format<input value="Online LMS" readOnly /></label>
      </fieldset>
      <div className="registration-flow"><strong>ඊළඟ පියවර</strong><span>Pay ID email → Bank transfer reference → Payment proof → Admin approval → OTP → Password & Login</span></div>
      <button className="button button-primary registration-submit" type="submit" disabled={busy}>{busy ? "Sending Pay ID..." : "Register & Send Pay ID"}<ArrowRight size={17} /></button>
    </form>
  </section>;
}

type PlatformNotification = {
  id: string; type: string; title: string; message: string;
  readAt: string | null; createdAt: string;
};

function NotificationBell({ enabled, onOpenModule }: { enabled: boolean; onOpenModule?: (module: string) => void }) {
  const [items, setItems] = useState<PlatformNotification[]>([]);
  const [open, setOpen] = useState(false);
  const initialized = useRef(false);
  const knownUnread = useRef(new Set<string>());

  function playAlert() {
    try {
      const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const context = new AudioContextClass();
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(880, context.currentTime);
      oscillator.frequency.setValueAtTime(660, context.currentTime + 0.14);
      gain.gain.setValueAtTime(0.0001, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.25, context.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.32);
      oscillator.connect(gain); gain.connect(context.destination);
      oscillator.start(); oscillator.stop(context.currentTime + 0.34);
      oscillator.addEventListener("ended", () => void context.close());
    } catch { /* Browser may require a user interaction before audio. */ }
  }

  async function loadNotifications() {
    if (!enabled) return;
    const response = await fetch("/api/notifications");
    if (!response.ok) return;
    const data = await response.json() as { notifications: PlatformNotification[] };
    const unread = data.notifications.filter((item) => !item.readAt);
    if (initialized.current && unread.some((item) => !knownUnread.current.has(item.id))) playAlert();
    knownUnread.current = new Set(unread.map((item) => item.id));
    initialized.current = true;
    setItems(data.notifications);
  }

  useEffect(() => {
    void loadNotifications();
    if (!enabled) return;
    const timer = window.setInterval(() => void loadNotifications(), 12_000);
    return () => window.clearInterval(timer);
  }, [enabled]);

  async function markRead(item: PlatformNotification) {
    if (!item.readAt) await fetch(`/api/notifications/${item.id}/read`, { method: "POST" });
    setItems((current) => current.map((entry) => entry.id === item.id ? { ...entry, readAt: entry.readAt ?? new Date().toISOString() } : entry));
    if (item.type === "CCO_ACTIVATION_REQUEST") {
      setOpen(false);
      onOpenModule?.("CCO Activations");
    } else if (item.type === "FRIDAY_PAYOUT_REMINDER") {
      setOpen(false);
      onOpenModule?.("Commissions");
    } else if (item.type === "SUPPORT_WAITING") {
      setOpen(false);
      onOpenModule?.("Customer Support");
    }
  }

  async function clearNotifications() {
    if (!items.length || !window.confirm("සියලු notifications clear කරන්නද?")) return;
    const response = await fetch("/api/notifications", { method: "DELETE" });
    if (!response.ok) return;
    knownUnread.current.clear();
    setItems([]);
  }

  const unreadCount = items.filter((item) => !item.readAt).length;
  return <div className="notification-center">
    <button type="button" className="notification-trigger" aria-label="Notifications" onClick={() => { setOpen((value) => !value); if (enabled) playAlert(); }}>
      <Bell />{unreadCount > 0 && <span className="notification-count">{unreadCount > 99 ? "99+" : unreadCount}</span>}
    </button>
    {open && <div className="notification-panel">
      <div className="notification-panel-heading">
        <span><strong>Notifications</strong><small>{unreadCount} unread</small></span>
        {items.length > 0 && <button type="button" className="notification-clear-button" onClick={() => void clearNotifications()}>Clear all</button>}
      </div>
      {items.slice(0, 12).map((item) => <button type="button" className={item.readAt ? "read" : "unread"} key={item.id} onClick={() => void markRead(item)}>
        <strong>{item.title}</strong><span>{item.message}</span><small>{new Date(item.createdAt).toLocaleString()}</small>
      </button>)}
      {!items.length && <p>No notifications yet.</p>}
    </div>}
  </div>;
}

function Dashboard({
  user,
  onLogout
}: {
  user: DemoUser;
  onLogout: () => void;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeModule, setActiveModule] = useState("Overview");
  const [portalMode, setPortalMode] = useState<"consultant" | "learning">("consultant");
  const [dashboardTheme, setDashboardTheme] = useState<"dark" | "light">(() => window.localStorage.getItem("adil-dashboard-theme") === "light" ? "light" : "dark");
  useEffect(() => { window.localStorage.setItem("adil-dashboard-theme", dashboardTheme); }, [dashboardTheme]);
  useEffect(() => {
    if (!["consultant", "staff", "admin"].includes(user.role)) return;
    const heartbeat = () => {
      if (document.visibilityState === "visible") void fetch("/api/support/heartbeat", { method: "POST" });
    };
    heartbeat();
    const timer = window.setInterval(heartbeat, 25_000);
    document.addEventListener("visibilitychange", heartbeat);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", heartbeat);
    };
  }, [user.id, user.role]);
  const effectiveRole: UserRole = user.role === "consultant" && portalMode === "learning" ? "student" : user.role;
  const roleTitle = {
    student: "Student Dashboard",
    consultant: "Consultant Control Panel",
    staff: "Staff Operations",
    admin: "Super Admin Control"
  }[effectiveRole];

  return (
    <div className={`dashboard-shell dashboard-theme-${dashboardTheme}`}>
      <aside className={sidebarOpen ? "dashboard-sidebar sidebar-open" : "dashboard-sidebar"}>
        <div className="sidebar-top">
          <Logo />
          <button
            type="button"
            className="sidebar-close"
            onClick={() => setSidebarOpen(false)}
          >
            <X />
          </button>
        </div>
        <span className="sidebar-section-label">MAIN MENU</span>
        <nav>
          {dashboardNav[effectiveRole].map((item) => (
            <button
              type="button"
              className={activeModule === item.label ? "active" : ""}
              key={item.label}
              onClick={() => {
                setActiveModule(item.label);
                setSidebarOpen(false);
              }}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-support">
          <ShieldCheck />
          <strong>Need help?</strong>
          <span>Adil Academy support team</span>
          <button type="button">Contact support</button>
        </div>
        <button className="logout-button" type="button" onClick={onLogout}>
          <LogOut />
          Logout
        </button>
      </aside>
      <main className="dashboard-main">
        <header className="dashboard-header">
          <button
            className="dashboard-menu"
            type="button"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu />
          </button>
          <div>
            <span className="eyebrow">{roleTitle}</span>
            <h1>ආයුබෝවන්, {user.name.split(" ")[0]}</h1>
          </div>
          <div className="header-actions">
            {user.role === "consultant" && user.learningPortalEnabled !== false && <button type="button" className="portal-switch-button" onClick={() => { setPortalMode((mode) => mode === "consultant" ? "learning" : "consultant"); setActiveModule("Overview"); }}><BookOpen /> <span>{portalMode === "consultant" ? "Learning Portal" : "Consultant Portal"}</span></button>}
            <button type="button" className="theme-toggle" onClick={() => setDashboardTheme((theme) => theme === "dark" ? "light" : "dark")} aria-label={dashboardTheme === "dark" ? "Switch to light theme" : "Switch to dark theme"} title={dashboardTheme === "dark" ? "Light mode" : "Dark mode"}>
              {dashboardTheme === "dark" ? <Sun /> : <Moon />}
            </button>
            <button type="button" className="header-logout" onClick={onLogout} aria-label="Logout">
              <LogOut /> <span>Logout</span>
            </button>
            <NotificationBell enabled={["consultant", "staff", "admin"].includes(user.role)} onOpenModule={setActiveModule} />
            <div className="dashboard-user">
              <span>{user.name.slice(0, 2).toUpperCase()}</span>
              <div>
                <strong>{user.name}</strong>
                <small>{user.accountNumber ?? roleTitle}</small>
              </div>
            </div>
          </div>
        </header>
        <div className="dashboard-content">
          <div className="dashboard-welcome">
            <div>
              <h2>{roleTitle}</h2>
              {activeModule === "Overview" && <p>ඔබගේ අද දින platform summary එක මෙන්න.</p>}
            </div>
            <span className="live-status">
              <i /> System Online
            </span>
          </div>
          {activeModule === "Overview" ? (
            <>
              {effectiveRole === "student" && <StudentDashboard />}
              {effectiveRole === "consultant" && <ConsultantDashboard onOpen={setActiveModule} />}
              {effectiveRole === "staff" && <OperationsDashboard role="staff" />}
              {effectiveRole === "admin" && <AdminDashboard onOpen={setActiveModule} />}
            </>
          ) : (
            <FeatureWorkspace role={effectiveRole} module={activeModule} />
          )}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<DemoUser | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then(async (response) => {
        if (!response.ok) return null;
        return (await response.json()) as { user: DemoUser };
      })
      .then((data) => setUser(data?.user ?? null))
      .finally(() => setAuthChecked(true));
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setUser(null);
  }

  if (!authChecked) {
    return (
      <div className="app-loading">
        <Logo />
        <span />
      </div>
    );
  }

  return (
    <><Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage onLogin={setUser} />} />
      <Route path="/cco-main" element={<CcoMainApplicationPage />} />
      <Route
        path="/dashboard"
        element={
          user ? (
            <Dashboard user={user} onLogout={logout} />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes><CustomerSupportWidget /></>
  );
}
