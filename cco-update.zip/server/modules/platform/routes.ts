import crypto from "node:crypto";
import { and, count, desc, eq, inArray, sql } from "drizzle-orm";
import { Router } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import {
  auditLogs,
  accountNumberSequence,
  certificates,
  commissionCycles,
  consultantApplications,
  coupons,
  courseSections,
  courses,
  enrollments,
  lessonProgress,
  lessons,
  networkAccounts,
  notifications,
  paymentRequests,
  quizAttempts,
  quizzes,
  sessions,
  supportTickets,
  systemSettings,
  users,
  wallets
} from "../../../db/schema";
import {
  HttpError,
  requireAuthenticatedUser,
  requireRole
} from "../../lib/auth";
import { asyncRoute } from "../../lib/http";

export const platformRouter = Router();

platformRouter.post(
  "/admin/accounts/repair",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const assigned = await db.transaction(async (tx) => {
      await tx.insert(accountNumberSequence).values({ id: 1, nextNumber: 527694 }).onConflictDoNothing();
      const existing = await tx.select({ numericPart: networkAccounts.numericPart }).from(networkAccounts).orderBy(desc(networkAccounts.numericPart)).limit(1);
      if (existing[0]) {
        await tx.update(accountNumberSequence).set({
          nextNumber: sql`GREATEST(${accountNumberSequence.nextNumber}, ${existing[0].numericPart + 1})`,
          updatedAt: new Date()
        }).where(eq(accountNumberSequence.id, 1));
      }
      const studentRows = await tx.select({ id: users.id, isActive: users.isActive }).from(users).where(eq(users.role, "student"));
      let countAssigned = 0;
      for (const student of studentRows) {
        const [main] = await tx.select({ id: networkAccounts.id }).from(networkAccounts)
          .where(and(eq(networkAccounts.ownerUserId, student.id), eq(networkAccounts.isMainAccount, true))).limit(1);
        if (main) continue;
        const [sequence] = await tx.update(accountNumberSequence).set({ nextNumber: sql.raw("next_number + 1"), updatedAt: new Date() })
          .where(eq(accountNumberSequence.id, 1)).returning({ nextNumber: accountNumberSequence.nextNumber });
        await tx.insert(networkAccounts).values({
          ownerUserId: student.id, prefix: "SR", numericPart: sequence.nextNumber - 1,
          status: student.isActive ? "ACTIVE" : "RESERVED", isMainAccount: true,
          activatedAt: student.isActive ? new Date() : null
        });
        countAssigned += 1;
      }
      if (countAssigned) await tx.insert(auditLogs).values({
        actorUserId: admin.id, action: "MISSING_SR_ACCOUNTS_REPAIRED",
        entityType: "network_account", metadata: { assigned: countAssigned }
      });
      return countAssigned;
    });
    response.json({ assigned });
  })
);

const couponInput = z.object({
  code: z.string().trim().min(2).max(50),
  discountType: z.enum(["PERCENT", "FIXED"]),
  discountValue: z.coerce.number().positive(),
  courseId: z.string().uuid().optional(),
  startsAt: z.coerce.date().optional(),
  expiresAt: z.coerce.date().optional(),
  maxUses: z.coerce.number().int().positive().optional(),
  isActive: z.boolean().default(true)
});

const supportInput = z.object({
  subject: z.string().trim().min(3).max(180),
  message: z.string().trim().min(10).max(5000),
  priority: z.enum(["LOW", "NORMAL", "HIGH"]).default("NORMAL")
});

platformRouter.get(
  "/notifications",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, user.id))
      .orderBy(desc(notifications.createdAt))
      .limit(100);
    response.json({ notifications: items });
  })
);

platformRouter.post(
  "/support-tickets",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = supportInput.parse(request.body);
    const db = requireDatabase();
    const [ticket] = await db
      .insert(supportTickets)
      .values({ userId: user.id, ...input })
      .returning();
    response.status(201).json({ ticket });
  })
);

platformRouter.get(
  "/support-tickets/me",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const tickets = await db
      .select()
      .from(supportTickets)
      .where(eq(supportTickets.userId, user.id))
      .orderBy(desc(supportTickets.createdAt));
    response.json({ tickets });
  })
);

platformRouter.get(
  "/admin/support-tickets",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const tickets = await db
      .select()
      .from(supportTickets)
      .orderBy(desc(supportTickets.createdAt));
    response.json({ tickets });
  })
);

platformRouter.post(
  "/admin/support-tickets/:id/resolve",
  asyncRoute(async (request, response) => {
    const staff = await requireRole(request, ["staff", "admin"]);
    const input = z
      .object({ resolution: z.string().trim().min(3).max(5000) })
      .parse(request.body);
    const db = requireDatabase();
    const [ticket] = await db
      .update(supportTickets)
      .set({
        status: "RESOLVED",
        resolution: input.resolution,
        assignedTo: staff.id,
        updatedAt: new Date()
      })
      .where(eq(supportTickets.id, String(request.params.id)))
      .returning();
    if (!ticket) throw new HttpError(404, "Support ticket not found.");
    await db.insert(notifications).values({
      userId: ticket.userId,
      type: "SUPPORT_TICKET_RESOLVED",
      title: "Support ticket resolved",
      message: input.resolution
    });
    response.json({ ticket });
  })
);

platformRouter.get(
  "/admin/coupons",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const items = await db.select().from(coupons).orderBy(desc(coupons.createdAt));
    response.json({ coupons: items });
  })
);

platformRouter.post(
  "/admin/coupons",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = couponInput.parse(request.body);
    if (
      input.discountType === "PERCENT" &&
      input.discountValue > 100
    ) {
      throw new HttpError(400, "Percentage discount cannot exceed 100.");
    }
    if (
      input.startsAt &&
      input.expiresAt &&
      input.expiresAt <= input.startsAt
    ) {
      throw new HttpError(400, "Coupon date range is invalid.");
    }
    const db = requireDatabase();
    const [coupon] = await db
      .insert(coupons)
      .values({
        ...input,
        code: input.code.toUpperCase(),
        discountValue: input.discountValue.toFixed(2)
      })
      .returning();
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: "COUPON_CREATED",
      entityType: "coupon",
      entityId: coupon.id,
      metadata: { code: coupon.code }
    });
    response.status(201).json({ coupon });
  })
);

platformRouter.get(
  "/admin/settings",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const settings = await db.select().from(systemSettings);
    response.json({ settings });
  })
);

platformRouter.put(
  "/admin/settings/:key",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = z.object({ value: z.unknown() }).parse(request.body);
    const key = z
      .string()
      .regex(/^[A-Z0-9_]+$/)
      .max(80)
      .parse(String(request.params.key).toUpperCase());
    const db = requireDatabase();
    const [setting] = await db
      .insert(systemSettings)
      .values({
        key,
        value: input.value,
        updatedBy: admin.id,
        updatedAt: new Date()
      })
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: {
          value: input.value,
          updatedBy: admin.id,
          updatedAt: new Date()
        }
      })
      .returning();
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: "SYSTEM_SETTING_UPDATED",
      entityType: "system_setting",
      entityId: key
    });
    response.json({ setting });
  })
);

platformRouter.post(
  "/notifications/:id/read",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [updated] = await db
      .update(notifications)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(notifications.id, String(request.params.id)),
          eq(notifications.userId, user.id)
        )
      )
      .returning();
    if (!updated) throw new HttpError(404, "Notification not found.");
    response.json({ notification: updated });
  })
);

platformRouter.get(
  "/student/certificates",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db
      .select({
        certificate: certificates,
        courseTitle: courses.title
      })
      .from(certificates)
      .innerJoin(courses, eq(certificates.courseId, courses.id))
      .where(eq(certificates.userId, user.id))
      .orderBy(desc(certificates.issuedAt));
    response.json({ certificates: items });
  })
);

platformRouter.post(
  "/student/certificates/issue",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = z
      .object({ courseId: z.string().uuid() })
      .parse(request.body);
    const db = requireDatabase();
    const [existing] = await db
      .select()
      .from(certificates)
      .where(
        and(
          eq(certificates.userId, user.id),
          eq(certificates.courseId, input.courseId)
        )
      )
      .limit(1);
    if (existing) {
      response.json({ certificate: existing });
      return;
    }
    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(
        and(
          eq(enrollments.userId, user.id),
          eq(enrollments.courseId, input.courseId),
          eq(enrollments.status, "ACTIVE")
        )
      )
      .limit(1);
    if (!enrollment) throw new HttpError(403, "Active enrollment required.");

    const sections = await db
      .select({ id: courseSections.id })
      .from(courseSections)
      .where(eq(courseSections.courseId, input.courseId));
    const sectionIds = sections.map((section) => section.id);
    const [{ totalLessons }] = sectionIds.length
      ? await db
          .select({ totalLessons: count() })
          .from(lessons)
          .where(inArray(lessons.sectionId, sectionIds))
      : [{ totalLessons: 0 }];
    const [{ completedLessons }] = await db
      .select({ completedLessons: count() })
      .from(lessonProgress)
      .where(
        and(
          eq(lessonProgress.enrollmentId, enrollment.id),
          eq(lessonProgress.progressPercent, 100)
        )
      );
    if (totalLessons < 1 || completedLessons < totalLessons) {
      throw new HttpError(409, "All course lessons must be completed.");
    }

    const publishedQuizzes = await db
      .select({ id: quizzes.id })
      .from(quizzes)
      .where(
        and(
          eq(quizzes.courseId, input.courseId),
          eq(quizzes.isPublished, true)
        )
      );
    if (publishedQuizzes.length) {
      const passed = await db
        .select({ quizId: quizAttempts.quizId })
        .from(quizAttempts)
        .where(
          and(
            eq(quizAttempts.userId, user.id),
            eq(quizAttempts.passed, true),
            inArray(
              quizAttempts.quizId,
              publishedQuizzes.map((quiz) => quiz.id)
            )
          )
        );
      const passedIds = new Set(passed.map((attempt) => attempt.quizId));
      if (passedIds.size < publishedQuizzes.length) {
        throw new HttpError(409, "All required quizzes must be passed.");
      }
    }

    const code =
      "ADIL-" +
      new Date().getUTCFullYear() +
      "-" +
      crypto.randomBytes(5).toString("hex").toUpperCase();
    const [created] = await db
      .insert(certificates)
      .values({
        certificateCode: code,
        userId: user.id,
        courseId: input.courseId
      })
      .returning();
    await db
      .update(enrollments)
      .set({ completedAt: new Date(), status: "COMPLETED" })
      .where(eq(enrollments.id, enrollment.id));
    response.status(201).json({ certificate: created });
  })
);

platformRouter.get(
  "/certificates/:code/verify",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [item] = await db
      .select({
        code: certificates.certificateCode,
        issuedAt: certificates.issuedAt,
        revokedAt: certificates.revokedAt,
        studentName: users.displayName,
        courseTitle: courses.title
      })
      .from(certificates)
      .innerJoin(users, eq(certificates.userId, users.id))
      .innerJoin(courses, eq(certificates.courseId, courses.id))
      .where(
        eq(
          certificates.certificateCode,
          String(request.params.code).toUpperCase()
        )
      )
      .limit(1);
    if (!item) throw new HttpError(404, "Certificate not found.");
    response.json({ certificate: item, valid: !item.revokedAt });
  })
);

platformRouter.get(
  "/admin/overview",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const [
      [{ students }],
      [{ consultants }],
      [{ pendingPayments }],
      [{ pendingApplications }],
      [{ activeAccounts }],
      [{ commissionCycleCount }]
    ] = await Promise.all([
      db.select({ students: count() }).from(users).where(eq(users.role, "student")),
      db
        .select({ consultants: count() })
        .from(users)
        .where(eq(users.role, "consultant")),
      db
        .select({ pendingPayments: count() })
        .from(paymentRequests)
        .where(
          inArray(paymentRequests.status, [
            "PENDING",
            "UNDER_REVIEW",
            "PARTIAL"
          ])
        ),
      db
        .select({ pendingApplications: count() })
        .from(consultantApplications)
        .where(
          inArray(consultantApplications.status, ["PENDING", "INTERVIEW"])
        ),
      db
        .select({ activeAccounts: count() })
        .from(networkAccounts)
        .where(eq(networkAccounts.status, "ACTIVE")),
      db.select({ commissionCycleCount: count() }).from(commissionCycles)
    ]);
    response.json({
      students,
      consultants,
      pendingPayments,
      pendingApplications,
      activeAccounts,
      commissionCycleCount
    });
  })
);

platformRouter.get(
  "/admin/students",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const studentRows = await db.select({
      id: users.id,
      name: users.displayName,
      email: users.email,
      phone: users.phone,
      nicOrPassport: users.nicOrPassport,
      address: users.address,
      dateOfBirth: users.dateOfBirth,
      isActive: users.isActive,
      emailVerifiedAt: users.emailVerifiedAt,
      passwordSetAt: users.passwordSetAt,
      createdAt: users.createdAt
    }).from(users).where(eq(users.role, "student")).orderBy(desc(users.createdAt));

    const students = await Promise.all(studentRows.map(async (student) => {
      const [[enrollment], [account], [payment]] = await Promise.all([
        db.select({ status: enrollments.status, courseTitle: courses.title })
          .from(enrollments).innerJoin(courses, eq(enrollments.courseId, courses.id))
          .where(eq(enrollments.userId, student.id)).limit(1),
        db.select({ prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart, status: networkAccounts.status })
          .from(networkAccounts).where(and(eq(networkAccounts.ownerUserId, student.id), eq(networkAccounts.isMainAccount, true))).limit(1),
        db.select({ status: paymentRequests.status, paidAmount: paymentRequests.paidAmount, totalAmount: paymentRequests.totalAmount, paymentCode: paymentRequests.paymentCode })
          .from(paymentRequests).where(eq(paymentRequests.userId, student.id)).orderBy(desc(paymentRequests.createdAt)).limit(1)
      ]);
      return {
        ...student,
        enrollment: enrollment ?? null,
        account: account ? { number: `${account.prefix}${account.numericPart}`, status: account.status } : null,
        latestPayment: payment ?? null
      };
    }));
    response.json({ students });
  })
);

platformRouter.get(
  "/admin/consultants",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const rows = await db.select({
      id: users.id, name: users.displayName, email: users.email,
      phone: users.phone, isActive: users.isActive, createdAt: users.createdAt
    }).from(users).where(eq(users.role, "consultant")).orderBy(desc(users.createdAt));
    const consultants = await Promise.all(rows.map(async (consultant) => {
      const accounts = await db.select({ prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart, status: networkAccounts.status })
        .from(networkAccounts).where(eq(networkAccounts.ownerUserId, consultant.id));
      return { ...consultant, accounts: accounts.map((account) => ({ ...account, number: `${account.prefix}${account.numericPart}` })) };
    }));
    response.json({ consultants });
  })
);

platformRouter.get(
  "/admin/accounts",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const accounts = await db.select({
      id: networkAccounts.id, prefix: networkAccounts.prefix,
      numericPart: networkAccounts.numericPart, status: networkAccounts.status,
      isMainAccount: networkAccounts.isMainAccount, activatedAt: networkAccounts.activatedAt,
      ownerId: users.id, ownerName: users.displayName, ownerEmail: users.email, ownerPhone: users.phone,
      ownerRole: users.role
    }).from(networkAccounts).innerJoin(users, eq(networkAccounts.ownerUserId, users.id))
      .orderBy(desc(networkAccounts.createdAt));
    response.json({ accounts: accounts.map((account) => ({ ...account, number: `${account.prefix}${account.numericPart}` })) });
  })
);

platformRouter.post(
  "/admin/accounts/:id/enable-cco",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const accountId = String(request.params.id);

    const result = await db.transaction(async (tx) => {
      const [record] = await tx.select({
        account: networkAccounts,
        ownerRole: users.role,
        ownerName: users.displayName
      }).from(networkAccounts)
        .innerJoin(users, eq(networkAccounts.ownerUserId, users.id))
        .where(eq(networkAccounts.id, accountId))
        .limit(1);

      if (!record) throw new HttpError(404, "Account not found.");
      const { account } = record;
      if (!account.isMainAccount) throw new HttpError(409, "CCO can only be enabled on the student's main account.");
      if (account.status !== "ACTIVE") throw new HttpError(409, "Activate the paid SR account before enabling CCO.");

      if (account.prefix === "CN" && record.ownerRole === "consultant") {
        return { account, alreadyEnabled: true, ownerName: record.ownerName };
      }
      if (account.prefix !== "SR" || record.ownerRole !== "student") {
        throw new HttpError(409, "Only an active student SR account can be converted to CCO.");
      }

      const [conflict] = await tx.select({ id: networkAccounts.id })
        .from(networkAccounts)
        .where(and(
          eq(networkAccounts.prefix, "CN"),
          eq(networkAccounts.numericPart, account.numericPart)
        ))
        .limit(1);
      if (conflict) throw new HttpError(409, `CN${account.numericPart} is already assigned. Contact system support.`);

      const [updatedAccount] = await tx.update(networkAccounts)
        .set({ prefix: "CN" })
        .where(eq(networkAccounts.id, account.id))
        .returning();
      await tx.update(users)
        .set({ role: "consultant", updatedAt: new Date() })
        .where(eq(users.id, account.ownerUserId));
      await tx.insert(wallets).values({ userId: account.ownerUserId })
        .onConflictDoNothing({ target: wallets.userId });
      await tx.insert(notifications).values({
        userId: account.ownerUserId,
        type: "CCO_ENABLED",
        title: "CCO account enabled",
        message: `Your account is now CN${account.numericPart}. Refresh or sign in again to open the CCO panel.`
      });
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "CCO_ENABLED",
        entityType: "network_account",
        entityId: account.id,
        metadata: {
          ownerUserId: account.ownerUserId,
          previousNumber: `SR${account.numericPart}`,
          newNumber: `CN${account.numericPart}`
        }
      });
      return { account: updatedAccount, alreadyEnabled: false, ownerName: record.ownerName };
    });

    response.json({
      ...result,
      number: `CN${result.account.numericPart}`,
      message: result.alreadyEnabled
        ? "CCO is already enabled for this account."
        : "CCO enabled successfully. The student must refresh or sign in again."
    });
  })
);

platformRouter.post(
  "/admin/accounts/:id/disable-cco",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const accountId = String(request.params.id);

    const result = await db.transaction(async (tx) => {
      const [record] = await tx.select({ account: networkAccounts, ownerRole: users.role })
        .from(networkAccounts)
        .innerJoin(users, eq(networkAccounts.ownerUserId, users.id))
        .where(eq(networkAccounts.id, accountId))
        .limit(1);
      if (!record) throw new HttpError(404, "Account not found.");
      const { account } = record;
      if (!account.isMainAccount || account.prefix !== "CN" || record.ownerRole !== "consultant") {
        throw new HttpError(409, "This account does not have an active CCO conversion.");
      }

      const [conflict] = await tx.select({ id: networkAccounts.id })
        .from(networkAccounts)
        .where(and(eq(networkAccounts.prefix, "SR"), eq(networkAccounts.numericPart, account.numericPart)))
        .limit(1);
      if (conflict) throw new HttpError(409, `SR${account.numericPart} is already assigned. Contact system support.`);

      const [updatedAccount] = await tx.update(networkAccounts)
        .set({ prefix: "SR" })
        .where(eq(networkAccounts.id, account.id))
        .returning();
      await tx.update(users)
        .set({ role: "student", updatedAt: new Date() })
        .where(eq(users.id, account.ownerUserId));
      await tx.insert(notifications).values({
        userId: account.ownerUserId,
        type: "CCO_DISABLED",
        title: "CCO account disabled",
        message: `Your consultant access was disabled. Your main account is now SR${account.numericPart}.`
      });
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "CCO_DISABLED",
        entityType: "network_account",
        entityId: account.id,
        metadata: {
          ownerUserId: account.ownerUserId,
          previousNumber: `CN${account.numericPart}`,
          newNumber: `SR${account.numericPart}`
        }
      });
      return updatedAccount;
    });

    response.json({
      account: result,
      number: `SR${result.numericPart}`,
      message: "CCO disabled successfully. The user must refresh or sign in again."
    });
  })
);

platformRouter.patch(
  "/admin/students/:id/status",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = z.object({ isActive: z.boolean() }).parse(request.body);
    const db = requireDatabase();
    const studentId = String(request.params.id);
    if (input.isActive) {
      const [candidate] = await db.select({ verified: users.emailVerifiedAt, passwordSet: users.passwordSetAt }).from(users).where(eq(users.id, studentId)).limit(1);
      if (!candidate?.verified || !candidate.passwordSet) throw new HttpError(409, "Student must verify the email and set a password first.");
    }
    const [student] = await db.update(users).set({
      isActive: input.isActive,
      updatedAt: new Date()
    }).where(and(eq(users.id, studentId), eq(users.role, "student"))).returning({
      id: users.id,
      name: users.displayName,
      isActive: users.isActive
    });
    if (!student) throw new HttpError(404, "Student not found.");
    if (!input.isActive) await db.delete(sessions).where(eq(sessions.userId, student.id));
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: input.isActive ? "STUDENT_ACTIVATED" : "STUDENT_SUSPENDED",
      entityType: "user",
      entityId: student.id
    });
    response.json({ student });
  })
);

platformRouter.get(
  "/admin/audit-logs",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const logs = await db
      .select()
      .from(auditLogs)
      .orderBy(desc(auditLogs.createdAt))
      .limit(250);
    response.json({ logs });
  })
);
