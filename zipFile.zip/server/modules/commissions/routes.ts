import { and, desc, eq } from "drizzle-orm";
import { Router } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import {
  accountPointBalances,
  auditLogs,
  commissionCycles,
  commissionEntries,
  networkAccounts,
  payoutRequests,
  walletLedger,
  wallets
} from "../../../db/schema";
import {
  HttpError,
  requireAuthenticatedUser,
  requireRole
} from "../../lib/auth";
import { asyncRoute } from "../../lib/http";
import { calculateCommissionCycle } from "./service";

export const commissionRouter = Router();

const calculateInput = z.object({
  cycleKey: z.string().trim().min(4).max(40),
  periodStart: z.coerce.date(),
  periodEnd: z.coerce.date()
});

const payoutInput = z.object({
  amount: z.coerce.number().positive(),
  payoutMethod: z.enum(["BANK_TRANSFER", "USDT"]),
  payoutDetails: z.record(z.string(), z.string().max(300))
});

const payoutReviewInput = z.object({
  status: z.enum(["APPROVED", "PAID", "REJECTED"])
});

commissionRouter.post(
  "/admin/commission-cycles/calculate",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = calculateInput.parse(request.body);
    const result = await calculateCommissionCycle(input, admin.id);
    response.status(201).json(result);
  })
);

/* Legacy inline implementation removed: calculation lives in service.ts so
   the same transaction is safely used by both the admin API and Friday job. */
/*
    const db = requireDatabase();
    const result = await db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(commissionCycles)
        .where(eq(commissionCycles.cycleKey, input.cycleKey))
        .limit(1);
      if (existing) {
        throw new HttpError(409, "This commission cycle already exists.");
      }
      const [cycle] = await tx
        .insert(commissionCycles)
        .values({
          cycleKey: input.cycleKey,
          periodStart: input.periodStart,
          periodEnd: input.periodEnd,
          status: "CALCULATING"
        })
        .returning();

      const balances = await tx
        .select({
          balance: accountPointBalances,
          account: networkAccounts
        })
        .from(accountPointBalances)
        .innerJoin(
          networkAccounts,
          eq(accountPointBalances.accountId, networkAccounts.id)
        )
        .where(eq(networkAccounts.status, "ACTIVE"));

      let totalAmount = 0;
      let awardedAccounts = 0;
      for (const row of balances) {
        const calculation = calculateAccountCommission({
          leftAvailable: row.balance.leftAvailable,
          rightAvailable: row.balance.rightAvailable,
          stageOneAchieved: row.balance.stageOneAchieved,
          stageTwoAchieved: row.balance.stageTwoAchieved
        });
        if (calculation.awards.length === 0) continue;

        awardedAccounts += 1;
        const accountTotal = calculation.awards.reduce(
          (sum, award) => sum + award.amount,
          0
        );
        totalAmount += accountTotal;
        for (const award of calculation.awards) {
          await tx.insert(commissionEntries).values({
            cycleId: cycle.id,
            accountId: row.account.id,
            stage: award.stage,
            matchedPairs: award.pairs,
            amount: award.amount.toFixed(2),
            metadata: {
              leftBefore: row.balance.leftAvailable,
              rightBefore: row.balance.rightAvailable
            }
          });
        }

        await tx
          .update(accountPointBalances)
          .set({
            leftAvailable: calculation.leftRemaining,
            rightAvailable: calculation.rightRemaining,
            stageOneAchieved: calculation.stageOneAchieved,
            stageTwoAchieved: calculation.stageTwoAchieved,
            updatedAt: new Date()
          })
          .where(eq(accountPointBalances.id, row.balance.id));

        await tx
          .insert(wallets)
          .values({ userId: row.account.ownerUserId })
          .onConflictDoNothing({ target: wallets.userId });
        const [wallet] = await tx
          .select()
          .from(wallets)
          .where(eq(wallets.userId, row.account.ownerUserId))
          .limit(1);
        const newPending =
          Number(wallet.pendingBalance) + Number(accountTotal);
        await tx
          .update(wallets)
          .set({
            pendingBalance: newPending.toFixed(2),
            updatedAt: new Date()
          })
          .where(eq(wallets.id, wallet.id));
        await tx.insert(walletLedger).values({
          walletId: wallet.id,
          idempotencyKey:
            "commission-pending:" + cycle.id + ":" + row.account.id,
          entryType: "COMMISSION_PENDING",
          amount: accountTotal.toFixed(2),
          referenceType: "commission_cycle",
          referenceId: cycle.id,
          note: "Commission calculated for " + row.account.prefix + row.account.numericPart
        });
      }

      const [updatedCycle] = await tx
        .update(commissionCycles)
        .set({ status: "CALCULATED", calculatedAt: new Date() })
        .where(eq(commissionCycles.id, cycle.id))
        .returning();
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "COMMISSION_CYCLE_CALCULATED",
        entityType: "commission_cycle",
        entityId: cycle.id,
        metadata: { awardedAccounts, totalAmount }
      });
      return { cycle: updatedCycle, awardedAccounts, totalAmount };
    });
    response.status(201).json(result);
  })
); */

commissionRouter.post(
  "/admin/commission-cycles/:id/approve",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const cycleId = String(request.params.id);
    const result = await db.transaction(async (tx) => {
      const [cycle] = await tx
        .select()
        .from(commissionCycles)
        .where(eq(commissionCycles.id, cycleId))
        .limit(1);
      if (!cycle) throw new HttpError(404, "Commission cycle not found.");
      if (cycle.status !== "CALCULATED") {
        throw new HttpError(409, "Only a calculated cycle can be approved.");
      }

      const rows = await tx
        .select({
          accountId: commissionEntries.accountId,
          amount: commissionEntries.amount,
          ownerUserId: networkAccounts.ownerUserId
        })
        .from(commissionEntries)
        .innerJoin(
          networkAccounts,
          eq(commissionEntries.accountId, networkAccounts.id)
        )
        .where(eq(commissionEntries.cycleId, cycle.id));
      const totals = new Map<string, number>();
      for (const row of rows) {
        totals.set(
          row.ownerUserId,
          (totals.get(row.ownerUserId) ?? 0) + Number(row.amount)
        );
      }

      for (const [userId, amount] of totals) {
        const [wallet] = await tx
          .select()
          .from(wallets)
          .where(eq(wallets.userId, userId))
          .limit(1);
        if (!wallet) throw new Error("Wallet missing for commission owner.");
        const pending = Number(wallet.pendingBalance);
        if (pending < amount) {
          throw new Error("Wallet pending balance is inconsistent.");
        }
        await tx
          .update(wallets)
          .set({
            pendingBalance: (pending - amount).toFixed(2),
            availableBalance: (
              Number(wallet.availableBalance) + amount
            ).toFixed(2),
            updatedAt: new Date()
          })
          .where(eq(wallets.id, wallet.id));
        await tx.insert(walletLedger).values({
          walletId: wallet.id,
          idempotencyKey: "commission-release:" + cycle.id + ":" + userId,
          entryType: "COMMISSION_RELEASED",
          amount: amount.toFixed(2),
          referenceType: "commission_cycle",
          referenceId: cycle.id
        });
      }

      const [approved] = await tx
        .update(commissionCycles)
        .set({
          status: "APPROVED",
          approvedBy: admin.id,
          approvedAt: new Date()
        })
        .where(eq(commissionCycles.id, cycle.id))
        .returning();
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "COMMISSION_CYCLE_APPROVED",
        entityType: "commission_cycle",
        entityId: cycle.id,
        metadata: { consultantCount: totals.size }
      });
      return { cycle: approved, consultantCount: totals.size };
    });
    response.json(result);
  })
);

commissionRouter.get(
  "/admin/commission-cycles",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const cycles = await db
      .select()
      .from(commissionCycles)
      .orderBy(desc(commissionCycles.periodEnd));
    response.json({ cycles });
  })
);

commissionRouter.get(
  "/consultant/wallet",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant", "admin"]);
    const db = requireDatabase();
    const [wallet] = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, user.id))
      .limit(1);
    if (!wallet) {
      response.json({ wallet: null, ledger: [], payouts: [] });
      return;
    }
    const ledger = await db
      .select()
      .from(walletLedger)
      .where(eq(walletLedger.walletId, wallet.id))
      .orderBy(desc(walletLedger.createdAt));
    const payouts = await db
      .select()
      .from(payoutRequests)
      .where(eq(payoutRequests.walletId, wallet.id))
      .orderBy(desc(payoutRequests.createdAt));
    response.json({ wallet, ledger, payouts });
  })
);

commissionRouter.post(
  "/consultant/payout-requests",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant"]);
    const input = payoutInput.parse(request.body);
    const db = requireDatabase();
    const result = await db.transaction(async (tx) => {
      const [wallet] = await tx
        .select()
        .from(wallets)
        .where(eq(wallets.userId, user.id))
        .limit(1);
      if (!wallet || Number(wallet.availableBalance) < input.amount) {
        throw new HttpError(400, "Available wallet balance is insufficient.");
      }
      const [payout] = await tx
        .insert(payoutRequests)
        .values({
          walletId: wallet.id,
          amount: input.amount.toFixed(2),
          payoutMethod: input.payoutMethod,
          payoutDetails: input.payoutDetails
        })
        .returning();
      await tx
        .update(wallets)
        .set({
          availableBalance: (
            Number(wallet.availableBalance) - input.amount
          ).toFixed(2),
          updatedAt: new Date()
        })
        .where(eq(wallets.id, wallet.id));
      await tx.insert(walletLedger).values({
        walletId: wallet.id,
        idempotencyKey: "payout-reserve:" + payout.id,
        entryType: "PAYOUT_RESERVED",
        amount: (-input.amount).toFixed(2),
        referenceType: "payout_request",
        referenceId: payout.id
      });
      return payout;
    });
    response.status(201).json({ payout: result });
  })
);

commissionRouter.get(
  "/admin/payout-requests",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const payouts = await db
      .select()
      .from(payoutRequests)
      .orderBy(desc(payoutRequests.createdAt));
    response.json({ payouts });
  })
);

commissionRouter.post(
  "/admin/payout-requests/:id/review",
  asyncRoute(async (request, response) => {
    const reviewer = await requireRole(request, ["admin"]);
    const input = payoutReviewInput.parse(request.body);
    const db = requireDatabase();
    const result = await db.transaction(async (tx) => {
      const [payout] = await tx
        .select()
        .from(payoutRequests)
        .where(eq(payoutRequests.id, String(request.params.id)))
        .limit(1);
      if (!payout) throw new HttpError(404, "Payout request not found.");
      if (["PAID", "REJECTED"].includes(payout.status)) {
        throw new HttpError(409, "Payout request is already finalized.");
      }

      if (input.status === "REJECTED") {
        const [wallet] = await tx
          .select()
          .from(wallets)
          .where(eq(wallets.id, payout.walletId))
          .limit(1);
        await tx
          .update(wallets)
          .set({
            availableBalance: (
              Number(wallet.availableBalance) + Number(payout.amount)
            ).toFixed(2),
            updatedAt: new Date()
          })
          .where(eq(wallets.id, wallet.id));
        await tx.insert(walletLedger).values({
          walletId: wallet.id,
          idempotencyKey: "payout-return:" + payout.id,
          entryType: "PAYOUT_RETURNED",
          amount: payout.amount,
          referenceType: "payout_request",
          referenceId: payout.id
        });
      }

      const [updated] = await tx
        .update(payoutRequests)
        .set({
          status: input.status,
          reviewedBy: reviewer.id,
          reviewedAt: new Date(),
          paidAt: input.status === "PAID" ? new Date() : null
        })
        .where(eq(payoutRequests.id, payout.id))
        .returning();
      await tx.insert(auditLogs).values({
        actorUserId: reviewer.id,
        action: "PAYOUT_" + input.status,
        entityType: "payout_request",
        entityId: payout.id,
        metadata: { amount: payout.amount }
      });
      return updated;
    });
    response.json({ payout: result });
  })
);
