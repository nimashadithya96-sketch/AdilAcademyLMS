import {
  useEffect,
  useState,
  type FormEvent,
  type ReactNode
} from "react";
import {
  ArrowRight,
  Award,
  BarChart3,
  Bell,
  BookOpen,
  Check,
  ChevronRight,
  CircleDollarSign,
  CreditCard,
  GraduationCap,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  Menu,
  Network,
  Play,
  Settings,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserCheck,
  Users,
  Wallet,
  X
} from "lucide-react";
import {
  Link,
  Navigate,
  Route,
  Routes,
  useNavigate
} from "react-router-dom";
import type {
  DemoUser,
  PlatformOverview,
  StudentDashboardSummary,
  UserRole
} from "../../shared/platform";

const courseModules = [
  {
    number: "01",
    title: "Crypto Foundations",
    text: "Blockchain, wallets, exchanges සහ Binance account security."
  },
  {
    number: "02",
    title: "Spot Trading",
    text: "Market orders, limit orders සහ disciplined trade execution."
  },
  {
    number: "03",
    title: "Technical Analysis",
    text: "Market structure, candlesticks, indicators සහ entry planning."
  },
  {
    number: "04",
    title: "Risk Management",
    text: "Position sizing, stop loss සහ capital protection systems."
  },
  {
    number: "05",
    title: "Futures Trading",
    text: "Leverage, margin, liquidation සහ controlled futures strategies."
  },
  {
    number: "06",
    title: "Trading Psychology",
    text: "Consistency, journal keeping සහ professional decision making."
  }
];

const defaultOverview: PlatformOverview = {
  course: {
    title: "Crypto Trading — Zero to Pro",
    language: "සිංහල",
    modules: 6,
    access: "Lifetime course access"
  },
  features: [],
  paymentMethods: ["Bank Transfer", "Binance Pay / USDT"]
};

function Logo() {
  return (
    <Link className="brand" to="/" aria-label="Adil Academy home">
      <span className="brand-mark">
        <span>A</span>
      </span>
      <span className="brand-copy">
        <strong>ADIL</strong>
        <small>ACADEMY</small>
      </span>
    </Link>
  );
}

function PublicHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="public-header">
      <div className="nav-shell">
        <Logo />
        <button
          className="menu-button"
          type="button"
          aria-label="Toggle menu"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
        <nav className={open ? "nav-links nav-open" : "nav-links"}>
          <a href="#course" onClick={() => setOpen(false)}>
            පාඨමාලාව
          </a>
          <a href="#platform" onClick={() => setOpen(false)}>
            වේදිකාව
          </a>
          <a href="#network" onClick={() => setOpen(false)}>
            Consultant Network
          </a>
          <Link to="/login" className="nav-login" onClick={() => setOpen(false)}>
            Login
          </Link>
          <Link
            to="/login"
            className="button button-small"
            onClick={() => setOpen(false)}
          >
            දැන් ආරම්භ කරන්න
          </Link>
        </nav>
      </div>
    </header>
  );
}

function HeroDashboardPreview() {
  return (
    <div className="hero-preview" aria-label="Student dashboard preview">
      <div className="preview-glow" />
      <div className="preview-top">
        <div>
          <span className="eyebrow">STUDENT DASHBOARD</span>
          <h3>ආයුබෝවන්, Nimal</h3>
        </div>
        <span className="avatar">NP</span>
      </div>
      <div className="progress-card">
        <div className="progress-card-copy">
          <span>Crypto Trading — Zero to Pro</span>
          <strong>ඔබගේ ප්‍රගතිය</strong>
        </div>
        <span className="progress-value">68%</span>
        <div className="progress-track">
          <span style={{ width: "68%" }} />
        </div>
        <button type="button" className="continue-button">
          <Play size={15} fill="currentColor" />
          පාඩම දිගටම බලන්න
        </button>
      </div>
      <div className="preview-stats">
        <div>
          <BookOpen size={19} />
          <span>Lessons</span>
          <strong>24 / 36</strong>
        </div>
        <div>
          <Award size={19} />
          <span>Quiz Score</span>
          <strong>86%</strong>
        </div>
        <div>
          <TrendingUp size={19} />
          <span>Day Streak</span>
          <strong>12</strong>
        </div>
      </div>
    </div>
  );
}

function HomePage() {
  const [overview, setOverview] =
    useState<PlatformOverview>(defaultOverview);

  useEffect(() => {
    fetch("/api/public/overview")
      .then((response) => response.json())
      .then(setOverview)
      .catch(() => undefined);
  }, []);

  return (
    <div className="site">
      <PublicHeader />
      <main>
        <section className="hero">
          <div className="hero-grid" />
          <div className="hero-orb hero-orb-one" />
          <div className="hero-orb hero-orb-two" />
          <div className="section-shell hero-layout">
            <div className="hero-copy">
              <span className="pill">
                <Sparkles size={15} />
                SRI LANKA'S SINHALA CRYPTO LEARNING PLATFORM
              </span>
              <h1>
                Trade කරන්න කලින්
                <span>හරියට ඉගෙනගන්න.</span>
              </h1>
              <p>
                Crypto Trading ගැන කිසිම දැනුමක් නැති තැනින්, disciplined
                trader කෙනෙක් දක්වා යන සම්පූර්ණ learning path එක සරල
                සිංහලෙන්.
              </p>
              <div className="hero-actions">
                <Link to="/login" className="button button-primary">
                  පාඨමාලාව ආරම්භ කරන්න
                  <ArrowRight size={18} />
                </Link>
                <a className="button button-ghost" href="#course">
                  <Play size={17} />
                  Course Overview
                </a>
              </div>
              <div className="trust-row">
                <span>
                  <Check size={15} /> {overview.course.modules} Modules
                </span>
                <span>
                  <Check size={15} /> {overview.course.language}
                </span>
                <span>
                  <Check size={15} /> {overview.course.access}
                </span>
              </div>
            </div>
            <HeroDashboardPreview />
          </div>
        </section>

        <section className="proof-strip">
          <div className="section-shell proof-grid">
            <div>
              <strong>Zero → Pro</strong>
              <span>Structured learning path</span>
            </div>
            <div>
              <strong>6</strong>
              <span>Complete modules</span>
            </div>
            <div>
              <strong>24/7</strong>
              <span>Student dashboard access</span>
            </div>
            <div>
              <strong>100%</strong>
              <span>Sinhala explanations</span>
            </div>
          </div>
        </section>

        <section className="section course-section" id="course">
          <div className="section-shell">
            <div className="section-heading">
              <span className="eyebrow">COMPLETE LEARNING PATH</span>
              <h2>අනුමාන නොකර, පිළිවෙළට ඉගෙනගන්න.</h2>
              <p>
                Beginner knowledge සිට professional risk discipline දක්වා,
                අවශ්‍ය සෑම කොටසක්ම එක learning system එකකින්.
              </p>
            </div>
            <div className="module-grid">
              {courseModules.map((module) => (
                <article className="module-card" key={module.number}>
                  <span className="module-number">{module.number}</span>
                  <div className="module-icon">
                    {module.number === "01" && <GraduationCap />}
                    {module.number === "02" && <BarChart3 />}
                    {module.number === "03" && <TrendingUp />}
                    {module.number === "04" && <ShieldCheck />}
                    {module.number === "05" && <CircleDollarSign />}
                    {module.number === "06" && <Sparkles />}
                  </div>
                  <h3>{module.title}</h3>
                  <p>{module.text}</p>
                  <span className="card-link">
                    Module details <ChevronRight size={16} />
                  </span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section platform-section" id="platform">
          <div className="section-shell platform-layout">
            <div className="platform-copy">
              <span className="eyebrow">MORE THAN A VIDEO COURSE</span>
              <h2>ඔබේ සම්පූර්ණ learning journey එක එකම dashboard එකක.</h2>
              <p>
                Lessons බලන්න, progress track කරන්න, payments සහ certificates
                manage කරන්න—mobile හෝ desktop ඕනෑම device එකකින්.
              </p>
              <div className="feature-list">
                {[
                  "Secure student-only video lessons",
                  "Lesson progress සහ quiz tracking",
                  "Bank Transfer / Binance Pay verification",
                  "Completion certificates සහ notifications"
                ].map((feature) => (
                  <div key={feature}>
                    <span>
                      <Check size={16} />
                    </span>
                    {feature}
                  </div>
                ))}
              </div>
              <Link to="/login" className="text-link">
                Dashboard preview බලන්න <ArrowRight size={17} />
              </Link>
            </div>
            <div className="platform-panel">
              <div className="panel-sidebar">
                <Logo />
                <span className="active-line">
                  <LayoutDashboard size={17} /> Overview
                </span>
                <span>
                  <BookOpen size={17} /> My Course
                </span>
                <span>
                  <Award size={17} /> Certificates
                </span>
                <span>
                  <CreditCard size={17} /> Payments
                </span>
              </div>
              <div className="panel-main">
                <span className="mini-label">WEEKLY ACTIVITY</span>
                <div className="chart-bars">
                  {[34, 58, 43, 76, 61, 88, 72].map((height, index) => (
                    <span key={index} style={{ height: height + "%" }} />
                  ))}
                </div>
                <div className="panel-course-row">
                  <span className="course-play">
                    <Play size={16} fill="currentColor" />
                  </span>
                  <div>
                    <strong>Risk Management Formula</strong>
                    <span>Module 04 • Lesson 03</span>
                  </div>
                  <span className="course-time">18 min</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section network-section" id="network">
          <div className="section-shell network-layout">
            <div className="network-visual">
              <div className="network-node network-root">
                <span>CN</span>
                <strong>527695</strong>
              </div>
              <div className="network-lines" />
              <div className="network-children">
                <div className="network-node network-left">
                  <span>LEFT</span>
                  <strong>SR527701</strong>
                </div>
                <div className="network-node network-right">
                  <span>RIGHT</span>
                  <strong>SR527702</strong>
                </div>
              </div>
              <div className="network-balance">
                <div>
                  <span>Left Points</span>
                  <strong>18,500</strong>
                </div>
                <div>
                  <span>Right Points</span>
                  <strong>15,000</strong>
                </div>
              </div>
            </div>
            <div className="platform-copy">
              <span className="eyebrow">CONSULTANT BUSINESS SYSTEM</span>
              <h2>Students, accounts සහ income පැහැදිලිව කළමනාකරණය කරන්න.</h2>
              <p>
                Approved consultants සඳහා SR/CN accounts, LEFT/RIGHT
                placements, points, carry-forward සහ weekly income reporting
                එකම secure control panel එකකින්.
              </p>
              <div className="network-tags">
                <span>
                  <Network size={17} /> Visual Binary Tree
                </span>
                <span>
                  <Wallet size={17} /> Commission Wallet
                </span>
                <span>
                  <Users size={17} /> Student Management
                </span>
              </div>
              <p className="disclaimer">
                Consultant access සහ commissions ලබාදෙන්නේ approved admissions
                සහ platform business rules අනුව පමණි.
              </p>
            </div>
          </div>
        </section>

        <section className="section cta-section">
          <div className="section-shell">
            <div className="cta-card">
              <div>
                <span className="eyebrow">START WITH KNOWLEDGE</span>
                <h2>ඔබේ Crypto learning journey එක අදම ආරම්භ කරන්න.</h2>
                <p>
                  Learn with structure. Trade with discipline. Protect your
                  capital.
                </p>
              </div>
              <Link to="/login" className="button button-light">
                Student Dashboard
                <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <footer className="site-footer">
        <div className="section-shell footer-grid">
          <div>
            <Logo />
            <p>
              සිංහලෙන් Crypto Trading ඉගෙනගන්න විශ්වාසදායක learning platform
              එක.
            </p>
          </div>
          <div>
            <strong>Platform</strong>
            <a href="#course">Course</a>
            <Link to="/login">Student Login</Link>
            <a href="#network">Consultants</a>
          </div>
          <div>
            <strong>Support</strong>
            <a href="#platform">How it works</a>
            <a href="#course">FAQ</a>
            <a href="mailto:support@adilacademy.com">Contact</a>
          </div>
          <div>
            <strong>Legal</strong>
            <span>Terms & Conditions</span>
            <span>Privacy Policy</span>
            <span>Risk Disclosure</span>
          </div>
        </div>
        <div className="section-shell footer-bottom">
          <span>© 2026 Adil Academy. All rights reserved.</span>
          <span>Education only. Trading profits are not guaranteed.</span>
        </div>
      </footer>
    </div>
  );
}

const roleOptions: {
  role: UserRole;
  title: string;
  description: string;
  icon: ReactNode;
}[] = [
  {
    role: "student",
    title: "Student",
    description: "Course, progress සහ certificates",
    icon: <GraduationCap />
  },
  {
    role: "consultant",
    title: "Consultant",
    description: "Accounts, network සහ income",
    icon: <Network />
  },
  {
    role: "staff",
    title: "Staff",
    description: "Payments සහ students",
    icon: <UserCheck />
  },
  {
    role: "admin",
    title: "Super Admin",
    description: "Complete platform control",
    icon: <ShieldCheck />
  }
];

function LoginPage({ onLogin }: { onLogin: (user: DemoUser) => void }) {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"preview" | "login" | "register">(
    "login"
  );
  const [busyRole, setBusyRole] = useState<UserRole | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    displayName: "",
    email: "",
    phone: "",
    password: ""
  });

  async function enterDemo(role: UserRole) {
    setBusyRole(role);
    setError("");
    try {
      const response = await fetch("/api/auth/demo-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role })
      });
      if (!response.ok) throw new Error("Preview login failed.");
      const data = (await response.json()) as { user: DemoUser };
      onLogin(data.user);
      navigate("/dashboard");
    } catch {
      setError("Preview එක විවෘත කළ නොහැක. Server එක නැවත run කරන්න.");
    } finally {
      setBusyRole(null);
    }
  }

  async function submitAccount(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      const isRegistration = mode === "register";
      const response = await fetch(
        isRegistration ? "/api/auth/register" : "/api/auth/login",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(
            isRegistration
              ? {
                  displayName: form.displayName,
                  email: form.email,
                  phone: form.phone || undefined,
                  password: form.password
                }
              : { email: form.email, password: form.password }
          )
        }
      );
      const data = (await response.json()) as {
        user?: DemoUser;
        message?: string;
      };
      if (!response.ok || !data.user) {
        throw new Error(data.message || "Account request failed.");
      }
      onLogin(data.user);
      navigate("/dashboard");
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Account request failed."
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="login-page">
      <div className="login-brand-panel">
        <Link to="/" className="login-back">
          <ArrowRight size={17} /> Home වෙත
        </Link>
        <Logo />
        <div className="login-brand-copy">
          <span className="pill">
            <LockKeyhole size={15} /> SECURE LEARNING PLATFORM
          </span>
          <h1>Learn. Grow. Lead.</h1>
          <p>
            Student learning සිට consultant business management දක්වා Adil
            Academy එකම digital platform එකක.
          </p>
        </div>
        <div className="login-quote">
          <ShieldCheck />
          <div>
            <strong>Protected access</strong>
            <span>Role-based dashboards සහ secure student content.</span>
          </div>
        </div>
      </div>
      <div className="login-form-panel">
        <div className="login-card">
          <div className="auth-tabs">
            {[
              ["login", "Login"],
              ["register", "Register"]
            ].map(([value, label]) => (
              <button
                key={value}
                type="button"
                className={mode === value ? "active" : ""}
                onClick={() => {
                  setMode(value as typeof mode);
                  setError("");
                }}
              >
                {label}
              </button>
            ))}
          </div>
          {mode === "preview" ? (
            <>
              <span className="eyebrow">PLATFORM PREVIEW</span>
              <h2>Dashboard එක තෝරන්න</h2>
              <p>
                Role එකක් තෝරා complete dashboard experience එක පරීක්ෂා
                කරන්න.
              </p>
              <div className="role-options">
                {roleOptions.map((option) => (
                  <button
                    type="button"
                    key={option.role}
                    onClick={() => enterDemo(option.role)}
                    disabled={busyRole !== null}
                  >
                    <span className="role-icon">{option.icon}</span>
                    <span>
                      <strong>{option.title}</strong>
                      <small>{option.description}</small>
                    </span>
                    <ChevronRight size={18} />
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              <span className="eyebrow">
                {mode === "register" ? "CREATE STUDENT ACCOUNT" : "WELCOME BACK"}
              </span>
              <h2>
                {mode === "register" ? "ගිණුමක් සාදන්න" : "Login වෙන්න"}
              </h2>
              <p>
                {mode === "register"
                  ? "මුලින් student account එකක් සාදා payment admission එක ආරම්භ කරන්න."
                  : "ඔබගේ Adil Academy account එකට secure ලෙස ඇතුළු වෙන්න."}
              </p>
              <form className="auth-form" onSubmit={submitAccount}>
                {mode === "register" && (
                  <>
                    <label>
                      සම්පූර්ණ නම
                      <input
                        required
                        minLength={2}
                        value={form.displayName}
                        onChange={(event) =>
                          setForm({ ...form, displayName: event.target.value })
                        }
                        placeholder="ඔබගේ නම"
                        autoComplete="name"
                      />
                    </label>
                    <label>
                      දුරකථන අංකය
                      <input
                        value={form.phone}
                        onChange={(event) =>
                          setForm({ ...form, phone: event.target.value })
                        }
                        placeholder="+94 7X XXX XXXX"
                        autoComplete="tel"
                      />
                    </label>
                  </>
                )}
                <label>
                  Email
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={(event) =>
                      setForm({ ...form, email: event.target.value })
                    }
                    placeholder="name@example.com"
                    autoComplete="email"
                  />
                </label>
                <label>
                  Password
                  <input
                    required
                    minLength={8}
                    type="password"
                    value={form.password}
                    onChange={(event) =>
                      setForm({ ...form, password: event.target.value })
                    }
                    placeholder="••••••••"
                    autoComplete={
                      mode === "register" ? "new-password" : "current-password"
                    }
                  />
                </label>
                {mode === "register" && (
                  <small className="password-hint">
                    අකුරු 8+, uppercase, lowercase සහ number එකක් අවශ්‍යයි.
                  </small>
                )}
                <button
                  type="submit"
                  className="button button-primary auth-submit"
                  disabled={submitting}
                >
                  {submitting
                    ? "Please wait..."
                    : mode === "register"
                      ? "Student account සාදන්න"
                      : "Login"}
                  {!submitting && <ArrowRight size={17} />}
                </button>
              </form>
            </>
          )}
          {error && <p className="form-error">{error}</p>}
          <div className="login-note">
            <LockKeyhole size={15} />
            Password සහ session data secure server-side authentication එකකින්
            ආරක්ෂා වේ.
          </div>
        </div>
      </div>
    </div>
  );
}

const dashboardNav: Record<
  UserRole,
  { label: string; icon: ReactNode }[]
> = {
  student: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "My Course", icon: <BookOpen /> },
    { label: "Progress", icon: <BarChart3 /> },
    { label: "Certificates", icon: <Award /> },
    { label: "Payments", icon: <CreditCard /> }
  ],
  consultant: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "My Students", icon: <Users /> },
    { label: "My Accounts", icon: <UserCheck /> },
    { label: "Binary Tree", icon: <Network /> },
    { label: "Income", icon: <Wallet /> }
  ],
  staff: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "Payments", icon: <CreditCard /> },
    { label: "Students", icon: <Users /> },
    { label: "Consultants", icon: <UserCheck /> },
    { label: "Reports", icon: <BarChart3 /> }
  ],
  admin: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "Students", icon: <Users /> },
    { label: "Payments", icon: <CreditCard /> },
    { label: "Network", icon: <Network /> },
    { label: "Commissions", icon: <CircleDollarSign /> },
    { label: "Settings", icon: <Settings /> }
  ]
};

function MetricCard({
  label,
  value,
  note,
  icon
}: {
  label: string;
  value: string;
  note: string;
  icon: ReactNode;
}) {
  return (
    <article className="metric-card">
      <span className="metric-icon">{icon}</span>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{note}</small>
    </article>
  );
}

function StudentDashboard() {
  const [summary, setSummary] = useState<StudentDashboardSummary | null>(null);
  const [loadError, setLoadError] = useState(false);
  useEffect(() => {
    fetch("/api/student/dashboard-summary")
      .then(async (response) => {
        if (!response.ok) throw new Error("Summary request failed");
        return response.json() as Promise<StudentDashboardSummary>;
      })
      .then(setSummary)
      .catch(() => setLoadError(true));
  }, []);

  if (loadError) {
    return <section className="dash-card"><h3>Dashboard data load කළ නොහැක</h3><p>Page එක refresh කරන්න.</p></section>;
  }
  if (!summary) {
    return <section className="dash-card"><h3>Dashboard loading...</h3></section>;
  }
  const enrolled = summary.enrollmentStatus !== "NOT_ENROLLED";
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Course Progress"
          value={`${summary.progressPercent}%`}
          note={`${summary.completedLessons} of ${summary.totalLessons} lessons`}
          icon={<TrendingUp />}
        />
        <MetricCard
          label="Learning Streak"
          value={summary.completedLessons ? "Active" : "0 days"}
          note={summary.completedLessons ? "Learning started" : "No activity yet"}
          icon={<Sparkles />}
        />
        <MetricCard
          label="Quiz Average"
          value={summary.quizAverage === null ? "—" : `${summary.quizAverage}%`}
          note={summary.quizAverage === null ? "No quiz attempts" : "Quiz performance"}
          icon={<Award />}
        />
        <MetricCard
          label="Account"
          value={summary.accountNumber ?? "Not assigned"}
          note={summary.accountStatus ?? "Payment pending"}
          icon={<UserCheck />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card dash-course-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">{enrolled ? "CONTINUE LEARNING" : "COURSE ACCESS LOCKED"}</span>
              <h3>{summary.courseTitle ?? "Payment approval required"}</h3>
            </div>
            <span>{summary.progressPercent}%</span>
          </div>
          <div className="course-visual">
            <span className="course-visual-icon">
              <ShieldCheck />
            </span>
            <div>
              <span>{enrolled ? "YOUR COURSE" : "NOT ENROLLED"}</span>
              <strong>{enrolled ? "ඔබ නතර කළ තැනින් ඉගෙනීම දිගටම කරගෙන යන්න" : "Full payment එක Admin approve කළ පසු lessons unlock වේ"}</strong>
            </div>
            <button type="button" disabled={!enrolled}>
              <Play fill="currentColor" />
            </button>
          </div>
          <div className="progress-track large">
            <span style={{ width: `${summary.progressPercent}%` }} />
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>Recent activity</h3>
            <button type="button">View all</button>
          </div>
          <div className="activity-list">
            {summary.recentActivity.length ? summary.recentActivity.map((activity) => (
              <div key={`${activity.title}-${activity.detail}`}>
                <span className="activity-dot completed"><Check /></span>
                <p><strong>{activity.title}</strong><small>{activity.detail}</small></p>
              </div>
            )) : <p>No learning activity yet.</p>}
          </div>
        </section>
      </div>
    </>
  );
}

function ConsultantDashboard() {
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Weekly Income"
          value="Rs. 7,500"
          note="Current cycle"
          icon={<Wallet />}
        />
        <MetricCard
          label="Direct Students"
          value="18"
          note="+3 this month"
          icon={<Users />}
        />
        <MetricCard
          label="Left Points"
          value="18,500"
          note="Carry forward active"
          icon={<ArrowRight />}
        />
        <MetricCard
          label="Right Points"
          value="15,000"
          note="3,500 pair gap"
          icon={<ArrowRight />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">BINARY NETWORK</span>
              <h3>CN527695</h3>
            </div>
            <button type="button">Full tree</button>
          </div>
          <div className="mini-tree">
            <div className="mini-tree-root">CN527695</div>
            <div className="mini-tree-branches">
              <div>
                <span>LEFT</span>
                <strong>SR527701</strong>
              </div>
              <div>
                <span>RIGHT</span>
                <strong>SR527702</strong>
              </div>
            </div>
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>My accounts</h3>
            <button type="button">Manage</button>
          </div>
          <div className="account-list">
            <div>
              <span className="account-badge">MAIN</span>
              <p>
                <strong>CN527695</strong>
                <small>Active • 18 students</small>
              </p>
              <span className="status-badge success">Active</span>
            </div>
            <div>
              <span className="account-badge">02</span>
              <p>
                <strong>CN527706</strong>
                <small>Active • 7 students</small>
              </p>
              <span className="status-badge success">Active</span>
            </div>
            <div>
              <span className="account-badge muted">03</span>
              <p>
                <strong>Available slot</strong>
                <small>Up to 7 accounts</small>
              </p>
              <span className="status-badge">Empty</span>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

function OperationsDashboard({ role }: { role: "staff" | "admin" }) {
  const isAdmin = role === "admin";
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Total Students"
          value="1,248"
          note="+64 this month"
          icon={<Users />}
        />
        <MetricCard
          label="Pending Payments"
          value="18"
          note="Needs review"
          icon={<CreditCard />}
        />
        <MetricCard
          label={isAdmin ? "Active Consultants" : "Open Tickets"}
          value={isAdmin ? "126" : "12"}
          note={isAdmin ? "+8 this month" : "4 high priority"}
          icon={isAdmin ? <Network /> : <Bell />}
        />
        <MetricCard
          label="Course Completion"
          value="72%"
          note="Across all students"
          icon={<GraduationCap />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">ACTION REQUIRED</span>
              <h3>Payment verification</h3>
            </div>
            <button type="button">View queue</button>
          </div>
          <div className="payment-table">
            <div className="table-head">
              <span>Student</span>
              <span>Method</span>
              <span>Amount</span>
              <span>Status</span>
            </div>
            {[
              ["Sahan Jay", "Bank", "Rs. 50,000", "Review"],
              ["Ishara M.", "USDT", "154 USDT", "Review"],
              ["Dulani K.", "Bank", "Rs. 25,000", "Partial"]
            ].map((row) => (
              <div className="table-row" key={row[0]}>
                <span>{row[0]}</span>
                <span>{row[1]}</span>
                <strong>{row[2]}</strong>
                <span
                  className={
                    row[3] === "Partial"
                      ? "status-badge warning"
                      : "status-badge"
                  }
                >
                  {row[3]}
                </span>
              </div>
            ))}
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>{isAdmin ? "Friday commission cycle" : "Student activity"}</h3>
            <button type="button">Details</button>
          </div>
          {isAdmin ? (
            <div className="cycle-card">
              <span className="cycle-icon">
                <CircleDollarSign />
              </span>
              <strong>2026-W29</strong>
              <p>126 accounts ready for calculation</p>
              <div className="cycle-progress">
                <span>
                  <small>Estimated payout</small>
                  <strong>Rs. 684,500</strong>
                </span>
                <span className="status-badge success">Scheduled</span>
              </div>
              <button type="button" className="button button-primary full">
                Review cycle
              </button>
            </div>
          ) : (
            <div className="activity-list">
              <div>
                <span className="activity-dot completed">
                  <Check />
                </span>
                <p>
                  <strong>32 lessons completed</strong>
                  <small>Today across all students</small>
                </p>
              </div>
              <div>
                <span className="activity-dot">
                  <Users />
                </span>
                <p>
                  <strong>8 new registrations</strong>
                  <small>Waiting for payments</small>
                </p>
              </div>
            </div>
          )}
        </section>
      </div>
    </>
  );
}

const workspaceData: Record<
  string,
  {
    title: string;
    description: string;
    action: string;
    rows: [string, string, string][];
  }
> = {
  "student:My Course": {
    title: "Crypto Trading — Zero to Pro",
    description: "ඔබට active course lessons සහ learning resources.",
    action: "Continue lesson",
    rows: [
      ["Module 01", "Crypto Foundations", "Completed"],
      ["Module 02", "Spot Trading", "Completed"],
      ["Module 03", "Technical Analysis", "86%"],
      ["Module 04", "Risk Management", "In progress"],
      ["Module 05", "Futures Trading", "Locked"],
      ["Module 06", "Trading Psychology", "Locked"]
    ]
  },
  "student:Progress": {
    title: "Learning Progress",
    description: "Lessons, quizzes සහ course completion summary.",
    action: "View report",
    rows: [
      ["Lessons completed", "24 of 36", "68%"],
      ["Quiz average", "86 points", "Good"],
      ["Learning time", "18h 42m", "This course"],
      ["Current streak", "12 days", "Active"]
    ]
  },
  "student:Certificates": {
    title: "Certificates",
    description: "Course requirements complete වූ පසු certificate නිකුත් වේ.",
    action: "Requirements",
    rows: [
      ["Crypto Trading — Zero to Pro", "68% complete", "Not issued"],
      ["Required quiz average", "Minimum 70%", "Passed"],
      ["All lessons", "24 of 36", "Pending"]
    ]
  },
  "student:Payments": {
    title: "Payment History",
    description: "Bank Transfer සහ USDT payment verification status.",
    action: "New payment",
    rows: [
      ["PAY-20260716-A31F", "Bank Transfer", "Approved"],
      ["Course access", "Rs. 50,000", "Active"],
      ["Payment proof", "bank-slip.webp", "Verified"]
    ]
  },
  "consultant:My Students": {
    title: "My Students",
    description: "ඔබ තෝරාගත් CN account හරහා පැමිණි admissions.",
    action: "Register student",
    rows: [
      ["Sahan Jay", "SR527701 • LEFT", "Active"],
      ["Ishara M.", "SR527702 • RIGHT", "Active"],
      ["Dulani K.", "Payment pending", "Review"],
      ["Nuwan P.", "SR527710 • LEFT", "Active"]
    ]
  },
  "consultant:My Accounts": {
    title: "SR/CN Accounts",
    description: "Main account සහ purchased consultant accounts.",
    action: "Account details",
    rows: [
      ["CN527695", "Main account", "Active"],
      ["CN527706", "Account 02", "Active"],
      ["Available accounts", "2 of 7 used", "5 slots"]
    ]
  },
  "consultant:Binary Tree": {
    title: "Binary Network",
    description: "LEFT/RIGHT placements සහ account ownership view.",
    action: "Expand tree",
    rows: [
      ["CN527695", "Main account", "Root"],
      ["SR527701", "Direct LEFT", "18,500 PV"],
      ["SR527702", "Direct RIGHT", "15,000 PV"],
      ["Carry forward", "Left 3,500", "Active"]
    ]
  },
  "consultant:Income": {
    title: "Income & Wallet",
    description: "Weekly commissions, wallet ledger සහ payout requests.",
    action: "Request payout",
    rows: [
      ["Available balance", "Rs. 22,500", "Ready"],
      ["Current weekly cycle", "Rs. 7,500", "Calculated"],
      ["Last payout", "Rs. 15,000", "Paid"],
      ["Next release", "Friday", "Scheduled"]
    ]
  },
  "staff:Payments": {
    title: "Payment Verification Queue",
    description: "Payment proof බලලා approve, partial හෝ reject කරන්න.",
    action: "Open queue",
    rows: [
      ["PAY-20260716-F29A", "Bank • Rs. 50,000", "Review"],
      ["PAY-20260716-C11B", "USDT • 154", "Review"],
      ["PAY-20260715-92AC", "Bank • Rs. 25,000", "Partial"]
    ]
  },
  "staff:Students": {
    title: "Student Management",
    description: "Accounts, enrollments, course access සහ status.",
    action: "Add student",
    rows: [
      ["Active students", "1,248", "Current"],
      ["New this month", "64", "+12%"],
      ["Pending admission", "18", "Review"],
      ["Suspended", "3", "Attention"]
    ]
  },
  "staff:Consultants": {
    title: "Consultant Applications",
    description: "Interviews සහ approval preparation.",
    action: "Review applications",
    rows: [
      ["Pending applications", "14", "New"],
      ["Interview stage", "6", "Scheduled"],
      ["Approved this month", "8", "Complete"]
    ]
  },
  "staff:Reports": {
    title: "Operations Reports",
    description: "Students, payments සහ course activity reports.",
    action: "Export report",
    rows: [
      ["Monthly admissions", "64 students", "July"],
      ["Approved revenue", "Rs. 3,200,000", "July"],
      ["Completion rate", "72%", "Current"]
    ]
  },
  "admin:Students": {
    title: "All Students",
    description: "Complete student and access administration.",
    action: "Manage students",
    rows: [
      ["Total students", "1,248", "Active platform"],
      ["Paid enrollments", "1,106", "88.6%"],
      ["Course completed", "798", "64%"]
    ]
  },
  "admin:Payments": {
    title: "Payments & Admissions",
    description: "Verification, approvals, refunds සහ audit records.",
    action: "Payment queue",
    rows: [
      ["Pending review", "18", "Action required"],
      ["Approved today", "12", "Rs. 600,000"],
      ["Partial payments", "7", "No points"],
      ["Rejected", "2", "Proof mismatch"]
    ]
  },
  "admin:Network": {
    title: "Network Administration",
    description: "SR/CN ownership, placement integrity සහ point balances.",
    action: "Open network",
    rows: [
      ["Active SR accounts", "1,122", "Students"],
      ["Active CN accounts", "184", "Consultants"],
      ["Unplaced accounts", "0", "Healthy"],
      ["90-day resets", "4", "This month"]
    ]
  },
  "admin:Commissions": {
    title: "Commissions & Payouts",
    description: "Friday cycles, approvals, wallets සහ payout ledger.",
    action: "Calculate cycle",
    rows: [
      ["Current cycle", "2026-W29", "Scheduled"],
      ["Estimated payout", "Rs. 684,500", "126 accounts"],
      ["Payout requests", "21", "Pending"],
      ["Ledger integrity", "No duplicates", "Healthy"]
    ]
  },
  "admin:Settings": {
    title: "Platform Settings",
    description: "Business rules, account limits සහ system configuration.",
    action: "Save settings",
    rows: [
      ["Account sequence", "Next 527711", "Protected"],
      ["Max CN accounts", "7 per consultant", "Configurable"],
      ["Commission day", "Friday", "Asia/Colombo"],
      ["Inactivity reset", "90 days", "Enabled"]
    ]
  }
};

type StudentPaymentView = {
  id: string;
  paymentCode: string;
  method: string;
  totalAmount: string;
  paidAmount: string;
  status: string;
  hasProof: boolean;
};

type StudentCertificateView = {
  courseTitle: string;
  certificate: {
    certificateCode: string;
    issuedAt: string;
    revokedAt: string | null;
  };
};

function StudentFeatureWorkspace({ module }: { module: string }) {
  const [summary, setSummary] = useState<StudentDashboardSummary | null>(null);
  const [payments, setPayments] = useState<StudentPaymentView[]>([]);
  const [certificates, setCertificates] = useState<StudentCertificateView[]>([]);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    Promise.all([
      fetch("/api/student/dashboard-summary"),
      fetch("/api/student/payments"),
      fetch("/api/student/certificates")
    ]).then(async ([summaryResponse, paymentsResponse, certificatesResponse]) => {
      if (!summaryResponse.ok || !paymentsResponse.ok || !certificatesResponse.ok) {
        throw new Error("Student workspace request failed");
      }
      const summaryData = await summaryResponse.json() as StudentDashboardSummary;
      const paymentData = await paymentsResponse.json() as { payments: StudentPaymentView[] };
      const certificateData = await certificatesResponse.json() as { certificates: StudentCertificateView[] };
      setSummary(summaryData);
      setPayments(paymentData.payments);
      setCertificates(certificateData.certificates);
    }).catch(() => setFailed(true)).finally(() => setLoading(false));
  }, []);

  if (loading) return <section className="dash-card workspace-card"><h3>Loading...</h3></section>;
  if (failed || !summary) return <section className="dash-card workspace-card"><h3>Data load කළ නොහැක</h3><p>Page එක refresh කරන්න.</p></section>;

  let title = module;
  let description = "ඔබගේ සැබෑ account data සහ course activity.";
  let rows: [string, string, string][] = [];
  if (module === "My Course") {
    title = summary.courseTitle ?? "Course access pending";
    description = summary.enrollmentStatus === "NOT_ENROLLED"
      ? "Full payment එක Admin approve කළ පසු course lessons unlock වේ."
      : "ඔබගේ active course modules සහ progress.";
    rows = summary.modules.length
      ? summary.modules.map((item, index) => [
          `Module ${String(index + 1).padStart(2, "0")}`,
          item.title,
          item.progressPercent === 100 ? "Completed" : item.progressPercent ? `${item.progressPercent}%` : "Not started"
        ])
      : [["Course access", "Payment approval required", "Locked"]];
  } else if (module === "Progress") {
    title = "Learning Progress";
    rows = [
      ["Lessons completed", `${summary.completedLessons} of ${summary.totalLessons}`, `${summary.progressPercent}%`],
      ["Quiz average", summary.quizAverage === null ? "No attempts" : `${summary.quizAverage}%`, summary.quizAverage === null ? "Not started" : "Recorded"],
      ["Recent activity", summary.recentActivity.length ? `${summary.recentActivity.length} updates` : "No activity", summary.recentActivity.length ? "Active" : "Not started"],
      ["Course access", summary.courseTitle ?? "Not enrolled", summary.enrollmentStatus]
    ];
  } else if (module === "Certificates") {
    title = "Certificates";
    description = "සියලු lessons සහ required quizzes complete කළ පසු certificate නිකුත් වේ.";
    rows = certificates.length
      ? certificates.map((item) => [item.courseTitle, item.certificate.certificateCode, item.certificate.revokedAt ? "Revoked" : "Issued"])
      : [
          [summary.courseTitle ?? "Crypto Trading — Zero to Pro", `${summary.progressPercent}% complete`, "Not issued"],
          ["All lessons", `${summary.completedLessons} of ${summary.totalLessons}`, summary.progressPercent === 100 ? "Completed" : "Pending"],
          ["Quiz result", summary.quizAverage === null ? "No attempts" : `${summary.quizAverage}%`, summary.quizAverage !== null && summary.quizAverage >= 70 ? "Passed" : "Pending"]
        ];
  } else if (module === "Payments") {
    title = "Payment History";
    description = "ඔබ submit කළ Bank Transfer සහ USDT payments පමණක් මෙහි පෙන්වයි.";
    rows = payments.length
      ? payments.map((item) => [
          item.paymentCode,
          `${item.method.replaceAll("_", " ")} • Rs. ${Number(item.paidAmount).toLocaleString()}`,
          item.status.replaceAll("_", " ")
        ])
      : [["No payments", "Payment request එකක් තවම submit කර නැහැ", "Empty"]];
  }

  return (
    <section className="dash-card workspace-card">
      <div className="workspace-heading">
        <div>
          <span className="eyebrow">ADIL ACADEMY STUDENT PORTAL</span>
          <h2>{title}</h2>
          <p>{description}</p>
        </div>
      </div>
      <div className="workspace-list">
        <div className="workspace-list-head"><span>Item</span><span>Details</span><span>Status</span></div>
        {rows.map((row, index) => (
          <div className="workspace-list-row" key={`${row[0]}-${index}`}>
            <strong>{row[0]}</strong><span>{row[1]}</span><span className="status-badge success">{row[2]}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function FeatureWorkspace({
  role,
  module
}: {
  role: UserRole;
  module: string;
}) {
  if (role === "student") return <StudentFeatureWorkspace module={module} />;
  const data = workspaceData[role + ":" + module];
  if (!data) {
    return (
      <section className="dash-card workspace-empty">
        <Settings />
        <h3>{module}</h3>
        <p>මෙම module එක සඳහා permissions අනුව content load වේ.</p>
      </section>
    );
  }
  return (
    <section className="dash-card workspace-card">
      <div className="workspace-heading">
        <div>
          <span className="eyebrow">ADIL ACADEMY CONTROL PANEL</span>
          <h2>{data.title}</h2>
          <p>{data.description}</p>
        </div>
        <button type="button" className="button button-primary">
          {data.action}
          <ArrowRight size={16} />
        </button>
      </div>
      <div className="workspace-list">
        <div className="workspace-list-head">
          <span>Item</span>
          <span>Details</span>
          <span>Status</span>
        </div>
        {data.rows.map((row) => (
          <div className="workspace-list-row" key={row[0]}>
            <strong>{row[0]}</strong>
            <span>{row[1]}</span>
            <span className="status-badge success">{row[2]}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Dashboard({
  user,
  onLogout
}: {
  user: DemoUser;
  onLogout: () => void;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeModule, setActiveModule] = useState("Overview");
  const roleTitle = {
    student: "Student Dashboard",
    consultant: "Consultant Control Panel",
    staff: "Staff Operations",
    admin: "Super Admin Control"
  }[user.role];

  return (
    <div className="dashboard-shell">
      <aside className={sidebarOpen ? "dashboard-sidebar sidebar-open" : "dashboard-sidebar"}>
        <div className="sidebar-top">
          <Logo />
          <button
            type="button"
            className="sidebar-close"
            onClick={() => setSidebarOpen(false)}
          >
            <X />
          </button>
        </div>
        <span className="sidebar-section-label">MAIN MENU</span>
        <nav>
          {dashboardNav[user.role].map((item) => (
            <button
              type="button"
              className={activeModule === item.label ? "active" : ""}
              key={item.label}
              onClick={() => {
                setActiveModule(item.label);
                setSidebarOpen(false);
              }}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-support">
          <ShieldCheck />
          <strong>Need help?</strong>
          <span>Adil Academy support team</span>
          <button type="button">Contact support</button>
        </div>
        <button className="logout-button" type="button" onClick={onLogout}>
          <LogOut />
          Logout
        </button>
      </aside>
      <main className="dashboard-main">
        <header className="dashboard-header">
          <button
            className="dashboard-menu"
            type="button"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu />
          </button>
          <div>
            <span className="eyebrow">{roleTitle}</span>
            <h1>ආයුබෝවන්, {user.name.split(" ")[0]}</h1>
          </div>
          <div className="header-actions">
            <button type="button" aria-label="Notifications">
              <Bell />
              <span />
            </button>
            <div className="dashboard-user">
              <span>{user.name.slice(0, 2).toUpperCase()}</span>
              <div>
                <strong>{user.name}</strong>
                <small>{user.accountNumber ?? roleTitle}</small>
              </div>
            </div>
          </div>
        </header>
        <div className="dashboard-content">
          <div className="dashboard-welcome">
            <div>
              <h2>{roleTitle}</h2>
              <p>ඔබගේ අද දින platform summary එක මෙන්න.</p>
            </div>
            <span className="live-status">
              <i /> System Online
            </span>
          </div>
          {activeModule === "Overview" ? (
            <>
              {user.role === "student" && <StudentDashboard />}
              {user.role === "consultant" && <ConsultantDashboard />}
              {user.role === "staff" && <OperationsDashboard role="staff" />}
              {user.role === "admin" && <OperationsDashboard role="admin" />}
            </>
          ) : (
            <FeatureWorkspace role={user.role} module={activeModule} />
          )}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<DemoUser | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then(async (response) => {
        if (!response.ok) return null;
        return (await response.json()) as { user: DemoUser };
      })
      .then((data) => setUser(data?.user ?? null))
      .finally(() => setAuthChecked(true));
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setUser(null);
  }

  if (!authChecked) {
    return (
      <div className="app-loading">
        <Logo />
        <span />
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage onLogin={setUser} />} />
      <Route
        path="/dashboard"
        element={
          user ? (
            <Dashboard user={user} onLogout={logout} />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
