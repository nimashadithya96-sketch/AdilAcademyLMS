import { eq } from "drizzle-orm";
import { requireDatabase } from "../../../db/client";
import { commissionCycles } from "../../../db/schema";
import { calculateCommissionCycle } from "./service";

const COLOMBO_OFFSET_MS = 5.5 * 60 * 60 * 1000;
const FRIDAY = 5;
const SETTLEMENT_HOUR = 12;
const SETTLEMENT_MINUTE = 30;
const CHECK_INTERVAL_MS = 60_000;

export type FridaySettlementWindow = {
  cycleKey: string;
  periodStart: Date;
  periodEnd: Date;
};

function dateKey(date: Date) {
  return date.toISOString().slice(0, 10);
}

export function latestFridaySettlement(now = new Date()): FridaySettlementWindow | null {
  // Shift UTC into Sri Lanka wall-clock time. Sri Lanka does not use DST.
  const local = new Date(now.getTime() + COLOMBO_OFFSET_MS);
  const daysSinceFriday = (local.getUTCDay() - FRIDAY + 7) % 7;
  const localDue = new Date(Date.UTC(
    local.getUTCFullYear(),
    local.getUTCMonth(),
    local.getUTCDate() - daysSinceFriday,
    SETTLEMENT_HOUR,
    SETTLEMENT_MINUTE
  ));

  // Before 12:30 PM on Friday, the latest due settlement was last Friday.
  if (local.getTime() < localDue.getTime()) localDue.setUTCDate(localDue.getUTCDate() - 7);

  const periodEnd = new Date(localDue.getTime() - COLOMBO_OFFSET_MS);
  if (periodEnd.getTime() > now.getTime()) return null;
  const periodStart = new Date(periodEnd.getTime() - 7 * 24 * 60 * 60 * 1000);
  return {
    cycleKey: `LK-FRIDAY-${dateKey(localDue)}`,
    periodStart,
    periodEnd
  };
}

export function nextFridaySettlement(now = new Date()) {
  const local = new Date(now.getTime() + COLOMBO_OFFSET_MS);
  const daysUntilFriday = (FRIDAY - local.getUTCDay() + 7) % 7;
  const localDue = new Date(Date.UTC(
    local.getUTCFullYear(),
    local.getUTCMonth(),
    local.getUTCDate() + daysUntilFriday,
    SETTLEMENT_HOUR,
    SETTLEMENT_MINUTE
  ));
  if (localDue.getTime() <= local.getTime()) localDue.setUTCDate(localDue.getUTCDate() + 7);
  return new Date(localDue.getTime() - COLOMBO_OFFSET_MS);
}

let running = false;

export async function runDueFridaySettlement(now = new Date()) {
  if (running) return;
  const window = latestFridaySettlement(now);
  if (!window) return;
  running = true;
  try {
    const db = requireDatabase();
    const [existing] = await db.select({ id: commissionCycles.id })
      .from(commissionCycles)
      .where(eq(commissionCycles.cycleKey, window.cycleKey))
      .limit(1);
    if (existing) return;
    const result = await calculateCommissionCycle(window, null);
    console.log(
      `[Friday settlement] ${window.cycleKey}: ${result.awardedAccounts} accounts, Rs. ${result.totalAmount}`
    );
  } catch (error) {
    // The cycle key is unique, so concurrent instances cannot pay twice.
    console.error("Friday commission settlement failed", error);
  } finally {
    running = false;
  }
}

export function startFridayCommissionScheduler() {
  void runDueFridaySettlement();
  const timer = setInterval(() => void runDueFridaySettlement(), CHECK_INTERVAL_MS);
  timer.unref();
  console.log("Friday commission scheduler active: Asia/Colombo Friday 12:30 PM");
}
