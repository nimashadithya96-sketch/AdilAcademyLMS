import crypto from "node:crypto";
import { and, desc, eq, gt, inArray, isNull, or } from "drizzle-orm";
import { Router, type Request } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import { notifications, supportAgentPresence, supportConversations, supportMessages, users } from "../../../db/schema";
import { getUserForSession } from "../auth/service";
import { HttpError, readCookie, requireRole } from "../../lib/auth";
import { asyncRoute } from "../../lib/http";

export const supportRouter = Router();
const tokenHash = (token: string) => crypto.createHash("sha256").update(token).digest("hex");
const createInput = z.object({ mode: z.enum(["FAQ", "HUMAN"]), name: z.string().trim().max(100).optional(), email: z.string().trim().email().max(200).optional() });
const messageInput = z.object({ token: z.string().min(32).max(200), message: z.string().trim().min(1).max(1500) });
const tokenInput = z.object({ token: z.string().min(32).max(200) });

const rate = new Map<string, { count: number; resets: number }>();
function limit(request: Request) {
  const key = request.ip || "unknown"; const now = Date.now(); const value = rate.get(key);
  if (!value || value.resets < now) { rate.set(key, { count: 1, resets: now + 60_000 }); return; }
  if (value.count >= 30) throw new HttpError(429, "කරුණාකර මිනිත්තුවකට පසු නැවත උත්සාහ කරන්න.");
  value.count += 1;
}
async function optionalUser(request: Request) {
  const token = readCookie(request.headers.cookie, "adil_session");
  return token ? await getUserForSession(token).catch(() => null) : null;
}

const FAQS = [
  { keys: ["pay id", "payid", "reference"], answer: "Pay ID එක payment එක හඳුනාගැනීමට භාවිත කරන unique reference එකයි. ඔබ consultant කෙනෙකු හරහා register වුණා නම් ඔහු/ඇය විසින් ලැබෙන Pay ID එක bank transfer reference එකට හරියටම ඇතුළත් කරන්න." },
  { keys: ["payment", "ගෙව", "bank", "slip"], answer: "Payment කළ පසු නිවැරදි Pay ID/reference එක සහ පැහැදිලි bank slip එක upload කරන්න. Admin විසින් පරීක්ෂා කර approve කළ පසු OTP එක ඔබගේ email එකට යවයි." },
  { keys: ["otp", "code", "කේත"], answer: "OTP එක Admin payment approve කළ පසුව verified email එකට යවයි. Inbox එකේ නැත්නම් Spam/Promotions folder බලන්න. OTP එක කිසිවෙකු සමඟ share කරන්න එපා." },
  { keys: ["password", "මුරපද", "login", "log in"], answer: "OTP verify කරන වෙලාවේ ඔබම permanent password එකක් තෝරන්න. එයට uppercase, lowercase සහ number එකක් ඇතුළත් විය යුතුයි." },
  { keys: ["course", "පාඨමාල", "video", "lesson"], answer: "Payment approve වී account active වූ පසු Student Portal → My Course තුළ lessons පෙනේ. Locked නම් payment/account status එක Admin හෝ consultant සමඟ පරීක්ෂා කරන්න." },
  { keys: ["consultant", "cco", "cn"], answer: "CCO/Consultant access ලබාදෙන්නේ interview සහ Admin approval එකෙන් පමණයි. Student account එකෙන්ම Consultant Portal වෙත switch කළ හැක." },
  { keys: ["commission", "income", "point", "කොමිස්", "ආදාය"], answer: "Verified full-payment admissions අනුව points සහ direct income record වේ. Weekly eligible points ශ්‍රී ලංකා වේලාවෙන් සිකුරාදා 12:30 PM settle වේ; payout එක Admin විසින් manual bank transfer කරයි." },
  { keys: ["certificate", "සහතික"], answer: "අදාළ lessons සහ quizzes සම්පූර්ණ කර course requirements ඉටු කළ පසු certificate eligibility ලැබේ." },
  { keys: ["hello", "hi", "හෙලෝ", "ආයුබෝවන්"], answer: "ආයුබෝවන්! මම Adil Academy සිංහල FAQ සහායකයා. Payment, Pay ID, OTP, login, course, CCO හෝ commission ගැන ප්‍රශ්නය ලියන්න." }
];
function faqAnswer(question: string) {
  const normalized = question.toLocaleLowerCase();
  const match = FAQS.map((item) => ({ ...item, score: item.keys.filter((key) => normalized.includes(key)).length })).sort((a, b) => b.score - a.score)[0];
  return match?.score ? match.answer : "මේ ප්‍රශ්නයට මගේ FAQ දත්තවල නිශ්චිත පිළිතුරක් නැහැ. ‘Human Support’ තෝරා Personal Guide කෙනෙකුගෙන් උදව් ඉල්ලන්න, නැත්නම් Pay ID / payment / OTP / login / course / CCO / commission ලෙස කෙටියෙන් අහන්න.";
}

supportRouter.get("/public/support/availability", asyncRoute(async (_request, response) => {
  const db = requireDatabase(); const since = new Date(Date.now() - 60_000);
  const online = await db.select({ id: users.id }).from(supportAgentPresence).innerJoin(users, eq(users.id, supportAgentPresence.userId)).where(and(gt(supportAgentPresence.lastSeenAt, since), eq(users.isActive, true), inArray(users.role, ["consultant", "staff", "admin"]))).limit(1);
  response.json({ humanOnline: online.length > 0 });
}));

supportRouter.post("/public/support/conversations", asyncRoute(async (request, response) => {
  limit(request); const input = createInput.parse(request.body); const db = requireDatabase(); const rawToken = crypto.randomBytes(32).toString("hex");
  const current = await optionalUser(request); const since = new Date(Date.now() - 60_000);
  const onlineAgents = input.mode === "HUMAN" ? await db.select({ id: users.id }).from(supportAgentPresence).innerJoin(users, eq(users.id, supportAgentPresence.userId)).where(and(gt(supportAgentPresence.lastSeenAt, since), eq(users.isActive, true), inArray(users.role, ["consultant", "staff", "admin"]))) : [];
  const humanOnline = onlineAgents.length > 0; const channel = input.mode === "HUMAN" && humanOnline ? "HUMAN" : "FAQ"; const status = channel === "HUMAN" ? "WAITING" : "BOT";
  const [conversation] = await db.insert(supportConversations).values({ publicTokenHash: tokenHash(rawToken), channel, status, visitorName: input.name, visitorEmail: input.email, visitorUserId: current?.id }).returning();
  const welcome = input.mode === "HUMAN" && !humanOnline ? "දැනට Human Support team එක online නැහැ. ඔබට ඉක්මනින් උදව් කිරීමට FAQ Bot එක සම්බන්ධ කළා." : channel === "HUMAN" ? "ඔබගේ request එක online support team එකට යැව්වා. පළමු available Personal Guide ඔබ සමඟ සම්බන්ධ වේ." : "ආයුබෝවන්! ඔබගේ ප්‍රශ්නය සිංහලෙන් හෝ English වලින් කෙටියෙන් ලියන්න.";
  await db.insert(supportMessages).values({ conversationId: conversation.id, senderType: "SYSTEM", body: welcome });
  if (channel === "HUMAN" && onlineAgents.length) await db.insert(notifications).values(onlineAgents.map((agent) => ({ userId: agent.id, type: "SUPPORT_WAITING", title: "Customer needs human support", message: `${input.name || "Visitor"} සමඟ chat කිරීමට I CAN HELP ඔබන්න.` })));
  response.status(201).json({ id: conversation.id, token: rawToken, status, humanOnline, message: welcome });
}));

supportRouter.post("/public/support/conversations/:id/messages", asyncRoute(async (request, response) => {
  limit(request); const input = messageInput.parse(request.body); const db = requireDatabase();
  const [conversation] = await db.select().from(supportConversations).where(and(eq(supportConversations.id, String(request.params.id)), eq(supportConversations.publicTokenHash, tokenHash(input.token)))).limit(1);
  if (!conversation) throw new HttpError(404, "Support chat එක සොයාගත නොහැක."); if (conversation.status === "CLOSED") throw new HttpError(409, "මෙම chat එක අවසන් කර ඇත.");
  const [sent] = await db.insert(supportMessages).values({ conversationId: conversation.id, senderType: "VISITOR", body: input.message }).returning();
  await db.update(supportConversations).set({ lastMessageAt: new Date(), updatedAt: new Date() }).where(eq(supportConversations.id, conversation.id));
  let bot = null; if (conversation.channel === "FAQ") { [bot] = await db.insert(supportMessages).values({ conversationId: conversation.id, senderType: "BOT", body: faqAnswer(input.message) }).returning(); }
  response.status(201).json({ message: sent, bot });
}));

supportRouter.get("/public/support/conversations/:id", asyncRoute(async (request, response) => {
  limit(request); const input = tokenInput.parse(request.query); const db = requireDatabase();
  const [conversation] = await db.select().from(supportConversations).where(and(eq(supportConversations.id, String(request.params.id)), eq(supportConversations.publicTokenHash, tokenHash(input.token)))).limit(1);
  if (!conversation) throw new HttpError(404, "Support chat එක සොයාගත නොහැක.");
  const messages = await db.select().from(supportMessages).where(eq(supportMessages.conversationId, conversation.id)).orderBy(supportMessages.createdAt);
  let agentName: string | null = null; if (conversation.assignedTo) { const [agent] = await db.select({ name: users.displayName }).from(users).where(eq(users.id, conversation.assignedTo)); agentName = agent?.name ?? null; }
  response.json({ conversation: { ...conversation, publicTokenHash: undefined, agentName }, messages });
}));

supportRouter.post("/support/heartbeat", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]); const db = requireDatabase();
  await db.insert(supportAgentPresence).values({ userId: user.id, lastSeenAt: new Date() }).onConflictDoUpdate({ target: supportAgentPresence.userId, set: { lastSeenAt: new Date() } }); response.status(204).end();
}));

supportRouter.get("/support/queue", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]); const db = requireDatabase();
  const rows = await db.select().from(supportConversations).where(or(eq(supportConversations.status, "WAITING"), and(eq(supportConversations.assignedTo, user.id), inArray(supportConversations.status, ["CLAIMED", "OPEN"])))).orderBy(desc(supportConversations.lastMessageAt)).limit(100);
  response.json({ conversations: rows.map(({ publicTokenHash: _secret, ...row }) => ({ ...row, visitorEmail: row.assignedTo === user.id || user.role === "admin" ? row.visitorEmail : null })) });
}));

supportRouter.post("/support/conversations/:id/claim", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]); const db = requireDatabase();
  const [claimed] = await db.update(supportConversations).set({ assignedTo: user.id, status: "CLAIMED", claimedAt: new Date(), updatedAt: new Date() }).where(and(eq(supportConversations.id, String(request.params.id)), eq(supportConversations.status, "WAITING"), isNull(supportConversations.assignedTo))).returning();
  if (!claimed) throw new HttpError(409, "මෙම customerට වෙනත් guide කෙනෙක් දැනටමත් උදව් කරයි.");
  await db.insert(supportMessages).values({ conversationId: claimed.id, senderType: "SYSTEM", body: `${user.name} Personal Guide ලෙස chat එකට සම්බන්ධ විය.` }); response.json({ conversation: claimed });
}));

supportRouter.get("/support/conversations/:id/messages", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]); const db = requireDatabase(); const id = String(request.params.id);
  const [conversation] = await db.select().from(supportConversations).where(eq(supportConversations.id, id)); if (!conversation || (user.role !== "admin" && conversation.assignedTo !== user.id)) throw new HttpError(403, "මෙම chat එකට access නැහැ.");
  const messages = await db.select().from(supportMessages).where(eq(supportMessages.conversationId, id)).orderBy(supportMessages.createdAt); response.json({ conversation, messages });
}));

supportRouter.post("/support/conversations/:id/messages", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]); const body = z.object({ message: z.string().trim().min(1).max(1500) }).parse(request.body); const db = requireDatabase(); const id = String(request.params.id);
  const [conversation] = await db.select().from(supportConversations).where(eq(supportConversations.id, id)); if (!conversation || (user.role !== "admin" && conversation.assignedTo !== user.id)) throw new HttpError(403, "මෙම chat එකට access නැහැ.");
  const [message] = await db.insert(supportMessages).values({ conversationId: id, senderType: "AGENT", senderUserId: user.id, body: body.message }).returning(); await db.update(supportConversations).set({ lastMessageAt: new Date(), updatedAt: new Date() }).where(eq(supportConversations.id, id)); response.status(201).json({ message });
}));

supportRouter.post("/support/conversations/:id/close", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]); const db = requireDatabase(); const id = String(request.params.id);
  const [closed] = await db.update(supportConversations).set({ status: "CLOSED", closedAt: new Date(), updatedAt: new Date() }).where(and(eq(supportConversations.id, id), user.role === "admin" ? or(eq(supportConversations.assignedTo, user.id), isNull(supportConversations.assignedTo))! : eq(supportConversations.assignedTo, user.id))).returning();
  if (!closed) throw new HttpError(403, "මෙම chat එක close කළ නොහැක."); await db.insert(supportMessages).values({ conversationId: id, senderType: "SYSTEM", body: "Support chat එක අවසන් කර ඇත. ඔබට නැවත උදව් අවශ්‍ය නම් අලුත් chat එකක් ආරම්භ කරන්න." }); response.json({ conversation: closed });
}));
