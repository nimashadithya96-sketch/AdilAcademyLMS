export type UserRole = "student" | "consultant" | "staff" | "admin";

export type DemoUser = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  accountNumber?: string;
};

export type PlatformOverview = {
  course: {
    title: string;
    language: string;
    modules: number;
    access: string;
  };
  features: string[];
  paymentMethods: string[];
};

export type StudentDashboardSummary = {
  enrollmentStatus: "NOT_ENROLLED" | "ACTIVE" | "COMPLETED";
  courseTitle: string | null;
  totalLessons: number;
  completedLessons: number;
  progressPercent: number;
  quizAverage: number | null;
  accountNumber: string | null;
  accountStatus: string | null;
  modules: Array<{
    title: string;
    totalLessons: number;
    completedLessons: number;
    progressPercent: number;
  }>;
  recentActivity: Array<{ title: string; detail: string }>;
};
