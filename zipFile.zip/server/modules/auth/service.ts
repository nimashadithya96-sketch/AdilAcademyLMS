import crypto from "node:crypto";
import argon2 from "argon2";
import { and, eq, gt } from "drizzle-orm";
import { requireDatabase } from "../../../db/client";
import { sessions, users } from "../../../db/schema";
import type { DemoUser } from "../../../shared/platform";

const SESSION_LIFETIME_MS = 1000 * 60 * 60 * 24 * 7;

export type RegisterInput = {
  displayName: string;
  email: string;
  phone?: string;
  password: string;
};

export type LoginInput = {
  email: string;
  password: string;
};

function publicUser(user: typeof users.$inferSelect): DemoUser {
  return {
    id: user.id,
    name: user.displayName,
    email: user.email,
    role: user.role
  };
}

function hashSessionToken(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function registerStudent(input: RegisterInput) {
  const db = requireDatabase();
  const email = input.email.trim().toLowerCase();
  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, email))
    .limit(1);

  if (existing.length > 0) {
    throw new Error("EMAIL_ALREADY_EXISTS");
  }

  const passwordHash = await argon2.hash(input.password, {
    type: argon2.argon2id
  });

  const [created] = await db
    .insert(users)
    .values({
      email,
      passwordHash,
      displayName: input.displayName.trim(),
      phone: input.phone?.trim() || null,
      role: "student"
    })
    .returning();

  return createPersistentSession(created);
}

export async function loginUser(input: LoginInput) {
  const db = requireDatabase();
  const email = input.email.trim().toLowerCase();
  const [user] = await db
    .select()
    .from(users)
    .where(and(eq(users.email, email), eq(users.isActive, true)))
    .limit(1);

  if (!user || !(await argon2.verify(user.passwordHash, input.password))) {
    throw new Error("INVALID_CREDENTIALS");
  }

  return createPersistentSession(user);
}

async function createPersistentSession(user: typeof users.$inferSelect) {
  const db = requireDatabase();
  const token = crypto.randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_LIFETIME_MS);
  await db.insert(sessions).values({
    userId: user.id,
    tokenHash: hashSessionToken(token),
    expiresAt
  });

  return {
    token,
    expiresAt,
    user: publicUser(user)
  };
}

export async function getUserForSession(token: string) {
  const db = requireDatabase();
  const [result] = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(
      and(
        eq(sessions.tokenHash, hashSessionToken(token)),
        gt(sessions.expiresAt, new Date()),
        eq(users.isActive, true)
      )
    )
    .limit(1);

  return result ? publicUser(result.user) : null;
}

export async function deletePersistentSession(token: string) {
  const db = requireDatabase();
  await db
    .delete(sessions)
    .where(eq(sessions.tokenHash, hashSessionToken(token)));
}
