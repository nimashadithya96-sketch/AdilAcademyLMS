import crypto from "node:crypto";
import { and, count, desc, eq, inArray } from "drizzle-orm";
import { Router } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import {
  auditLogs,
  certificates,
  commissionCycles,
  consultantApplications,
  coupons,
  courseSections,
  courses,
  enrollments,
  lessonProgress,
  lessons,
  networkAccounts,
  notifications,
  paymentRequests,
  quizAttempts,
  quizzes,
  supportTickets,
  systemSettings,
  users
} from "../../../db/schema";
import {
  HttpError,
  requireAuthenticatedUser,
  requireRole
} from "../../lib/auth";
import { asyncRoute } from "../../lib/http";

export const platformRouter = Router();

const couponInput = z.object({
  code: z.string().trim().min(2).max(50),
  discountType: z.enum(["PERCENT", "FIXED"]),
  discountValue: z.coerce.number().positive(),
  courseId: z.string().uuid().optional(),
  startsAt: z.coerce.date().optional(),
  expiresAt: z.coerce.date().optional(),
  maxUses: z.coerce.number().int().positive().optional(),
  isActive: z.boolean().default(true)
});

const supportInput = z.object({
  subject: z.string().trim().min(3).max(180),
  message: z.string().trim().min(10).max(5000),
  priority: z.enum(["LOW", "NORMAL", "HIGH"]).default("NORMAL")
});

platformRouter.get(
  "/notifications",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, user.id))
      .orderBy(desc(notifications.createdAt))
      .limit(100);
    response.json({ notifications: items });
  })
);

platformRouter.post(
  "/support-tickets",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = supportInput.parse(request.body);
    const db = requireDatabase();
    const [ticket] = await db
      .insert(supportTickets)
      .values({ userId: user.id, ...input })
      .returning();
    response.status(201).json({ ticket });
  })
);

platformRouter.get(
  "/support-tickets/me",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const tickets = await db
      .select()
      .from(supportTickets)
      .where(eq(supportTickets.userId, user.id))
      .orderBy(desc(supportTickets.createdAt));
    response.json({ tickets });
  })
);

platformRouter.get(
  "/admin/support-tickets",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const tickets = await db
      .select()
      .from(supportTickets)
      .orderBy(desc(supportTickets.createdAt));
    response.json({ tickets });
  })
);

platformRouter.post(
  "/admin/support-tickets/:id/resolve",
  asyncRoute(async (request, response) => {
    const staff = await requireRole(request, ["staff", "admin"]);
    const input = z
      .object({ resolution: z.string().trim().min(3).max(5000) })
      .parse(request.body);
    const db = requireDatabase();
    const [ticket] = await db
      .update(supportTickets)
      .set({
        status: "RESOLVED",
        resolution: input.resolution,
        assignedTo: staff.id,
        updatedAt: new Date()
      })
      .where(eq(supportTickets.id, String(request.params.id)))
      .returning();
    if (!ticket) throw new HttpError(404, "Support ticket not found.");
    await db.insert(notifications).values({
      userId: ticket.userId,
      type: "SUPPORT_TICKET_RESOLVED",
      title: "Support ticket resolved",
      message: input.resolution
    });
    response.json({ ticket });
  })
);

platformRouter.get(
  "/admin/coupons",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const items = await db.select().from(coupons).orderBy(desc(coupons.createdAt));
    response.json({ coupons: items });
  })
);

platformRouter.post(
  "/admin/coupons",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = couponInput.parse(request.body);
    if (
      input.discountType === "PERCENT" &&
      input.discountValue > 100
    ) {
      throw new HttpError(400, "Percentage discount cannot exceed 100.");
    }
    if (
      input.startsAt &&
      input.expiresAt &&
      input.expiresAt <= input.startsAt
    ) {
      throw new HttpError(400, "Coupon date range is invalid.");
    }
    const db = requireDatabase();
    const [coupon] = await db
      .insert(coupons)
      .values({
        ...input,
        code: input.code.toUpperCase(),
        discountValue: input.discountValue.toFixed(2)
      })
      .returning();
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: "COUPON_CREATED",
      entityType: "coupon",
      entityId: coupon.id,
      metadata: { code: coupon.code }
    });
    response.status(201).json({ coupon });
  })
);

platformRouter.get(
  "/admin/settings",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const settings = await db.select().from(systemSettings);
    response.json({ settings });
  })
);

platformRouter.put(
  "/admin/settings/:key",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = z.object({ value: z.unknown() }).parse(request.body);
    const key = z
      .string()
      .regex(/^[A-Z0-9_]+$/)
      .max(80)
      .parse(String(request.params.key).toUpperCase());
    const db = requireDatabase();
    const [setting] = await db
      .insert(systemSettings)
      .values({
        key,
        value: input.value,
        updatedBy: admin.id,
        updatedAt: new Date()
      })
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: {
          value: input.value,
          updatedBy: admin.id,
          updatedAt: new Date()
        }
      })
      .returning();
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: "SYSTEM_SETTING_UPDATED",
      entityType: "system_setting",
      entityId: key
    });
    response.json({ setting });
  })
);

platformRouter.post(
  "/notifications/:id/read",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [updated] = await db
      .update(notifications)
      .set({ readAt: new Date() })
      .where(
        and(
          eq(notifications.id, String(request.params.id)),
          eq(notifications.userId, user.id)
        )
      )
      .returning();
    if (!updated) throw new HttpError(404, "Notification not found.");
    response.json({ notification: updated });
  })
);

platformRouter.get(
  "/student/certificates",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db
      .select({
        certificate: certificates,
        courseTitle: courses.title
      })
      .from(certificates)
      .innerJoin(courses, eq(certificates.courseId, courses.id))
      .where(eq(certificates.userId, user.id))
      .orderBy(desc(certificates.issuedAt));
    response.json({ certificates: items });
  })
);

platformRouter.post(
  "/student/certificates/issue",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = z
      .object({ courseId: z.string().uuid() })
      .parse(request.body);
    const db = requireDatabase();
    const [existing] = await db
      .select()
      .from(certificates)
      .where(
        and(
          eq(certificates.userId, user.id),
          eq(certificates.courseId, input.courseId)
        )
      )
      .limit(1);
    if (existing) {
      response.json({ certificate: existing });
      return;
    }
    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(
        and(
          eq(enrollments.userId, user.id),
          eq(enrollments.courseId, input.courseId),
          eq(enrollments.status, "ACTIVE")
        )
      )
      .limit(1);
    if (!enrollment) throw new HttpError(403, "Active enrollment required.");

    const sections = await db
      .select({ id: courseSections.id })
      .from(courseSections)
      .where(eq(courseSections.courseId, input.courseId));
    const sectionIds = sections.map((section) => section.id);
    const [{ totalLessons }] = sectionIds.length
      ? await db
          .select({ totalLessons: count() })
          .from(lessons)
          .where(inArray(lessons.sectionId, sectionIds))
      : [{ totalLessons: 0 }];
    const [{ completedLessons }] = await db
      .select({ completedLessons: count() })
      .from(lessonProgress)
      .where(
        and(
          eq(lessonProgress.enrollmentId, enrollment.id),
          eq(lessonProgress.progressPercent, 100)
        )
      );
    if (totalLessons < 1 || completedLessons < totalLessons) {
      throw new HttpError(409, "All course lessons must be completed.");
    }

    const publishedQuizzes = await db
      .select({ id: quizzes.id })
      .from(quizzes)
      .where(
        and(
          eq(quizzes.courseId, input.courseId),
          eq(quizzes.isPublished, true)
        )
      );
    if (publishedQuizzes.length) {
      const passed = await db
        .select({ quizId: quizAttempts.quizId })
        .from(quizAttempts)
        .where(
          and(
            eq(quizAttempts.userId, user.id),
            eq(quizAttempts.passed, true),
            inArray(
              quizAttempts.quizId,
              publishedQuizzes.map((quiz) => quiz.id)
            )
          )
        );
      const passedIds = new Set(passed.map((attempt) => attempt.quizId));
      if (passedIds.size < publishedQuizzes.length) {
        throw new HttpError(409, "All required quizzes must be passed.");
      }
    }

    const code =
      "ADIL-" +
      new Date().getUTCFullYear() +
      "-" +
      crypto.randomBytes(5).toString("hex").toUpperCase();
    const [created] = await db
      .insert(certificates)
      .values({
        certificateCode: code,
        userId: user.id,
        courseId: input.courseId
      })
      .returning();
    await db
      .update(enrollments)
      .set({ completedAt: new Date(), status: "COMPLETED" })
      .where(eq(enrollments.id, enrollment.id));
    response.status(201).json({ certificate: created });
  })
);

platformRouter.get(
  "/certificates/:code/verify",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [item] = await db
      .select({
        code: certificates.certificateCode,
        issuedAt: certificates.issuedAt,
        revokedAt: certificates.revokedAt,
        studentName: users.displayName,
        courseTitle: courses.title
      })
      .from(certificates)
      .innerJoin(users, eq(certificates.userId, users.id))
      .innerJoin(courses, eq(certificates.courseId, courses.id))
      .where(
        eq(
          certificates.certificateCode,
          String(request.params.code).toUpperCase()
        )
      )
      .limit(1);
    if (!item) throw new HttpError(404, "Certificate not found.");
    response.json({ certificate: item, valid: !item.revokedAt });
  })
);

platformRouter.get(
  "/admin/overview",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const [
      [{ students }],
      [{ consultants }],
      [{ pendingPayments }],
      [{ pendingApplications }],
      [{ activeAccounts }],
      [{ commissionCycleCount }]
    ] = await Promise.all([
      db.select({ students: count() }).from(users).where(eq(users.role, "student")),
      db
        .select({ consultants: count() })
        .from(users)
        .where(eq(users.role, "consultant")),
      db
        .select({ pendingPayments: count() })
        .from(paymentRequests)
        .where(
          inArray(paymentRequests.status, [
            "PENDING",
            "UNDER_REVIEW",
            "PARTIAL"
          ])
        ),
      db
        .select({ pendingApplications: count() })
        .from(consultantApplications)
        .where(
          inArray(consultantApplications.status, ["PENDING", "INTERVIEW"])
        ),
      db
        .select({ activeAccounts: count() })
        .from(networkAccounts)
        .where(eq(networkAccounts.status, "ACTIVE")),
      db.select({ commissionCycleCount: count() }).from(commissionCycles)
    ]);
    response.json({
      students,
      consultants,
      pendingPayments,
      pendingApplications,
      activeAccounts,
      commissionCycleCount
    });
  })
);

platformRouter.get(
  "/admin/audit-logs",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const logs = await db
      .select()
      .from(auditLogs)
      .orderBy(desc(auditLogs.createdAt))
      .limit(250);
    response.json({ logs });
  })
);
