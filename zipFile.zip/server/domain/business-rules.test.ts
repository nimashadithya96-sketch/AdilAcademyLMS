import { describe, expect, it } from "vitest";
import {
  convertStudentToConsultant,
  formatAccountNumber,
  unlocksCourseAndPoints
} from "./business-rules";

describe("Adil Academy business rules", () => {
  it("formats sequential SR and CN account numbers", () => {
    expect(formatAccountNumber("SR", 527694)).toBe("SR527694");
    expect(formatAccountNumber("CN", 527695)).toBe("CN527695");
  });

  it("preserves the numeric part when a student becomes a consultant", () => {
    expect(convertStudentToConsultant("SR527694")).toBe("CN527694");
  });

  it("unlocks access and points only after full approved payment", () => {
    expect(unlocksCourseAndPoints("APPROVED", 50000, 50000)).toBe(true);
    expect(unlocksCourseAndPoints("PARTIAL", 25000, 50000)).toBe(false);
    expect(unlocksCourseAndPoints("APPROVED", 25000, 50000)).toBe(false);
  });
});
