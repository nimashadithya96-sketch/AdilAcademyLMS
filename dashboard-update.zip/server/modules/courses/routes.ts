import { and, asc, eq, inArray } from "drizzle-orm";
import { Router } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import {
  courseSections,
  courses,
  enrollments,
  lessonProgress,
  lessons,
  networkAccounts,
  quizAttempts,
  quizQuestions,
  quizzes
} from "../../../db/schema";
import { requireAuthenticatedUser, requireRole } from "../../lib/auth";
import { asyncRoute } from "../../lib/http";

export const courseRouter = Router();

const courseInput = z.object({
  slug: z.string().trim().min(3).max(120).regex(/^[a-z0-9-]+$/),
  title: z.string().trim().min(3).max(180),
  shortDescription: z.string().trim().min(10).max(400),
  description: z.string().trim().max(10000).optional(),
  price: z.coerce.number().positive(),
  points: z.coerce.number().int().min(0).default(0),
  currency: z.string().trim().length(3).default("LKR"),
  isPublished: z.boolean().default(false)
});

const sectionInput = z.object({
  courseId: z.string().uuid(),
  title: z.string().trim().min(2).max(180),
  position: z.coerce.number().int().min(1)
});

const lessonInput = z.object({
  sectionId: z.string().uuid(),
  title: z.string().trim().min(2).max(180),
  content: z.string().trim().max(30000).optional(),
  videoProvider: z.enum(["youtube", "vimeo"]).optional(),
  videoId: z.string().trim().max(200).optional(),
  durationSeconds: z.coerce.number().int().min(0).default(0),
  position: z.coerce.number().int().min(1),
  isPreview: z.boolean().default(false)
});

const progressInput = z.object({
  enrollmentId: z.string().uuid(),
  lessonId: z.string().uuid(),
  progressPercent: z.coerce.number().int().min(0).max(100)
});
const quizInput = z.object({
  courseId: z.string().uuid(),
  title: z.string().trim().min(3).max(180),
  passingPercent: z.coerce.number().int().min(1).max(100).default(70),
  position: z.coerce.number().int().min(1),
  isPublished: z.boolean().default(false)
});
const questionInput = z.object({
  quizId: z.string().uuid(),
  question: z.string().trim().min(3).max(2000),
  options: z.array(z.string().trim().min(1).max(1000)).min(2).max(8),
  correctOption: z.coerce.number().int().min(0),
  explanation: z.string().trim().max(3000).optional(),
  position: z.coerce.number().int().min(1)
});
const attemptInput = z.object({
  answers: z.array(z.coerce.number().int().min(0)).max(200)
});

courseRouter.get(
  "/courses",
  asyncRoute(async (_request, response) => {
    const db = requireDatabase();
    const items = await db
      .select({
        id: courses.id,
        slug: courses.slug,
        title: courses.title,
        shortDescription: courses.shortDescription,
        price: courses.price,
        currency: courses.currency,
        language: courses.language,
        thumbnailUrl: courses.thumbnailUrl
      })
      .from(courses)
      .where(eq(courses.isPublished, true))
      .orderBy(asc(courses.createdAt));
    response.json({ courses: items });
  })
);

courseRouter.get(
  "/courses/:slug",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [course] = await db
      .select()
      .from(courses)
      .where(
        and(
          eq(courses.slug, String(request.params.slug)),
          eq(courses.isPublished, true)
        )
      )
      .limit(1);
    if (!course) {
      response.status(404).json({ message: "Course not found." });
      return;
    }

    const sections = await db
      .select()
      .from(courseSections)
      .where(eq(courseSections.courseId, course.id))
      .orderBy(asc(courseSections.position));
    const sectionIds = new Set(sections.map((section) => section.id));
    const allLessons = sectionIds.size
      ? await db
          .select({
            id: lessons.id,
            sectionId: lessons.sectionId,
            title: lessons.title,
            durationSeconds: lessons.durationSeconds,
            position: lessons.position,
            isPreview: lessons.isPreview
          })
          .from(lessons)
          .where(inArray(lessons.sectionId, [...sectionIds]))
          .orderBy(asc(lessons.position))
      : [];

    response.json({
      course,
      sections: sections.map((section) => ({
        ...section,
        lessons: allLessons.filter(
          (lesson) => lesson.sectionId === section.id
        )
      }))
    });
  })
);

courseRouter.get(
  "/student/enrollments",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db
      .select({
        enrollmentId: enrollments.id,
        status: enrollments.status,
        enrolledAt: enrollments.enrolledAt,
        completedAt: enrollments.completedAt,
        courseId: courses.id,
        slug: courses.slug,
        title: courses.title,
        shortDescription: courses.shortDescription,
        thumbnailUrl: courses.thumbnailUrl
      })
      .from(enrollments)
      .innerJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.userId, user.id))
      .orderBy(asc(enrollments.enrolledAt));
    response.json({ enrollments: items });
  })
);

courseRouter.get(
  "/student/dashboard-summary",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [account] = await db.select().from(networkAccounts).where(
      and(
        eq(networkAccounts.ownerUserId, user.id),
        eq(networkAccounts.isMainAccount, true)
      )
    ).limit(1);
    const [enrollment] = await db.select({
      id: enrollments.id,
      status: enrollments.status,
      courseId: enrollments.courseId,
      courseTitle: courses.title
    }).from(enrollments)
      .innerJoin(courses, eq(enrollments.courseId, courses.id))
      .where(eq(enrollments.userId, user.id))
      .orderBy(asc(enrollments.enrolledAt)).limit(1);

    if (!enrollment) {
      response.json({
        enrollmentStatus: "NOT_ENROLLED",
        courseTitle: null,
        totalLessons: 0,
        completedLessons: 0,
        progressPercent: 0,
        quizAverage: null,
        accountNumber: account ? `${account.prefix}${account.numericPart}` : null,
        accountStatus: account?.status ?? null,
        recentActivity: []
      });
      return;
    }

    const sections = await db.select({ id: courseSections.id })
      .from(courseSections).where(eq(courseSections.courseId, enrollment.courseId));
    const sectionIds = sections.map((item) => item.id);
    const courseLessons = sectionIds.length
      ? await db.select({ id: lessons.id, title: lessons.title }).from(lessons)
          .where(inArray(lessons.sectionId, sectionIds))
      : [];
    const progress = await db.select().from(lessonProgress)
      .where(eq(lessonProgress.enrollmentId, enrollment.id))
      .orderBy(asc(lessonProgress.updatedAt));
    const completed = progress.filter((item) => item.progressPercent === 100);
    const attempts = await db.select({ score: quizAttempts.scorePercent })
      .from(quizAttempts).innerJoin(quizzes, eq(quizAttempts.quizId, quizzes.id))
      .where(and(eq(quizAttempts.userId, user.id), eq(quizzes.courseId, enrollment.courseId)));
    const quizAverage = attempts.length
      ? Math.round(attempts.reduce((sum, item) => sum + item.score, 0) / attempts.length)
      : null;
    const lessonTitles = new Map(courseLessons.map((item) => [item.id, item.title]));
    const recentActivity = [...progress].reverse().slice(0, 3).map((item) => ({
      title: lessonTitles.get(item.lessonId) ?? "Course lesson",
      detail: item.progressPercent === 100 ? "Completed" : `${item.progressPercent}% watched`
    }));

    response.json({
      enrollmentStatus: enrollment.status,
      courseTitle: enrollment.courseTitle,
      totalLessons: courseLessons.length,
      completedLessons: completed.length,
      progressPercent: courseLessons.length
        ? Math.round((completed.length / courseLessons.length) * 100)
        : 0,
      quizAverage,
      accountNumber: account ? `${account.prefix}${account.numericPart}` : null,
      accountStatus: account?.status ?? null,
      recentActivity
    });
  })
);

courseRouter.post(
  "/student/progress",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = progressInput.parse(request.body);
    const db = requireDatabase();

    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(
        and(
          eq(enrollments.id, input.enrollmentId),
          eq(enrollments.userId, user.id),
          eq(enrollments.status, "ACTIVE")
        )
      )
      .limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }

    const [lesson] = await db
      .select({ courseId: courseSections.courseId })
      .from(lessons)
      .innerJoin(
        courseSections,
        eq(lessons.sectionId, courseSections.id)
      )
      .where(eq(lessons.id, input.lessonId))
      .limit(1);
    if (!lesson || lesson.courseId !== enrollment.courseId) {
      response.status(400).json({ message: "Lesson is not in this course." });
      return;
    }

    const [saved] = await db
      .insert(lessonProgress)
      .values({
        enrollmentId: input.enrollmentId,
        lessonId: input.lessonId,
        progressPercent: input.progressPercent,
        completedAt: input.progressPercent === 100 ? new Date() : null,
        updatedAt: new Date()
      })
      .onConflictDoUpdate({
        target: [lessonProgress.enrollmentId, lessonProgress.lessonId],
        set: {
          progressPercent: input.progressPercent,
          completedAt: input.progressPercent === 100 ? new Date() : null,
          updatedAt: new Date()
        }
      })
      .returning();
    response.json({ progress: saved });
  })
);

courseRouter.get(
  "/student/quizzes/:id",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [quiz] = await db
      .select()
      .from(quizzes)
      .where(
        and(
          eq(quizzes.id, String(request.params.id)),
          eq(quizzes.isPublished, true)
        )
      )
      .limit(1);
    if (!quiz) {
      response.status(404).json({ message: "Quiz not found." });
      return;
    }
    const [enrollment] = await db
      .select({ id: enrollments.id })
      .from(enrollments)
      .where(
        and(
          eq(enrollments.userId, user.id),
          eq(enrollments.courseId, quiz.courseId),
          eq(enrollments.status, "ACTIVE")
        )
      )
      .limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }
    const questions = await db
      .select({
        id: quizQuestions.id,
        question: quizQuestions.question,
        options: quizQuestions.options,
        position: quizQuestions.position
      })
      .from(quizQuestions)
      .where(eq(quizQuestions.quizId, quiz.id))
      .orderBy(asc(quizQuestions.position));
    response.json({ quiz, questions });
  })
);

courseRouter.post(
  "/student/quizzes/:id/attempts",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = attemptInput.parse(request.body);
    const db = requireDatabase();
    const [quiz] = await db
      .select()
      .from(quizzes)
      .where(
        and(
          eq(quizzes.id, String(request.params.id)),
          eq(quizzes.isPublished, true)
        )
      )
      .limit(1);
    if (!quiz) {
      response.status(404).json({ message: "Quiz not found." });
      return;
    }
    const [enrollment] = await db
      .select({ id: enrollments.id })
      .from(enrollments)
      .where(
        and(
          eq(enrollments.userId, user.id),
          eq(enrollments.courseId, quiz.courseId),
          eq(enrollments.status, "ACTIVE")
        )
      )
      .limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }
    const questions = await db
      .select()
      .from(quizQuestions)
      .where(eq(quizQuestions.quizId, quiz.id))
      .orderBy(asc(quizQuestions.position));
    if (questions.length === 0 || input.answers.length !== questions.length) {
      response.status(400).json({ message: "Answer every quiz question." });
      return;
    }
    const correct = questions.reduce(
      (total, question, index) =>
        total + (input.answers[index] === question.correctOption ? 1 : 0),
      0
    );
    const scorePercent = Math.round((correct / questions.length) * 100);
    const passed = scorePercent >= quiz.passingPercent;
    const [attempt] = await db
      .insert(quizAttempts)
      .values({
        quizId: quiz.id,
        userId: user.id,
        answers: input.answers,
        scorePercent,
        passed
      })
      .returning();
    response.status(201).json({
      attempt,
      explanations: questions.map((question) => ({
        questionId: question.id,
        correctOption: question.correctOption,
        explanation: question.explanation
      }))
    });
  })
);

courseRouter.post(
  "/admin/quizzes",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = quizInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(quizzes).values(input).returning();
    response.status(201).json({ quiz: created });
  })
);

courseRouter.post(
  "/admin/quiz-questions",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = questionInput.parse(request.body);
    if (input.correctOption >= input.options.length) {
      response.status(400).json({ message: "Correct option is out of range." });
      return;
    }
    const db = requireDatabase();
    const [created] = await db
      .insert(quizQuestions)
      .values(input)
      .returning();
    response.status(201).json({ question: created });
  })
);

courseRouter.post(
  "/admin/courses",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = courseInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db
      .insert(courses)
      .values({
        ...input,
        price: input.price.toFixed(2)
      })
      .returning();
    response.status(201).json({ course: created });
  })
);

courseRouter.post(
  "/admin/course-sections",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = sectionInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db
      .insert(courseSections)
      .values(input)
      .returning();
    response.status(201).json({ section: created });
  })
);

courseRouter.post(
  "/admin/lessons",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = lessonInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(lessons).values(input).returning();
    response.status(201).json({ lesson: created });
  })
);
