import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { z } from "zod";
import type { DemoUser, PlatformOverview, UserRole } from "../shared/platform";
import {
  deletePersistentSession,
  getUserForSession,
  loginUser,
  registerStudent
} from "./modules/auth/service";
import { apiErrorHandler } from "./lib/http";
import { courseRouter } from "./modules/courses/routes";
import { paymentRouter } from "./modules/payments/routes";
import { consultantRouter } from "./modules/consultants/routes";
import { commissionRouter } from "./modules/commissions/routes";
import { platformRouter } from "./modules/platform/routes";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT ?? 3000);
const isProduction = process.env.NODE_ENV === "production";
// Demo access is opt-in in every environment. Never grant passwordless role
// access merely because the server is running in development mode.
const demoLoginEnabled = process.env.ENABLE_DEMO_LOGIN === "true";

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));

const overview: PlatformOverview = {
  course: {
    title: "Crypto Trading — Zero to Pro",
    language: "සිංහල",
    modules: 6,
    access: "Lifetime course access"
  },
  features: [
    "Spot & Futures Trading",
    "Technical Analysis",
    "Risk Management",
    "Progress Tracking",
    "Consultant Network",
    "Weekly Commission Reports"
  ],
  paymentMethods: ["Bank Transfer", "Binance Pay / USDT"]
};

const demoUsers: Record<UserRole, DemoUser> = {
  student: {
    id: "demo-student",
    name: "Nimal Perera",
    email: "student@adilacademy.demo",
    role: "student",
    accountNumber: "SR527694"
  },
  consultant: {
    id: "demo-consultant",
    name: "Kasun Silva",
    email: "consultant@adilacademy.demo",
    role: "consultant",
    accountNumber: "CN527695"
  },
  staff: {
    id: "demo-staff",
    name: "Academy Staff",
    email: "staff@adilacademy.demo",
    role: "staff"
  },
  admin: {
    id: "demo-admin",
    name: "Super Admin",
    email: "admin@adilacademy.demo",
    role: "admin"
  }
};

const demoSessions = new Map<string, DemoUser>();
const demoLoginSchema = z.object({
  role: z.enum(["student", "consultant", "staff", "admin"])
});
const registerSchema = z.object({
  displayName: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(200),
  phone: z.string().trim().min(7).max(30).optional(),
  password: z
    .string()
    .min(8)
    .max(128)
    .regex(/[A-Z]/, "Password needs an uppercase letter.")
    .regex(/[a-z]/, "Password needs a lowercase letter.")
    .regex(/[0-9]/, "Password needs a number.")
});
const loginSchema = z.object({
  email: z.string().trim().email().max(200),
  password: z.string().min(1).max(128)
});

function authCookieOptions(expiresAt?: Date) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: isProduction,
    ...(expiresAt
      ? { expires: expiresAt }
      : { maxAge: 1000 * 60 * 60 * 8 })
  };
}

function readCookie(cookieHeader: string | undefined, name: string) {
  if (!cookieHeader) return undefined;
  for (const part of cookieHeader.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === name) return decodeURIComponent(value.join("="));
  }
  return undefined;
}

app.get("/api/health", (_request, response) => {
  response.json({
    status: "ok",
    service: "adil-academy-lms",
    environment: process.env.NODE_ENV ?? "development",
    databaseConfigured: Boolean(process.env.DATABASE_URL)
  });
});

app.get("/api/public/overview", (_request, response) => {
  response.json(overview);
});

app.post("/api/auth/demo-login", (request, response) => {
  if (!demoLoginEnabled) {
    response.status(404).json({ message: "Demo login is disabled." });
    return;
  }

  const parsed = demoLoginSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ message: "Invalid role." });
    return;
  }

  const token = crypto.randomBytes(32).toString("hex");
  const user = demoUsers[parsed.data.role];
  demoSessions.set(token, user);

  response.cookie("adil_session", token, authCookieOptions());
  response.json({ user });
});

app.post("/api/auth/register", async (request, response) => {
  const parsed = registerSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({
      message: "Registration details are invalid.",
      issues: parsed.error.issues.map((issue) => issue.message)
    });
    return;
  }

  try {
    const session = await registerStudent(parsed.data);
    response.cookie(
      "adil_session",
      session.token,
      authCookieOptions(session.expiresAt)
    );
    response.status(201).json({ user: session.user });
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    if (code === "EMAIL_ALREADY_EXISTS") {
      response.status(409).json({ message: "Email already registered." });
      return;
    }
    if (code === "DATABASE_NOT_CONFIGURED") {
      response.status(503).json({
        message: "Database is not configured. Add Replit PostgreSQL first."
      });
      return;
    }
    console.error("Registration failed", error);
    response.status(500).json({ message: "Registration failed." });
  }
});

app.post("/api/auth/login", async (request, response) => {
  const parsed = loginSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ message: "Invalid email or password." });
    return;
  }

  try {
    const session = await loginUser(parsed.data);
    response.cookie(
      "adil_session",
      session.token,
      authCookieOptions(session.expiresAt)
    );
    response.json({ user: session.user });
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    if (code === "INVALID_CREDENTIALS") {
      response.status(401).json({ message: "Invalid email or password." });
      return;
    }
    if (code === "DATABASE_NOT_CONFIGURED") {
      response.status(503).json({
        message: "Database is not configured. Use platform preview for now."
      });
      return;
    }
    console.error("Login failed", error);
    response.status(500).json({ message: "Login failed." });
  }
});

app.get("/api/auth/me", async (request, response) => {
  const token = readCookie(request.headers.cookie, "adil_session");
  const demoUser = token ? demoSessions.get(token) : undefined;

  if (demoUser) {
    response.json({ user: demoUser });
    return;
  }

  if (!token) {
    response.status(401).json({ message: "Not authenticated." });
    return;
  }

  try {
    const user = await getUserForSession(token);
    if (!user) {
      response.status(401).json({ message: "Not authenticated." });
      return;
    }
    response.json({ user });
  } catch (error) {
    if (error instanceof Error && error.message === "DATABASE_NOT_CONFIGURED") {
      response.status(401).json({ message: "Not authenticated." });
      return;
    }
    console.error("Session lookup failed", error);
    response.status(500).json({ message: "Session lookup failed." });
  }
});

app.post("/api/auth/logout", async (request, response) => {
  const token = readCookie(request.headers.cookie, "adil_session");
  if (token) {
    if (demoSessions.has(token)) {
      demoSessions.delete(token);
    } else {
      try {
        await deletePersistentSession(token);
      } catch (error) {
        if (
          !(error instanceof Error) ||
          error.message !== "DATABASE_NOT_CONFIGURED"
        ) {
          console.error("Session deletion failed", error);
        }
      }
    }
  }
  response.clearCookie("adil_session");
  response.status(204).end();
});

app.use("/api", courseRouter);
app.use("/api", paymentRouter);
app.use("/api", consultantRouter);
app.use("/api", commissionRouter);
app.use("/api", platformRouter);
app.use("/api", apiErrorHandler);

async function attachFrontend() {
  if (!isProduction && process.env.SERVE_STATIC !== "true") {
    const { createServer } = await import("vite");
    const vite = await createServer({
      root: path.resolve(process.cwd(), "client"),
      server: { middlewareMode: true, allowedHosts: true, hmr: false },
      appType: "spa"
    });
    app.use(vite.middlewares);
    return;
  }

  const distPath = path.resolve(__dirname, "../dist");
  app.use(express.static(distPath));
  app.use((_request, response) => {
    response.sendFile(path.join(distPath, "index.html"));
  });
}

await attachFrontend();

app.listen(port, "0.0.0.0", () => {
  console.log("Adil Academy LMS running on port " + port);
});
