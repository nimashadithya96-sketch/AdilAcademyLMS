import nodemailer from "nodemailer";

const senderEmail = process.env.EMAIL_FROM?.trim() || "adilacademy65@gmail.com";

export function emailConfigured() {
  return Boolean(process.env.EMAIL_APP_PASSWORD);
}

export async function sendVerificationCode(email: string, code: string) {
  const password = process.env.EMAIL_APP_PASSWORD;
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: senderEmail, pass: password }
  });

  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Adil Academy email verification code",
    text: `Your Adil Academy verification code is ${code}. It expires in 10 minutes. Do not share this code.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:28px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY</p><h2>Email verification</h2><p>ඔබගේ payment එක approve කර ඇත. Account එක activate කිරීමට පහත OTP code එක භාවිත කරන්න.</p><div style="font-size:34px;font-weight:800;letter-spacing:8px;margin:24px 0;color:#7cff4f">${code}</div><p style="color:#9aa59f">මෙම code එක විනාඩි 10කින් expire වේ. වෙනත් කෙනෙකුට ලබා නොදෙන්න.</p></div>`
  });
}

export async function sendApplicationReceived(email: string, name: string, paymentCode: string) {
  const password = process.env.EMAIL_APP_PASSWORD;
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: senderEmail, pass: password }
  });
  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Adil Academy application received",
    text: `Hello ${name}, we received your details and payment proof (${paymentCode}). We will review them. If the details are correct, an OTP code will be sent to this email within 24 hours.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:30px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY</p><h2>ඔබගේ details ලැබී ඇත</h2><p>ආයුබෝවන් ${name},</p><p>ඔබ submit කළ details සහ payment proof එක අපට ලැබී ඇත. ඒවා දැන් පරීක්ෂා කරනු ලැබේ.</p><div style="margin:22px 0;padding:16px;border:1px solid #254331;border-radius:10px"><strong>Payment ID:</strong> ${paymentCode}</div><p>ඔබගේ details නිවැරදි නම් <strong>පැය 24ක් ඇතුළත</strong> මෙම email ලිපිනයට OTP code එකක් එවනු ලැබේ.</p><p style="color:#9aa59f">OTP code එක ලැබෙන තුරු නැවත application එකක් submit කිරීම අවශ්‍ය නැත.</p></div>`
  });
}
