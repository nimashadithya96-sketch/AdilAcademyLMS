export type PaymentStatus =
  | "PENDING"
  | "UNDER_REVIEW"
  | "PARTIAL"
  | "APPROVED"
  | "REJECTED"
  | "REFUNDED";

export function formatAccountNumber(
  prefix: "SR" | "CN",
  numericPart: number
): string {
  if (!Number.isInteger(numericPart) || numericPart < 1) {
    throw new Error("Account number must be a positive integer.");
  }
  return prefix + numericPart;
}

export function convertStudentToConsultant(accountNumber: string): string {
  if (!/^SR\d+$/.test(accountNumber)) {
    throw new Error("Only an SR account can be converted.");
  }
  return "CN" + accountNumber.slice(2);
}

export function unlocksCourseAndPoints(
  status: PaymentStatus,
  paidAmount: number,
  totalAmount: number
): boolean {
  return status === "APPROVED" && paidAmount >= totalAmount && totalAmount > 0;
}
