var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import crypto9 from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express5 from "express";
import { z as z8 } from "zod";
import { and as and9, desc as desc9, eq as eq11, gt as gt6, isNull as isNull6 } from "drizzle-orm";

// db/client.ts
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";

// db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  accountNumberSequence: () => accountNumberSequence,
  accountPointBalances: () => accountPointBalances,
  accountSideEnum: () => accountSideEnum,
  accountStatusEnum: () => accountStatusEnum,
  accountTypeEnum: () => accountTypeEnum,
  applicationStatusEnum: () => applicationStatusEnum,
  auditLogs: () => auditLogs,
  balancePaymentRequests: () => balancePaymentRequests,
  ccoActivationRequests: () => ccoActivationRequests,
  ccoMainApplications: () => ccoMainApplications,
  ccoMainPayIds: () => ccoMainPayIds,
  certificates: () => certificates,
  commissionCycles: () => commissionCycles,
  commissionEntries: () => commissionEntries,
  consultantAdmissionTargets: () => consultantAdmissionTargets,
  consultantApplications: () => consultantApplications,
  consultantBankDetails: () => consultantBankDetails,
  consultantStudentRegistrations: () => consultantStudentRegistrations,
  couponUses: () => couponUses,
  coupons: () => coupons,
  courseSections: () => courseSections,
  courses: () => courses,
  discountTypeEnum: () => discountTypeEnum,
  emailVerificationCodes: () => emailVerificationCodes,
  enrollments: () => enrollments,
  inactivityResets: () => inactivityResets,
  lessonProgress: () => lessonProgress,
  lessons: () => lessons,
  networkAccounts: () => networkAccounts,
  networkPlacements: () => networkPlacements,
  notifications: () => notifications,
  paymentReferenceIds: () => paymentReferenceIds,
  paymentRequests: () => paymentRequests,
  paymentStatusEnum: () => paymentStatusEnum,
  payoutRequests: () => payoutRequests,
  payoutStatusEnum: () => payoutStatusEnum,
  pointEvents: () => pointEvents,
  quizAttempts: () => quizAttempts,
  quizQuestions: () => quizQuestions,
  quizzes: () => quizzes,
  roleEnum: () => roleEnum,
  sessions: () => sessions,
  supportAgentPresence: () => supportAgentPresence,
  supportConversations: () => supportConversations,
  supportMessages: () => supportMessages,
  supportTickets: () => supportTickets,
  systemSettings: () => systemSettings,
  users: () => users,
  walletLedger: () => walletLedger,
  wallets: () => wallets
});
import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid
} from "drizzle-orm/pg-core";
var roleEnum = pgEnum("user_role", [
  "student",
  "consultant",
  "staff",
  "admin"
]);
var accountTypeEnum = pgEnum("account_type", ["SR", "CN"]);
var accountSideEnum = pgEnum("account_side", ["LEFT", "RIGHT"]);
var accountStatusEnum = pgEnum("account_status", [
  "RESERVED",
  "ACTIVE",
  "SUSPENDED"
]);
var paymentStatusEnum = pgEnum("payment_status", [
  "PENDING",
  "UNDER_REVIEW",
  "PARTIAL",
  "APPROVED",
  "REJECTED",
  "REFUNDED"
]);
var applicationStatusEnum = pgEnum("application_status", [
  "PENDING",
  "INTERVIEW",
  "APPROVED",
  "REJECTED"
]);
var payoutStatusEnum = pgEnum("payout_status", [
  "PENDING",
  "APPROVED",
  "PAID",
  "REJECTED"
]);
var discountTypeEnum = pgEnum("discount_type", [
  "PERCENT",
  "FIXED"
]);
var users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    displayName: text("display_name").notNull(),
    phone: text("phone"),
    nicOrPassport: text("nic_or_passport"),
    address: text("address"),
    dateOfBirth: text("date_of_birth"),
    role: roleEnum("role").default("student").notNull(),
    isActive: boolean("is_active").default(false).notNull(),
    learningPortalEnabled: boolean("learning_portal_enabled").default(true).notNull(),
    emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
    passwordSetAt: timestamp("password_set_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    profilePhotoObjectKey: text("profile_photo_object_key"),
    profilePhotoMimeType: text("profile_photo_mime_type"),
    removedAt: timestamp("removed_at", { withTimezone: true }),
    removalReason: text("removal_reason")
  },
  (table) => [uniqueIndex("users_email_unique").on(table.email)]
);
var consultantAdmissionTargets = pgTable("consultant_admission_targets", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  dailyTarget: integer("daily_target").default(0).notNull(),
  weeklyTarget: integer("weekly_target").default(0).notNull(),
  monthlyTarget: integer("monthly_target").default(0).notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
});
var sessions = pgTable(
  "sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [uniqueIndex("sessions_token_hash_unique").on(table.tokenHash)]
);
var courses = pgTable(
  "courses",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    shortDescription: text("short_description").notNull(),
    description: text("description"),
    price: numeric("price", { precision: 12, scale: 2 }).notNull(),
    points: integer("points").default(0).notNull(),
    halfPaymentLessonLimit: integer("half_payment_lesson_limit").default(7).notNull(),
    currency: text("currency").default("LKR").notNull(),
    language: text("language").default("si-LK").notNull(),
    thumbnailUrl: text("thumbnail_url"),
    isPublished: boolean("is_published").default(false).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [uniqueIndex("courses_slug_unique").on(table.slug)]
);
var courseSections = pgTable("course_sections", {
  id: uuid("id").defaultRandom().primaryKey(),
  courseId: uuid("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  position: integer("position").notNull()
});
var lessons = pgTable("lessons", {
  id: uuid("id").defaultRandom().primaryKey(),
  sectionId: uuid("section_id").notNull().references(() => courseSections.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  videoProvider: text("video_provider"),
  videoId: text("video_id"),
  content: text("content"),
  resourceObjectKey: text("resource_object_key"),
  durationSeconds: integer("duration_seconds").default(0).notNull(),
  position: integer("position").notNull(),
  isPreview: boolean("is_preview").default(false).notNull()
});
var enrollments = pgTable(
  "enrollments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id),
    courseId: uuid("course_id").notNull().references(() => courses.id),
    status: text("status").default("ACTIVE").notNull(),
    enrolledAt: timestamp("enrolled_at", { withTimezone: true }).defaultNow().notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true })
  },
  (table) => [
    uniqueIndex("enrollments_user_course_unique").on(
      table.userId,
      table.courseId
    )
  ]
);
var lessonProgress = pgTable(
  "lesson_progress",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    enrollmentId: uuid("enrollment_id").notNull().references(() => enrollments.id, { onDelete: "cascade" }),
    lessonId: uuid("lesson_id").notNull().references(() => lessons.id, { onDelete: "cascade" }),
    progressPercent: integer("progress_percent").default(0).notNull(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("lesson_progress_unique").on(
      table.enrollmentId,
      table.lessonId
    )
  ]
);
var quizzes = pgTable("quizzes", {
  id: uuid("id").defaultRandom().primaryKey(),
  courseId: uuid("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  passingPercent: integer("passing_percent").default(70).notNull(),
  position: integer("position").notNull(),
  isPublished: boolean("is_published").default(false).notNull()
});
var quizQuestions = pgTable("quiz_questions", {
  id: uuid("id").defaultRandom().primaryKey(),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id, { onDelete: "cascade" }),
  question: text("question").notNull(),
  options: jsonb("options").notNull(),
  correctOption: integer("correct_option").notNull(),
  explanation: text("explanation"),
  position: integer("position").notNull()
});
var quizAttempts = pgTable("quiz_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  quizId: uuid("quiz_id").notNull().references(() => quizzes.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => users.id),
  answers: jsonb("answers").notNull(),
  scorePercent: integer("score_percent").notNull(),
  passed: boolean("passed").notNull(),
  submittedAt: timestamp("submitted_at", { withTimezone: true }).defaultNow().notNull()
});
var certificates = pgTable(
  "certificates",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    certificateCode: text("certificate_code").notNull(),
    userId: uuid("user_id").notNull().references(() => users.id),
    courseId: uuid("course_id").notNull().references(() => courses.id),
    objectKey: text("object_key"),
    issuedAt: timestamp("issued_at", { withTimezone: true }).defaultNow().notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true })
  },
  (table) => [
    uniqueIndex("certificates_code_unique").on(table.certificateCode),
    uniqueIndex("certificates_user_course_unique").on(
      table.userId,
      table.courseId
    )
  ]
);
var coupons = pgTable(
  "coupons",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    code: text("code").notNull(),
    discountType: discountTypeEnum("discount_type").notNull(),
    discountValue: numeric("discount_value", {
      precision: 12,
      scale: 2
    }).notNull(),
    courseId: uuid("course_id").references(() => courses.id),
    startsAt: timestamp("starts_at", { withTimezone: true }),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    maxUses: integer("max_uses"),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [uniqueIndex("coupons_code_unique").on(table.code)]
);
var paymentReferenceIds = pgTable(
  "payment_reference_ids",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    code: text("code").notNull(),
    email: text("email").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [uniqueIndex("payment_reference_ids_code_unique").on(table.code)]
);
var ccoMainPayIds = pgTable("cco_main_pay_ids", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull(),
  intendedName: text("intended_name").notNull(),
  intendedEmail: text("intended_email").notNull(),
  intendedPhone: text("intended_phone").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).default("5000").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  claimedAt: timestamp("claimed_at", { withTimezone: true }),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  createdBy: uuid("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [
  uniqueIndex("cco_main_pay_ids_code_unique").on(table.code)
]);
var ccoMainApplications = pgTable("cco_main_applications", {
  id: uuid("id").defaultRandom().primaryKey(),
  payIdId: uuid("pay_id_id").notNull().references(() => ccoMainPayIds.id),
  userId: uuid("user_id").notNull().references(() => users.id),
  accountId: uuid("account_id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  nicOrPassport: text("nic_or_passport").notNull(),
  addressLine1: text("address_line_1").notNull(),
  addressLine2: text("address_line_2"),
  province: text("province").notNull(),
  district: text("district").notNull(),
  city: text("city").notNull(),
  transactionReference: text("transaction_reference").notNull(),
  proofObjectKey: text("proof_object_key"),
  proofMimeType: text("proof_mime_type"),
  status: text("status").default("AWAITING_PROOF").notNull(),
  registrationTokenHash: text("registration_token_hash"),
  reviewNote: text("review_note"),
  reviewedBy: uuid("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [
  uniqueIndex("cco_main_applications_pay_id_unique").on(table.payIdId),
  uniqueIndex("cco_main_applications_user_unique").on(table.userId),
  uniqueIndex("cco_main_applications_account_unique").on(table.accountId)
]);
var paymentRequests = pgTable(
  "payment_requests",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    paymentCode: text("payment_code").notNull(),
    userId: uuid("user_id").notNull().references(() => users.id),
    courseId: uuid("course_id").references(() => courses.id),
    method: text("method").notNull(),
    totalAmount: numeric("total_amount", {
      precision: 12,
      scale: 2
    }).notNull(),
    paidAmount: numeric("paid_amount", {
      precision: 12,
      scale: 2
    }).notNull(),
    status: paymentStatusEnum("status").default("PENDING").notNull(),
    proofObjectKey: text("proof_object_key"),
    proofMimeType: text("proof_mime_type"),
    transactionReference: text("transaction_reference"),
    payIdId: uuid("pay_id_id").references(() => paymentReferenceIds.id),
    couponId: uuid("coupon_id").references(() => coupons.id),
    receivingAccountId: uuid("receiving_account_id"),
    requestedParentAccountId: uuid("requested_parent_account_id"),
    requestedSide: accountSideEnum("requested_side"),
    reviewedBy: uuid("reviewed_by").references(() => users.id),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    reviewNote: text("review_note"),
    registrationTokenHash: text("registration_token_hash"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("payment_requests_payment_code_unique").on(table.paymentCode)
  ]
);
var balancePaymentRequests = pgTable(
  "balance_payment_requests",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    originalPaymentId: uuid("original_payment_id").notNull().references(() => paymentRequests.id),
    userId: uuid("user_id").notNull().references(() => users.id),
    courseId: uuid("course_id").notNull().references(() => courses.id),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    transactionReference: text("transaction_reference").notNull(),
    proofObjectKey: text("proof_object_key"),
    proofMimeType: text("proof_mime_type"),
    status: paymentStatusEnum("status").default("PENDING").notNull(),
    reviewedBy: uuid("reviewed_by").references(() => users.id),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    reviewNote: text("review_note"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("balance_payment_transaction_unique").on(table.transactionReference)
  ]
);
var emailVerificationCodes = pgTable("email_verification_codes", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  codeHash: text("code_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  attempts: integer("attempts").default(0).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var couponUses = pgTable(
  "coupon_uses",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    couponId: uuid("coupon_id").notNull().references(() => coupons.id),
    userId: uuid("user_id").notNull().references(() => users.id),
    paymentRequestId: uuid("payment_request_id").notNull().references(() => paymentRequests.id),
    usedAt: timestamp("used_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("coupon_uses_payment_unique").on(table.paymentRequestId)
  ]
);
var consultantApplications = pgTable("consultant_applications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id),
  motivation: text("motivation"),
  status: applicationStatusEnum("status").default("PENDING").notNull(),
  interviewNote: text("interview_note"),
  reviewedBy: uuid("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var accountNumberSequence = pgTable("account_number_sequence", {
  id: integer("id").primaryKey(),
  nextNumber: integer("next_number").default(527694).notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
});
var networkAccounts = pgTable(
  "network_accounts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    ownerUserId: uuid("owner_user_id").notNull().references(() => users.id),
    prefix: accountTypeEnum("prefix").notNull(),
    numericPart: integer("numeric_part").notNull(),
    status: accountStatusEnum("status").default("RESERVED").notNull(),
    isMainAccount: boolean("is_main_account").default(false).notNull(),
    activatedAt: timestamp("activated_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("network_accounts_number_unique").on(
      table.prefix,
      table.numericPart
    )
  ]
);
var consultantStudentRegistrations = pgTable("consultant_student_registrations", {
  id: uuid("id").defaultRandom().primaryKey(),
  consultantUserId: uuid("consultant_user_id").references(() => users.id),
  parentAccountId: uuid("parent_account_id").references(() => networkAccounts.id),
  payIdId: uuid("pay_id_id").notNull().references(() => paymentReferenceIds.id),
  courseId: uuid("course_id").notNull().references(() => courses.id),
  paymentPlan: text("payment_plan").default("FULL").notNull(),
  expectedPaymentAmount: numeric("expected_payment_amount", { precision: 12, scale: 2 }).notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  dateOfBirth: text("date_of_birth").notNull(),
  nicOrPassport: text("nic_or_passport"),
  addressLine1: text("address_line_1").notNull(),
  addressLine2: text("address_line_2"),
  province: text("province").notNull(),
  district: text("district").notNull(),
  city: text("city").notNull(),
  side: accountSideEnum("side"),
  registrationSource: text("registration_source").default("CONSULTANT").notNull(),
  status: text("status").default("AWAITING_PAYMENT").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [uniqueIndex("consultant_student_registrations_pay_id_unique").on(table.payIdId)]);
var ccoActivationRequests = pgTable("cco_activation_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  consultantUserId: uuid("consultant_user_id").notNull().references(() => users.id),
  slotPosition: integer("slot_position").notNull(),
  requestedNumericPart: integer("requested_numeric_part").notNull(),
  parentAccountId: uuid("parent_account_id").notNull().references(() => networkAccounts.id),
  side: accountSideEnum("side").notNull(),
  activationMode: text("activation_mode").default("FULL").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  transactionReference: text("transaction_reference").notNull(),
  seniorConsultantName: text("senior_consultant_name"),
  proofObjectKey: text("proof_object_key"),
  proofMimeType: text("proof_mime_type"),
  status: text("status").default("PENDING").notNull(),
  reviewNote: text("review_note"),
  reviewedBy: uuid("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  activatedAccountId: uuid("activated_account_id").references(() => networkAccounts.id),
  trialExpiresAt: timestamp("trial_expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
});
var networkPlacements = pgTable(
  "network_placements",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    accountId: uuid("account_id").notNull().references(() => networkAccounts.id),
    parentAccountId: uuid("parent_account_id").notNull().references(() => networkAccounts.id),
    side: accountSideEnum("side").notNull(),
    placementKind: text("placement_kind").default("STUDENT").notNull(),
    placedByUserId: uuid("placed_by_user_id").notNull().references(() => users.id),
    activatedAt: timestamp("activated_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("network_placements_account_unique").on(table.accountId),
    uniqueIndex("network_parent_side_kind_unique").on(
      table.parentAccountId,
      table.side,
      table.placementKind
    )
  ]
);
var pointEvents = pgTable(
  "point_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    idempotencyKey: text("idempotency_key").notNull(),
    sourcePaymentId: uuid("source_payment_id").notNull().references(() => paymentRequests.id),
    beneficiaryAccountId: uuid("beneficiary_account_id").notNull().references(() => networkAccounts.id),
    side: accountSideEnum("side").notNull(),
    points: integer("points").notNull(),
    eventType: text("event_type").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("point_events_idempotency_unique").on(table.idempotencyKey)
  ]
);
var commissionCycles = pgTable(
  "commission_cycles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    cycleKey: text("cycle_key").notNull(),
    periodStart: timestamp("period_start", { withTimezone: true }).notNull(),
    periodEnd: timestamp("period_end", { withTimezone: true }).notNull(),
    status: text("status").default("DRAFT").notNull(),
    calculatedAt: timestamp("calculated_at", { withTimezone: true }),
    approvedBy: uuid("approved_by").references(() => users.id),
    approvedAt: timestamp("approved_at", { withTimezone: true })
  },
  (table) => [
    uniqueIndex("commission_cycles_cycle_key_unique").on(table.cycleKey)
  ]
);
var commissionEntries = pgTable(
  "commission_entries",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    cycleId: uuid("cycle_id").notNull().references(() => commissionCycles.id),
    accountId: uuid("account_id").notNull().references(() => networkAccounts.id),
    stage: text("stage").notNull(),
    matchedPairs: integer("matched_pairs").notNull(),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    metadata: jsonb("metadata").default({}).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("commission_cycle_account_stage_unique").on(
      table.cycleId,
      table.accountId,
      table.stage
    )
  ]
);
var accountPointBalances = pgTable(
  "account_point_balances",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    accountId: uuid("account_id").notNull().references(() => networkAccounts.id),
    leftAvailable: integer("left_available").default(0).notNull(),
    rightAvailable: integer("right_available").default(0).notNull(),
    lifetimeLeft: integer("lifetime_left").default(0).notNull(),
    lifetimeRight: integer("lifetime_right").default(0).notNull(),
    stageOneAchieved: boolean("stage_one_achieved").default(false).notNull(),
    stageTwoAchieved: boolean("stage_two_achieved").default(false).notNull(),
    lastQualifiedActivityAt: timestamp("last_qualified_activity_at", {
      withTimezone: true
    }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("account_point_balances_account_unique").on(table.accountId)
  ]
);
var wallets = pgTable(
  "wallets",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id),
    availableBalance: numeric("available_balance", {
      precision: 14,
      scale: 2
    }).default("0").notNull(),
    pendingBalance: numeric("pending_balance", {
      precision: 14,
      scale: 2
    }).default("0").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [uniqueIndex("wallets_user_unique").on(table.userId)]
);
var consultantBankDetails = pgTable("consultant_bank_details", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  bankName: text("bank_name").notNull(),
  branchName: text("branch_name").notNull(),
  accountHolderName: text("account_holder_name").notNull(),
  accountNumberEncrypted: text("account_number_encrypted").notNull(),
  accountNumberLast4: text("account_number_last4").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [uniqueIndex("consultant_bank_details_user_unique").on(table.userId)]);
var walletLedger = pgTable(
  "wallet_ledger",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    walletId: uuid("wallet_id").notNull().references(() => wallets.id),
    idempotencyKey: text("idempotency_key").notNull(),
    entryType: text("entry_type").notNull(),
    amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
    referenceType: text("reference_type").notNull(),
    referenceId: text("reference_id").notNull(),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
  },
  (table) => [
    uniqueIndex("wallet_ledger_idempotency_unique").on(table.idempotencyKey)
  ]
);
var payoutRequests = pgTable("payout_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  walletId: uuid("wallet_id").notNull().references(() => wallets.id),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  status: payoutStatusEnum("status").default("PENDING").notNull(),
  payoutMethod: text("payout_method").notNull(),
  payoutDetails: jsonb("payout_details").notNull(),
  reviewedBy: uuid("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var notifications = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var inactivityResets = pgTable("inactivity_resets", {
  id: uuid("id").defaultRandom().primaryKey(),
  accountId: uuid("account_id").notNull().references(() => networkAccounts.id),
  leftPointsReset: integer("left_points_reset").notNull(),
  rightPointsReset: integer("right_points_reset").notNull(),
  inactivityDays: integer("inactivity_days").default(90).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var systemSettings = pgTable("system_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedBy: uuid("updated_by").references(() => users.id),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
});
var supportTickets = pgTable("support_tickets", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  priority: text("priority").default("NORMAL").notNull(),
  status: text("status").default("OPEN").notNull(),
  assignedTo: uuid("assigned_to").references(() => users.id),
  resolution: text("resolution"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
});
var supportConversations = pgTable("support_conversations", {
  id: uuid("id").defaultRandom().primaryKey(),
  publicTokenHash: text("public_token_hash").notNull(),
  channel: text("channel").default("FAQ").notNull(),
  status: text("status").default("OPEN").notNull(),
  visitorName: text("visitor_name"),
  visitorEmail: text("visitor_email"),
  visitorUserId: uuid("visitor_user_id").references(() => users.id, { onDelete: "set null" }),
  assignedTo: uuid("assigned_to").references(() => users.id, { onDelete: "set null" }),
  claimedAt: timestamp("claimed_at", { withTimezone: true }),
  closedAt: timestamp("closed_at", { withTimezone: true }),
  lastMessageAt: timestamp("last_message_at", { withTimezone: true }).defaultNow().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull()
}, (table) => [uniqueIndex("support_conversations_token_unique").on(table.publicTokenHash)]);
var supportMessages = pgTable("support_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id").notNull().references(() => supportConversations.id, { onDelete: "cascade" }),
  senderType: text("sender_type").notNull(),
  senderUserId: uuid("sender_user_id").references(() => users.id, { onDelete: "set null" }),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});
var supportAgentPresence = pgTable("support_agent_presence", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).defaultNow().notNull()
});
var auditLogs = pgTable("audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  actorUserId: uuid("actor_user_id").references(() => users.id),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id"),
  metadata: jsonb("metadata").default({}).notNull(),
  ipAddress: text("ip_address"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull()
});

// db/client.ts
var { Pool } = pg;
var pool = process.env.DATABASE_URL ? new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
}) : null;
var database = pool ? drizzle(pool, { schema: schema_exports }) : null;
function requireDatabase() {
  if (!database) {
    throw new Error("DATABASE_NOT_CONFIGURED");
  }
  return database;
}

// server/modules/auth/service.ts
import crypto from "node:crypto";
import argon2 from "argon2";
import { and, desc, eq, gt, isNull, sql } from "drizzle-orm";

// server/domain/business-rules.ts
var FIRST_ACCOUNT_NUMBER = 527694;
var ACCOUNT_BLOCK_SIZE = 7;
var DIRECT_ADMISSION_INCOME = 3e3;
function qualifiesForDirectAdmissionIncome(status) {
  return status === "PARTIAL" || status === "APPROVED";
}
function nextStudentAccountNumber(maxUsedNumber) {
  if (maxUsedNumber == null || maxUsedNumber < FIRST_ACCOUNT_NUMBER) {
    return FIRST_ACCOUNT_NUMBER;
  }
  const usedBlock = Math.floor(
    (maxUsedNumber - FIRST_ACCOUNT_NUMBER) / ACCOUNT_BLOCK_SIZE
  );
  return FIRST_ACCOUNT_NUMBER + (usedBlock + 1) * ACCOUNT_BLOCK_SIZE;
}

// server/services/email.ts
import nodemailer from "nodemailer";
var senderEmail = process.env.EMAIL_FROM?.trim() || "adilacademy65@gmail.com";
async function sendVerificationCode(email, code) {
  const password = process.env.EMAIL_APP_PASSWORD?.replaceAll(" ", "");
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: senderEmail, pass: password }
  });
  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Adil Academy email verification code",
    text: `Your Adil Academy verification code is ${code}. It expires in 10 minutes. Do not share this code.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:28px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY</p><h2>Email verification</h2><p>\u0D94\u0DB6\u0D9C\u0DDA payment \u0D91\u0D9A approve \u0D9A\u0DBB \u0D87\u0DAD. Account \u0D91\u0D9A activate \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8\u0DA7 \u0DB4\u0DC4\u0DAD OTP code \u0D91\u0D9A \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.</p><div style="font-size:34px;font-weight:800;letter-spacing:8px;margin:24px 0;color:#7cff4f">${code}</div><p style="color:#9aa59f">\u0DB8\u0DD9\u0DB8 code \u0D91\u0D9A \u0DC0\u0DD2\u0DB1\u0DCF\u0DA9\u0DD2 10\u0D9A\u0DD2\u0DB1\u0DCA expire \u0DC0\u0DDA. \u0DC0\u0DD9\u0DB1\u0DAD\u0DCA \u0D9A\u0DD9\u0DB1\u0DD9\u0D9A\u0DD4\u0DA7 \u0DBD\u0DB6\u0DCF \u0DB1\u0DDC\u0DAF\u0DD9\u0DB1\u0DCA\u0DB1.</p></div>`
  });
}
async function sendApplicationReceived(email, name, paymentCode2) {
  const password = process.env.EMAIL_APP_PASSWORD?.replaceAll(" ", "");
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: senderEmail, pass: password }
  });
  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Adil Academy application received",
    text: `Hello ${name}, we received your details and payment proof (${paymentCode2}). We will review them. If the details are correct, an OTP code will be sent to this email within 24 hours.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:30px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY</p><h2>\u0D94\u0DB6\u0D9C\u0DDA details \u0DBD\u0DD0\u0DB6\u0DD3 \u0D87\u0DAD</h2><p>\u0D86\u0DBA\u0DD4\u0DB6\u0DDD\u0DC0\u0DB1\u0DCA ${name},</p><p>\u0D94\u0DB6 submit \u0D9A\u0DC5 details \u0DC3\u0DC4 payment proof \u0D91\u0D9A \u0D85\u0DB4\u0DA7 \u0DBD\u0DD0\u0DB6\u0DD3 \u0D87\u0DAD. \u0D92\u0DC0\u0DCF \u0DAF\u0DD0\u0DB1\u0DCA \u0DB4\u0DBB\u0DD3\u0D9A\u0DCA\u0DC2\u0DCF \u0D9A\u0DBB\u0DB1\u0DD4 \u0DBD\u0DD0\u0DB6\u0DDA.</p><div style="margin:22px 0;padding:16px;border:1px solid #254331;border-radius:10px"><strong>Payment ID:</strong> ${paymentCode2}</div><p>\u0D94\u0DB6\u0D9C\u0DDA details \u0DB1\u0DD2\u0DC0\u0DD0\u0DBB\u0DAF\u0DD2 \u0DB1\u0DB8\u0DCA <strong>\u0DB4\u0DD0\u0DBA 24\u0D9A\u0DCA \u0D87\u0DAD\u0DD4\u0DC5\u0DAD</strong> \u0DB8\u0DD9\u0DB8 email \u0DBD\u0DD2\u0DB4\u0DD2\u0DB1\u0DBA\u0DA7 OTP code \u0D91\u0D9A\u0D9A\u0DCA \u0D91\u0DC0\u0DB1\u0DD4 \u0DBD\u0DD0\u0DB6\u0DDA.</p><p style="color:#9aa59f">OTP code \u0D91\u0D9A \u0DBD\u0DD0\u0DB6\u0DD9\u0DB1 \u0DAD\u0DD4\u0DBB\u0DD4 \u0DB1\u0DD0\u0DC0\u0DAD application \u0D91\u0D9A\u0D9A\u0DCA submit \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8 \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA \u0DB1\u0DD0\u0DAD.</p></div>`
  });
}
async function sendPayId(email, payId, expiresAt) {
  const password = process.env.EMAIL_APP_PASSWORD?.replaceAll(" ", "");
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: senderEmail, pass: password }
  });
  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Your Adil Academy Pay ID",
    text: `Your Adil Academy Pay ID is ${payId}. Use this exact Pay ID as your bank payment reference and in the admission form. It expires at ${expiresAt.toISOString()} and can be used once.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:30px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY</p><h2>Your Pay ID</h2><p>Bank payment \u0D91\u0D9A\u0DDA <strong>Reference</strong> \u0DBD\u0DD9\u0DC3 \u0DB4\u0DC4\u0DAD Pay ID \u0D91\u0D9A \u0DC0\u0DD9\u0DB1\u0DC3\u0D9A\u0DCA \u0DB1\u0DDC\u0D9A\u0DBB \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.</p><div style="margin:24px 0;padding:20px;border:1px solid #315c40;border-radius:12px;color:#7cff4f;font-size:24px;font-weight:800;letter-spacing:2px;text-align:center">${payId}</div><p>Admission form \u0D91\u0D9A\u0DDA\u0DAD\u0DCA \u0DB8\u0DD9\u0DB8 Pay ID \u0D91\u0D9A\u0DB8 \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.</p><ul><li>\u0DB8\u0DD9\u0DBA \u0D91\u0D9A\u0DCA payment \u0D91\u0D9A\u0D9A\u0DA7 \u0DB4\u0DB8\u0DAB\u0DBA\u0DD2.</li><li>\u0DB4\u0DD0\u0DBA 48\u0D9A\u0DD2\u0DB1\u0DCA expire \u0DC0\u0DDA.</li><li>Pay ID \u0DB1\u0DD0\u0DAD\u0DD2 payment \u0D91\u0D9A\u0D9A\u0DCA approve \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1\u0DDA \u0DB1\u0DD0\u0DAD.</li></ul><p style="color:#9aa59f">Expires: ${expiresAt.toLocaleString("en-LK", { timeZone: "Asia/Colombo" })}</p></div>`
  });
}
async function sendCcoMainPayId(email, name, payId, amount, expiresAt) {
  const password = process.env.EMAIL_APP_PASSWORD?.replaceAll(" ", "");
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");
  const transporter = nodemailer.createTransport({ service: "gmail", auth: { user: senderEmail, pass: password } });
  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Your CCO Main Account Pay ID",
    text: `Hello ${name}, your one-time CCO Main Pay ID is ${payId}. Amount: LKR ${amount}. It expires at ${expiresAt.toISOString()}.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:30px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY \xB7 CCO MAIN</p><h2>Special CCO Main Pay ID</h2><p>\u0D86\u0DBA\u0DD4\u0DB6\u0DDD\u0DC0\u0DB1\u0DCA ${name}, course \u0D91\u0D9A\u0D9A\u0DCA \u0DB1\u0DDC\u0DB8\u0DD0\u0DAD\u0DD2 CCO Main account application \u0D91\u0D9A \u0DC3\u0DB3\u0DC4\u0DCF \u0DB8\u0DD9\u0DB8 Pay ID \u0D91\u0D9A \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.</p><div style="margin:22px 0;padding:18px;border:1px solid #315c40;border-radius:12px;text-align:center"><strong style="font-size:24px;color:#7cff4f">${payId}</strong><br><span>LKR ${amount.toLocaleString()}</span></div><p>Bank transfer reference \u0D91\u0D9A\u0DA7\u0DAD\u0DCA CCO form \u0D91\u0D9A\u0DA7\u0DAD\u0DCA \u0DB8\u0DD9\u0DB8 ID \u0D91\u0D9A\u0DB8 \u0DBA\u0DDC\u0DAF\u0DB1\u0DCA\u0DB1. \u0D91\u0D9A\u0DCA \u0DC0\u0DBB\u0D9A\u0DCA \u0DB4\u0DB8\u0DAB\u0D9A\u0DCA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DC5 \u0DC4\u0DD0\u0D9A\u0DD2 \u0D85\u0DAD\u0DBB \u0DB4\u0DD0\u0DBA 48\u0D9A\u0DD2\u0DB1\u0DCA expire \u0DC0\u0DDA.</p></div>`
  });
}
async function sendCcoMainApplicationReceived(email, name) {
  const password = process.env.EMAIL_APP_PASSWORD?.replaceAll(" ", "");
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");
  const transporter = nodemailer.createTransport({ service: "gmail", auth: { user: senderEmail, pass: password } });
  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "CCO Main application received",
    text: `Hello ${name}, your CCO Main application and payment slip were received. If approved, an OTP will be emailed within 24 hours.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:30px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY \xB7 CCO MAIN</p><h2>Application \u0D91\u0D9A \u0DC3\u0DCF\u0DBB\u0DCA\u0DAE\u0D9A\u0DBA\u0DD2</h2><p>\u0D86\u0DBA\u0DD4\u0DB6\u0DDD\u0DC0\u0DB1\u0DCA ${name}, \u0D94\u0DB6\u0D9C\u0DDA details \u0DC3\u0DC4 bank slip \u0D91\u0D9A \u0DBD\u0DD0\u0DB6\u0DD3 \u0D87\u0DAD.</p><p>Admin \u0DC0\u0DD2\u0DC3\u0DD2\u0DB1\u0DCA payment slip \u0D91\u0D9A \u0DB4\u0DBB\u0DD3\u0D9A\u0DCA\u0DC2\u0DCF \u0D9A\u0DBB \u0DB1\u0DD2\u0DC0\u0DD0\u0DBB\u0DAF\u0DD2 \u0DB1\u0DB8\u0DCA <strong>\u0DB4\u0DD0\u0DBA 24\u0D9A\u0DCA \u0D87\u0DAD\u0DD4\u0DC5\u0DAD</strong> \u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 OTP code \u0D91\u0D9A\u0D9A\u0DCA \u0D91\u0DC0\u0DB1\u0DD4 \u0DBD\u0DD0\u0DB6\u0DDA.</p><p>OTP \u0DBD\u0DD0\u0DB6\u0DD4\u0DAB\u0DD4 \u0DB4\u0DC3\u0DD4 Login \u2192 Verify OTP \u0DC0\u0DD9\u0DAD \u0D9C\u0DDC\u0DC3\u0DCA OTP \u0D91\u0D9A \u0DC3\u0DC4 \u0DB1\u0DC0 password \u0D91\u0D9A \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.</p></div>`
  });
}
async function sendFridayPayoutReminder(email, totalAmount, consultantCount) {
  const password = process.env.EMAIL_APP_PASSWORD?.replaceAll(" ", "");
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: senderEmail, pass: password }
  });
  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Friday consultant payouts are waiting",
    text: `${consultantCount} consultant payouts totalling LKR ${totalAmount.toLocaleString()} are waiting. Open Admin > Commissions, make each bank transfer, then mark it Paid & Clear Balance.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:30px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY</p><h2>Friday payout reminder</h2><p>Consultant payments manually complete \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8\u0DA7 \u0D9A\u0DCF\u0DBD\u0DBA\u0DBA\u0DD2.</p><div style="margin:22px 0;padding:18px;border:1px solid #315c40;border-radius:12px"><strong>${consultantCount} consultants</strong><br><span style="font-size:28px;color:#7cff4f;font-weight:800">LKR ${totalAmount.toLocaleString()}</span></div><p>Admin Panel \u2192 Commissions \u0DC0\u0DD9\u0DAD \u0D9C\u0DDC\u0DC3\u0DCA bank transfer \u0D91\u0D9A \u0DC3\u0DD2\u0DAF\u0DD4\u0D9A\u0DBB, \u0DC3\u0DCF\u0DBB\u0DCA\u0DAE\u0D9A \u0DC0\u0DD6 \u0DB4\u0DC3\u0DD4 <strong>Paid &amp; Clear Balance</strong> \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.</p></div>`
  });
}

// server/modules/auth/service.ts
var SESSION_LIFETIME_MS = 1e3 * 60 * 60 * 24 * 7;
function publicUser(user) {
  return {
    id: user.id,
    name: user.displayName,
    email: user.email,
    role: user.role,
    learningPortalEnabled: user.learningPortalEnabled
  };
}
function hashSessionToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
function hashVerificationCode(userId, code) {
  return crypto.createHmac("sha256", process.env.SESSION_SECRET || "local-development").update(`${userId}:${code}`).digest("hex");
}
function registrationTokenHash(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
function matchesRegistrationToken(token, hash) {
  return Boolean(hash) && registrationTokenHash(token) === hash;
}
async function createAdmissionApplication(input) {
  const db = requireDatabase();
  const email = input.email.trim().toLowerCase();
  const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing) throw new Error("EMAIL_ALREADY_EXISTS");
  const [course] = await db.select().from(courses).where(and(eq(courses.id, input.courseId), eq(courses.isPublished, true))).limit(1);
  if (!course) throw new Error("COURSE_NOT_FOUND");
  const normalizedPayId = input.payId.trim().toUpperCase();
  const [payId] = await db.select().from(paymentReferenceIds).where(and(
    eq(paymentReferenceIds.code, normalizedPayId),
    eq(paymentReferenceIds.email, email),
    isNull(paymentReferenceIds.usedAt),
    gt(paymentReferenceIds.expiresAt, /* @__PURE__ */ new Date())
  )).limit(1);
  if (!payId || input.transactionReference.trim().toUpperCase() !== normalizedPayId) {
    throw new Error("INVALID_PAY_ID");
  }
  const [consultantRegistration] = await db.select().from(consultantStudentRegistrations).where(eq(consultantStudentRegistrations.payIdId, payId.id)).limit(1);
  const registrationToken = crypto.randomBytes(32).toString("base64url");
  const result = await db.transaction(async (tx) => {
    const [user] = await tx.insert(users).values({
      email,
      passwordHash: await argon2.hash(crypto.randomBytes(32).toString("hex"), { type: argon2.argon2id }),
      displayName: consultantRegistration ? `${consultantRegistration.firstName} ${consultantRegistration.lastName}` : input.displayName.trim(),
      phone: consultantRegistration?.phone ?? input.phone.trim(),
      nicOrPassport: consultantRegistration?.nicOrPassport ?? input.nicOrPassport.trim(),
      address: consultantRegistration ? [consultantRegistration.addressLine1, consultantRegistration.addressLine2, consultantRegistration.city, consultantRegistration.district, consultantRegistration.province].filter(Boolean).join(", ") : null,
      dateOfBirth: consultantRegistration?.dateOfBirth ?? null,
      role: "student",
      isActive: false
    }).returning();
    await tx.insert(accountNumberSequence).values({ id: 1, nextNumber: 527694 }).onConflictDoNothing();
    const [highest] = await tx.select({ numericPart: networkAccounts.numericPart }).from(networkAccounts).orderBy(desc(networkAccounts.numericPart)).limit(1);
    const nextBlock = nextStudentAccountNumber(highest?.numericPart);
    const [sequence] = await tx.update(accountNumberSequence).set({
      nextNumber: sql`GREATEST(${accountNumberSequence.nextNumber}, ${nextBlock}) + ${ACCOUNT_BLOCK_SIZE}`,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(accountNumberSequence.id, 1)).returning({ nextNumber: accountNumberSequence.nextNumber });
    const numericPart = sequence.nextNumber - ACCOUNT_BLOCK_SIZE;
    await tx.insert(networkAccounts).values({
      ownerUserId: user.id,
      prefix: "SR",
      numericPart,
      status: "RESERVED",
      isMainAccount: true
    });
    const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "");
    const expectedAmount = consultantRegistration ? Number(consultantRegistration.expectedPaymentAmount) : Number(course.price);
    const [payment] = await tx.insert(paymentRequests).values({
      paymentCode: `PAY-${day}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`,
      userId: user.id,
      courseId: course.id,
      method: "BANK_TRANSFER",
      totalAmount: course.price,
      paidAmount: expectedAmount.toFixed(2),
      transactionReference: normalizedPayId,
      payIdId: payId.id,
      requestedParentAccountId: consultantRegistration?.parentAccountId,
      requestedSide: consultantRegistration?.side,
      registrationTokenHash: registrationTokenHash(registrationToken)
    }).returning();
    if (consultantRegistration) await tx.update(consultantStudentRegistrations).set({ status: "PAYMENT_SUBMITTED", updatedAt: /* @__PURE__ */ new Date() }).where(eq(consultantStudentRegistrations.id, consultantRegistration.id));
    return { user, payment };
  });
  return { applicationId: result.payment.id, paymentCode: result.payment.paymentCode, registrationToken };
}
async function createAndSendVerificationCode(userId) {
  const db = requireDatabase();
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) throw new Error("USER_NOT_FOUND");
  const code = String(crypto.randomInt(1e5, 1e6));
  await db.insert(emailVerificationCodes).values({
    userId,
    codeHash: hashVerificationCode(userId, code),
    expiresAt: new Date(Date.now() + 10 * 60 * 1e3)
  });
  await sendVerificationCode(user.email, code);
}
async function verifyCodeAndSetPassword(input) {
  const db = requireDatabase();
  const email = input.email.trim().toLowerCase();
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user) throw new Error("INVALID_VERIFICATION");
  const [verification] = await db.select().from(emailVerificationCodes).where(
    and(
      eq(emailVerificationCodes.userId, user.id),
      isNull(emailVerificationCodes.usedAt),
      gt(emailVerificationCodes.expiresAt, /* @__PURE__ */ new Date())
    )
  ).orderBy(desc(emailVerificationCodes.createdAt)).limit(1);
  if (!verification || verification.attempts >= 5) {
    throw new Error("INVALID_VERIFICATION");
  }
  if (verification.codeHash !== hashVerificationCode(user.id, input.code)) {
    await db.update(emailVerificationCodes).set({ attempts: verification.attempts + 1 }).where(eq(emailVerificationCodes.id, verification.id));
    throw new Error("INVALID_VERIFICATION");
  }
  const passwordHash = await argon2.hash(input.password, { type: argon2.argon2id });
  const [activated] = await db.transaction(async (tx) => {
    await tx.update(emailVerificationCodes).set({ usedAt: /* @__PURE__ */ new Date() }).where(eq(emailVerificationCodes.id, verification.id));
    return tx.update(users).set({
      passwordHash,
      emailVerifiedAt: /* @__PURE__ */ new Date(),
      passwordSetAt: /* @__PURE__ */ new Date(),
      isActive: true,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq(users.id, user.id)).returning();
  });
  return createPersistentSession(activated);
}
async function loginUser(input) {
  const db = requireDatabase();
  const email = input.email.trim().toLowerCase();
  const [user] = await db.select().from(users).where(and(eq(users.email, email), eq(users.isActive, true))).limit(1);
  if (!user || !user.emailVerifiedAt || !user.passwordSetAt || !await argon2.verify(user.passwordHash, input.password)) {
    throw new Error("INVALID_CREDENTIALS");
  }
  return createPersistentSession(user);
}
async function createPersistentSession(user) {
  const db = requireDatabase();
  const token = crypto.randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_LIFETIME_MS);
  await db.insert(sessions).values({
    userId: user.id,
    tokenHash: hashSessionToken(token),
    expiresAt
  });
  return {
    token,
    expiresAt,
    user: publicUser(user)
  };
}
async function getUserForSession(token) {
  const db = requireDatabase();
  const [result] = await db.select({ user: users }).from(sessions).innerJoin(users, eq(sessions.userId, users.id)).where(
    and(
      eq(sessions.tokenHash, hashSessionToken(token)),
      gt(sessions.expiresAt, /* @__PURE__ */ new Date()),
      eq(users.isActive, true)
    )
  ).limit(1);
  return result ? publicUser(result.user) : null;
}
async function deletePersistentSession(token) {
  const db = requireDatabase();
  await db.delete(sessions).where(eq(sessions.tokenHash, hashSessionToken(token)));
}

// server/services/storage.ts
import { Client } from "@replit/object-storage";
var storageClient = null;
function client() {
  storageClient ??= new Client();
  return storageClient;
}
async function uploadPrivateFile(objectKey, contents) {
  try {
    const result = await client().uploadFromBytes(objectKey, contents);
    if (!result.ok) {
      throw new Error(String(result.error));
    }
  } catch (error) {
    console.error("App Storage upload failed", error);
    throw new Error("APP_STORAGE_UNAVAILABLE");
  }
}
async function downloadPrivateFile(objectKey) {
  try {
    const result = await client().downloadAsBytes(objectKey);
    if (!result.ok) {
      throw new Error(String(result.error));
    }
    return result.value[0];
  } catch (error) {
    console.error("App Storage download failed", error);
    throw new Error("APP_STORAGE_UNAVAILABLE");
  }
}

// server/lib/http.ts
import { ZodError } from "zod";

// server/lib/auth.ts
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
  status;
};
function readCookie(cookieHeader, name) {
  if (!cookieHeader) return void 0;
  for (const part of cookieHeader.split(";")) {
    const [key2, ...value] = part.trim().split("=");
    if (key2 === name) return decodeURIComponent(value.join("="));
  }
  return void 0;
}
async function requireAuthenticatedUser(request) {
  const token = readCookie(request.headers.cookie, "adil_session");
  if (!token) throw new HttpError(401, "Authentication required.");
  const user = await getUserForSession(token);
  if (!user) throw new HttpError(401, "Authentication required.");
  return user;
}
async function requireRole(request, roles) {
  const user = await requireAuthenticatedUser(request);
  if (!roles.includes(user.role)) {
    throw new HttpError(403, "You do not have permission for this action.");
  }
  return user;
}

// server/lib/http.ts
function asyncRoute(handler) {
  return (request, response, next) => {
    void handler(request, response, next).catch(next);
  };
}
function apiErrorHandler(error, _request, response, _next) {
  if (error instanceof HttpError) {
    response.status(error.status).json({ message: error.message });
    return;
  }
  if (error instanceof ZodError) {
    response.status(400).json({
      message: "Request validation failed.",
      issues: error.issues.map((issue) => issue.message)
    });
    return;
  }
  if (error instanceof Error && error.message === "DATABASE_NOT_CONFIGURED") {
    response.status(503).json({
      message: "Replit PostgreSQL database is not configured."
    });
    return;
  }
  if (error instanceof Error && error.message === "APP_STORAGE_UNAVAILABLE") {
    response.status(503).json({
      message: "Replit App Storage is not configured."
    });
    return;
  }
  if (error && typeof error === "object" && "code" in error && error.code === "42P01") {
    response.status(503).json({ message: "Registration database update \u0D91\u0D9A apply \u0DC0\u0DD3 \u0DB1\u0DD0\u0DC4\u0DD0. Replit Shell \u0D91\u0D9A\u0DDA npm run db:migrate \u0DAF\u0DD3 \u0DB1\u0DD0\u0DC0\u0DAD \u0D8B\u0DAD\u0DCA\u0DC3\u0DCF\u0DC4 \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." });
    return;
  }
  console.error("Unhandled API error", error);
  response.status(500).json({ message: "Unexpected server error." });
}

// server/modules/courses/routes.ts
import { and as and2, asc, count, desc as desc2, eq as eq2, inArray } from "drizzle-orm";
import crypto2 from "node:crypto";
import express, { Router } from "express";
import { z } from "zod";
var courseRouter = Router();
var courseInput = z.object({
  slug: z.string().trim().min(3).max(120).regex(/^[a-z0-9-]+$/),
  title: z.string().trim().min(3).max(180),
  shortDescription: z.string().trim().min(10).max(400),
  description: z.string().trim().max(1e4).optional(),
  price: z.coerce.number().positive(),
  points: z.coerce.number().int().min(0).default(0),
  halfPaymentLessonLimit: z.coerce.number().int().min(0).max(1e4).default(7),
  currency: z.string().trim().length(3).default("LKR"),
  isPublished: z.boolean().default(false)
});
async function courseAccess(db, userId, courseId) {
  const [payment] = await db.select({ status: paymentRequests.status }).from(paymentRequests).where(and2(eq2(paymentRequests.userId, userId), eq2(paymentRequests.courseId, courseId), inArray(paymentRequests.status, ["PARTIAL", "APPROVED"]))).orderBy(desc2(paymentRequests.createdAt)).limit(1);
  const [course] = await db.select({ halfPaymentLessonLimit: courses.halfPaymentLessonLimit }).from(courses).where(eq2(courses.id, courseId)).limit(1);
  return { accessLevel: payment?.status === "APPROVED" ? "FULL" : "HALF", halfPaymentLessonLimit: course?.halfPaymentLessonLimit ?? 0 };
}
var sectionInput = z.object({
  courseId: z.string().uuid(),
  title: z.string().trim().min(2).max(180),
  position: z.coerce.number().int().min(1)
});
var lessonInput = z.object({
  sectionId: z.string().uuid(),
  title: z.string().trim().min(2).max(180),
  content: z.string().trim().max(3e4).optional(),
  videoProvider: z.enum(["youtube", "vimeo"]).optional(),
  videoId: z.string().trim().max(200).optional(),
  durationSeconds: z.coerce.number().int().min(0).default(0),
  position: z.coerce.number().int().min(1),
  isPreview: z.boolean().default(false)
});
var progressInput = z.object({
  enrollmentId: z.string().uuid(),
  lessonId: z.string().uuid(),
  progressPercent: z.coerce.number().int().min(0).max(100)
});
var quizInput = z.object({
  courseId: z.string().uuid(),
  title: z.string().trim().min(3).max(180),
  passingPercent: z.coerce.number().int().min(1).max(100).default(70),
  position: z.coerce.number().int().min(1),
  isPublished: z.boolean().default(false)
});
var questionInput = z.object({
  quizId: z.string().uuid(),
  question: z.string().trim().min(3).max(2e3),
  options: z.array(z.string().trim().min(1).max(1e3)).min(2).max(8),
  correctOption: z.coerce.number().int().min(0),
  explanation: z.string().trim().max(3e3).optional(),
  position: z.coerce.number().int().min(1)
});
var attemptInput = z.object({
  answers: z.array(z.coerce.number().int().min(0)).max(200)
});
var courseUpdateInput = courseInput.partial().refine((value) => Object.keys(value).length > 0);
var sectionUpdateInput = sectionInput.omit({ courseId: true }).partial().refine((value) => Object.keys(value).length > 0);
var lessonUpdateInput = lessonInput.omit({ sectionId: true }).partial().refine((value) => Object.keys(value).length > 0);
courseRouter.get(
  "/courses",
  asyncRoute(async (_request, response) => {
    const db = requireDatabase();
    const items = await db.select({
      id: courses.id,
      slug: courses.slug,
      title: courses.title,
      shortDescription: courses.shortDescription,
      price: courses.price,
      currency: courses.currency,
      language: courses.language,
      thumbnailUrl: courses.thumbnailUrl,
      halfPaymentLessonLimit: courses.halfPaymentLessonLimit
    }).from(courses).where(eq2(courses.isPublished, true)).orderBy(asc(courses.createdAt));
    response.json({ courses: items });
  })
);
courseRouter.get(
  "/courses/:slug",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [course] = await db.select().from(courses).where(
      and2(
        eq2(courses.slug, String(request.params.slug)),
        eq2(courses.isPublished, true)
      )
    ).limit(1);
    if (!course) {
      response.status(404).json({ message: "Course not found." });
      return;
    }
    const sections = await db.select().from(courseSections).where(eq2(courseSections.courseId, course.id)).orderBy(asc(courseSections.position));
    const sectionIds = new Set(sections.map((section) => section.id));
    const allLessons = sectionIds.size ? await db.select({
      id: lessons.id,
      sectionId: lessons.sectionId,
      title: lessons.title,
      durationSeconds: lessons.durationSeconds,
      position: lessons.position,
      isPreview: lessons.isPreview
    }).from(lessons).where(inArray(lessons.sectionId, [...sectionIds])).orderBy(asc(lessons.position)) : [];
    const [{ enrolledStudents }] = await db.select({ enrolledStudents: count() }).from(enrollments).where(and2(eq2(enrollments.courseId, course.id), eq2(enrollments.status, "ACTIVE")));
    response.json({
      course,
      enrolledStudents,
      sections: sections.map((section) => ({
        ...section,
        lessons: allLessons.filter(
          (lesson) => lesson.sectionId === section.id
        )
      }))
    });
  })
);
courseRouter.get(
  "/courses/:id/thumbnail",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [course] = await db.select({ key: courses.thumbnailUrl }).from(courses).where(and2(eq2(courses.id, String(request.params.id)), eq2(courses.isPublished, true))).limit(1);
    if (!course?.key) {
      response.status(404).json({ message: "Course image not found." });
      return;
    }
    const extension = course.key.split(".").pop()?.toLowerCase();
    response.type(extension === "png" ? "image/png" : extension === "webp" ? "image/webp" : "image/jpeg").set("Cache-Control", "public, max-age=3600").send(await downloadPrivateFile(course.key));
  })
);
courseRouter.get(
  "/student/enrollments",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db.select({
      enrollmentId: enrollments.id,
      status: enrollments.status,
      enrolledAt: enrollments.enrolledAt,
      completedAt: enrollments.completedAt,
      courseId: courses.id,
      slug: courses.slug,
      title: courses.title,
      shortDescription: courses.shortDescription,
      thumbnailUrl: courses.thumbnailUrl
    }).from(enrollments).innerJoin(courses, eq2(enrollments.courseId, courses.id)).where(eq2(enrollments.userId, user.id)).orderBy(asc(enrollments.enrolledAt));
    response.json({ enrollments: await Promise.all(items.map(async (item) => ({ ...item, ...await courseAccess(db, user.id, item.courseId) }))) });
  })
);
courseRouter.get(
  "/student/dashboard-summary",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [account] = await db.select().from(networkAccounts).where(
      and2(
        eq2(networkAccounts.ownerUserId, user.id),
        eq2(networkAccounts.isMainAccount, true)
      )
    ).limit(1);
    const [enrollment] = await db.select({
      id: enrollments.id,
      status: enrollments.status,
      courseId: enrollments.courseId,
      courseTitle: courses.title,
      halfPaymentLessonLimit: courses.halfPaymentLessonLimit
    }).from(enrollments).innerJoin(courses, eq2(enrollments.courseId, courses.id)).where(eq2(enrollments.userId, user.id)).orderBy(asc(enrollments.enrolledAt)).limit(1);
    if (!enrollment) {
      response.json({
        enrollmentStatus: "NOT_ENROLLED",
        courseTitle: null,
        totalLessons: 0,
        completedLessons: 0,
        progressPercent: 0,
        quizAverage: null,
        accountNumber: account ? `${account.prefix}${account.numericPart}` : null,
        accountStatus: account?.status ?? null,
        modules: [],
        recentActivity: []
      });
      return;
    }
    const access = await courseAccess(db, user.id, enrollment.courseId);
    const sections = await db.select({ id: courseSections.id, title: courseSections.title, position: courseSections.position }).from(courseSections).where(eq2(courseSections.courseId, enrollment.courseId)).orderBy(asc(courseSections.position));
    const sectionIds = sections.map((item) => item.id);
    const unorderedLessons = sectionIds.length ? await db.select({ id: lessons.id, title: lessons.title, sectionId: lessons.sectionId, position: lessons.position }).from(lessons).where(inArray(lessons.sectionId, sectionIds)).orderBy(asc(lessons.position)) : [];
    const sectionOrder = new Map(sections.map((section, index) => [section.id, index]));
    const courseLessons = [...unorderedLessons].sort(
      (a, b) => (sectionOrder.get(a.sectionId) ?? 0) - (sectionOrder.get(b.sectionId) ?? 0) || a.position - b.position
    );
    const lessonOrder = new Map(courseLessons.map((lesson, index) => [lesson.id, index]));
    const unlockedLimit = access.accessLevel === "FULL" ? courseLessons.length : access.halfPaymentLessonLimit;
    const progress = await db.select().from(lessonProgress).where(eq2(lessonProgress.enrollmentId, enrollment.id)).orderBy(asc(lessonProgress.updatedAt));
    const completed = progress.filter((item) => item.progressPercent === 100);
    const attempts = await db.select({ score: quizAttempts.scorePercent }).from(quizAttempts).innerJoin(quizzes, eq2(quizAttempts.quizId, quizzes.id)).where(and2(eq2(quizAttempts.userId, user.id), eq2(quizzes.courseId, enrollment.courseId)));
    const quizAverage = attempts.length ? Math.round(attempts.reduce((sum, item) => sum + item.score, 0) / attempts.length) : null;
    const lessonTitles = new Map(courseLessons.map((item) => [item.id, item.title]));
    const completedIds = new Set(completed.map((item) => item.lessonId));
    const modules = sections.map((section) => {
      const moduleLessons = courseLessons.filter((lesson) => lesson.sectionId === section.id);
      const moduleCompleted = moduleLessons.filter((lesson) => completedIds.has(lesson.id)).length;
      return {
        title: section.title,
        totalLessons: moduleLessons.length,
        completedLessons: moduleCompleted,
        progressPercent: moduleLessons.length ? Math.round(moduleCompleted / moduleLessons.length * 100) : 0,
        lessons: moduleLessons.map((lesson) => ({
          id: lesson.id,
          title: lesson.title,
          locked: (lessonOrder.get(lesson.id) ?? 0) >= unlockedLimit
        }))
      };
    });
    const recentActivity = [...progress].reverse().slice(0, 3).map((item) => ({
      title: lessonTitles.get(item.lessonId) ?? "Course lesson",
      detail: item.progressPercent === 100 ? "Completed" : `${item.progressPercent}% watched`
    }));
    response.json({
      enrollmentStatus: enrollment.status,
      courseTitle: enrollment.courseTitle,
      totalLessons: courseLessons.length,
      completedLessons: completed.length,
      progressPercent: courseLessons.length ? Math.round(completed.length / courseLessons.length * 100) : 0,
      quizAverage,
      accountNumber: account ? `${account.prefix}${account.numericPart}` : null,
      accountStatus: account?.status ?? null,
      accessLevel: access.accessLevel,
      halfPaymentLessonLimit: access.halfPaymentLessonLimit,
      unlockedLessons: unlockedLimit,
      modules,
      recentActivity
    });
  })
);
courseRouter.post(
  "/student/progress",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = progressInput.parse(request.body);
    const db = requireDatabase();
    const [enrollment] = await db.select().from(enrollments).where(
      and2(
        eq2(enrollments.id, input.enrollmentId),
        eq2(enrollments.userId, user.id),
        eq2(enrollments.status, "ACTIVE")
      )
    ).limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }
    const [lesson] = await db.select({ courseId: courseSections.courseId }).from(lessons).innerJoin(
      courseSections,
      eq2(lessons.sectionId, courseSections.id)
    ).where(eq2(lessons.id, input.lessonId)).limit(1);
    if (!lesson || lesson.courseId !== enrollment.courseId) {
      response.status(400).json({ message: "Lesson is not in this course." });
      return;
    }
    const access = await courseAccess(db, user.id, enrollment.courseId);
    if (access.accessLevel === "HALF") {
      const sections = await db.select({ id: courseSections.id }).from(courseSections).where(eq2(courseSections.courseId, enrollment.courseId)).orderBy(asc(courseSections.position));
      const sectionOrder = new Map(sections.map((section, index) => [section.id, index]));
      const unorderedLessons = sections.length ? await db.select({ id: lessons.id, sectionId: lessons.sectionId, position: lessons.position }).from(lessons).where(inArray(lessons.sectionId, sections.map((section) => section.id))).orderBy(asc(lessons.position)) : [];
      const orderedLessons = [...unorderedLessons].sort(
        (a, b) => (sectionOrder.get(a.sectionId) ?? 0) - (sectionOrder.get(b.sectionId) ?? 0) || a.position - b.position
      );
      const lessonIndex = orderedLessons.findIndex((item) => item.id === input.lessonId);
      if (lessonIndex < 0 || lessonIndex >= access.halfPaymentLessonLimit) {
        throw new HttpError(403, "Balance payment approval is required to unlock this lesson.");
      }
    }
    const [saved] = await db.insert(lessonProgress).values({
      enrollmentId: input.enrollmentId,
      lessonId: input.lessonId,
      progressPercent: input.progressPercent,
      completedAt: input.progressPercent === 100 ? /* @__PURE__ */ new Date() : null,
      updatedAt: /* @__PURE__ */ new Date()
    }).onConflictDoUpdate({
      target: [lessonProgress.enrollmentId, lessonProgress.lessonId],
      set: {
        progressPercent: input.progressPercent,
        completedAt: input.progressPercent === 100 ? /* @__PURE__ */ new Date() : null,
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    response.json({ progress: saved });
  })
);
courseRouter.get(
  "/student/quizzes/:id",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [quiz] = await db.select().from(quizzes).where(
      and2(
        eq2(quizzes.id, String(request.params.id)),
        eq2(quizzes.isPublished, true)
      )
    ).limit(1);
    if (!quiz) {
      response.status(404).json({ message: "Quiz not found." });
      return;
    }
    const [enrollment] = await db.select({ id: enrollments.id }).from(enrollments).where(
      and2(
        eq2(enrollments.userId, user.id),
        eq2(enrollments.courseId, quiz.courseId),
        eq2(enrollments.status, "ACTIVE")
      )
    ).limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }
    const questions = await db.select({
      id: quizQuestions.id,
      question: quizQuestions.question,
      options: quizQuestions.options,
      position: quizQuestions.position
    }).from(quizQuestions).where(eq2(quizQuestions.quizId, quiz.id)).orderBy(asc(quizQuestions.position));
    response.json({ quiz, questions });
  })
);
courseRouter.post(
  "/student/quizzes/:id/attempts",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = attemptInput.parse(request.body);
    const db = requireDatabase();
    const [quiz] = await db.select().from(quizzes).where(
      and2(
        eq2(quizzes.id, String(request.params.id)),
        eq2(quizzes.isPublished, true)
      )
    ).limit(1);
    if (!quiz) {
      response.status(404).json({ message: "Quiz not found." });
      return;
    }
    const [enrollment] = await db.select({ id: enrollments.id }).from(enrollments).where(
      and2(
        eq2(enrollments.userId, user.id),
        eq2(enrollments.courseId, quiz.courseId),
        eq2(enrollments.status, "ACTIVE")
      )
    ).limit(1);
    if (!enrollment) {
      response.status(403).json({ message: "Active enrollment required." });
      return;
    }
    const questions = await db.select().from(quizQuestions).where(eq2(quizQuestions.quizId, quiz.id)).orderBy(asc(quizQuestions.position));
    if (questions.length === 0 || input.answers.length !== questions.length) {
      response.status(400).json({ message: "Answer every quiz question." });
      return;
    }
    const correct = questions.reduce(
      (total, question, index) => total + (input.answers[index] === question.correctOption ? 1 : 0),
      0
    );
    const scorePercent = Math.round(correct / questions.length * 100);
    const passed = scorePercent >= quiz.passingPercent;
    const [attempt] = await db.insert(quizAttempts).values({
      quizId: quiz.id,
      userId: user.id,
      answers: input.answers,
      scorePercent,
      passed
    }).returning();
    response.status(201).json({
      attempt,
      explanations: questions.map((question) => ({
        questionId: question.id,
        correctOption: question.correctOption,
        explanation: question.explanation
      }))
    });
  })
);
courseRouter.post(
  "/admin/quizzes",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = quizInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(quizzes).values(input).returning();
    response.status(201).json({ quiz: created });
  })
);
courseRouter.post(
  "/admin/quiz-questions",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = questionInput.parse(request.body);
    if (input.correctOption >= input.options.length) {
      response.status(400).json({ message: "Correct option is out of range." });
      return;
    }
    const db = requireDatabase();
    const [created] = await db.insert(quizQuestions).values(input).returning();
    response.status(201).json({ question: created });
  })
);
courseRouter.post(
  "/admin/courses",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = courseInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(courses).values({
      ...input,
      price: input.price.toFixed(2)
    }).returning();
    response.status(201).json({ course: created });
  })
);
courseRouter.get(
  "/admin/courses",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const courseItems = await db.select().from(courses).orderBy(asc(courses.createdAt));
    const result = await Promise.all(courseItems.map(async (course) => {
      const sections = await db.select().from(courseSections).where(eq2(courseSections.courseId, course.id)).orderBy(asc(courseSections.position));
      const sectionIds = sections.map((section) => section.id);
      const lessonItems = sectionIds.length ? await db.select().from(lessons).where(inArray(lessons.sectionId, sectionIds)).orderBy(asc(lessons.position)) : [];
      return { ...course, sections: sections.map((section) => ({
        ...section,
        lessons: lessonItems.filter((lesson) => lesson.sectionId === section.id)
      })) };
    }));
    response.json({ courses: result });
  })
);
courseRouter.patch(
  "/admin/courses/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const input = courseUpdateInput.parse(request.body);
    const db = requireDatabase();
    const { price, ...courseChanges } = input;
    const [course] = await db.update(courses).set({
      ...courseChanges,
      ...price !== void 0 ? { price: price.toFixed(2) } : {},
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq2(courses.id, String(request.params.id))).returning();
    if (!course) {
      response.status(404).json({ message: "Course not found." });
      return;
    }
    response.json({ course });
  })
);
courseRouter.put(
  "/admin/courses/:id/thumbnail",
  express.raw({ type: ["image/jpeg", "image/png", "image/webp"], limit: "5mb" }),
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    if (!Buffer.isBuffer(request.body) || request.body.length < 10) {
      response.status(400).json({ message: "Course cover image \u0D91\u0D9A\u0D9A\u0DCA \u0DAD\u0DDD\u0DBB\u0DB1\u0DCA\u0DB1." });
      return;
    }
    const db = requireDatabase();
    const [existing] = await db.select({ id: courses.id }).from(courses).where(eq2(courses.id, String(request.params.id))).limit(1);
    if (!existing) {
      response.status(404).json({ message: "Course not found." });
      return;
    }
    const mime = request.headers["content-type"] ?? "image/jpeg";
    const extension = mime.includes("png") ? "png" : mime.includes("webp") ? "webp" : "jpg";
    const key2 = `course-thumbnails/${existing.id}-${crypto2.randomBytes(6).toString("hex")}.${extension}`;
    await uploadPrivateFile(key2, request.body);
    await db.update(courses).set({ thumbnailUrl: key2, updatedAt: /* @__PURE__ */ new Date() }).where(eq2(courses.id, existing.id));
    response.json({ thumbnailUrl: `/api/courses/${existing.id}/thumbnail?v=${Date.now()}` });
  })
);
courseRouter.post(
  "/admin/course-sections",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = sectionInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(courseSections).values(input).returning();
    response.status(201).json({ section: created });
  })
);
courseRouter.post(
  "/admin/lessons",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = lessonInput.parse(request.body);
    const db = requireDatabase();
    const [created] = await db.insert(lessons).values(input).returning();
    response.status(201).json({ lesson: created });
  })
);
courseRouter.patch(
  "/admin/course-sections/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = sectionUpdateInput.parse(request.body);
    const db = requireDatabase();
    const [section] = await db.update(courseSections).set(input).where(eq2(courseSections.id, String(request.params.id))).returning();
    if (!section) {
      response.status(404).json({ message: "Section not found." });
      return;
    }
    response.json({ section });
  })
);
courseRouter.patch(
  "/admin/lessons/:id",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const input = lessonUpdateInput.parse(request.body);
    const db = requireDatabase();
    const [lesson] = await db.update(lessons).set(input).where(eq2(lessons.id, String(request.params.id))).returning();
    if (!lesson) {
      response.status(404).json({ message: "Lesson not found." });
      return;
    }
    response.json({ lesson });
  })
);

// server/modules/payments/routes.ts
import crypto3 from "node:crypto";
import { and as and3, count as count2, desc as desc3, eq as eq3, inArray as inArray2, sql as sql2 } from "drizzle-orm";
import express2, { Router as Router2 } from "express";
import { z as z2 } from "zod";
var paymentRouter = Router2();
var createPaymentInput = z2.object({
  courseId: z2.string().uuid(),
  method: z2.enum(["BANK_TRANSFER", "BINANCE_PAY", "USDT"]),
  paidAmount: z2.coerce.number().positive(),
  transactionReference: z2.string().trim().min(2).max(200),
  receivingAccountId: z2.string().uuid().optional(),
  requestedParentAccountId: z2.string().uuid().optional(),
  requestedSide: z2.enum(["LEFT", "RIGHT"]).optional(),
  couponCode: z2.string().trim().min(2).max(50).optional()
});
var reviewInput = z2.object({
  status: z2.enum(["APPROVED", "PARTIAL", "REJECTED"]),
  note: z2.string().trim().max(1e3).optional()
});
var balancePaymentInput = z2.object({
  transactionReference: z2.string().trim().min(2).max(200)
});
async function awardAdmissionPoints(tx, payment) {
  if (!payment.requestedParentAccountId || !payment.requestedSide) return;
  let beneficiaryAccountId = payment.requestedParentAccountId;
  let side = payment.requestedSide;
  let depth = 0;
  while (beneficiaryAccountId && depth < 100) {
    const inserted = await tx.insert(pointEvents).values({
      idempotencyKey: `payment:${payment.id}:account:${beneficiaryAccountId}`,
      sourcePaymentId: payment.id,
      beneficiaryAccountId,
      side,
      points: 1,
      eventType: "FULL_ADMISSION"
    }).onConflictDoNothing({ target: pointEvents.idempotencyKey }).returning({ id: pointEvents.id });
    if (inserted.length) {
      const left = side === "LEFT" ? 1 : 0;
      const right = side === "RIGHT" ? 1 : 0;
      await tx.insert(accountPointBalances).values({
        accountId: beneficiaryAccountId,
        leftAvailable: left,
        rightAvailable: right,
        lifetimeLeft: left,
        lifetimeRight: right,
        lastQualifiedActivityAt: /* @__PURE__ */ new Date()
      }).onConflictDoUpdate({
        target: accountPointBalances.accountId,
        set: {
          leftAvailable: sql2.raw(`"account_point_balances"."left_available" + ${left}`),
          rightAvailable: sql2.raw(`"account_point_balances"."right_available" + ${right}`),
          lifetimeLeft: sql2.raw(`"account_point_balances"."lifetime_left" + ${left}`),
          lifetimeRight: sql2.raw(`"account_point_balances"."lifetime_right" + ${right}`),
          lastQualifiedActivityAt: /* @__PURE__ */ new Date(),
          updatedAt: /* @__PURE__ */ new Date()
        }
      });
    }
    const [parent] = await tx.select({ parentAccountId: networkPlacements.parentAccountId, side: networkPlacements.side }).from(networkPlacements).where(eq3(networkPlacements.accountId, beneficiaryAccountId)).limit(1);
    beneficiaryAccountId = parent?.parentAccountId ?? null;
    if (parent) side = parent.side;
    depth += 1;
  }
}
var proofMimeExtensions = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "application/pdf": "pdf"
};
function paymentCode() {
  const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "");
  return "PAY-" + day + "-" + crypto3.randomBytes(4).toString("hex").toUpperCase();
}
paymentRouter.post(
  "/payments",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = createPaymentInput.parse(request.body);
    if (Boolean(input.requestedParentAccountId) !== Boolean(input.requestedSide)) {
      throw new HttpError(
        400,
        "Parent account and LEFT/RIGHT side must be selected together."
      );
    }
    const db = requireDatabase();
    const [course] = await db.select().from(courses).where(
      and3(eq3(courses.id, input.courseId), eq3(courses.isPublished, true))
    ).limit(1);
    if (!course) throw new HttpError(404, "Course not found.");
    let coupon;
    let totalAmount = Number(course.price);
    if (input.couponCode) {
      [coupon] = await db.select().from(coupons).where(
        and3(
          eq3(coupons.code, input.couponCode.toUpperCase()),
          eq3(coupons.isActive, true)
        )
      ).limit(1);
      const now = /* @__PURE__ */ new Date();
      if (!coupon || coupon.courseId && coupon.courseId !== course.id || coupon.startsAt && coupon.startsAt > now || coupon.expiresAt && coupon.expiresAt < now) {
        throw new HttpError(400, "Coupon is invalid or expired.");
      }
      if (coupon.maxUses) {
        const [{ uses }] = await db.select({ uses: count2() }).from(couponUses).where(eq3(couponUses.couponId, coupon.id));
        if (uses >= coupon.maxUses) {
          throw new HttpError(400, "Coupon usage limit has been reached.");
        }
      }
      const value = Number(coupon.discountValue);
      totalAmount = coupon.discountType === "PERCENT" ? totalAmount * (1 - Math.min(value, 100) / 100) : Math.max(0, totalAmount - value);
    }
    if (input.receivingAccountId) {
      const [receiving] = await db.select({ id: networkAccounts.id }).from(networkAccounts).where(
        and3(
          eq3(networkAccounts.id, input.receivingAccountId),
          eq3(networkAccounts.status, "ACTIVE")
        )
      ).limit(1);
      if (!receiving) {
        throw new HttpError(400, "Receiving account is not active.");
      }
    }
    const [created] = await db.insert(paymentRequests).values({
      paymentCode: paymentCode(),
      userId: user.id,
      courseId: course.id,
      method: input.method,
      totalAmount: totalAmount.toFixed(2),
      paidAmount: input.paidAmount.toFixed(2),
      transactionReference: input.transactionReference,
      couponId: coupon?.id,
      receivingAccountId: input.receivingAccountId,
      requestedParentAccountId: input.requestedParentAccountId,
      requestedSide: input.requestedSide
    }).returning();
    response.status(201).json({ payment: created });
  })
);
paymentRouter.put(
  "/payments/:id/proof",
  express2.raw({
    type: ["image/jpeg", "image/png", "image/webp", "application/pdf"],
    limit: "8mb"
  }),
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const paymentId = String(request.params.id);
    const [payment] = await db.select().from(paymentRequests).where(
      and3(
        eq3(paymentRequests.id, paymentId),
        eq3(paymentRequests.userId, user.id)
      )
    ).limit(1);
    if (!payment) throw new HttpError(404, "Payment request not found.");
    if (!["PENDING", "UNDER_REVIEW", "PARTIAL"].includes(payment.status)) {
      throw new HttpError(409, "Payment proof is locked.");
    }
    const mimeType = String(request.headers["content-type"] ?? "").split(";")[0];
    const extension = proofMimeExtensions[mimeType];
    if (!extension || !Buffer.isBuffer(request.body) || request.body.length < 1) {
      throw new HttpError(400, "Upload a JPG, PNG, WebP, or PDF proof file.");
    }
    const objectKey = "payment-proofs/" + user.id + "/" + payment.id + "-" + crypto3.randomBytes(6).toString("hex") + "." + extension;
    await uploadPrivateFile(objectKey, request.body);
    const [updated] = await db.update(paymentRequests).set({
      proofObjectKey: objectKey,
      proofMimeType: mimeType,
      status: "UNDER_REVIEW"
    }).where(eq3(paymentRequests.id, payment.id)).returning();
    response.json({ payment: updated });
  })
);
paymentRouter.get(
  "/student/payments",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db.select().from(paymentRequests).where(eq3(paymentRequests.userId, user.id)).orderBy(desc3(paymentRequests.createdAt));
    const payments = await Promise.all(items.map(async ({ proofObjectKey: proof, ...payment }) => {
      const [[student], [account]] = await Promise.all([
        db.select({ name: users.displayName, email: users.email, phone: users.phone }).from(users).where(eq3(users.id, payment.userId)).limit(1),
        db.select({ prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart }).from(networkAccounts).where(and3(eq3(networkAccounts.ownerUserId, payment.userId), eq3(networkAccounts.isMainAccount, true))).limit(1)
      ]);
      return { ...payment, hasProof: Boolean(proof), student: student ?? null, accountNumber: account ? `${account.prefix}${account.numericPart}` : null };
    }));
    response.json({ payments });
  })
);
paymentRouter.get("/student/balance-payment", asyncRoute(async (request, response) => {
  const user = await requireAuthenticatedUser(request);
  const db = requireDatabase();
  const [original] = await db.select({ payment: paymentRequests, course: courses }).from(paymentRequests).innerJoin(courses, eq3(courses.id, paymentRequests.courseId)).where(and3(eq3(paymentRequests.userId, user.id), eq3(paymentRequests.status, "PARTIAL"))).orderBy(desc3(paymentRequests.createdAt)).limit(1);
  if (!original) {
    response.json({ eligible: false, outstandingAmount: 0, request: null });
    return;
  }
  const [latest] = await db.select().from(balancePaymentRequests).where(eq3(balancePaymentRequests.originalPaymentId, original.payment.id)).orderBy(desc3(balancePaymentRequests.createdAt)).limit(1);
  response.json({
    eligible: true,
    originalPaymentId: original.payment.id,
    courseId: original.course.id,
    courseTitle: original.course.title,
    halfPaymentLessonLimit: original.course.halfPaymentLessonLimit,
    outstandingAmount: Math.max(0, Number(original.payment.totalAmount) - Number(original.payment.paidAmount)),
    request: latest ? { ...latest, proofObjectKey: void 0, hasProof: Boolean(latest.proofObjectKey) } : null
  });
}));
paymentRouter.post("/student/balance-payments", asyncRoute(async (request, response) => {
  const user = await requireAuthenticatedUser(request);
  const input = balancePaymentInput.parse(request.body);
  const db = requireDatabase();
  const created = await db.transaction(async (tx) => {
    const [original] = await tx.select().from(paymentRequests).where(and3(eq3(paymentRequests.userId, user.id), eq3(paymentRequests.status, "PARTIAL"))).orderBy(desc3(paymentRequests.createdAt)).limit(1);
    if (!original?.courseId) throw new HttpError(409, "No half-payment course balance is available.");
    const [open] = await tx.select().from(balancePaymentRequests).where(and3(eq3(balancePaymentRequests.originalPaymentId, original.id), inArray2(balancePaymentRequests.status, ["PENDING", "UNDER_REVIEW", "APPROVED"]))).limit(1);
    if (open) throw new HttpError(409, open.status === "APPROVED" ? "Balance payment is already approved." : "A balance payment request is already pending.");
    const amount = Number(original.totalAmount) - Number(original.paidAmount);
    if (amount <= 0) throw new HttpError(409, "No outstanding balance remains.");
    const [item] = await tx.insert(balancePaymentRequests).values({
      originalPaymentId: original.id,
      userId: user.id,
      courseId: original.courseId,
      amount: amount.toFixed(2),
      transactionReference: input.transactionReference
    }).returning();
    return item;
  });
  response.status(201).json({ request: created });
}));
paymentRouter.put("/student/balance-payments/:id/proof", express2.raw({
  type: ["image/jpeg", "image/png", "image/webp", "application/pdf"],
  limit: "8mb"
}), asyncRoute(async (request, response) => {
  const user = await requireAuthenticatedUser(request);
  const db = requireDatabase();
  const [item] = await db.select().from(balancePaymentRequests).where(and3(
    eq3(balancePaymentRequests.id, String(request.params.id)),
    eq3(balancePaymentRequests.userId, user.id)
  )).limit(1);
  if (!item) throw new HttpError(404, "Balance payment request not found.");
  if (item.status !== "PENDING") throw new HttpError(409, "This balance payment proof is locked.");
  const mimeType = String(request.headers["content-type"] ?? "").split(";")[0];
  const extension = proofMimeExtensions[mimeType];
  if (!extension || !Buffer.isBuffer(request.body) || request.body.length < 1) throw new HttpError(400, "Upload a JPG, PNG, WebP, or PDF proof file.");
  const objectKey = `balance-payment-proofs/${user.id}/${item.id}-${crypto3.randomBytes(6).toString("hex")}.${extension}`;
  await uploadPrivateFile(objectKey, request.body);
  const [updated] = await db.update(balancePaymentRequests).set({ proofObjectKey: objectKey, proofMimeType: mimeType, status: "UNDER_REVIEW", updatedAt: /* @__PURE__ */ new Date() }).where(eq3(balancePaymentRequests.id, item.id)).returning();
  response.json({ request: updated });
}));
paymentRouter.get("/admin/balance-payments", asyncRoute(async (request, response) => {
  await requireRole(request, ["staff", "admin"]);
  const db = requireDatabase();
  const rows = await db.select({ request: balancePaymentRequests, student: users, course: courses, original: paymentRequests }).from(balancePaymentRequests).innerJoin(users, eq3(users.id, balancePaymentRequests.userId)).innerJoin(courses, eq3(courses.id, balancePaymentRequests.courseId)).innerJoin(paymentRequests, eq3(paymentRequests.id, balancePaymentRequests.originalPaymentId)).orderBy(desc3(balancePaymentRequests.createdAt));
  response.json({ requests: rows.map(({ request: item, student, course, original }) => ({
    ...item,
    proofObjectKey: void 0,
    hasProof: Boolean(item.proofObjectKey),
    student: { name: student.displayName, email: student.email, phone: student.phone },
    course: { id: course.id, title: course.title },
    originalPaymentCode: original.paymentCode
  })) });
}));
paymentRouter.get("/admin/balance-payments/:id/proof", asyncRoute(async (request, response) => {
  await requireRole(request, ["staff", "admin"]);
  const db = requireDatabase();
  const [item] = await db.select().from(balancePaymentRequests).where(eq3(balancePaymentRequests.id, String(request.params.id))).limit(1);
  if (!item?.proofObjectKey) throw new HttpError(404, "Balance payment proof not found.");
  response.type(item.proofMimeType ?? "application/octet-stream").send(await downloadPrivateFile(item.proofObjectKey));
}));
paymentRouter.post("/admin/balance-payments/:id/review", asyncRoute(async (request, response) => {
  const reviewer = await requireRole(request, ["staff", "admin"]);
  const input = z2.object({ status: z2.enum(["APPROVED", "REJECTED"]), note: z2.string().trim().max(1e3).optional() }).parse(request.body);
  const db = requireDatabase();
  const result = await db.transaction(async (tx) => {
    const [item] = await tx.select().from(balancePaymentRequests).where(eq3(balancePaymentRequests.id, String(request.params.id))).limit(1);
    if (!item) throw new HttpError(404, "Balance payment request not found.");
    if (!["PENDING", "UNDER_REVIEW"].includes(item.status)) throw new HttpError(409, "Balance payment request is already finalized.");
    if (input.status === "APPROVED" && !item.proofObjectKey) throw new HttpError(400, "Payment proof is required.");
    const [original] = await tx.select().from(paymentRequests).where(eq3(paymentRequests.id, item.originalPaymentId)).limit(1);
    if (!original) throw new HttpError(404, "Original payment not found.");
    const [updated] = await tx.update(balancePaymentRequests).set({ status: input.status, reviewNote: input.note, reviewedBy: reviewer.id, reviewedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq3(balancePaymentRequests.id, item.id)).returning();
    if (input.status === "REJECTED") {
      await tx.insert(notifications).values({ userId: item.userId, type: "BALANCE_PAYMENT_REJECTED", title: "Balance payment rejected", message: "Please check the payment details and submit a new proof." });
      return updated;
    }
    if (original.status !== "PARTIAL") throw new HttpError(409, "Original payment is no longer awaiting a balance.");
    await tx.update(paymentRequests).set({ status: "APPROVED", paidAmount: original.totalAmount, reviewedBy: reviewer.id, reviewedAt: /* @__PURE__ */ new Date(), reviewNote: "Balance payment approved" }).where(eq3(paymentRequests.id, original.id));
    await tx.insert(enrollments).values({ userId: original.userId, courseId: item.courseId, status: "ACTIVE" }).onConflictDoUpdate({ target: [enrollments.userId, enrollments.courseId], set: { status: "ACTIVE" } });
    await awardAdmissionPoints(tx, original);
    await tx.insert(notifications).values({ userId: item.userId, type: "BALANCE_PAYMENT_APPROVED", title: "Course fully unlocked", message: "Your balance payment was approved. All lessons are now available." });
    await tx.insert(auditLogs).values({ actorUserId: reviewer.id, action: "BALANCE_PAYMENT_APPROVED", entityType: "balance_payment_request", entityId: item.id, metadata: { originalPaymentId: original.id, pointsProtectedBy: "pointEvents.idempotencyKey" } });
    return updated;
  });
  response.json({ request: result });
}));
paymentRouter.get(
  "/admin/payments",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const status = z2.enum([
      "PENDING",
      "UNDER_REVIEW",
      "PARTIAL",
      "APPROVED",
      "REJECTED",
      "REFUNDED"
    ]).optional().parse(request.query.status);
    const items = status ? await db.select().from(paymentRequests).where(eq3(paymentRequests.status, status)).orderBy(desc3(paymentRequests.createdAt)) : await db.select().from(paymentRequests).orderBy(desc3(paymentRequests.createdAt));
    const payments = await Promise.all(items.map(async ({ proofObjectKey: proof, ...payment }) => {
      const [[student], [account], [placementConsultant]] = await Promise.all([
        db.select({ name: users.displayName, email: users.email, phone: users.phone }).from(users).where(eq3(users.id, payment.userId)).limit(1),
        db.select({ prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart }).from(networkAccounts).where(and3(eq3(networkAccounts.ownerUserId, payment.userId), eq3(networkAccounts.isMainAccount, true))).limit(1),
        payment.requestedParentAccountId ? db.select({
          id: users.id,
          name: users.displayName,
          email: users.email,
          phone: users.phone,
          prefix: networkAccounts.prefix,
          numericPart: networkAccounts.numericPart
        }).from(networkAccounts).innerJoin(users, eq3(users.id, networkAccounts.ownerUserId)).where(eq3(networkAccounts.id, payment.requestedParentAccountId)).limit(1) : Promise.resolve([])
      ]);
      return {
        ...payment,
        hasProof: Boolean(proof),
        student: student ?? null,
        accountNumber: account ? `${account.prefix}${account.numericPart}` : null,
        placementConsultant: placementConsultant ? {
          id: placementConsultant.id,
          name: placementConsultant.name,
          email: placementConsultant.email,
          phone: placementConsultant.phone,
          accountNumber: `${placementConsultant.prefix}${placementConsultant.numericPart}`,
          side: payment.requestedSide
        } : null
      };
    }));
    response.json({ payments });
  })
);
paymentRouter.get(
  "/admin/payments/:id/proof",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const [payment] = await db.select({
      proofObjectKey: paymentRequests.proofObjectKey,
      proofMimeType: paymentRequests.proofMimeType
    }).from(paymentRequests).where(eq3(paymentRequests.id, String(request.params.id))).limit(1);
    if (!payment?.proofObjectKey) {
      throw new HttpError(404, "Payment proof not found.");
    }
    const bytes = await downloadPrivateFile(payment.proofObjectKey);
    response.type(payment.proofMimeType ?? "application/octet-stream");
    response.send(bytes);
  })
);
paymentRouter.post(
  "/admin/payments/:id/undo-rejection",
  asyncRoute(async (request, response) => {
    const reviewer = await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const paymentId = String(request.params.id);
    const result = await db.transaction(async (tx) => {
      const [payment] = await tx.select().from(paymentRequests).where(eq3(paymentRequests.id, paymentId)).limit(1);
      if (!payment) throw new HttpError(404, "Payment request not found.");
      if (payment.status !== "REJECTED") throw new HttpError(409, "Rejected payment \u0D91\u0D9A\u0D9A\u0DCA \u0DB4\u0DB8\u0DAB\u0D9A\u0DCA undo \u0D9A\u0DC5 \u0DC4\u0DD0\u0D9A.");
      const [updated] = await tx.update(paymentRequests).set({
        status: "UNDER_REVIEW",
        reviewNote: null,
        reviewedBy: null,
        reviewedAt: null
      }).where(eq3(paymentRequests.id, payment.id)).returning();
      await tx.insert(auditLogs).values({
        actorUserId: reviewer.id,
        action: "PAYMENT_REJECTION_UNDONE",
        entityType: "payment_request",
        entityId: payment.id,
        metadata: { previousStatus: "REJECTED", newStatus: "UNDER_REVIEW" }
      });
      return updated;
    });
    response.json({ payment: result, message: "Rejection undo \u0D9A\u0DC5\u0DCF. Payment \u0D91\u0D9A \u0DB1\u0DD0\u0DC0\u0DAD review \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1 \u0DB4\u0DD4\u0DC5\u0DD4\u0DC0\u0DB1\u0DCA." });
  })
);
paymentRouter.post(
  "/admin/payments/:id/review",
  asyncRoute(async (request, response) => {
    const reviewer = await requireRole(request, ["staff", "admin"]);
    const input = reviewInput.parse(request.body);
    const db = requireDatabase();
    const paymentId = String(request.params.id);
    const result = await db.transaction(async (tx) => {
      const [payment] = await tx.select().from(paymentRequests).where(eq3(paymentRequests.id, paymentId)).limit(1);
      if (!payment) throw new HttpError(404, "Payment request not found.");
      if (["APPROVED", "REJECTED", "REFUNDED"].includes(payment.status)) {
        throw new HttpError(409, "Payment request is already finalized.");
      }
      if (input.status === "APPROVED") {
        if (!payment.proofObjectKey) {
          throw new HttpError(400, "Payment proof is required.");
        }
        if (Number(payment.paidAmount) < Number(payment.totalAmount)) {
          throw new HttpError(400, "Full payment is required for approval.");
        }
        if (!payment.payIdId) {
          throw new HttpError(400, "A valid Pay ID is required for approval.");
        }
        const [payId] = await tx.select().from(paymentReferenceIds).where(eq3(paymentReferenceIds.id, payment.payIdId)).limit(1);
        if (!payId?.usedAt || payId.code !== payment.transactionReference) {
          throw new HttpError(400, "Bank reference must exactly match the verified Pay ID.");
        }
      }
      const [updatedPayment] = await tx.update(paymentRequests).set({
        status: input.status,
        reviewNote: input.note,
        reviewedBy: reviewer.id,
        reviewedAt: /* @__PURE__ */ new Date()
      }).where(eq3(paymentRequests.id, payment.id)).returning();
      if (qualifiesForDirectAdmissionIncome(input.status)) {
        const beneficiaryId = payment.requestedParentAccountId ?? payment.receivingAccountId;
        if (beneficiaryId) {
          const [beneficiary] = await tx.select({ ownerUserId: networkAccounts.ownerUserId, prefix: networkAccounts.prefix, ownerRole: users.role }).from(networkAccounts).innerJoin(users, eq3(users.id, networkAccounts.ownerUserId)).where(and3(eq3(networkAccounts.id, beneficiaryId), eq3(networkAccounts.status, "ACTIVE"))).limit(1);
          if (beneficiary?.prefix === "CN" && beneficiary.ownerRole === "consultant") {
            await tx.insert(wallets).values({ userId: beneficiary.ownerUserId }).onConflictDoNothing({ target: wallets.userId });
            const [wallet] = await tx.select().from(wallets).where(eq3(wallets.userId, beneficiary.ownerUserId)).limit(1);
            const inserted = await tx.insert(walletLedger).values({
              walletId: wallet.id,
              idempotencyKey: `direct-admission:${payment.id}`,
              entryType: "DIRECT_ADMISSION_INCOME",
              amount: DIRECT_ADMISSION_INCOME.toFixed(2),
              referenceType: "payment_request",
              referenceId: payment.id,
              note: `${updatedPayment.status} direct admission \u2022 ${payment.paymentCode}`
            }).onConflictDoNothing({ target: walletLedger.idempotencyKey }).returning({ id: walletLedger.id });
            if (inserted.length) {
              await tx.update(wallets).set({ pendingBalance: sql2`${wallets.pendingBalance} + ${DIRECT_ADMISSION_INCOME}`, updatedAt: /* @__PURE__ */ new Date() }).where(eq3(wallets.id, wallet.id));
              await tx.insert(notifications).values({ userId: beneficiary.ownerUserId, type: "DIRECT_ADMISSION_INCOME", title: "Rs. 3,000 direct admission income", message: `${payment.paymentCode} \u0DC3\u0DB3\u0DC4\u0DCF direct admission income \u0D91\u0D9A pending wallet \u0D91\u0D9A\u0DA7 \u0D91\u0D9A\u0DAD\u0DD4 \u0DC0\u0DD2\u0DBA.` });
            }
          }
        }
      }
      if (input.status === "PARTIAL" && payment.courseId) {
        await tx.insert(enrollments).values({ userId: payment.userId, courseId: payment.courseId, status: "ACTIVE" }).onConflictDoUpdate({ target: [enrollments.userId, enrollments.courseId], set: { status: "ACTIVE" } });
        await tx.insert(notifications).values({
          userId: payment.userId,
          type: "HALF_PAYMENT_APPROVED",
          title: "Half payment approved",
          message: "Your first course lessons are unlocked. Complete the balance payment to unlock all lessons."
        });
      }
      if (input.status !== "APPROVED" || !payment.courseId) {
        await tx.insert(auditLogs).values({
          actorUserId: reviewer.id,
          action: "PAYMENT_" + input.status,
          entityType: "payment_request",
          entityId: payment.id,
          metadata: { note: input.note ?? null }
        });
        return { payment: updatedPayment, account: null };
      }
      await tx.insert(enrollments).values({
        userId: payment.userId,
        courseId: payment.courseId,
        status: "ACTIVE"
      }).onConflictDoNothing({
        target: [enrollments.userId, enrollments.courseId]
      });
      let [account] = await tx.select().from(networkAccounts).where(
        and3(
          eq3(networkAccounts.ownerUserId, payment.userId),
          eq3(networkAccounts.isMainAccount, true)
        )
      ).limit(1);
      if (!account) {
        await tx.insert(accountNumberSequence).values({ id: 1, nextNumber: 527694 }).onConflictDoNothing();
        const [highest] = await tx.select({ numericPart: networkAccounts.numericPart }).from(networkAccounts).orderBy(desc3(networkAccounts.numericPart)).limit(1);
        const nextBlock = nextStudentAccountNumber(highest?.numericPart);
        const [sequence] = await tx.update(accountNumberSequence).set({
          nextNumber: sql2`GREATEST(${accountNumberSequence.nextNumber}, ${nextBlock}) + ${ACCOUNT_BLOCK_SIZE}`,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq3(accountNumberSequence.id, 1)).returning({ nextNumber: accountNumberSequence.nextNumber });
        const allocatedNumber = sequence.nextNumber - ACCOUNT_BLOCK_SIZE;
        [account] = await tx.insert(networkAccounts).values({
          ownerUserId: payment.userId,
          prefix: "SR",
          numericPart: allocatedNumber,
          status: "ACTIVE",
          isMainAccount: true,
          activatedAt: /* @__PURE__ */ new Date()
        }).returning();
        if (payment.requestedParentAccountId && payment.requestedSide) {
          await tx.insert(networkPlacements).values({
            accountId: account.id,
            parentAccountId: payment.requestedParentAccountId,
            side: payment.requestedSide,
            placedByUserId: reviewer.id
          });
        }
      } else if (account.status !== "ACTIVE") {
        [account] = await tx.update(networkAccounts).set({
          status: "ACTIVE",
          activatedAt: /* @__PURE__ */ new Date()
        }).where(eq3(networkAccounts.id, account.id)).returning();
      }
      if (payment.requestedParentAccountId && payment.requestedSide) {
        const [existingPlacement] = await tx.select({ id: networkPlacements.id }).from(networkPlacements).where(eq3(networkPlacements.accountId, account.id)).limit(1);
        if (!existingPlacement) await tx.insert(networkPlacements).values({
          accountId: account.id,
          parentAccountId: payment.requestedParentAccountId,
          side: payment.requestedSide,
          placedByUserId: reviewer.id
        });
      }
      if (payment.requestedParentAccountId && payment.requestedSide) {
        let beneficiaryAccountId = payment.requestedParentAccountId;
        let side = payment.requestedSide;
        let depth = 0;
        while (beneficiaryAccountId && depth < 100) {
          const idempotencyKey = "payment:" + payment.id + ":account:" + beneficiaryAccountId;
          const insertedPoint = await tx.insert(pointEvents).values({
            idempotencyKey,
            sourcePaymentId: payment.id,
            beneficiaryAccountId,
            side,
            points: 1,
            eventType: "FULL_ADMISSION"
          }).onConflictDoNothing({
            target: pointEvents.idempotencyKey
          }).returning({ id: pointEvents.id });
          if (insertedPoint.length) {
            const leftPoints = side === "LEFT" ? 1 : 0;
            const rightPoints = side === "RIGHT" ? 1 : 0;
            await tx.insert(accountPointBalances).values({
              accountId: beneficiaryAccountId,
              leftAvailable: leftPoints,
              rightAvailable: rightPoints,
              lifetimeLeft: leftPoints,
              lifetimeRight: rightPoints,
              lastQualifiedActivityAt: /* @__PURE__ */ new Date()
            }).onConflictDoUpdate({
              target: accountPointBalances.accountId,
              set: {
                leftAvailable: sql2.raw(
                  '"account_point_balances"."left_available" + ' + String(leftPoints)
                ),
                rightAvailable: sql2.raw(
                  '"account_point_balances"."right_available" + ' + String(rightPoints)
                ),
                lifetimeLeft: sql2.raw(
                  '"account_point_balances"."lifetime_left" + ' + String(leftPoints)
                ),
                lifetimeRight: sql2.raw(
                  '"account_point_balances"."lifetime_right" + ' + String(rightPoints)
                ),
                lastQualifiedActivityAt: /* @__PURE__ */ new Date(),
                updatedAt: /* @__PURE__ */ new Date()
              }
            });
          }
          const [parentPlacement] = await tx.select({
            parentAccountId: networkPlacements.parentAccountId,
            side: networkPlacements.side
          }).from(networkPlacements).where(eq3(networkPlacements.accountId, beneficiaryAccountId)).limit(1);
          beneficiaryAccountId = parentPlacement?.parentAccountId ?? null;
          if (parentPlacement) side = parentPlacement.side;
          depth += 1;
        }
      }
      await tx.insert(notifications).values({
        userId: payment.userId,
        type: "PAYMENT_APPROVED",
        title: "Payment approved",
        message: "Your course access and student account are now active."
      });
      if (payment.couponId) {
        await tx.insert(couponUses).values({
          couponId: payment.couponId,
          userId: payment.userId,
          paymentRequestId: payment.id
        }).onConflictDoNothing({ target: couponUses.paymentRequestId });
      }
      await tx.insert(auditLogs).values({
        actorUserId: reviewer.id,
        action: "PAYMENT_APPROVED",
        entityType: "payment_request",
        entityId: payment.id,
        metadata: {
          enrollmentCourseId: payment.courseId,
          accountId: account.id
        }
      });
      return { payment: updatedPayment, account };
    });
    let otpEmailSent = false;
    if (["APPROVED", "PARTIAL"].includes(result.payment.status)) {
      try {
        await createAndSendVerificationCode(result.payment.userId);
        otpEmailSent = true;
      } catch (error) {
        console.error("Payment approved but OTP email failed", error);
      }
    }
    response.json({ ...result, otpEmailSent });
  })
);
paymentRouter.post("/admin/payments/:id/repair-point", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const paymentId = z2.string().uuid().parse(request.params.id);
  const db = requireDatabase();
  const result = await db.transaction(async (tx) => {
    const [payment] = await tx.select().from(paymentRequests).where(eq3(paymentRequests.id, paymentId)).limit(1);
    if (!payment) throw new HttpError(404, "Payment \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
    if (payment.status !== "APPROVED" || Number(payment.paidAmount) < Number(payment.totalAmount)) throw new HttpError(409, "Full approved payment \u0D91\u0D9A\u0D9A\u0DA7 \u0DB4\u0DB8\u0DAB\u0D9A\u0DCA point add \u0D9A\u0DC5 \u0DC4\u0DD0\u0D9A.");
    if (!payment.requestedParentAccountId || !payment.requestedSide) throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 payment \u0D91\u0D9A\u0DA7 consultant CN placement side \u0D91\u0D9A\u0D9A\u0DCA \u0DC3\u0DB8\u0DCA\u0DB6\u0DB1\u0DCA\u0DB0 \u0DC0\u0DD3 \u0DB1\u0DD0\u0DC4\u0DD0.");
    let beneficiaryAccountId = payment.requestedParentAccountId;
    let side = payment.requestedSide;
    let added = 0;
    let depth = 0;
    while (beneficiaryAccountId && depth < 100) {
      const inserted = await tx.insert(pointEvents).values({
        idempotencyKey: `payment:${payment.id}:account:${beneficiaryAccountId}`,
        sourcePaymentId: payment.id,
        beneficiaryAccountId,
        side,
        points: 1,
        eventType: "FULL_ADMISSION"
      }).onConflictDoNothing({ target: pointEvents.idempotencyKey }).returning({ id: pointEvents.id });
      if (inserted.length) {
        const leftPoints = side === "LEFT" ? 1 : 0;
        const rightPoints = side === "RIGHT" ? 1 : 0;
        await tx.insert(accountPointBalances).values({ accountId: beneficiaryAccountId, leftAvailable: leftPoints, rightAvailable: rightPoints, lifetimeLeft: leftPoints, lifetimeRight: rightPoints, lastQualifiedActivityAt: /* @__PURE__ */ new Date() }).onConflictDoUpdate({ target: accountPointBalances.accountId, set: { leftAvailable: sql2.raw(`"account_point_balances"."left_available" + ${leftPoints}`), rightAvailable: sql2.raw(`"account_point_balances"."right_available" + ${rightPoints}`), lifetimeLeft: sql2.raw(`"account_point_balances"."lifetime_left" + ${leftPoints}`), lifetimeRight: sql2.raw(`"account_point_balances"."lifetime_right" + ${rightPoints}`), lastQualifiedActivityAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() } });
        added += 1;
      }
      const [parent] = await tx.select({ parentAccountId: networkPlacements.parentAccountId, side: networkPlacements.side }).from(networkPlacements).where(eq3(networkPlacements.accountId, beneficiaryAccountId)).limit(1);
      beneficiaryAccountId = parent?.parentAccountId ?? null;
      if (parent) side = parent.side;
      depth += 1;
    }
    await tx.insert(auditLogs).values({ actorUserId: admin.id, action: "FULL_ADMISSION_POINT_REPAIRED", entityType: "payment_request", entityId: payment.id, metadata: { added } });
    return { added, message: added ? `Missing admission point ${added} account(s) \u0DC3\u0DB3\u0DC4\u0DCF add \u0DC0\u0DD2\u0DBA.` : "Point \u0D91\u0D9A \u0D9A\u0DBD\u0DD2\u0DB1\u0DCA\u0DB8 add \u0DC0\u0DD3 \u0D87\u0DAD; duplicate point \u0D91\u0D9A\u0D9A\u0DCA add \u0D9A\u0DC5\u0DDA \u0DB1\u0DD0\u0DC4\u0DD0." };
  });
  response.json(result);
}));

// server/modules/consultants/routes.ts
import crypto5 from "node:crypto";
import { and as and4, desc as desc4, eq as eq4, gt as gt2, inArray as inArray3, isNull as isNull2, lte } from "drizzle-orm";
import express3, { Router as Router3 } from "express";
import { z as z3 } from "zod";

// server/services/bank-details.ts
import crypto4 from "node:crypto";
function key() {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 16) throw new Error("SESSION_SECRET_REQUIRED");
  return crypto4.createHash("sha256").update(secret).digest();
}
function encryptBankAccount(value) {
  const iv = crypto4.randomBytes(12);
  const cipher = crypto4.createCipheriv("aes-256-gcm", key(), iv);
  const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return [iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), encrypted.toString("base64url")].join(".");
}
function decryptBankAccount(value) {
  const [iv, tag, encrypted] = value.split(".");
  if (!iv || !tag || !encrypted) throw new Error("INVALID_BANK_DETAILS");
  const decipher = crypto4.createDecipheriv("aes-256-gcm", key(), Buffer.from(iv, "base64url"));
  decipher.setAuthTag(Buffer.from(tag, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(encrypted, "base64url")), decipher.final()]).toString("utf8");
}

// server/modules/consultants/routes.ts
var consultantRouter = Router3();
var COLOMBO_OFFSET_MS = 330 * 60 * 1e3;
function colomboDate(date) {
  return new Date(date.getTime() + COLOMBO_OFFSET_MS);
}
function dateKey(date) {
  return colomboDate(date).toISOString().slice(0, 10);
}
function weekKey(date) {
  const local = colomboDate(date);
  const day = local.getUTCDay() || 7;
  local.setUTCDate(local.getUTCDate() - day + 1);
  return local.toISOString().slice(0, 10);
}
function monthKey(date) {
  return colomboDate(date).toISOString().slice(0, 7);
}
function periodKey(date, period) {
  return period === "daily" ? dateKey(date) : period === "weekly" ? weekKey(date) : monthKey(date);
}
function earningTrend(rows, period) {
  const count4 = period === "daily" ? 14 : period === "weekly" ? 10 : 12;
  const totals = /* @__PURE__ */ new Map();
  for (const row of rows) totals.set(periodKey(row.createdAt, period), (totals.get(periodKey(row.createdAt, period)) ?? 0) + Number(row.amount));
  const points = [];
  const now = /* @__PURE__ */ new Date();
  for (let offset = count4 - 1; offset >= 0; offset--) {
    const cursor = new Date(now);
    if (period === "daily") cursor.setUTCDate(cursor.getUTCDate() - offset);
    else if (period === "weekly") cursor.setUTCDate(cursor.getUTCDate() - offset * 7);
    else {
      cursor.setUTCDate(1);
      cursor.setUTCMonth(cursor.getUTCMonth() - offset);
    }
    const key2 = periodKey(cursor, period);
    const local = colomboDate(cursor);
    const label = period === "daily" ? local.toLocaleDateString("en-LK", { timeZone: "UTC", month: "short", day: "numeric" }) : period === "weekly" ? `W ${(/* @__PURE__ */ new Date(`${key2}T00:00:00Z`)).toLocaleDateString("en-LK", { timeZone: "UTC", month: "short", day: "numeric" })}` : local.toLocaleDateString("en-LK", { timeZone: "UTC", month: "short", year: "2-digit" });
    points.push({ key: key2, label, amount: totals.get(key2) ?? 0 });
  }
  const current = points.at(-1)?.amount ?? 0;
  const previous = points.at(-2)?.amount ?? 0;
  const best = points.reduce((winner, point) => point.amount > winner.amount ? point : winner, points[0]);
  const changePercent = previous > 0 ? Math.round((current - previous) / previous * 100) : current > 0 ? 100 : 0;
  return { points, current, previous, bestAmount: best?.amount ?? 0, bestLabel: best?.label ?? "\u2014", changePercent };
}
var bankDetailsInput = z3.object({
  bankName: z3.string().trim().min(2).max(100),
  branchName: z3.string().trim().min(2).max(100),
  accountHolderName: z3.string().trim().min(2).max(150),
  accountNumber: z3.string().trim().regex(/^[0-9A-Za-z-]{5,34}$/)
});
async function admissionSnapshot() {
  const db = requireDatabase();
  const rows = await db.select({
    ownerUserId: networkAccounts.ownerUserId,
    paidAmount: paymentRequests.paidAmount,
    totalAmount: paymentRequests.totalAmount,
    createdAt: paymentRequests.reviewedAt,
    fallbackCreatedAt: paymentRequests.createdAt
  }).from(paymentRequests).innerJoin(networkAccounts, eq4(networkAccounts.id, paymentRequests.requestedParentAccountId)).where(eq4(paymentRequests.status, "APPROVED"));
  return rows.filter((row) => Number(row.paidAmount) >= Number(row.totalAmount)).map((row) => ({
    ownerUserId: row.ownerUserId,
    createdAt: row.createdAt ?? row.fallbackCreatedAt
  }));
}
consultantRouter.get("/consultant/admission-targets", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const [target] = await db.select().from(consultantAdmissionTargets).where(eq4(consultantAdmissionTargets.userId, consultant.id)).limit(1);
  const admissions = (await admissionSnapshot()).filter((item) => item.ownerUserId === consultant.id);
  const now = /* @__PURE__ */ new Date();
  const count4 = (period) => admissions.filter((item) => periodKey(item.createdAt, period) === periodKey(now, period)).length;
  const targets = { daily: target?.dailyTarget ?? 0, weekly: target?.weeklyTarget ?? 0, monthly: target?.monthlyTarget ?? 0 };
  const progress = { daily: count4("daily"), weekly: count4("weekly"), monthly: count4("monthly") };
  response.json({ targets, progress, achieved: { daily: targets.daily > 0 && progress.daily >= targets.daily, weekly: targets.weekly > 0 && progress.weekly >= targets.weekly, monthly: targets.monthly > 0 && progress.monthly >= targets.monthly } });
}));
consultantRouter.put("/consultant/admission-targets", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const input = z3.object({ daily: z3.number().int().min(0).max(1e4), weekly: z3.number().int().min(0).max(1e4), monthly: z3.number().int().min(0).max(1e4) }).parse(request.body);
  await db.insert(consultantAdmissionTargets).values({ userId: consultant.id, dailyTarget: input.daily, weeklyTarget: input.weekly, monthlyTarget: input.monthly }).onConflictDoUpdate({ target: consultantAdmissionTargets.userId, set: { dailyTarget: input.daily, weeklyTarget: input.weekly, monthlyTarget: input.monthly, updatedAt: /* @__PURE__ */ new Date() } });
  response.json({ message: "Admission targets saved." });
}));
consultantRouter.get("/consultant/profile", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const [profile] = await db.select({ id: users.id, name: users.displayName, email: users.email, phone: users.phone, hasPhoto: users.profilePhotoObjectKey }).from(users).where(eq4(users.id, consultant.id)).limit(1);
  response.json({ ...profile, photoUrl: profile?.hasPhoto ? `/api/consultant/profile-photo/${consultant.id}` : null });
}));
consultantRouter.put("/consultant/profile-photo", express3.raw({ type: ["image/jpeg", "image/png", "image/webp"], limit: "5mb" }), asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  if (!Buffer.isBuffer(request.body) || request.body.length < 10) throw new HttpError(400, "Profile image \u0D91\u0D9A\u0D9A\u0DCA \u0DAD\u0DDD\u0DBB\u0DB1\u0DCA\u0DB1.");
  const mime = request.headers["content-type"] ?? "image/jpeg";
  const extension = mime.includes("png") ? "png" : mime.includes("webp") ? "webp" : "jpg";
  const key2 = `consultant-profile-photos/${consultant.id}-${crypto5.randomBytes(6).toString("hex")}.${extension}`;
  await uploadPrivateFile(key2, request.body);
  const db = requireDatabase();
  await db.update(users).set({ profilePhotoObjectKey: key2, profilePhotoMimeType: mime, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(users.id, consultant.id));
  response.json({ photoUrl: `/api/consultant/profile-photo/${consultant.id}?v=${Date.now()}` });
}));
consultantRouter.delete("/consultant/profile-photo", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  await db.update(users).set({ profilePhotoObjectKey: null, profilePhotoMimeType: null, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(users.id, consultant.id));
  response.json({ message: "Profile photo removed." });
}));
consultantRouter.get("/consultant/profile-photo/:userId", asyncRoute(async (request, response) => {
  await requireAuthenticatedUser(request);
  const db = requireDatabase();
  const [profile] = await db.select({ key: users.profilePhotoObjectKey, mime: users.profilePhotoMimeType }).from(users).where(eq4(users.id, String(request.params.userId))).limit(1);
  if (!profile?.key) throw new HttpError(404, "Profile photo not found.");
  response.type(profile.mime ?? "image/jpeg").set("Cache-Control", "private, max-age=300").send(await downloadPrivateFile(profile.key));
}));
consultantRouter.get("/consultant/admission-heroes", asyncRoute(async (request, response) => {
  await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const [consultants, targets, admissions] = await Promise.all([
    db.select({ id: users.id, name: users.displayName, accountNumericPart: networkAccounts.numericPart, hasPhoto: users.profilePhotoObjectKey }).from(users).leftJoin(networkAccounts, and4(eq4(networkAccounts.ownerUserId, users.id), eq4(networkAccounts.prefix, "CN"), eq4(networkAccounts.isMainAccount, true))).where(and4(eq4(users.role, "consultant"), eq4(users.isActive, true))),
    db.select().from(consultantAdmissionTargets),
    admissionSnapshot()
  ]);
  const now = /* @__PURE__ */ new Date();
  const targetMap = new Map(targets.map((item) => [item.userId, item]));
  const heroes = consultants.map((person) => {
    const own = admissions.filter((item) => item.ownerUserId === person.id);
    const counts = { daily: own.filter((x) => dateKey(x.createdAt) === dateKey(now)).length, weekly: own.filter((x) => weekKey(x.createdAt) === weekKey(now)).length, monthly: own.filter((x) => monthKey(x.createdAt) === monthKey(now)).length };
    const target = targetMap.get(person.id);
    const wins = ["daily", "weekly", "monthly"].filter((period) => (target?.[`${period}Target`] ?? 0) > 0 && counts[period] >= (target?.[`${period}Target`] ?? 0));
    return { ...person, accountNumber: person.accountNumericPart ? `CN${person.accountNumericPart}` : null, photoUrl: person.hasPhoto ? `/api/consultant/profile-photo/${person.id}` : null, counts, wins };
  });
  const rank = (period, limit2) => heroes.filter((item) => item.counts[period] > 0).sort((a, b) => b.counts[period] - a.counts[period] || a.name.localeCompare(b.name)).slice(0, limit2);
  response.json({ targetWinners: heroes.filter((item) => item.wins.length), weeklyChampions: rank("weekly", 5), monthlyChampions: rank("monthly", 10) });
}));
consultantRouter.get("/consultant/bank-details", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const [details] = await db.select({ bankName: consultantBankDetails.bankName, branchName: consultantBankDetails.branchName, accountHolderName: consultantBankDetails.accountHolderName, accountNumberLast4: consultantBankDetails.accountNumberLast4, updatedAt: consultantBankDetails.updatedAt }).from(consultantBankDetails).where(eq4(consultantBankDetails.userId, consultant.id)).limit(1);
  response.json({ bankDetails: details ?? null });
}));
consultantRouter.put("/consultant/bank-details", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const input = bankDetailsInput.parse(request.body);
  const db = requireDatabase();
  const normalized = input.accountNumber.replaceAll(" ", "");
  const [saved] = await db.insert(consultantBankDetails).values({
    userId: consultant.id,
    bankName: input.bankName,
    branchName: input.branchName,
    accountHolderName: input.accountHolderName,
    accountNumberEncrypted: encryptBankAccount(normalized),
    accountNumberLast4: normalized.slice(-4)
  }).onConflictDoUpdate({ target: consultantBankDetails.userId, set: {
    bankName: input.bankName,
    branchName: input.branchName,
    accountHolderName: input.accountHolderName,
    accountNumberEncrypted: encryptBankAccount(normalized),
    accountNumberLast4: normalized.slice(-4),
    updatedAt: /* @__PURE__ */ new Date()
  } }).returning({ bankName: consultantBankDetails.bankName, branchName: consultantBankDetails.branchName, accountHolderName: consultantBankDetails.accountHolderName, accountNumberLast4: consultantBankDetails.accountNumberLast4, updatedAt: consultantBankDetails.updatedAt });
  response.json({ bankDetails: saved, message: "Bank details securely saved." });
}));
var studentRegistrationInput = z3.object({
  firstName: z3.string().trim().min(2).max(60),
  lastName: z3.string().trim().min(2).max(60),
  email: z3.string().trim().email().max(200),
  phone: z3.string().trim().min(7).max(30),
  dateOfBirth: z3.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((value) => (/* @__PURE__ */ new Date(`${value}T00:00:00Z`)).getTime() <= Date.now(), "Date of birth \u0D85\u0DB1\u0DCF\u0D9C\u0DAD \u0DAF\u0DD2\u0DB1\u0DBA\u0D9A\u0DCA \u0DC0\u0DD2\u0DBA \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A."),
  nicOrPassport: z3.string().trim().max(50).optional(),
  withoutNic: z3.boolean().default(false),
  addressLine1: z3.string().trim().min(3).max(250),
  addressLine2: z3.string().trim().max(250).optional(),
  province: z3.string().trim().min(2).max(80),
  district: z3.string().trim().min(2).max(80),
  city: z3.string().trim().min(2).max(80),
  courseId: z3.string().uuid(),
  paymentPlan: z3.enum(["FULL", "HALF"]),
  parentAccountId: z3.string().uuid(),
  side: z3.enum(["LEFT", "RIGHT"])
}).superRefine((value, context) => {
  if (!value.withoutNic && (!value.nicOrPassport || value.nicOrPassport.length < 5)) context.addIssue({ code: "custom", path: ["nicOrPassport"], message: "NIC / Passport \u0D91\u0D9A \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA\u0DBA\u0DD2." });
});
consultantRouter.post("/consultant/student-registrations", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const input = studentRegistrationInput.parse(request.body);
  const db = requireDatabase();
  const email = input.email.toLowerCase();
  const [[account], [course], [existingUser], [recentPayId]] = await Promise.all([
    db.select().from(networkAccounts).where(and4(eq4(networkAccounts.id, input.parentAccountId), eq4(networkAccounts.ownerUserId, consultant.id), eq4(networkAccounts.prefix, "CN"), eq4(networkAccounts.status, "ACTIVE"))).limit(1),
    db.select().from(courses).where(and4(eq4(courses.id, input.courseId), eq4(courses.isPublished, true))).limit(1),
    db.select({ id: users.id }).from(users).where(and4(eq4(users.email, email), isNull2(users.removedAt))).limit(1),
    db.select().from(paymentReferenceIds).where(and4(eq4(paymentReferenceIds.email, email), gt2(paymentReferenceIds.createdAt, new Date(Date.now() - 48 * 60 * 60 * 1e3)))).orderBy(desc4(paymentReferenceIds.createdAt)).limit(1)
  ]);
  if (!account) throw new HttpError(400, "Active consultant CN account \u0D91\u0D9A\u0D9A\u0DCA \u0DAD\u0DDD\u0DBB\u0DB1\u0DCA\u0DB1.");
  if (!course) throw new HttpError(404, "Course \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
  const fullAmount = Number(course.price);
  const expectedPaymentAmount = input.paymentPlan === "HALF" ? 1e4 : fullAmount;
  if (input.paymentPlan === "HALF" && fullAmount !== 15e3) {
    throw new HttpError(400, "Half payment option \u0D91\u0D9A \u0DB8\u0DD9\u0DB8 course \u0D91\u0D9A\u0DA7 \u0DBD\u0DB6\u0DCF \u0DAF\u0DD3 \u0DB1\u0DDC\u0DB8\u0DD0\u0DAD.");
  }
  if (existingUser) throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 account \u0D91\u0D9A\u0D9A\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0D87\u0DAD.");
  if (recentPayId) throw new HttpError(429, "\u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 \u0DB4\u0DD0\u0DBA 48 \u0D87\u0DAD\u0DD4\u0DC5\u0DAD Pay ID \u0D91\u0D9A\u0D9A\u0DCA \u0DB1\u0DD2\u0D9A\u0DD4\u0DAD\u0DCA \u0D9A\u0DBB \u0D87\u0DAD.");
  const [occupied] = await db.select({ id: networkPlacements.id }).from(networkPlacements).where(and4(eq4(networkPlacements.parentAccountId, account.id), eq4(networkPlacements.side, input.side), eq4(networkPlacements.placementKind, "STUDENT"))).limit(1);
  if (occupied) throw new HttpError(409, `${input.side} placement \u0D91\u0D9A \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB \u0D87\u0DAD.`);
  const [pendingPlacement] = await db.select({ id: consultantStudentRegistrations.id }).from(consultantStudentRegistrations).where(and4(
    eq4(consultantStudentRegistrations.parentAccountId, account.id),
    eq4(consultantStudentRegistrations.side, input.side),
    inArray3(consultantStudentRegistrations.status, ["AWAITING_PAYMENT", "PAYMENT_SUBMITTED"])
  )).limit(1);
  if (pendingPlacement) throw new HttpError(409, `${input.side} placement \u0D91\u0D9A \u0DC3\u0DB3\u0DC4\u0DCF \u0DAD\u0DC0\u0DAD\u0DCA admission \u0D91\u0D9A\u0D9A\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7 process \u0DC0\u0DD9\u0DB8\u0DD2\u0DB1\u0DCA \u0DB4\u0DC0\u0DAD\u0DD3.`);
  const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "");
  const code = `ADIL-PAY-${day}-${crypto5.randomBytes(3).toString("hex").toUpperCase()}`;
  const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1e3);
  const result = await db.transaction(async (tx) => {
    const [payId] = await tx.insert(paymentReferenceIds).values({ code, email, expiresAt }).returning();
    const [registration] = await tx.insert(consultantStudentRegistrations).values({
      consultantUserId: consultant.id,
      parentAccountId: account.id,
      payIdId: payId.id,
      courseId: course.id,
      paymentPlan: input.paymentPlan,
      expectedPaymentAmount: expectedPaymentAmount.toFixed(2),
      firstName: input.firstName,
      lastName: input.lastName,
      email,
      phone: input.phone,
      dateOfBirth: input.dateOfBirth,
      nicOrPassport: input.withoutNic ? null : input.nicOrPassport,
      addressLine1: input.addressLine1,
      addressLine2: input.addressLine2,
      province: input.province,
      district: input.district,
      city: input.city,
      side: input.side
    }).returning();
    return { registration, payId };
  });
  try {
    await sendPayId(email, code, expiresAt);
  } catch {
    await db.delete(consultantStudentRegistrations).where(eq4(consultantStudentRegistrations.id, result.registration.id));
    await db.delete(paymentReferenceIds).where(eq4(paymentReferenceIds.id, result.payId.id));
    throw new HttpError(503, "Pay ID email \u0D91\u0D9A \u0DBA\u0DD0\u0DC0\u0DD3\u0DB8\u0DA7 \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A\u0DD2 \u0DC0\u0DD2\u0DBA.");
  }
  response.status(201).json({ registration: { id: result.registration.id, status: result.registration.status }, payIdSent: true, expiresAt });
}));
consultantRouter.get("/consultant/student-registrations", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const rows = await db.select({
    registration: consultantStudentRegistrations,
    payId: paymentReferenceIds.code,
    payIdExpiresAt: paymentReferenceIds.expiresAt,
    courseTitle: courses.title,
    paymentPlan: consultantStudentRegistrations.paymentPlan,
    expectedPaymentAmount: consultantStudentRegistrations.expectedPaymentAmount,
    paymentStatus: paymentRequests.status,
    paymentCode: paymentRequests.paymentCode,
    paidAmount: paymentRequests.paidAmount,
    totalAmount: paymentRequests.totalAmount,
    studentUserId: users.id,
    studentActive: users.isActive,
    accountPrefix: networkAccounts.prefix,
    accountNumericPart: networkAccounts.numericPart,
    accountStatus: networkAccounts.status
  }).from(consultantStudentRegistrations).innerJoin(paymentReferenceIds, eq4(paymentReferenceIds.id, consultantStudentRegistrations.payIdId)).innerJoin(courses, eq4(courses.id, consultantStudentRegistrations.courseId)).leftJoin(paymentRequests, eq4(paymentRequests.payIdId, consultantStudentRegistrations.payIdId)).leftJoin(users, eq4(users.email, consultantStudentRegistrations.email)).leftJoin(networkAccounts, and4(eq4(networkAccounts.ownerUserId, users.id), eq4(networkAccounts.isMainAccount, true))).where(eq4(consultantStudentRegistrations.consultantUserId, consultant.id)).orderBy(desc4(consultantStudentRegistrations.createdAt));
  response.json({ registrations: rows.map((row) => ({
    ...row.registration,
    payId: row.payId,
    payIdExpiresAt: row.payIdExpiresAt,
    courseTitle: row.courseTitle,
    paymentPlan: row.paymentPlan,
    expectedPaymentAmount: Number(row.expectedPaymentAmount),
    paymentCode: row.paymentCode,
    paidAmount: row.paidAmount === null ? null : Number(row.paidAmount),
    totalAmount: row.totalAmount === null ? null : Number(row.totalAmount),
    accountNumber: row.accountPrefix && row.accountNumericPart ? `${row.accountPrefix}${row.accountNumericPart}` : null,
    accountStatus: row.accountStatus,
    status: row.paymentStatus === "APPROVED" && row.accountStatus === "ACTIVE" ? "ACTIVE" : row.paymentStatus === "PENDING" ? "PAYMENT_REVIEW" : row.paymentStatus === "REJECTED" ? "REJECTED" : row.registration.status
  })) });
}));
consultantRouter.get(
  "/consultant/cco-dashboard",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant"]);
    const db = requireDatabase();
    await expireTrialAccounts(db);
    const accountRows = await db.select({
      account: networkAccounts,
      balance: accountPointBalances
    }).from(networkAccounts).leftJoin(accountPointBalances, eq4(accountPointBalances.accountId, networkAccounts.id)).where(eq4(networkAccounts.ownerUserId, user.id)).orderBy(desc4(networkAccounts.isMainAccount));
    const accountIds = accountRows.map((row) => row.account.id);
    const [wallet] = await db.select().from(wallets).where(eq4(wallets.userId, user.id)).limit(1);
    const [entries, placements, ledger, payouts, directEntries] = await Promise.all([
      accountIds.length ? db.select().from(commissionEntries).where(inArray3(commissionEntries.accountId, accountIds)).orderBy(desc4(commissionEntries.createdAt)) : Promise.resolve([]),
      accountIds.length ? db.select().from(networkPlacements).where(inArray3(networkPlacements.parentAccountId, accountIds)) : Promise.resolve([]),
      wallet ? db.select().from(walletLedger).where(eq4(walletLedger.walletId, wallet.id)).orderBy(desc4(walletLedger.createdAt)) : Promise.resolve([]),
      wallet ? db.select().from(payoutRequests).where(eq4(payoutRequests.walletId, wallet.id)).orderBy(desc4(payoutRequests.createdAt)) : Promise.resolve([]),
      wallet ? db.select({ amount: walletLedger.amount }).from(walletLedger).where(and4(eq4(walletLedger.walletId, wallet.id), eq4(walletLedger.entryType, "DIRECT_ADMISSION_INCOME"))) : Promise.resolve([])
    ]);
    const main = accountRows.find((row) => row.account.isMainAccount)?.account ?? accountRows[0]?.account;
    const activeByNumber = new Map(accountRows.map((row) => [row.account.numericPart, row.account]));
    const slots = main ? Array.from({ length: 7 }, (_, index) => {
      const numericPart = main.numericPart + index;
      const active = activeByNumber.get(numericPart);
      return {
        position: index + 1,
        numericPart,
        number: active ? `${active.prefix}${numericPart}` : `CN${numericPart}`,
        status: active?.status ?? "RESERVED_SLOT",
        isMain: index === 0,
        accountId: active?.id ?? null
      };
    }) : [];
    const accountSummaries = accountRows.map(({ account, balance }) => {
      const accountIncome = entries.filter((entry) => entry.accountId === account.id).reduce((sum, entry) => sum + Number(entry.amount), 0);
      const left = balance?.leftAvailable ?? 0;
      const right = balance?.rightAvailable ?? 0;
      return {
        id: account.id,
        number: `${account.prefix}${account.numericPart}`,
        status: account.status,
        isMain: account.isMainAccount,
        leftAvailable: left,
        rightAvailable: right,
        lifetimeLeft: balance?.lifetimeLeft ?? 0,
        lifetimeRight: balance?.lifetimeRight ?? 0,
        stageOneAchieved: balance?.stageOneAchieved ?? false,
        stageTwoAchieved: balance?.stageTwoAchieved ?? false,
        nextStage: !balance?.stageOneAchieved ? "1:1" : !balance?.stageTwoAchieved ? "2:2" : "3:3",
        nextPayout: !balance?.stageOneAchieved ? 2500 : !balance?.stageTwoAchieved ? 5e3 : 8e3,
        income: accountIncome
      };
    });
    const directIncome = directEntries.reduce((sum, item) => sum + Number(item.amount), 0);
    const earningRows = ledger.filter((item) => ["DIRECT_ADMISSION_INCOME", "COMMISSION_PENDING"].includes(item.entryType) && Number(item.amount) > 0);
    response.json({
      mainAccountNumber: main ? `${main.prefix}${main.numericPart}` : null,
      totalIncome: entries.reduce((sum, entry) => sum + Number(entry.amount), 0) + directIncome,
      directIncome,
      totalPaid: payouts.filter((item) => item.status === "PAID").reduce((sum, item) => sum + Number(item.amount), 0),
      upcomingIncome: Number(wallet?.pendingBalance ?? 0),
      availableBalance: Number(wallet?.availableBalance ?? 0),
      directStudents: new Set(placements.map((item) => item.accountId)).size,
      leftPoints: accountSummaries.reduce((sum, item) => sum + item.leftAvailable, 0),
      rightPoints: accountSummaries.reduce((sum, item) => sum + item.rightAvailable, 0),
      accounts: accountSummaries,
      slots,
      recentLedger: ledger.slice(0, 20),
      earningChart: {
        daily: earningTrend(earningRows, "daily"),
        weekly: earningTrend(earningRows, "weekly"),
        monthly: earningTrend(earningRows, "monthly")
      }
    });
  })
);
consultantRouter.get("/consultant/service-accounts", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const rows = await db.select({ account: networkAccounts, balance: accountPointBalances }).from(networkAccounts).leftJoin(accountPointBalances, eq4(accountPointBalances.accountId, networkAccounts.id)).where(and4(eq4(networkAccounts.ownerUserId, user.id), eq4(networkAccounts.prefix, "CN"))).orderBy(desc4(networkAccounts.isMainAccount), networkAccounts.numericPart);
  const accountIds = rows.map((row) => row.account.id);
  const entries = accountIds.length ? await db.select({ entry: commissionEntries, cycle: commissionCycles }).from(commissionEntries).innerJoin(commissionCycles, eq4(commissionEntries.cycleId, commissionCycles.id)).where(inArray3(commissionEntries.accountId, accountIds)).orderBy(desc4(commissionCycles.periodEnd), desc4(commissionEntries.createdAt)) : [];
  const [allAccounts, pointRows] = await Promise.all([
    db.select().from(networkAccounts),
    accountIds.length ? db.select({ event: pointEvents, payment: paymentRequests, studentName: users.displayName, studentEmail: users.email, studentPhone: users.phone }).from(pointEvents).innerJoin(paymentRequests, eq4(paymentRequests.id, pointEvents.sourcePaymentId)).innerJoin(users, eq4(users.id, paymentRequests.userId)).where(inArray3(pointEvents.beneficiaryAccountId, accountIds)).orderBy(desc4(pointEvents.createdAt)) : []
  ]);
  const accountById = new Map(allAccounts.map((item) => [item.id, item]));
  const studentMainByUser = new Map(allAccounts.filter((item) => item.isMainAccount).map((item) => [item.ownerUserId, item]));
  const groupedActivity = /* @__PURE__ */ new Map();
  for (const row of pointRows) {
    const key2 = `${row.payment.id}:${row.event.side}`;
    const beneficiary = accountById.get(row.event.beneficiaryAccountId);
    const beneficiaryNumber = beneficiary ? `${beneficiary.prefix}${beneficiary.numericPart}` : "Unknown";
    const existing = groupedActivity.get(key2);
    if (existing) {
      existing.beneficiaryAccountIds.push(row.event.beneficiaryAccountId);
      existing.beneficiaryAccountNumbers.push(beneficiaryNumber);
      existing.pointCount += row.event.points;
      continue;
    }
    const studentAccount = studentMainByUser.get(row.payment.userId);
    groupedActivity.set(key2, {
      id: key2,
      beneficiaryAccountIds: [row.event.beneficiaryAccountId],
      beneficiaryAccountNumbers: [beneficiaryNumber],
      side: row.event.side,
      studentName: row.studentName,
      studentEmail: row.studentEmail,
      studentPhone: row.studentPhone,
      studentAccountNumber: studentAccount ? `${studentAccount.prefix}${studentAccount.numericPart}` : null,
      paymentCode: row.payment.paymentCode,
      paidAmount: Number(row.payment.paidAmount),
      totalAmount: Number(row.payment.totalAmount),
      paymentType: "FULL",
      paymentStatus: row.payment.status,
      pointAwarded: true,
      pointCount: row.event.points,
      createdAt: row.event.createdAt
    });
  }
  const activity = [...groupedActivity.values()];
  response.json({
    accounts: rows.map(({ account, balance }, index) => {
      const latest = entries.find((row) => row.entry.accountId === account.id);
      const metadata = latest?.entry.metadata ?? {};
      const leftBefore = Number(metadata.leftBefore ?? 0);
      const rightBefore = Number(metadata.rightBefore ?? 0);
      const matchedPairs = latest?.entry.matchedPairs ?? 0;
      return {
        id: account.id,
        position: index + 1,
        number: `${account.prefix}${account.numericPart}`,
        username: user.name.split(/\s+/)[0] || user.name,
        status: account.status,
        leftPoints: balance?.leftAvailable ?? 0,
        rightPoints: balance?.rightAvailable ?? 0,
        weeklyFlush: latest ? {
          cycleKey: latest.cycle.cycleKey,
          periodStart: latest.cycle.periodStart,
          periodEnd: latest.cycle.periodEnd,
          stage: latest.entry.stage,
          matchedPairs,
          leftBefore,
          rightBefore,
          leftFlushed: Math.min(leftBefore, matchedPairs),
          rightFlushed: Math.min(rightBefore, matchedPairs),
          amount: Number(latest.entry.amount)
        } : null
      };
    }),
    activity
  });
}));
var defaultActivationPrices = { "2": 2e4, "3": 2e4, "4": 15e3, "5": 15e3, "6": 15e3, "7": 15e3 };
var activationPlacement = {
  2: { parentPosition: 1, side: "LEFT" },
  3: { parentPosition: 1, side: "RIGHT" },
  4: { parentPosition: 2, side: "LEFT" },
  5: { parentPosition: 3, side: "RIGHT" },
  6: { parentPosition: 2, side: "RIGHT" },
  7: { parentPosition: 3, side: "LEFT" }
};
var activationRequestInput = z3.object({
  slotPosition: z3.coerce.number().int().min(2).max(7),
  activationMode: z3.enum(["FULL", "TRIAL"]),
  parentAccountId: z3.string().uuid(),
  side: z3.enum(["LEFT", "RIGHT"]),
  amount: z3.coerce.number().positive(),
  transactionReference: z3.string().trim().min(3).max(150),
  seniorConsultantName: z3.string().trim().max(150).optional()
});
var activationReviewInput = z3.object({ status: z3.enum(["APPROVED", "REJECTED"]), note: z3.string().trim().max(1e3).optional() });
var activationProofTypes = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "application/pdf": "pdf" };
async function activationConfiguration(db) {
  const settings = await db.select().from(systemSettings).where(inArray3(systemSettings.key, ["CCO_BANK_DETAILS", "CCO_ACCOUNT_PRICES"]));
  const byKey = new Map(settings.map((item) => [item.key, item.value]));
  return {
    bankDetails: byKey.get("CCO_BANK_DETAILS") ?? null,
    prices: { ...defaultActivationPrices, ...byKey.get("CCO_ACCOUNT_PRICES") ?? {} }
  };
}
async function expireTrialAccounts(db) {
  const expired = await db.select({ requestId: ccoActivationRequests.id, accountId: ccoActivationRequests.activatedAccountId }).from(ccoActivationRequests).where(and4(eq4(ccoActivationRequests.activationMode, "TRIAL"), eq4(ccoActivationRequests.status, "APPROVED"), lte(ccoActivationRequests.trialExpiresAt, /* @__PURE__ */ new Date())));
  for (const item of expired) {
    if (item.accountId) await db.update(networkAccounts).set({ status: "SUSPENDED" }).where(eq4(networkAccounts.id, item.accountId));
    await db.update(ccoActivationRequests).set({ status: "EXPIRED", updatedAt: /* @__PURE__ */ new Date() }).where(eq4(ccoActivationRequests.id, item.requestId));
  }
}
consultantRouter.get("/consultant/cco-activation-config", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  await expireTrialAccounts(db);
  const [consultantProfile] = await db.select({ name: users.displayName, phone: users.phone }).from(users).where(eq4(users.id, consultant.id)).limit(1);
  const accounts = await db.select().from(networkAccounts).where(and4(eq4(networkAccounts.ownerUserId, consultant.id), eq4(networkAccounts.prefix, "CN"))).orderBy(desc4(networkAccounts.isMainAccount));
  const main = accounts.find((item) => item.isMainAccount) ?? accounts[0];
  const config = await activationConfiguration(db);
  const pendingRequests = await db.select({ numericPart: ccoActivationRequests.requestedNumericPart }).from(ccoActivationRequests).where(and4(eq4(ccoActivationRequests.consultantUserId, consultant.id), eq4(ccoActivationRequests.status, "PENDING")));
  const pendingNumbers = new Set(pendingRequests.map((item) => item.numericPart));
  const activeTrials = await db.select({ numericPart: ccoActivationRequests.requestedNumericPart, expiresAt: ccoActivationRequests.trialExpiresAt }).from(ccoActivationRequests).where(and4(eq4(ccoActivationRequests.consultantUserId, consultant.id), eq4(ccoActivationRequests.activationMode, "TRIAL"), eq4(ccoActivationRequests.status, "APPROVED")));
  const trialByNumber = new Map(activeTrials.map((item) => [item.numericPart, item.expiresAt]));
  const firstMissingPosition = main && !activeTrials.length ? Array.from({ length: 6 }, (_, index) => index + 2).find((position) => !accounts.some((item) => item.numericPart === main.numericPart + position - 1 && item.status === "ACTIVE")) ?? null : null;
  response.json({
    ...config,
    consultant: { name: consultantProfile?.name ?? consultant.name, phone: consultantProfile?.phone ?? null, mainAccountNumber: main ? `CN${main.numericPart}` : null },
    activeAccounts: accounts.filter((item) => item.status === "ACTIVE").map((item) => ({ id: item.id, number: `CN${item.numericPart}` })),
    slots: main ? Array.from({ length: 6 }, (_, index) => {
      const position = index + 2;
      const numericPart = main.numericPart + index + 1;
      const active = accounts.find((item) => item.numericPart === numericPart);
      const placement = activationPlacement[position];
      const parentNumericPart = main.numericPart + placement.parentPosition - 1;
      const parent = accounts.find((item) => item.numericPart === parentNumericPart && item.status === "ACTIVE");
      const trialExpiry = trialByNumber.get(numericPart);
      const purchaseState = trialExpiry ? "TRIAL_ACTIVE" : active?.status === "ACTIVE" ? "ACTIVE" : pendingNumbers.has(numericPart) ? "PENDING" : position === firstMissingPosition ? "AVAILABLE" : "LOCKED";
      return { position, numericPart, number: `CN${numericPart}`, status: active?.status ?? "RESERVED", purchaseState, price: Number(config.prices[String(position)] ?? 0), trialPrice: 5e3, trialExpiresAt: trialExpiry ?? null, parentAccountId: parent?.id ?? null, parentAccountNumber: `CN${parentNumericPart}`, side: placement.side };
    }) : []
  });
}));
consultantRouter.get("/consultant/cco-activations", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const rows = await db.select().from(ccoActivationRequests).where(eq4(ccoActivationRequests.consultantUserId, consultant.id)).orderBy(desc4(ccoActivationRequests.createdAt));
  response.json({ requests: rows.map(({ proofObjectKey, ...item }) => ({ ...item, hasProof: Boolean(proofObjectKey) })) });
}));
consultantRouter.post("/consultant/cco-activations", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const input = activationRequestInput.parse(request.body);
  const db = requireDatabase();
  await expireTrialAccounts(db);
  const config = await activationConfiguration(db);
  const expected = input.activationMode === "TRIAL" ? 5e3 : Number(config.prices[String(input.slotPosition)] ?? 0);
  if (!config.bankDetails?.accountNumber) throw new HttpError(409, "Adil Academy bank details Admin \u0DC0\u0DD2\u0DC3\u0DD2\u0DB1\u0DCA \u0DAD\u0DC0\u0DB8 configure \u0D9A\u0DBB \u0DB1\u0DD0\u0DC4\u0DD0.");
  if (input.amount !== expected) throw new HttpError(400, `Account ${input.slotPosition} activation amount \u0D91\u0D9A Rs. ${expected.toLocaleString()} \u0DC0\u0DD2\u0DBA \u0DBA\u0DD4\u0DAD\u0DD4\u0DBA\u0DD2.`);
  const accounts = await db.select().from(networkAccounts).where(and4(eq4(networkAccounts.ownerUserId, consultant.id), eq4(networkAccounts.prefix, "CN")));
  const main = accounts.find((item) => item.isMainAccount) ?? accounts[0];
  if (!main) throw new HttpError(409, "Main CN account \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
  const [runningTrial] = await db.select({ id: ccoActivationRequests.id }).from(ccoActivationRequests).where(and4(eq4(ccoActivationRequests.consultantUserId, consultant.id), eq4(ccoActivationRequests.activationMode, "TRIAL"), eq4(ccoActivationRequests.status, "APPROVED"))).limit(1);
  if (runningTrial) throw new HttpError(409, "\u0DAF\u0DD0\u0DB1\u0DA7 active trial account \u0D91\u0D9A \u0D85\u0DC0\u0DC3\u0DB1\u0DCA \u0DC0\u0DB1\u0DAD\u0DD4\u0DBB\u0DD4 \u0DC0\u0DD9\u0DB1\u0DAD\u0DCA account \u0D91\u0D9A\u0D9A\u0DCA \u0DB8\u0DD2\u0DBD\u0DAF\u0DD3\u0D9C\u0DAD \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A.");
  const nextPosition = Array.from({ length: 6 }, (_, index) => index + 2).find((position) => !accounts.some((item) => item.numericPart === main.numericPart + position - 1 && item.status === "ACTIVE"));
  if (input.slotPosition !== nextPosition) throw new HttpError(409, nextPosition ? `\u0DB8\u0DD4\u0DBD\u0DD2\u0DB1\u0DCA CN${main.numericPart + nextPosition - 1} (${nextPosition}th account) activate \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.` : "\u0DC3\u0DD2\u0DBA\u0DBD\u0DD4 CCO accounts \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA active.");
  const numericPart = main.numericPart + input.slotPosition - 1;
  if (accounts.some((item) => item.numericPart === numericPart && item.status === "ACTIVE")) throw new HttpError(409, `CN${numericPart} \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA active.`);
  const placement = activationPlacement[input.slotPosition];
  const expectedParentNumber = main.numericPart + placement.parentPosition - 1;
  const parent = accounts.find((item) => item.status === "ACTIVE" && item.numericPart === expectedParentNumber);
  if (!parent) throw new HttpError(409, `Required parent CN${expectedParentNumber} \u0DAD\u0DC0\u0DB8 active \u0DB1\u0DD0\u0DC4\u0DD0.`);
  if (input.parentAccountId !== parent.id || input.side !== placement.side) throw new HttpError(400, `CN${numericPart} placement \u0D91\u0D9A CN${expectedParentNumber} ${placement.side} \u0DC0\u0DD2\u0DBA \u0DBA\u0DD4\u0DAD\u0DD4\u0DBA\u0DD2.`);
  const [occupied] = await db.select({ id: networkPlacements.id }).from(networkPlacements).where(and4(eq4(networkPlacements.parentAccountId, parent.id), eq4(networkPlacements.side, input.side), eq4(networkPlacements.placementKind, "CCO"))).limit(1);
  if (occupied) throw new HttpError(409, `${parent.prefix}${parent.numericPart} ${input.side} position \u0D91\u0D9A \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB \u0D87\u0DAD.`);
  const [pending] = await db.select({ id: ccoActivationRequests.id }).from(ccoActivationRequests).where(and4(eq4(ccoActivationRequests.consultantUserId, consultant.id), eq4(ccoActivationRequests.requestedNumericPart, numericPart), eq4(ccoActivationRequests.status, "PENDING"))).limit(1);
  if (pending) throw new HttpError(409, `CN${numericPart} \u0DC3\u0DB3\u0DC4\u0DCF pending request \u0D91\u0D9A\u0D9A\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0D87\u0DAD.`);
  const [created] = await db.insert(ccoActivationRequests).values({ consultantUserId: consultant.id, slotPosition: input.slotPosition, requestedNumericPart: numericPart, parentAccountId: parent.id, side: input.side, activationMode: input.activationMode, amount: input.amount.toFixed(2), transactionReference: input.transactionReference, seniorConsultantName: input.seniorConsultantName }).returning();
  response.status(201).json({ request: created, message: "Request saved. \u0DAF\u0DD0\u0DB1\u0DCA payment slip \u0D91\u0D9A upload \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." });
}));
consultantRouter.put("/consultant/cco-activations/:id/proof", express3.raw({ type: ["image/jpeg", "image/png", "image/webp", "application/pdf"], limit: "10mb" }), asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const id = z3.string().uuid().parse(request.params.id);
  const mime = String(request.headers["content-type"] ?? "").split(";")[0];
  const extension = activationProofTypes[mime];
  if (!extension || !Buffer.isBuffer(request.body) || !request.body.length) throw new HttpError(400, "JPG, PNG, WEBP \u0DC4\u0DDD PDF slip \u0D91\u0D9A\u0D9A\u0DCA upload \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.");
  const [item] = await db.select().from(ccoActivationRequests).where(and4(eq4(ccoActivationRequests.id, id), eq4(ccoActivationRequests.consultantUserId, consultant.id), eq4(ccoActivationRequests.status, "PENDING"))).limit(1);
  if (!item) throw new HttpError(404, "Pending activation request \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
  const objectKey = `cco-activation-proofs/${item.id}-${crypto5.randomBytes(5).toString("hex")}.${extension}`;
  await uploadPrivateFile(objectKey, request.body);
  await db.update(ccoActivationRequests).set({ proofObjectKey: objectKey, proofMimeType: mime, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(ccoActivationRequests.id, item.id));
  const admins = await db.select({ id: users.id }).from(users).where(eq4(users.role, "admin"));
  if (admins.length) await db.insert(notifications).values(admins.map((admin) => ({ userId: admin.id, type: "CCO_ACTIVATION_REQUEST", title: "New CCO activation request", message: `${consultant.name} \u2022 CN${item.requestedNumericPart} \u2022 ${item.side} \u2022 Rs. ${Number(item.amount).toLocaleString()}` })));
  response.json({ message: "Payment slip submitted. Admin review notification sent." });
}));
consultantRouter.get("/admin/cco-activations", asyncRoute(async (request, response) => {
  await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const rows = await db.select({ request: ccoActivationRequests, consultantName: users.displayName, consultantEmail: users.email, consultantPhone: users.phone, parentPrefix: networkAccounts.prefix, parentNumericPart: networkAccounts.numericPart }).from(ccoActivationRequests).innerJoin(users, eq4(users.id, ccoActivationRequests.consultantUserId)).innerJoin(networkAccounts, eq4(networkAccounts.id, ccoActivationRequests.parentAccountId)).orderBy(desc4(ccoActivationRequests.createdAt));
  response.json({ requests: rows.map(({ request: item, ...extra }) => {
    const { proofObjectKey, ...safe } = item;
    return { ...safe, ...extra, parentAccountNumber: `${extra.parentPrefix}${extra.parentNumericPart}`, hasProof: Boolean(proofObjectKey) };
  }) });
}));
consultantRouter.get("/admin/cco-activations/:id/proof", asyncRoute(async (request, response) => {
  await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const id = z3.string().uuid().parse(request.params.id);
  const [item] = await db.select({ key: ccoActivationRequests.proofObjectKey, mime: ccoActivationRequests.proofMimeType }).from(ccoActivationRequests).where(eq4(ccoActivationRequests.id, id)).limit(1);
  if (!item?.key) throw new HttpError(404, "Slip \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
  response.type(item.mime ?? "application/octet-stream").send(await downloadPrivateFile(item.key));
}));
consultantRouter.post("/admin/cco-activations/:id/review", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const input = activationReviewInput.parse(request.body);
  const db = requireDatabase();
  const id = z3.string().uuid().parse(request.params.id);
  const config = await activationConfiguration(db);
  const result = await db.transaction(async (tx) => {
    const [item] = await tx.select().from(ccoActivationRequests).where(eq4(ccoActivationRequests.id, id)).limit(1);
    if (!item) throw new HttpError(404, "Activation request \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
    if (item.status !== "PENDING") throw new HttpError(409, "Request \u0D91\u0D9A \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA review \u0D9A\u0DBB \u0D87\u0DAD.");
    if (!item.proofObjectKey) throw new HttpError(400, "Payment slip \u0D91\u0D9A \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA\u0DBA\u0DD2.");
    if (input.status === "REJECTED") {
      await tx.update(ccoActivationRequests).set({ status: "REJECTED", reviewNote: input.note, reviewedBy: admin.id, reviewedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq4(ccoActivationRequests.id, item.id));
      await tx.insert(notifications).values({ userId: item.consultantUserId, type: "CCO_ACTIVATION_REJECTED", title: "CCO activation request rejected", message: input.note || `CN${item.requestedNumericPart} request \u0D91\u0D9A reject \u0D9A\u0DBB \u0D87\u0DAD.` });
      return { activated: false };
    }
    const expected = item.activationMode === "TRIAL" ? 5e3 : Number(config.prices[String(item.slotPosition)] ?? 0);
    if (Number(item.amount) !== expected) throw new HttpError(409, `Expected amount Rs. ${expected.toLocaleString()}.`);
    const ownedAccounts = await tx.select().from(networkAccounts).where(and4(eq4(networkAccounts.ownerUserId, item.consultantUserId), eq4(networkAccounts.prefix, "CN")));
    const mainAccount = ownedAccounts.find((account2) => account2.isMainAccount) ?? ownedAccounts[0];
    if (!mainAccount) throw new HttpError(409, "Main CN account \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
    const nextPosition = Array.from({ length: 6 }, (_, index) => index + 2).find((position) => !ownedAccounts.some((account2) => account2.numericPart === mainAccount.numericPart + position - 1 && account2.status === "ACTIVE"));
    if (nextPosition !== item.slotPosition) throw new HttpError(409, nextPosition ? `\u0DB8\u0DD4\u0DBD\u0DD2\u0DB1\u0DCA CN${mainAccount.numericPart + nextPosition - 1} activate \u0D9A\u0DC5 \u0DBA\u0DD4\u0DAD\u0DD4\u0DBA\u0DD2.` : "\u0DC3\u0DD2\u0DBA\u0DBD\u0DD4 accounts active.");
    const fixedPlacement = activationPlacement[item.slotPosition];
    const fixedParentNumber = mainAccount.numericPart + fixedPlacement.parentPosition - 1;
    if (item.side !== fixedPlacement.side) throw new HttpError(409, "Saved placement side \u0D91\u0D9A fixed network plan \u0D91\u0D9A\u0DA7 \u0DB1\u0DDC\u0D9C\u0DD0\u0DBD\u0DB4\u0DDA.");
    const [parent] = await tx.select().from(networkAccounts).where(and4(eq4(networkAccounts.id, item.parentAccountId), eq4(networkAccounts.ownerUserId, item.consultantUserId), eq4(networkAccounts.status, "ACTIVE"))).limit(1);
    if (!parent) throw new HttpError(409, "Parent CN account \u0D91\u0D9A active \u0DB1\u0DD0\u0DC4\u0DD0.");
    if (parent.numericPart !== fixedParentNumber) throw new HttpError(409, `Parent account \u0D91\u0D9A CN${fixedParentNumber} \u0DC0\u0DD2\u0DBA \u0DBA\u0DD4\u0DAD\u0DD4\u0DBA\u0DD2.`);
    const [existing] = await tx.select().from(networkAccounts).where(and4(eq4(networkAccounts.prefix, "CN"), eq4(networkAccounts.numericPart, item.requestedNumericPart))).limit(1);
    if (existing && (existing.ownerUserId !== item.consultantUserId || existing.status !== "SUSPENDED")) throw new HttpError(409, `CN${item.requestedNumericPart} \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0DB4\u0DC0\u0DAD\u0DD3.`);
    const [occupied] = await tx.select({ accountId: networkPlacements.accountId }).from(networkPlacements).where(and4(eq4(networkPlacements.parentAccountId, parent.id), eq4(networkPlacements.side, item.side), eq4(networkPlacements.placementKind, "CCO"))).limit(1);
    if (occupied && occupied.accountId !== existing?.id) throw new HttpError(409, `${parent.prefix}${parent.numericPart} ${item.side} CCO position \u0D91\u0D9A \u0DC0\u0DD9\u0DB1\u0DAD\u0DCA account \u0D91\u0D9A\u0D9A\u0DCA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB\u0DBA\u0DD2.`);
    const account = existing ? (await tx.update(networkAccounts).set({ status: "ACTIVE", activatedAt: /* @__PURE__ */ new Date() }).where(eq4(networkAccounts.id, existing.id)).returning())[0] : (await tx.insert(networkAccounts).values({ ownerUserId: item.consultantUserId, prefix: "CN", numericPart: item.requestedNumericPart, status: "ACTIVE", isMainAccount: false, activatedAt: /* @__PURE__ */ new Date() }).returning())[0];
    if (!occupied) await tx.insert(networkPlacements).values({ accountId: account.id, parentAccountId: parent.id, side: item.side, placementKind: "CCO", placedByUserId: admin.id });
    await tx.insert(accountPointBalances).values({ accountId: account.id }).onConflictDoNothing({ target: accountPointBalances.accountId });
    const trialExpiresAt = item.activationMode === "TRIAL" ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1e3) : null;
    await tx.update(ccoActivationRequests).set({ status: "APPROVED", reviewNote: input.note, reviewedBy: admin.id, reviewedAt: /* @__PURE__ */ new Date(), activatedAccountId: account.id, trialExpiresAt, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(ccoActivationRequests.id, item.id));
    await tx.insert(notifications).values({ userId: item.consultantUserId, type: "CCO_ACTIVATION_APPROVED", title: `CN${item.requestedNumericPart} activated`, message: item.activationMode === "TRIAL" ? `30-day trial active. ${trialExpiresAt.toLocaleDateString()} \u0DAF\u0DD2\u0DB1 \u0DC3\u0DCA\u0DC0\u0DBA\u0D82\u0D9A\u0DCA\u200D\u0DBB\u0DD3\u0DBA\u0DC0 suspend \u0DC0\u0DDA.` : `${parent.prefix}${parent.numericPart} ${item.side} \u0DBA\u0DA7\u0DAD\u0DDA account \u0D91\u0D9A \u0DC3\u0DCF\u0DBB\u0DCA\u0DAE\u0D9A\u0DC0 active \u0D9A\u0DBB \u0D87\u0DAD.` });
    await tx.insert(auditLogs).values({ actorUserId: admin.id, action: "CCO_ACCOUNT_ACTIVATED", entityType: "network_account", entityId: account.id, metadata: { requestId: item.id, activationMode: item.activationMode, amount: item.amount, transactionReference: item.transactionReference } });
    return { activated: true, accountNumber: `CN${account.numericPart}` };
  });
  response.json({ ...result, message: result.activated ? `${result.accountNumber} successfully activated.` : "Request rejected." });
}));
consultantRouter.get("/admin/cco-activation-config", asyncRoute(async (request, response) => {
  await requireRole(request, ["admin"]);
  response.json(await activationConfiguration(requireDatabase()));
}));
consultantRouter.put("/admin/cco-activation-config", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const input = z3.object({ bankDetails: z3.object({ bankName: z3.string().trim().min(2), branchName: z3.string().trim().min(2), accountHolderName: z3.string().trim().min(2), accountNumber: z3.string().trim().min(5) }), prices: z3.record(z3.string(), z3.coerce.number().positive()) }).parse(request.body);
  const db = requireDatabase();
  await db.transaction(async (tx) => {
    for (const [key2, value] of [["CCO_BANK_DETAILS", input.bankDetails], ["CCO_ACCOUNT_PRICES", input.prices]]) await tx.insert(systemSettings).values({ key: key2, value, updatedBy: admin.id }).onConflictDoUpdate({ target: systemSettings.key, set: { value, updatedBy: admin.id, updatedAt: /* @__PURE__ */ new Date() } });
  });
  response.json({ message: "CCO bank details and prices saved." });
}));
var applicationInput = z3.object({
  motivation: z3.string().trim().min(10).max(3e3)
});
var reviewInput2 = z3.object({
  status: z3.enum(["INTERVIEW", "APPROVED", "REJECTED"]),
  interviewNote: z3.string().trim().max(3e3).optional()
});
consultantRouter.post(
  "/consultant-applications",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    if (user.role !== "student") {
      throw new HttpError(409, "Only students can apply to become consultants.");
    }
    const input = applicationInput.parse(request.body);
    const db = requireDatabase();
    const [existing] = await db.select().from(consultantApplications).where(
      and4(
        eq4(consultantApplications.userId, user.id),
        inArray3(consultantApplications.status, ["PENDING", "INTERVIEW"])
      )
    ).limit(1);
    if (existing) {
      throw new HttpError(409, "A consultant application is already active.");
    }
    const [created] = await db.insert(consultantApplications).values({ userId: user.id, motivation: input.motivation }).returning();
    response.status(201).json({ application: created });
  })
);
consultantRouter.get(
  "/consultant-applications/me",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [application] = await db.select().from(consultantApplications).where(eq4(consultantApplications.userId, user.id)).orderBy(desc4(consultantApplications.createdAt)).limit(1);
    response.json({ application: application ?? null });
  })
);
consultantRouter.get(
  "/admin/consultant-applications",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const applications = await db.select({
      application: consultantApplications,
      student: {
        id: users.id,
        displayName: users.displayName,
        email: users.email,
        phone: users.phone
      }
    }).from(consultantApplications).innerJoin(users, eq4(consultantApplications.userId, users.id)).orderBy(desc4(consultantApplications.createdAt));
    response.json({ applications });
  })
);
consultantRouter.post(
  "/admin/consultant-applications/:id/review",
  asyncRoute(async (request, response) => {
    const reviewer = await requireRole(request, ["staff", "admin"]);
    const input = reviewInput2.parse(request.body);
    if (input.status === "APPROVED" && reviewer.role !== "admin") {
      throw new HttpError(403, "Super Admin approval is required.");
    }
    const db = requireDatabase();
    const result = await db.transaction(async (tx) => {
      const [application] = await tx.select().from(consultantApplications).where(eq4(consultantApplications.id, String(request.params.id))).limit(1);
      if (!application) {
        throw new HttpError(404, "Consultant application not found.");
      }
      if (["APPROVED", "REJECTED"].includes(application.status)) {
        throw new HttpError(409, "Application is already finalized.");
      }
      const [updated] = await tx.update(consultantApplications).set({
        status: input.status,
        interviewNote: input.interviewNote,
        reviewedBy: reviewer.id,
        reviewedAt: /* @__PURE__ */ new Date()
      }).where(eq4(consultantApplications.id, application.id)).returning();
      let mainAccount = null;
      if (input.status === "APPROVED") {
        [mainAccount] = await tx.select().from(networkAccounts).where(
          and4(
            eq4(networkAccounts.ownerUserId, application.userId),
            eq4(networkAccounts.isMainAccount, true),
            eq4(networkAccounts.status, "ACTIVE")
          )
        ).limit(1);
        if (!mainAccount) {
          throw new HttpError(
            409,
            "An active paid SR account is required before consultant approval."
          );
        }
        if (mainAccount.prefix === "SR") {
          [mainAccount] = await tx.update(networkAccounts).set({ prefix: "CN" }).where(eq4(networkAccounts.id, mainAccount.id)).returning();
        }
        await tx.update(users).set({ role: "consultant", updatedAt: /* @__PURE__ */ new Date() }).where(eq4(users.id, application.userId));
        await tx.insert(wallets).values({ userId: application.userId }).onConflictDoNothing({ target: wallets.userId });
      }
      await tx.insert(notifications).values({
        userId: application.userId,
        type: "CONSULTANT_APPLICATION_" + input.status,
        title: input.status === "APPROVED" ? "Consultant account approved" : "Consultant application updated",
        message: input.status === "APPROVED" ? "Your SR main account is now an active CN consultant account." : "Your consultant application status is now " + input.status + "."
      });
      await tx.insert(auditLogs).values({
        actorUserId: reviewer.id,
        action: "CONSULTANT_APPLICATION_" + input.status,
        entityType: "consultant_application",
        entityId: application.id,
        metadata: {
          userId: application.userId,
          accountId: mainAccount?.id ?? null
        }
      });
      return { application: updated, account: mainAccount };
    });
    response.json(result);
  })
);
consultantRouter.get(
  "/consultant/accounts",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant", "admin"]);
    const db = requireDatabase();
    const accounts = await db.select({
      account: networkAccounts,
      balance: accountPointBalances
    }).from(networkAccounts).leftJoin(
      accountPointBalances,
      eq4(accountPointBalances.accountId, networkAccounts.id)
    ).where(eq4(networkAccounts.ownerUserId, user.id)).orderBy(desc4(networkAccounts.isMainAccount));
    response.json({ accounts, maxAccounts: 7 });
  })
);
consultantRouter.get(
  "/consultant/network",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant", "admin"]);
    const db = requireDatabase();
    const owned = await db.select().from(networkAccounts).where(eq4(networkAccounts.ownerUserId, user.id));
    if (owned.length === 0) {
      response.json({ roots: [], accounts: [], placements: [] });
      return;
    }
    const allAccounts = await db.select().from(networkAccounts);
    const allPlacements = await db.select().from(networkPlacements);
    const accountMap = new Map(
      allAccounts.map((account) => [account.id, account])
    );
    const children = /* @__PURE__ */ new Map();
    for (const placement of allPlacements) {
      const list = children.get(placement.parentAccountId) ?? [];
      list.push({ side: placement.side, accountId: placement.accountId });
      children.set(placement.parentAccountId, list);
    }
    const visibleIds = /* @__PURE__ */ new Set();
    const queue = owned.map((account) => account.id);
    while (queue.length && visibleIds.size < 2e3) {
      const current = queue.shift();
      if (visibleIds.has(current)) continue;
      visibleIds.add(current);
      for (const child of children.get(current) ?? []) {
        queue.push(child.accountId);
      }
    }
    response.json({
      roots: owned.map((account) => account.id),
      accounts: [...visibleIds].map((id) => accountMap.get(id)).filter(Boolean),
      placements: allPlacements.filter(
        (placement) => visibleIds.has(placement.accountId) && visibleIds.has(placement.parentAccountId)
      )
    });
  })
);

// server/modules/commissions/routes.ts
import { and as and5, desc as desc5, eq as eq7, inArray as inArray4 } from "drizzle-orm";
import { Router as Router4 } from "express";
import { z as z4 } from "zod";

// server/modules/commissions/service.ts
import { eq as eq5 } from "drizzle-orm";

// server/domain/commission.ts
function calculateAccountCommission(balance) {
  let left = Math.max(0, Math.trunc(balance.leftAvailable));
  let right = Math.max(0, Math.trunc(balance.rightAvailable));
  let stageOne = balance.stageOneAchieved;
  let stageTwo = balance.stageTwoAchieved;
  const awards = [];
  function canMatch(pairs) {
    return left >= pairs && right >= pairs;
  }
  function consume(stage, pairs, amount) {
    left -= pairs;
    right -= pairs;
    awards.push({ stage, pairs, amount });
  }
  if (!stageOne && canMatch(1)) {
    consume("STAGE_1", 1, 2500);
    stageOne = true;
  }
  if (stageOne && !stageTwo && canMatch(2)) {
    consume("STAGE_2", 2, 5e3);
    stageTwo = true;
  }
  if (stageOne && stageTwo && canMatch(3)) {
    consume("STAGE_3", 3, 8e3);
  }
  return {
    awards,
    leftRemaining: left,
    rightRemaining: right,
    stageOneAchieved: stageOne,
    stageTwoAchieved: stageTwo
  };
}

// server/modules/commissions/service.ts
async function calculateCommissionCycle(input, actorUserId) {
  if (input.periodEnd <= input.periodStart) {
    throw new HttpError(400, "Commission period is invalid.");
  }
  const db = requireDatabase();
  return db.transaction(async (tx) => {
    const [existing] = await tx.select().from(commissionCycles).where(eq5(commissionCycles.cycleKey, input.cycleKey)).limit(1);
    if (existing) throw new HttpError(409, "This commission cycle already exists.");
    const [cycle] = await tx.insert(commissionCycles).values({
      cycleKey: input.cycleKey,
      periodStart: input.periodStart,
      periodEnd: input.periodEnd,
      status: "CALCULATING"
    }).returning();
    const balances = await tx.select({ balance: accountPointBalances, account: networkAccounts }).from(accountPointBalances).innerJoin(networkAccounts, eq5(accountPointBalances.accountId, networkAccounts.id)).where(eq5(networkAccounts.status, "ACTIVE"));
    let totalAmount = 0;
    let awardedAccounts = 0;
    const ownerTotals = /* @__PURE__ */ new Map();
    for (const row of balances) {
      const calculation = calculateAccountCommission({
        leftAvailable: row.balance.leftAvailable,
        rightAvailable: row.balance.rightAvailable,
        stageOneAchieved: row.balance.stageOneAchieved,
        stageTwoAchieved: row.balance.stageTwoAchieved
      });
      if (calculation.awards.length) awardedAccounts += 1;
      const accountTotal = calculation.awards.reduce((sum, award) => sum + award.amount, 0);
      totalAmount += accountTotal;
      for (const award of calculation.awards) {
        await tx.insert(commissionEntries).values({
          cycleId: cycle.id,
          accountId: row.account.id,
          stage: award.stage,
          matchedPairs: award.pairs,
          amount: award.amount.toFixed(2),
          metadata: { leftBefore: row.balance.leftAvailable, rightBefore: row.balance.rightAvailable }
        });
      }
      await tx.update(accountPointBalances).set({
        // Adil Academy weekly rule: every Friday settlement clears every
        // available point, including an unmatched point on either side.
        leftAvailable: 0,
        rightAvailable: 0,
        stageOneAchieved: calculation.stageOneAchieved,
        stageTwoAchieved: calculation.stageTwoAchieved,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq5(accountPointBalances.id, row.balance.id));
      if (accountTotal > 0) {
        ownerTotals.set(
          row.account.ownerUserId,
          (ownerTotals.get(row.account.ownerUserId) ?? 0) + accountTotal
        );
        await tx.insert(wallets).values({ userId: row.account.ownerUserId }).onConflictDoNothing({ target: wallets.userId });
        const [wallet] = await tx.select().from(wallets).where(eq5(wallets.userId, row.account.ownerUserId)).limit(1);
        await tx.update(wallets).set({
          pendingBalance: (Number(wallet.pendingBalance) + accountTotal).toFixed(2),
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq5(wallets.id, wallet.id));
        await tx.insert(walletLedger).values({
          walletId: wallet.id,
          idempotencyKey: `commission-pending:${cycle.id}:${row.account.id}`,
          entryType: "COMMISSION_PENDING",
          amount: accountTotal.toFixed(2),
          referenceType: "commission_cycle",
          referenceId: cycle.id,
          note: `Friday commission for ${row.account.prefix}${row.account.numericPart}`
        });
      }
    }
    for (const [userId, amount] of ownerTotals) {
      await tx.insert(notifications).values({
        userId,
        type: "FRIDAY_COMMISSION_ADDED",
        title: "Friday commission added",
        message: `Weekly points flush \u0DC3\u0DB8\u0DCA\u0DB4\u0DD6\u0DBB\u0DCA\u0DAB\u0DBA\u0DD2. Rs. ${amount.toLocaleString()} commission \u0D94\u0DB6\u0D9C\u0DDA pending income \u0D91\u0D9A\u0DA7 \u0D91\u0D9A\u0DAD\u0DD4 \u0DC0\u0DD2\u0DBA.`
      });
    }
    const [updatedCycle] = await tx.update(commissionCycles).set({ status: "CALCULATED", calculatedAt: /* @__PURE__ */ new Date() }).where(eq5(commissionCycles.id, cycle.id)).returning();
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "COMMISSION_CYCLE_CALCULATED",
      entityType: "commission_cycle",
      entityId: cycle.id,
      metadata: { awardedAccounts, totalAmount, source: actorUserId ? "ADMIN" : "SCHEDULED_JOB" }
    });
    return { cycle: updatedCycle, awardedAccounts, totalAmount };
  });
}

// server/modules/commissions/scheduler.ts
import { eq as eq6 } from "drizzle-orm";
var COLOMBO_OFFSET_MS2 = 5.5 * 60 * 60 * 1e3;
var FRIDAY = 5;
var SETTLEMENT_HOUR = 12;
var SETTLEMENT_MINUTE = 30;
var CHECK_INTERVAL_MS = 6e4;
function dateKey2(date) {
  return date.toISOString().slice(0, 10);
}
function latestFridaySettlement(now = /* @__PURE__ */ new Date()) {
  const local = new Date(now.getTime() + COLOMBO_OFFSET_MS2);
  const daysSinceFriday = (local.getUTCDay() - FRIDAY + 7) % 7;
  const localDue = new Date(Date.UTC(
    local.getUTCFullYear(),
    local.getUTCMonth(),
    local.getUTCDate() - daysSinceFriday,
    SETTLEMENT_HOUR,
    SETTLEMENT_MINUTE
  ));
  if (local.getTime() < localDue.getTime()) localDue.setUTCDate(localDue.getUTCDate() - 7);
  const periodEnd = new Date(localDue.getTime() - COLOMBO_OFFSET_MS2);
  if (periodEnd.getTime() > now.getTime()) return null;
  const periodStart = new Date(periodEnd.getTime() - 7 * 24 * 60 * 60 * 1e3);
  return {
    cycleKey: `LK-FRIDAY-${dateKey2(localDue)}`,
    periodStart,
    periodEnd
  };
}
function nextFridaySettlement(now = /* @__PURE__ */ new Date()) {
  const local = new Date(now.getTime() + COLOMBO_OFFSET_MS2);
  const daysUntilFriday = (FRIDAY - local.getUTCDay() + 7) % 7;
  const localDue = new Date(Date.UTC(
    local.getUTCFullYear(),
    local.getUTCMonth(),
    local.getUTCDate() + daysUntilFriday,
    SETTLEMENT_HOUR,
    SETTLEMENT_MINUTE
  ));
  if (localDue.getTime() <= local.getTime()) localDue.setUTCDate(localDue.getUTCDate() + 7);
  return new Date(localDue.getTime() - COLOMBO_OFFSET_MS2);
}
var running = false;
var reminderRunning = false;
function payoutReminderSlot(now) {
  const local = new Date(now.getTime() + COLOMBO_OFFSET_MS2);
  if (local.getUTCDay() !== FRIDAY) return null;
  const minutes = local.getUTCHours() * 60 + local.getUTCMinutes();
  if (minutes < 17 * 60) return null;
  const slot = minutes >= 17 * 60 + 30 ? "1730" : minutes >= 17 * 60 + 20 ? "1720" : "1700";
  return { slot, date: dateKey2(local) };
}
async function runFridayPayoutReminder(now = /* @__PURE__ */ new Date()) {
  if (reminderRunning) return;
  const reminder = payoutReminderSlot(now);
  if (!reminder) return;
  reminderRunning = true;
  try {
    const db = requireDatabase();
    const walletRows = await db.select({ available: wallets.availableBalance, pending: wallets.pendingBalance }).from(wallets).innerJoin(users, eq6(users.id, wallets.userId)).where(eq6(users.role, "consultant"));
    const amounts = walletRows.map((row) => Number(row.available) + Number(row.pending)).filter((amount) => amount > 0);
    const totalAmount = amounts.reduce((sum, amount) => sum + amount, 0);
    if (totalAmount <= 0) return;
    const markerKey = `friday-payout-reminder:${reminder.date}:${reminder.slot}`;
    const [created] = await db.insert(systemSettings).values({
      key: markerKey,
      value: { sentAt: now.toISOString(), totalAmount, consultantCount: amounts.length }
    }).onConflictDoNothing().returning({ key: systemSettings.key });
    if (!created) return;
    await db.insert(systemSettings).values({
      key: "friday-payout-current",
      value: { payoutDate: reminder.date, dueAt: now.toISOString(), completedAt: null }
    }).onConflictDoUpdate({
      target: systemSettings.key,
      set: { value: { payoutDate: reminder.date, dueAt: now.toISOString(), completedAt: null }, updatedAt: now }
    });
    const admins = await db.select({ id: users.id, email: users.email }).from(users).where(eq6(users.role, "admin"));
    if (admins.length) await db.insert(notifications).values(admins.map((admin) => ({
      userId: admin.id,
      type: "FRIDAY_PAYOUT_REMINDER",
      title: reminder.slot === "1730" ? "URGENT: Friday payouts are due" : "Friday payout reminder",
      message: `${amounts.length} consultants \u0DC3\u0DB3\u0DC4\u0DCF Rs. ${totalAmount.toLocaleString()} manual bank payments \u0DC3\u0DB8\u0DCA\u0DB4\u0DD6\u0DBB\u0DCA\u0DAB \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.`
    })));
    await Promise.all(admins.map((admin) => sendFridayPayoutReminder(admin.email, totalAmount, amounts.length).catch((error) => console.error("Friday payout reminder email failed", error))));
    console.log(`[Friday payout reminder] ${reminder.date} ${reminder.slot}: ${amounts.length} consultants, Rs. ${totalAmount}`);
  } catch (error) {
    console.error("Friday payout reminder failed", error);
  } finally {
    reminderRunning = false;
  }
}
async function runDueFridaySettlement(now = /* @__PURE__ */ new Date()) {
  if (running) return;
  const window = latestFridaySettlement(now);
  if (!window) return;
  running = true;
  try {
    const db = requireDatabase();
    const [existing] = await db.select({ id: commissionCycles.id }).from(commissionCycles).where(eq6(commissionCycles.cycleKey, window.cycleKey)).limit(1);
    if (existing) return;
    const result = await calculateCommissionCycle(window, null);
    console.log(
      `[Friday settlement] ${window.cycleKey}: ${result.awardedAccounts} accounts, Rs. ${result.totalAmount}`
    );
  } catch (error) {
    console.error("Friday commission settlement failed", error);
  } finally {
    running = false;
  }
}
function startFridayCommissionScheduler() {
  void runDueFridaySettlement();
  void runFridayPayoutReminder();
  const timer = setInterval(() => {
    void runDueFridaySettlement();
    void runFridayPayoutReminder();
  }, CHECK_INTERVAL_MS);
  timer.unref();
  console.log("Friday scheduler active: settlement 12:30 PM; payout reminders 5:00/5:20/5:30 PM Asia/Colombo");
}

// server/modules/commissions/routes.ts
var commissionRouter = Router4();
var calculateInput = z4.object({
  cycleKey: z4.string().trim().min(4).max(40),
  periodStart: z4.coerce.date(),
  periodEnd: z4.coerce.date()
});
var payoutInput = z4.object({
  amount: z4.coerce.number().positive(),
  payoutMethod: z4.enum(["BANK_TRANSFER", "USDT"]),
  payoutDetails: z4.record(z4.string(), z4.string().max(300))
});
var payoutReviewInput = z4.object({
  status: z4.enum(["APPROVED", "PAID", "REJECTED"])
});
var fridayBatchInput = z4.object({ batchKey: z4.string().trim().regex(/^\d{4}-W\d{2}$/) });
commissionRouter.get("/consultant/income-summary", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const [wallet] = await db.select().from(wallets).where(eq7(wallets.userId, consultant.id)).limit(1);
  if (!wallet) {
    response.json({
      availableBalance: 0,
      pendingBalance: 0,
      directIncome: 0,
      serviceIncome: 0,
      totalIncome: 0,
      lastPayout: null,
      nextSettlementAt: nextFridaySettlement().toISOString(),
      ledger: []
    });
    return;
  }
  const [ledger, paidPayouts] = await Promise.all([
    db.select().from(walletLedger).where(eq7(walletLedger.walletId, wallet.id)).orderBy(desc5(walletLedger.createdAt)).limit(50),
    db.select().from(payoutRequests).where(and5(
      eq7(payoutRequests.walletId, wallet.id),
      eq7(payoutRequests.status, "PAID")
    )).orderBy(desc5(payoutRequests.paidAt)).limit(1)
  ]);
  const directIncome = ledger.filter((item) => item.entryType === "DIRECT_ADMISSION_INCOME").reduce((sum, item) => sum + Number(item.amount), 0);
  const serviceIncome = ledger.filter((item) => item.entryType === "COMMISSION_PENDING").reduce((sum, item) => sum + Number(item.amount), 0);
  const lastPayout = paidPayouts[0];
  response.json({
    availableBalance: Number(wallet.availableBalance),
    pendingBalance: Number(wallet.pendingBalance),
    directIncome,
    serviceIncome,
    totalIncome: directIncome + serviceIncome,
    lastPayout: lastPayout ? {
      amount: Number(lastPayout.amount),
      paidAt: lastPayout.paidAt?.toISOString() ?? null
    } : null,
    nextSettlementAt: nextFridaySettlement().toISOString(),
    ledger: ledger.slice(0, 25).map((item) => ({
      id: item.id,
      entryType: item.entryType,
      amount: Number(item.amount),
      note: item.note,
      createdAt: item.createdAt.toISOString()
    }))
  });
}));
commissionRouter.get("/admin/consultant-payout-summary", asyncRoute(async (request, response) => {
  await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const consultants = await db.select({ id: users.id, name: users.displayName, email: users.email }).from(users).where(eq7(users.role, "consultant"));
  const rows = await Promise.all(consultants.map(async (consultant) => {
    const accounts = await db.select({ id: networkAccounts.id, prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart }).from(networkAccounts).where(eq7(networkAccounts.ownerUserId, consultant.id));
    const accountIds = accounts.map((item) => item.id);
    const [[wallet], [bank], serviceEntries] = await Promise.all([
      db.select().from(wallets).where(eq7(wallets.userId, consultant.id)).limit(1),
      db.select({ bankName: consultantBankDetails.bankName, accountNumberLast4: consultantBankDetails.accountNumberLast4 }).from(consultantBankDetails).where(eq7(consultantBankDetails.userId, consultant.id)).limit(1),
      accountIds.length ? db.select({ amount: commissionEntries.amount }).from(commissionEntries).where(inArray4(commissionEntries.accountId, accountIds)) : Promise.resolve([])
    ]);
    const directEntries = wallet ? await db.select({ amount: walletLedger.amount }).from(walletLedger).where(and5(eq7(walletLedger.walletId, wallet.id), eq7(walletLedger.entryType, "DIRECT_ADMISSION_INCOME"))) : [];
    const directIncome = directEntries.reduce((sum, item) => sum + Number(item.amount), 0);
    const serviceGroupIncome = serviceEntries.reduce((sum, item) => sum + Number(item.amount), 0);
    const [fullBank] = await db.select().from(consultantBankDetails).where(eq7(consultantBankDetails.userId, consultant.id)).limit(1);
    return { ...consultant, accounts: accounts.map((item) => `${item.prefix}${item.numericPart}`), directIncome, serviceGroupIncome, totalIncome: directIncome + serviceGroupIncome, pendingBalance: Number(wallet?.pendingBalance ?? 0), availableBalance: Number(wallet?.availableBalance ?? 0), fridayPayable: Number(wallet?.pendingBalance ?? 0) + Number(wallet?.availableBalance ?? 0), bankDetailsReady: Boolean(bank), bankSummary: bank ? `${bank.bankName} \u2022\u2022\u2022\u2022${bank.accountNumberLast4}` : null, bankDetails: fullBank ? { bankName: fullBank.bankName, branchName: fullBank.branchName, accountHolderName: fullBank.accountHolderName, accountNumber: decryptBankAccount(fullBank.accountNumberEncrypted) } : null };
  }));
  rows.sort((a, b) => b.totalIncome - a.totalIncome);
  const [reminderSetting] = await db.select({ value: systemSettings.value }).from(systemSettings).where(eq7(systemSettings.key, "friday-payout-current")).limit(1);
  response.json({ consultants: rows, totalFridayPayable: rows.reduce((sum, item) => sum + item.fridayPayable, 0), totalIncome: rows.reduce((sum, item) => sum + item.totalIncome, 0), payoutReminder: reminderSetting?.value ?? null });
}));
commissionRouter.post("/admin/consultants/:userId/pay-and-clear", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const consultantUserId = z4.string().uuid().parse(request.params.userId);
  const db = requireDatabase();
  const result = await db.transaction(async (tx) => {
    const [row] = await tx.select({ wallet: wallets, user: users, bank: consultantBankDetails }).from(wallets).innerJoin(users, eq7(users.id, wallets.userId)).leftJoin(consultantBankDetails, eq7(consultantBankDetails.userId, users.id)).where(and5(eq7(wallets.userId, consultantUserId), eq7(users.role, "consultant"))).limit(1);
    if (!row) throw new HttpError(404, "Consultant wallet \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
    if (!row.bank) throw new HttpError(400, "Consultant bank details \u0DAD\u0DC0\u0DB8 add \u0D9A\u0DBB \u0DB1\u0DD0\u0DC4\u0DD0.");
    const amount = Number(row.wallet.availableBalance) + Number(row.wallet.pendingBalance);
    if (amount <= 0) throw new HttpError(409, "Clear \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8\u0DA7 payable balance \u0D91\u0D9A\u0D9A\u0DCA \u0DB1\u0DD0\u0DC4\u0DD0.");
    const now = /* @__PURE__ */ new Date();
    const [payout] = await tx.insert(payoutRequests).values({
      walletId: row.wallet.id,
      amount: amount.toFixed(2),
      status: "PAID",
      payoutMethod: "BANK_TRANSFER",
      payoutDetails: { paidManually: true, bankName: row.bank.bankName, accountNumberLast4: row.bank.accountNumberLast4 },
      reviewedBy: admin.id,
      reviewedAt: now,
      paidAt: now
    }).returning();
    await tx.update(wallets).set({ availableBalance: "0.00", pendingBalance: "0.00", updatedAt: now }).where(eq7(wallets.id, row.wallet.id));
    await tx.insert(walletLedger).values({
      walletId: row.wallet.id,
      idempotencyKey: `manual-payout:${payout.id}`,
      entryType: "MANUAL_BANK_PAYOUT",
      amount: (-amount).toFixed(2),
      referenceType: "payout_request",
      referenceId: payout.id,
      note: `Paid manually by Admin to ${row.bank.bankName} \u2022\u2022\u2022\u2022${row.bank.accountNumberLast4}`
    });
    await tx.insert(notifications).values({ userId: row.user.id, type: "PAYOUT_PAID", title: "Commission payment completed", message: `Rs. ${amount.toLocaleString()} bank transfer payment \u0D91\u0D9A \u0DC3\u0DB8\u0DCA\u0DB4\u0DD6\u0DBB\u0DCA\u0DAB \u0D9A\u0DBB \u0D87\u0DAD.` });
    await tx.insert(auditLogs).values({ actorUserId: admin.id, action: "CONSULTANT_PAYOUT_PAID_AND_CLEARED", entityType: "payout_request", entityId: payout.id, metadata: { consultantUserId, amount, bankName: row.bank.bankName, accountNumberLast4: row.bank.accountNumberLast4 } });
    return { payoutId: payout.id, consultantName: row.user.displayName, amount };
  });
  const remaining = await db.select({ available: wallets.availableBalance, pending: wallets.pendingBalance }).from(wallets).innerJoin(users, eq7(users.id, wallets.userId)).where(eq7(users.role, "consultant"));
  if (remaining.every((item) => Number(item.available) + Number(item.pending) <= 0)) {
    const [current] = await db.select({ value: systemSettings.value }).from(systemSettings).where(eq7(systemSettings.key, "friday-payout-current")).limit(1);
    const value = current?.value ?? {};
    await db.insert(systemSettings).values({ key: "friday-payout-current", value: { ...value, completedAt: (/* @__PURE__ */ new Date()).toISOString() }, updatedBy: admin.id }).onConflictDoUpdate({ target: systemSettings.key, set: { value: { ...value, completedAt: (/* @__PURE__ */ new Date()).toISOString() }, updatedBy: admin.id, updatedAt: /* @__PURE__ */ new Date() } });
  }
  response.json(result);
}));
commissionRouter.post("/admin/friday-payout-batches", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const { batchKey } = fridayBatchInput.parse(request.body);
  const db = requireDatabase();
  const result = await db.transaction(async (tx) => {
    const walletRows = await tx.select({ wallet: wallets, user: users, bank: consultantBankDetails }).from(wallets).innerJoin(users, eq7(users.id, wallets.userId)).leftJoin(consultantBankDetails, eq7(consultantBankDetails.userId, users.id)).where(eq7(users.role, "consultant"));
    let totalAmount = 0;
    let createdCount = 0;
    const skipped = [];
    for (const row of walletRows) {
      const amount = Number(row.wallet.availableBalance) + Number(row.wallet.pendingBalance);
      if (amount <= 0) continue;
      if (!row.bank) {
        skipped.push(`${row.user.displayName}: bank details missing`);
        continue;
      }
      const key2 = `friday-payout:${batchKey}:${row.user.id}`;
      const [existing] = await tx.select({ id: walletLedger.id }).from(walletLedger).where(eq7(walletLedger.idempotencyKey, key2)).limit(1);
      if (existing) {
        skipped.push(`${row.user.displayName}: already included`);
        continue;
      }
      const [payout] = await tx.insert(payoutRequests).values({ walletId: row.wallet.id, amount: amount.toFixed(2), payoutMethod: "BANK_TRANSFER", payoutDetails: { batchKey, bankDetailsOnFile: true } }).returning();
      await tx.update(wallets).set({ availableBalance: "0.00", pendingBalance: "0.00", updatedAt: /* @__PURE__ */ new Date() }).where(eq7(wallets.id, row.wallet.id));
      await tx.insert(walletLedger).values({ walletId: row.wallet.id, idempotencyKey: key2, entryType: "FRIDAY_PAYOUT_RESERVED", amount: (-amount).toFixed(2), referenceType: "payout_request", referenceId: payout.id, note: `${batchKey} Friday batch` });
      await tx.insert(notifications).values({ userId: row.user.id, type: "FRIDAY_PAYOUT_CREATED", title: "Friday payout prepared", message: `Rs. ${amount.toLocaleString()} payout \u0D91\u0D9A Admin \u0DC0\u0DD2\u0DC3\u0DD2\u0DB1\u0DCA \u0DC3\u0D9A\u0DC3\u0DCA \u0D9A\u0DBB \u0D87\u0DAD.` });
      totalAmount += amount;
      createdCount += 1;
    }
    await tx.insert(auditLogs).values({ actorUserId: admin.id, action: "FRIDAY_PAYOUT_BATCH_CREATED", entityType: "payout_batch", entityId: batchKey, metadata: { createdCount, totalAmount, skipped } });
    return { batchKey, createdCount, totalAmount, skipped };
  });
  response.status(201).json(result);
}));
commissionRouter.post("/admin/friday-payout-batches/:batchKey/mark-paid", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const batchKey = fridayBatchInput.shape.batchKey.parse(request.params.batchKey);
  const db = requireDatabase();
  const all = await db.select().from(payoutRequests).where(inArray4(payoutRequests.status, ["PENDING", "APPROVED"]));
  const matching = all.filter((item) => item.payoutDetails.batchKey === batchKey);
  if (!matching.length) throw new HttpError(404, "Payout batch not found or already paid.");
  await db.transaction(async (tx) => {
    for (const payout of matching) await tx.update(payoutRequests).set({ status: "PAID", reviewedBy: admin.id, reviewedAt: /* @__PURE__ */ new Date(), paidAt: /* @__PURE__ */ new Date() }).where(eq7(payoutRequests.id, payout.id));
    await tx.insert(auditLogs).values({ actorUserId: admin.id, action: "FRIDAY_PAYOUT_BATCH_PAID", entityType: "payout_batch", entityId: batchKey, metadata: { payoutCount: matching.length, totalAmount: matching.reduce((sum, item) => sum + Number(item.amount), 0) } });
  });
  response.json({ batchKey, paidCount: matching.length, totalAmount: matching.reduce((sum, item) => sum + Number(item.amount), 0) });
}));
commissionRouter.post(
  "/admin/commission-cycles/calculate",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = calculateInput.parse(request.body);
    const result = await calculateCommissionCycle(input, admin.id);
    response.status(201).json(result);
  })
);
commissionRouter.post(
  "/admin/commission-cycles/:id/approve",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const cycleId = String(request.params.id);
    const result = await db.transaction(async (tx) => {
      const [cycle] = await tx.select().from(commissionCycles).where(eq7(commissionCycles.id, cycleId)).limit(1);
      if (!cycle) throw new HttpError(404, "Commission cycle not found.");
      if (cycle.status !== "CALCULATED") {
        throw new HttpError(409, "Only a calculated cycle can be approved.");
      }
      const rows = await tx.select({
        accountId: commissionEntries.accountId,
        amount: commissionEntries.amount,
        ownerUserId: networkAccounts.ownerUserId
      }).from(commissionEntries).innerJoin(
        networkAccounts,
        eq7(commissionEntries.accountId, networkAccounts.id)
      ).where(eq7(commissionEntries.cycleId, cycle.id));
      const totals = /* @__PURE__ */ new Map();
      for (const row of rows) {
        totals.set(
          row.ownerUserId,
          (totals.get(row.ownerUserId) ?? 0) + Number(row.amount)
        );
      }
      for (const [userId, amount] of totals) {
        const [wallet] = await tx.select().from(wallets).where(eq7(wallets.userId, userId)).limit(1);
        if (!wallet) throw new Error("Wallet missing for commission owner.");
        const pending = Number(wallet.pendingBalance);
        if (pending < amount) {
          throw new Error("Wallet pending balance is inconsistent.");
        }
        await tx.update(wallets).set({
          pendingBalance: (pending - amount).toFixed(2),
          availableBalance: (Number(wallet.availableBalance) + amount).toFixed(2),
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq7(wallets.id, wallet.id));
        await tx.insert(walletLedger).values({
          walletId: wallet.id,
          idempotencyKey: "commission-release:" + cycle.id + ":" + userId,
          entryType: "COMMISSION_RELEASED",
          amount: amount.toFixed(2),
          referenceType: "commission_cycle",
          referenceId: cycle.id
        });
      }
      const [approved] = await tx.update(commissionCycles).set({
        status: "APPROVED",
        approvedBy: admin.id,
        approvedAt: /* @__PURE__ */ new Date()
      }).where(eq7(commissionCycles.id, cycle.id)).returning();
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "COMMISSION_CYCLE_APPROVED",
        entityType: "commission_cycle",
        entityId: cycle.id,
        metadata: { consultantCount: totals.size }
      });
      return { cycle: approved, consultantCount: totals.size };
    });
    response.json(result);
  })
);
commissionRouter.get(
  "/admin/commission-cycles",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const cycles = await db.select().from(commissionCycles).orderBy(desc5(commissionCycles.periodEnd));
    response.json({ cycles });
  })
);
commissionRouter.get(
  "/consultant/wallet",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant", "admin"]);
    const db = requireDatabase();
    const [wallet] = await db.select().from(wallets).where(eq7(wallets.userId, user.id)).limit(1);
    if (!wallet) {
      response.json({ wallet: null, ledger: [], payouts: [] });
      return;
    }
    const ledger = await db.select().from(walletLedger).where(eq7(walletLedger.walletId, wallet.id)).orderBy(desc5(walletLedger.createdAt));
    const payouts = await db.select().from(payoutRequests).where(eq7(payoutRequests.walletId, wallet.id)).orderBy(desc5(payoutRequests.createdAt));
    response.json({ wallet, ledger, payouts });
  })
);
commissionRouter.post(
  "/consultant/payout-requests",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant"]);
    const input = payoutInput.parse(request.body);
    const db = requireDatabase();
    const result = await db.transaction(async (tx) => {
      const [wallet] = await tx.select().from(wallets).where(eq7(wallets.userId, user.id)).limit(1);
      if (!wallet || Number(wallet.availableBalance) < input.amount) {
        throw new HttpError(400, "Available wallet balance is insufficient.");
      }
      const [payout] = await tx.insert(payoutRequests).values({
        walletId: wallet.id,
        amount: input.amount.toFixed(2),
        payoutMethod: input.payoutMethod,
        payoutDetails: input.payoutDetails
      }).returning();
      await tx.update(wallets).set({
        availableBalance: (Number(wallet.availableBalance) - input.amount).toFixed(2),
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq7(wallets.id, wallet.id));
      await tx.insert(walletLedger).values({
        walletId: wallet.id,
        idempotencyKey: "payout-reserve:" + payout.id,
        entryType: "PAYOUT_RESERVED",
        amount: (-input.amount).toFixed(2),
        referenceType: "payout_request",
        referenceId: payout.id
      });
      return payout;
    });
    response.status(201).json({ payout: result });
  })
);
commissionRouter.get(
  "/admin/payout-requests",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const payouts = await db.select().from(payoutRequests).orderBy(desc5(payoutRequests.createdAt));
    response.json({ payouts });
  })
);
commissionRouter.post(
  "/admin/payout-requests/:id/review",
  asyncRoute(async (request, response) => {
    const reviewer = await requireRole(request, ["admin"]);
    const input = payoutReviewInput.parse(request.body);
    const db = requireDatabase();
    const result = await db.transaction(async (tx) => {
      const [payout] = await tx.select().from(payoutRequests).where(eq7(payoutRequests.id, String(request.params.id))).limit(1);
      if (!payout) throw new HttpError(404, "Payout request not found.");
      if (["PAID", "REJECTED"].includes(payout.status)) {
        throw new HttpError(409, "Payout request is already finalized.");
      }
      if (input.status === "REJECTED") {
        const [wallet] = await tx.select().from(wallets).where(eq7(wallets.id, payout.walletId)).limit(1);
        await tx.update(wallets).set({
          availableBalance: (Number(wallet.availableBalance) + Number(payout.amount)).toFixed(2),
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq7(wallets.id, wallet.id));
        await tx.insert(walletLedger).values({
          walletId: wallet.id,
          idempotencyKey: "payout-return:" + payout.id,
          entryType: "PAYOUT_RETURNED",
          amount: payout.amount,
          referenceType: "payout_request",
          referenceId: payout.id
        });
      }
      const [updated] = await tx.update(payoutRequests).set({
        status: input.status,
        reviewedBy: reviewer.id,
        reviewedAt: /* @__PURE__ */ new Date(),
        paidAt: input.status === "PAID" ? /* @__PURE__ */ new Date() : null
      }).where(eq7(payoutRequests.id, payout.id)).returning();
      await tx.insert(auditLogs).values({
        actorUserId: reviewer.id,
        action: "PAYOUT_" + input.status,
        entityType: "payout_request",
        entityId: payout.id,
        metadata: { amount: payout.amount }
      });
      return updated;
    });
    response.json({ payout: result });
  })
);

// server/modules/platform/routes.ts
import crypto6 from "node:crypto";
import { and as and6, count as count3, desc as desc6, eq as eq8, gt as gt3, inArray as inArray5, isNull as isNull3, sql as sql3 } from "drizzle-orm";
import { Router as Router5 } from "express";
import { z as z5 } from "zod";
var platformRouter = Router5();
platformRouter.post(
  "/admin/accounts/repair",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const assigned = await db.transaction(async (tx) => {
      await tx.insert(accountNumberSequence).values({ id: 1, nextNumber: 527694 }).onConflictDoNothing();
      const existing = await tx.select({ numericPart: networkAccounts.numericPart }).from(networkAccounts).orderBy(desc6(networkAccounts.numericPart)).limit(1);
      const nextBlock = nextStudentAccountNumber(existing[0]?.numericPart);
      await tx.update(accountNumberSequence).set({
        nextNumber: sql3`GREATEST(${accountNumberSequence.nextNumber}, ${nextBlock})`,
        updatedAt: /* @__PURE__ */ new Date()
      }).where(eq8(accountNumberSequence.id, 1));
      const studentRows = await tx.select({ id: users.id, isActive: users.isActive }).from(users).where(eq8(users.role, "student"));
      let countAssigned = 0;
      for (const student of studentRows) {
        const [main] = await tx.select({ id: networkAccounts.id }).from(networkAccounts).where(and6(eq8(networkAccounts.ownerUserId, student.id), eq8(networkAccounts.isMainAccount, true))).limit(1);
        if (main) continue;
        const [sequence] = await tx.update(accountNumberSequence).set({
          nextNumber: sql3`${accountNumberSequence.nextNumber} + ${ACCOUNT_BLOCK_SIZE}`,
          updatedAt: /* @__PURE__ */ new Date()
        }).where(eq8(accountNumberSequence.id, 1)).returning({ nextNumber: accountNumberSequence.nextNumber });
        await tx.insert(networkAccounts).values({
          ownerUserId: student.id,
          prefix: "SR",
          numericPart: sequence.nextNumber - ACCOUNT_BLOCK_SIZE,
          status: student.isActive ? "ACTIVE" : "RESERVED",
          isMainAccount: true,
          activatedAt: student.isActive ? /* @__PURE__ */ new Date() : null
        });
        countAssigned += 1;
      }
      if (countAssigned) await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "MISSING_SR_ACCOUNTS_REPAIRED",
        entityType: "network_account",
        metadata: { assigned: countAssigned }
      });
      return countAssigned;
    });
    response.json({ assigned });
  })
);
var couponInput = z5.object({
  code: z5.string().trim().min(2).max(50),
  discountType: z5.enum(["PERCENT", "FIXED"]),
  discountValue: z5.coerce.number().positive(),
  courseId: z5.string().uuid().optional(),
  startsAt: z5.coerce.date().optional(),
  expiresAt: z5.coerce.date().optional(),
  maxUses: z5.coerce.number().int().positive().optional(),
  isActive: z5.boolean().default(true)
});
var supportInput = z5.object({
  subject: z5.string().trim().min(3).max(180),
  message: z5.string().trim().min(10).max(5e3),
  priority: z5.enum(["LOW", "NORMAL", "HIGH"]).default("NORMAL")
});
platformRouter.get(
  "/notifications",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db.select().from(notifications).where(eq8(notifications.userId, user.id)).orderBy(desc6(notifications.createdAt)).limit(100);
    response.json({ notifications: items });
  })
);
platformRouter.delete(
  "/notifications",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    await db.delete(notifications).where(eq8(notifications.userId, user.id));
    response.status(204).end();
  })
);
platformRouter.post(
  "/support-tickets",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = supportInput.parse(request.body);
    const db = requireDatabase();
    const [ticket] = await db.insert(supportTickets).values({ userId: user.id, ...input }).returning();
    response.status(201).json({ ticket });
  })
);
platformRouter.get(
  "/support-tickets/me",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const tickets = await db.select().from(supportTickets).where(eq8(supportTickets.userId, user.id)).orderBy(desc6(supportTickets.createdAt));
    response.json({ tickets });
  })
);
platformRouter.get(
  "/admin/support-tickets",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const tickets = await db.select().from(supportTickets).orderBy(desc6(supportTickets.createdAt));
    response.json({ tickets });
  })
);
platformRouter.post(
  "/admin/support-tickets/:id/resolve",
  asyncRoute(async (request, response) => {
    const staff = await requireRole(request, ["staff", "admin"]);
    const input = z5.object({ resolution: z5.string().trim().min(3).max(5e3) }).parse(request.body);
    const db = requireDatabase();
    const [ticket] = await db.update(supportTickets).set({
      status: "RESOLVED",
      resolution: input.resolution,
      assignedTo: staff.id,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq8(supportTickets.id, String(request.params.id))).returning();
    if (!ticket) throw new HttpError(404, "Support ticket not found.");
    await db.insert(notifications).values({
      userId: ticket.userId,
      type: "SUPPORT_TICKET_RESOLVED",
      title: "Support ticket resolved",
      message: input.resolution
    });
    response.json({ ticket });
  })
);
platformRouter.get(
  "/admin/coupons",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const items = await db.select().from(coupons).orderBy(desc6(coupons.createdAt));
    response.json({ coupons: items });
  })
);
platformRouter.post(
  "/admin/coupons",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = couponInput.parse(request.body);
    if (input.discountType === "PERCENT" && input.discountValue > 100) {
      throw new HttpError(400, "Percentage discount cannot exceed 100.");
    }
    if (input.startsAt && input.expiresAt && input.expiresAt <= input.startsAt) {
      throw new HttpError(400, "Coupon date range is invalid.");
    }
    const db = requireDatabase();
    const [coupon] = await db.insert(coupons).values({
      ...input,
      code: input.code.toUpperCase(),
      discountValue: input.discountValue.toFixed(2)
    }).returning();
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: "COUPON_CREATED",
      entityType: "coupon",
      entityId: coupon.id,
      metadata: { code: coupon.code }
    });
    response.status(201).json({ coupon });
  })
);
platformRouter.get(
  "/admin/settings",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const settings = await db.select().from(systemSettings);
    response.json({ settings });
  })
);
platformRouter.put(
  "/admin/settings/:key",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = z5.object({ value: z5.unknown() }).parse(request.body);
    const key2 = z5.string().regex(/^[A-Z0-9_]+$/).max(80).parse(String(request.params.key).toUpperCase());
    const db = requireDatabase();
    const [setting] = await db.insert(systemSettings).values({
      key: key2,
      value: input.value,
      updatedBy: admin.id,
      updatedAt: /* @__PURE__ */ new Date()
    }).onConflictDoUpdate({
      target: systemSettings.key,
      set: {
        value: input.value,
        updatedBy: admin.id,
        updatedAt: /* @__PURE__ */ new Date()
      }
    }).returning();
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: "SYSTEM_SETTING_UPDATED",
      entityType: "system_setting",
      entityId: key2
    });
    response.json({ setting });
  })
);
platformRouter.post(
  "/notifications/:id/read",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [updated] = await db.update(notifications).set({ readAt: /* @__PURE__ */ new Date() }).where(
      and6(
        eq8(notifications.id, String(request.params.id)),
        eq8(notifications.userId, user.id)
      )
    ).returning();
    if (!updated) throw new HttpError(404, "Notification not found.");
    response.json({ notification: updated });
  })
);
platformRouter.get(
  "/student/certificates",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db.select({
      certificate: certificates,
      courseTitle: courses.title
    }).from(certificates).innerJoin(courses, eq8(certificates.courseId, courses.id)).where(eq8(certificates.userId, user.id)).orderBy(desc6(certificates.issuedAt));
    response.json({ certificates: items });
  })
);
platformRouter.post(
  "/student/certificates/issue",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = z5.object({ courseId: z5.string().uuid() }).parse(request.body);
    const db = requireDatabase();
    const [existing] = await db.select().from(certificates).where(
      and6(
        eq8(certificates.userId, user.id),
        eq8(certificates.courseId, input.courseId)
      )
    ).limit(1);
    if (existing) {
      response.json({ certificate: existing });
      return;
    }
    const [enrollment] = await db.select().from(enrollments).where(
      and6(
        eq8(enrollments.userId, user.id),
        eq8(enrollments.courseId, input.courseId),
        eq8(enrollments.status, "ACTIVE")
      )
    ).limit(1);
    if (!enrollment) throw new HttpError(403, "Active enrollment required.");
    const sections = await db.select({ id: courseSections.id }).from(courseSections).where(eq8(courseSections.courseId, input.courseId));
    const sectionIds = sections.map((section) => section.id);
    const [{ totalLessons }] = sectionIds.length ? await db.select({ totalLessons: count3() }).from(lessons).where(inArray5(lessons.sectionId, sectionIds)) : [{ totalLessons: 0 }];
    const [{ completedLessons }] = await db.select({ completedLessons: count3() }).from(lessonProgress).where(
      and6(
        eq8(lessonProgress.enrollmentId, enrollment.id),
        eq8(lessonProgress.progressPercent, 100)
      )
    );
    if (totalLessons < 1 || completedLessons < totalLessons) {
      throw new HttpError(409, "All course lessons must be completed.");
    }
    const publishedQuizzes = await db.select({ id: quizzes.id }).from(quizzes).where(
      and6(
        eq8(quizzes.courseId, input.courseId),
        eq8(quizzes.isPublished, true)
      )
    );
    if (publishedQuizzes.length) {
      const passed = await db.select({ quizId: quizAttempts.quizId }).from(quizAttempts).where(
        and6(
          eq8(quizAttempts.userId, user.id),
          eq8(quizAttempts.passed, true),
          inArray5(
            quizAttempts.quizId,
            publishedQuizzes.map((quiz) => quiz.id)
          )
        )
      );
      const passedIds = new Set(passed.map((attempt) => attempt.quizId));
      if (passedIds.size < publishedQuizzes.length) {
        throw new HttpError(409, "All required quizzes must be passed.");
      }
    }
    const code = "ADIL-" + (/* @__PURE__ */ new Date()).getUTCFullYear() + "-" + crypto6.randomBytes(5).toString("hex").toUpperCase();
    const [created] = await db.insert(certificates).values({
      certificateCode: code,
      userId: user.id,
      courseId: input.courseId
    }).returning();
    await db.update(enrollments).set({ completedAt: /* @__PURE__ */ new Date(), status: "COMPLETED" }).where(eq8(enrollments.id, enrollment.id));
    response.status(201).json({ certificate: created });
  })
);
platformRouter.get(
  "/certificates/:code/verify",
  asyncRoute(async (request, response) => {
    const db = requireDatabase();
    const [item] = await db.select({
      code: certificates.certificateCode,
      issuedAt: certificates.issuedAt,
      revokedAt: certificates.revokedAt,
      studentName: users.displayName,
      courseTitle: courses.title
    }).from(certificates).innerJoin(users, eq8(certificates.userId, users.id)).innerJoin(courses, eq8(certificates.courseId, courses.id)).where(
      eq8(
        certificates.certificateCode,
        String(request.params.code).toUpperCase()
      )
    ).limit(1);
    if (!item) throw new HttpError(404, "Certificate not found.");
    response.json({ certificate: item, valid: !item.revokedAt });
  })
);
platformRouter.get(
  "/admin/overview",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const [
      [{ students }],
      [{ consultants }],
      [{ pendingPayments }],
      [{ pendingApplications }],
      [{ activeAccounts }],
      [{ commissionCycleCount }]
    ] = await Promise.all([
      db.select({ students: count3() }).from(users).where(eq8(users.role, "student")),
      db.select({ consultants: count3() }).from(users).where(eq8(users.role, "consultant")),
      db.select({ pendingPayments: count3() }).from(paymentRequests).where(
        inArray5(paymentRequests.status, [
          "PENDING",
          "UNDER_REVIEW",
          "PARTIAL"
        ])
      ),
      db.select({ pendingApplications: count3() }).from(consultantApplications).where(
        inArray5(consultantApplications.status, ["PENDING", "INTERVIEW"])
      ),
      db.select({ activeAccounts: count3() }).from(networkAccounts).where(eq8(networkAccounts.status, "ACTIVE")),
      db.select({ commissionCycleCount: count3() }).from(commissionCycles)
    ]);
    response.json({
      students,
      consultants,
      pendingPayments,
      pendingApplications,
      activeAccounts,
      commissionCycleCount
    });
  })
);
platformRouter.get(
  "/admin/students",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const studentRows = await db.select({
      id: users.id,
      name: users.displayName,
      email: users.email,
      phone: users.phone,
      nicOrPassport: users.nicOrPassport,
      address: users.address,
      dateOfBirth: users.dateOfBirth,
      isActive: users.isActive,
      emailVerifiedAt: users.emailVerifiedAt,
      passwordSetAt: users.passwordSetAt,
      createdAt: users.createdAt
    }).from(users).where(and6(eq8(users.role, "student"), isNull3(users.removedAt))).orderBy(desc6(users.createdAt));
    const students = await Promise.all(studentRows.map(async (student) => {
      const [[enrollment], [account], [payment]] = await Promise.all([
        db.select({ status: enrollments.status, courseTitle: courses.title }).from(enrollments).innerJoin(courses, eq8(enrollments.courseId, courses.id)).where(eq8(enrollments.userId, student.id)).limit(1),
        db.select({ prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart, status: networkAccounts.status }).from(networkAccounts).where(and6(eq8(networkAccounts.ownerUserId, student.id), eq8(networkAccounts.isMainAccount, true))).limit(1),
        db.select({ status: paymentRequests.status, paidAmount: paymentRequests.paidAmount, totalAmount: paymentRequests.totalAmount, paymentCode: paymentRequests.paymentCode }).from(paymentRequests).where(eq8(paymentRequests.userId, student.id)).orderBy(desc6(paymentRequests.createdAt)).limit(1)
      ]);
      return {
        ...student,
        enrollment: enrollment ?? null,
        account: account ? { number: `${account.prefix}${account.numericPart}`, status: account.status } : null,
        latestPayment: payment ?? null
      };
    }));
    response.json({ students });
  })
);
var adminStudentRegistrationInput = z5.object({
  firstName: z5.string().trim().min(2).max(60),
  lastName: z5.string().trim().min(2).max(60),
  email: z5.string().trim().email().max(200),
  phone: z5.string().trim().min(7).max(30),
  dateOfBirth: z5.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((value) => (/* @__PURE__ */ new Date(`${value}T00:00:00Z`)).getTime() <= Date.now(), "Date of birth \u0D85\u0DB1\u0DCF\u0D9C\u0DAD \u0DAF\u0DD2\u0DB1\u0DBA\u0D9A\u0DCA \u0DC0\u0DD2\u0DBA \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A."),
  nicOrPassport: z5.string().trim().max(50).optional(),
  withoutNic: z5.boolean().default(false),
  addressLine1: z5.string().trim().min(3).max(250),
  addressLine2: z5.string().trim().max(250).optional(),
  province: z5.string().trim().min(2).max(80),
  district: z5.string().trim().min(2).max(80),
  city: z5.string().trim().min(2).max(80),
  courseId: z5.string().uuid(),
  paymentPlan: z5.enum(["FULL", "HALF"]),
  assignmentType: z5.enum(["DIRECT", "CONSULTANT"]),
  parentAccountId: z5.string().uuid().optional(),
  side: z5.enum(["LEFT", "RIGHT"]).optional()
}).superRefine((value, context) => {
  if (!value.withoutNic && (!value.nicOrPassport || value.nicOrPassport.length < 5)) {
    context.addIssue({ code: "custom", path: ["nicOrPassport"], message: "NIC / Passport \u0D91\u0D9A \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA\u0DBA\u0DD2." });
  }
  if (value.assignmentType === "CONSULTANT" && (!value.parentAccountId || !value.side)) {
    context.addIssue({ code: "custom", path: ["parentAccountId"], message: "Consultant CN account \u0DC3\u0DC4 LEFT/RIGHT side \u0DAD\u0DDD\u0DBB\u0DB1\u0DCA\u0DB1." });
  }
});
platformRouter.get(
  "/admin/student-registration-options",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const [courseRows, accountRows] = await Promise.all([
      db.select({ id: courses.id, title: courses.title, price: courses.price, currency: courses.currency }).from(courses).where(eq8(courses.isPublished, true)).orderBy(courses.title),
      db.select({
        id: networkAccounts.id,
        numericPart: networkAccounts.numericPart,
        ownerId: users.id,
        ownerName: users.displayName,
        ownerEmail: users.email
      }).from(networkAccounts).innerJoin(users, eq8(networkAccounts.ownerUserId, users.id)).where(and6(
        eq8(networkAccounts.prefix, "CN"),
        eq8(networkAccounts.status, "ACTIVE"),
        eq8(users.role, "consultant"),
        eq8(users.isActive, true),
        isNull3(users.removedAt)
      )).orderBy(networkAccounts.numericPart)
    ]);
    response.json({
      courses: courseRows,
      accounts: accountRows.map((account) => ({ ...account, number: `CN${account.numericPart}` }))
    });
  })
);
platformRouter.post(
  "/admin/student-registrations",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = adminStudentRegistrationInput.parse(request.body);
    const db = requireDatabase();
    const email = input.email.toLowerCase();
    const [[course], [existingUser], [recentPayId]] = await Promise.all([
      db.select().from(courses).where(and6(eq8(courses.id, input.courseId), eq8(courses.isPublished, true))).limit(1),
      db.select({ id: users.id }).from(users).where(and6(eq8(users.email, email), isNull3(users.removedAt))).limit(1),
      db.select({ id: paymentReferenceIds.id }).from(paymentReferenceIds).where(and6(eq8(paymentReferenceIds.email, email), gt3(paymentReferenceIds.createdAt, new Date(Date.now() - 48 * 60 * 60 * 1e3)))).orderBy(desc6(paymentReferenceIds.createdAt)).limit(1)
    ]);
    if (!course) throw new HttpError(404, "Course \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
    if (existingUser) throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 active account \u0D91\u0D9A\u0D9A\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0D87\u0DAD.");
    if (recentPayId) throw new HttpError(429, "\u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 \u0DB4\u0DD0\u0DBA 48 \u0D87\u0DAD\u0DD4\u0DC5\u0DAD Pay ID \u0D91\u0D9A\u0D9A\u0DCA \u0DB1\u0DD2\u0D9A\u0DD4\u0DAD\u0DCA \u0D9A\u0DBB \u0D87\u0DAD.");
    const fullAmount = Number(course.price);
    const expectedPaymentAmount = input.paymentPlan === "HALF" ? 1e4 : fullAmount;
    if (input.paymentPlan === "HALF" && fullAmount !== 15e3) {
      throw new HttpError(400, "Half payment option \u0D91\u0D9A \u0DB8\u0DD9\u0DB8 course \u0D91\u0D9A\u0DA7 \u0DBD\u0DB6\u0DCF \u0DAF\u0DD3 \u0DB1\u0DDC\u0DB8\u0DD0\u0DAD.");
    }
    let consultantUserId = null;
    let parentAccountId = null;
    let side = null;
    if (input.assignmentType === "CONSULTANT") {
      const [account] = await db.select({ id: networkAccounts.id, ownerUserId: networkAccounts.ownerUserId }).from(networkAccounts).innerJoin(users, eq8(networkAccounts.ownerUserId, users.id)).where(and6(
        eq8(networkAccounts.id, input.parentAccountId),
        eq8(networkAccounts.prefix, "CN"),
        eq8(networkAccounts.status, "ACTIVE"),
        eq8(users.role, "consultant"),
        eq8(users.isActive, true),
        isNull3(users.removedAt)
      )).limit(1);
      if (!account) throw new HttpError(400, "Active consultant CN account \u0D91\u0D9A\u0D9A\u0DCA \u0DAD\u0DDD\u0DBB\u0DB1\u0DCA\u0DB1.");
      const [occupied] = await db.select({ id: networkPlacements.id }).from(networkPlacements).where(and6(eq8(networkPlacements.parentAccountId, account.id), eq8(networkPlacements.side, input.side), eq8(networkPlacements.placementKind, "STUDENT"))).limit(1);
      if (occupied) throw new HttpError(409, `${input.side} placement \u0D91\u0D9A \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB \u0D87\u0DAD.`);
      const [pendingPlacement] = await db.select({ id: consultantStudentRegistrations.id }).from(consultantStudentRegistrations).where(and6(
        eq8(consultantStudentRegistrations.parentAccountId, account.id),
        eq8(consultantStudentRegistrations.side, input.side),
        inArray5(consultantStudentRegistrations.status, ["AWAITING_PAYMENT", "PAYMENT_SUBMITTED"])
      )).limit(1);
      if (pendingPlacement) throw new HttpError(409, `${input.side} placement \u0D91\u0D9A \u0DC3\u0DB3\u0DC4\u0DCF \u0DAD\u0DC0\u0DAD\u0DCA admission \u0D91\u0D9A\u0D9A\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7 process \u0DC0\u0DD9\u0DB8\u0DD2\u0DB1\u0DCA \u0DB4\u0DC0\u0DAD\u0DD3.`);
      consultantUserId = account.ownerUserId;
      parentAccountId = account.id;
      side = input.side;
    }
    const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "");
    const code = `ADIL-PAY-${day}-${crypto6.randomBytes(3).toString("hex").toUpperCase()}`;
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1e3);
    const result = await db.transaction(async (tx) => {
      const [payId] = await tx.insert(paymentReferenceIds).values({ code, email, expiresAt }).returning();
      const [registration] = await tx.insert(consultantStudentRegistrations).values({
        consultantUserId,
        parentAccountId,
        side,
        payIdId: payId.id,
        courseId: course.id,
        registrationSource: input.assignmentType === "DIRECT" ? "ADMIN_DIRECT" : "ADMIN_ASSIGNED",
        paymentPlan: input.paymentPlan,
        expectedPaymentAmount: expectedPaymentAmount.toFixed(2),
        firstName: input.firstName,
        lastName: input.lastName,
        email,
        phone: input.phone,
        dateOfBirth: input.dateOfBirth,
        nicOrPassport: input.withoutNic ? null : input.nicOrPassport,
        addressLine1: input.addressLine1,
        addressLine2: input.addressLine2,
        province: input.province,
        district: input.district,
        city: input.city
      }).returning();
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "ADMIN_STUDENT_REGISTRATION_CREATED",
        entityType: "consultant_student_registration",
        entityId: registration.id,
        metadata: { source: registration.registrationSource, email, payId: code, parentAccountId, side }
      });
      return { registration, payId };
    });
    try {
      await sendPayId(email, code, expiresAt);
    } catch {
      await db.delete(consultantStudentRegistrations).where(eq8(consultantStudentRegistrations.id, result.registration.id));
      await db.delete(paymentReferenceIds).where(eq8(paymentReferenceIds.id, result.payId.id));
      throw new HttpError(503, "Pay ID email \u0D91\u0D9A \u0DBA\u0DD0\u0DC0\u0DD3\u0DB8\u0DA7 \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A\u0DD2 \u0DC0\u0DD2\u0DBA.");
    }
    response.status(201).json({
      registration: { id: result.registration.id, status: result.registration.status, source: result.registration.registrationSource },
      payIdSent: true,
      expiresAt
    });
  })
);
platformRouter.get(
  "/admin/consultants",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const rows = await db.select({
      id: users.id,
      name: users.displayName,
      email: users.email,
      phone: users.phone,
      isActive: users.isActive,
      createdAt: users.createdAt
    }).from(users).where(eq8(users.role, "consultant")).orderBy(desc6(users.createdAt));
    const consultants = await Promise.all(rows.map(async (consultant) => {
      const accounts = await db.select({ prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart, status: networkAccounts.status }).from(networkAccounts).where(eq8(networkAccounts.ownerUserId, consultant.id));
      return { ...consultant, accounts: accounts.map((account) => ({ ...account, number: `${account.prefix}${account.numericPart}` })) };
    }));
    response.json({ consultants });
  })
);
platformRouter.get("/admin/consultants/:id/financial-profile", asyncRoute(async (request, response) => {
  await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const consultantId = String(request.params.id);
  const [consultant] = await db.select({ id: users.id, name: users.displayName, email: users.email, phone: users.phone, nicOrPassport: users.nicOrPassport, address: users.address, dateOfBirth: users.dateOfBirth, isActive: users.isActive, createdAt: users.createdAt }).from(users).where(and6(eq8(users.id, consultantId), eq8(users.role, "consultant"))).limit(1);
  if (!consultant) throw new HttpError(404, "Consultant not found.");
  const accounts = await db.select().from(networkAccounts).where(eq8(networkAccounts.ownerUserId, consultant.id));
  const accountIds = accounts.map((account) => account.id);
  const [[wallet], [bank], entries] = await Promise.all([
    db.select().from(wallets).where(eq8(wallets.userId, consultant.id)).limit(1),
    db.select().from(consultantBankDetails).where(eq8(consultantBankDetails.userId, consultant.id)).limit(1),
    accountIds.length ? db.select().from(commissionEntries).where(inArray5(commissionEntries.accountId, accountIds)) : Promise.resolve([])
  ]);
  const payouts = wallet ? await db.select().from(payoutRequests).where(eq8(payoutRequests.walletId, wallet.id)).orderBy(desc6(payoutRequests.createdAt)) : [];
  const directEntries = wallet ? await db.select({ amount: walletLedger.amount }).from(walletLedger).where(and6(eq8(walletLedger.walletId, wallet.id), eq8(walletLedger.entryType, "DIRECT_ADMISSION_INCOME"))) : [];
  const directIncome = directEntries.reduce((sum, item) => sum + Number(item.amount), 0);
  const pendingRequests = payouts.filter((item) => ["PENDING", "APPROVED"].includes(item.status)).reduce((sum, item) => sum + Number(item.amount), 0);
  let bankDetails = null;
  if (bank) {
    try {
      bankDetails = { bankName: bank.bankName, branchName: bank.branchName, accountHolderName: bank.accountHolderName, accountNumber: decryptBankAccount(bank.accountNumberEncrypted), accountNumberLast4: bank.accountNumberLast4, updatedAt: bank.updatedAt };
    } catch {
      bankDetails = { bankName: bank.bankName, branchName: bank.branchName, accountHolderName: bank.accountHolderName, accountNumber: `\u2022\u2022\u2022\u2022${bank.accountNumberLast4}`, accountNumberLast4: bank.accountNumberLast4, updatedAt: bank.updatedAt };
    }
  }
  response.json({
    consultant,
    accounts: accounts.map((account) => ({ id: account.id, number: `${account.prefix}${account.numericPart}`, status: account.status, isMainAccount: account.isMainAccount })),
    financials: {
      totalIncome: entries.reduce((sum, entry) => sum + Number(entry.amount), 0) + directIncome,
      directIncome,
      pendingIncome: Number(wallet?.pendingBalance ?? 0),
      availableBalance: Number(wallet?.availableBalance ?? 0),
      weeklyPayable: Number(wallet?.pendingBalance ?? 0),
      requestedPayouts: pendingRequests,
      totalPaid: payouts.filter((item) => item.status === "PAID").reduce((sum, item) => sum + Number(item.amount), 0)
    },
    bankDetails,
    recentPayouts: payouts.slice(0, 10)
  });
}));
platformRouter.get(
  "/admin/accounts",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const accounts = await db.select({
      id: networkAccounts.id,
      prefix: networkAccounts.prefix,
      numericPart: networkAccounts.numericPart,
      status: networkAccounts.status,
      isMainAccount: networkAccounts.isMainAccount,
      activatedAt: networkAccounts.activatedAt,
      ownerId: users.id,
      ownerName: users.displayName,
      ownerEmail: users.email,
      ownerPhone: users.phone,
      ownerRole: users.role,
      learningPortalEnabled: users.learningPortalEnabled
    }).from(networkAccounts).innerJoin(users, eq8(networkAccounts.ownerUserId, users.id)).orderBy(desc6(networkAccounts.createdAt));
    response.json({ accounts: accounts.map((account) => ({ ...account, number: `${account.prefix}${account.numericPart}` })) });
  })
);
platformRouter.patch("/admin/users/:id/learning-portal", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const input = z5.object({ enabled: z5.boolean() }).parse(request.body);
  const userId = String(request.params.id);
  const [updated] = await db.update(users).set({ learningPortalEnabled: input.enabled, updatedAt: /* @__PURE__ */ new Date() }).where(eq8(users.id, userId)).returning({ id: users.id });
  if (!updated) throw new HttpError(404, "User not found.");
  await db.insert(auditLogs).values({ actorUserId: admin.id, action: input.enabled ? "LEARNING_PORTAL_ENABLED" : "LEARNING_PORTAL_DISABLED", entityType: "user", entityId: userId, metadata: {} });
  response.json({ message: `Learning Portal ${input.enabled ? "enabled" : "disabled"}.` });
}));
platformRouter.post(
  "/admin/accounts/:id/enable-cco",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const accountId = String(request.params.id);
    const result = await db.transaction(async (tx) => {
      const [record] = await tx.select({
        account: networkAccounts,
        ownerRole: users.role,
        ownerName: users.displayName
      }).from(networkAccounts).innerJoin(users, eq8(networkAccounts.ownerUserId, users.id)).where(eq8(networkAccounts.id, accountId)).limit(1);
      if (!record) throw new HttpError(404, "Account not found.");
      const { account } = record;
      if (!account.isMainAccount) throw new HttpError(409, "CCO can only be enabled on the student's main account.");
      if (account.status !== "ACTIVE") throw new HttpError(409, "Activate the paid SR account before enabling CCO.");
      if (account.prefix === "CN" && record.ownerRole === "consultant") {
        return { account, alreadyEnabled: true, ownerName: record.ownerName };
      }
      if (account.prefix !== "SR" || record.ownerRole !== "student") {
        throw new HttpError(409, "Only an active student SR account can be converted to CCO.");
      }
      const [conflict] = await tx.select({ id: networkAccounts.id }).from(networkAccounts).where(and6(
        eq8(networkAccounts.prefix, "CN"),
        eq8(networkAccounts.numericPart, account.numericPart)
      )).limit(1);
      if (conflict) throw new HttpError(409, `CN${account.numericPart} is already assigned. Contact system support.`);
      const [updatedAccount] = await tx.update(networkAccounts).set({ prefix: "CN" }).where(eq8(networkAccounts.id, account.id)).returning();
      await tx.update(users).set({ role: "consultant", updatedAt: /* @__PURE__ */ new Date() }).where(eq8(users.id, account.ownerUserId));
      await tx.insert(wallets).values({ userId: account.ownerUserId }).onConflictDoNothing({ target: wallets.userId });
      await tx.insert(notifications).values({
        userId: account.ownerUserId,
        type: "CCO_ENABLED",
        title: "CCO account enabled",
        message: `Your account is now CN${account.numericPart}. Refresh or sign in again to open the CCO panel.`
      });
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "CCO_ENABLED",
        entityType: "network_account",
        entityId: account.id,
        metadata: {
          ownerUserId: account.ownerUserId,
          previousNumber: `SR${account.numericPart}`,
          newNumber: `CN${account.numericPart}`
        }
      });
      return { account: updatedAccount, alreadyEnabled: false, ownerName: record.ownerName };
    });
    response.json({
      ...result,
      number: `CN${result.account.numericPart}`,
      message: result.alreadyEnabled ? "CCO is already enabled for this account." : "CCO enabled successfully. The student must refresh or sign in again."
    });
  })
);
platformRouter.post(
  "/admin/accounts/:id/disable-cco",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const accountId = String(request.params.id);
    const result = await db.transaction(async (tx) => {
      const [record] = await tx.select({ account: networkAccounts, ownerRole: users.role }).from(networkAccounts).innerJoin(users, eq8(networkAccounts.ownerUserId, users.id)).where(eq8(networkAccounts.id, accountId)).limit(1);
      if (!record) throw new HttpError(404, "Account not found.");
      const { account } = record;
      if (!account.isMainAccount || account.prefix !== "CN" || record.ownerRole !== "consultant") {
        throw new HttpError(409, "This account does not have an active CCO conversion.");
      }
      const [conflict] = await tx.select({ id: networkAccounts.id }).from(networkAccounts).where(and6(eq8(networkAccounts.prefix, "SR"), eq8(networkAccounts.numericPart, account.numericPart))).limit(1);
      if (conflict) throw new HttpError(409, `SR${account.numericPart} is already assigned. Contact system support.`);
      const [updatedAccount] = await tx.update(networkAccounts).set({ prefix: "SR" }).where(eq8(networkAccounts.id, account.id)).returning();
      await tx.update(users).set({ role: "student", updatedAt: /* @__PURE__ */ new Date() }).where(eq8(users.id, account.ownerUserId));
      await tx.insert(notifications).values({
        userId: account.ownerUserId,
        type: "CCO_DISABLED",
        title: "CCO account disabled",
        message: `Your consultant access was disabled. Your main account is now SR${account.numericPart}.`
      });
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "CCO_DISABLED",
        entityType: "network_account",
        entityId: account.id,
        metadata: {
          ownerUserId: account.ownerUserId,
          previousNumber: `CN${account.numericPart}`,
          newNumber: `SR${account.numericPart}`
        }
      });
      return updatedAccount;
    });
    response.json({
      account: result,
      number: `SR${result.numericPart}`,
      message: "CCO disabled successfully. The user must refresh or sign in again."
    });
  })
);
platformRouter.patch(
  "/admin/students/:id/status",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = z5.object({ isActive: z5.boolean() }).parse(request.body);
    const db = requireDatabase();
    const studentId = String(request.params.id);
    if (input.isActive) {
      const [candidate] = await db.select({ verified: users.emailVerifiedAt, passwordSet: users.passwordSetAt }).from(users).where(eq8(users.id, studentId)).limit(1);
      if (!candidate?.verified || !candidate.passwordSet) throw new HttpError(409, "Student must verify the email and set a password first.");
    }
    const [student] = await db.update(users).set({
      isActive: input.isActive,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(and6(eq8(users.id, studentId), eq8(users.role, "student"))).returning({
      id: users.id,
      name: users.displayName,
      isActive: users.isActive
    });
    if (!student) throw new HttpError(404, "Student not found.");
    if (!input.isActive) await db.delete(sessions).where(eq8(sessions.userId, student.id));
    await db.insert(auditLogs).values({
      actorUserId: admin.id,
      action: input.isActive ? "STUDENT_ACTIVATED" : "STUDENT_SUSPENDED",
      entityType: "user",
      entityId: student.id
    });
    response.json({ student });
  })
);
platformRouter.post(
  "/admin/students/:id/remove",
  asyncRoute(async (request, response) => {
    const admin = await requireRole(request, ["admin"]);
    const input = z5.object({
      confirmationEmail: z5.string().trim().email(),
      reason: z5.string().trim().max(250).optional()
    }).parse(request.body);
    const db = requireDatabase();
    const studentId = String(request.params.id);
    const result = await db.transaction(async (tx) => {
      const [student] = await tx.select({
        id: users.id,
        email: users.email,
        role: users.role,
        removedAt: users.removedAt
      }).from(users).where(eq8(users.id, studentId)).limit(1);
      if (!student || student.role !== "student" || student.removedAt) {
        throw new HttpError(404, "Active student record not found.");
      }
      if (student.email.toLowerCase() !== input.confirmationEmail.toLowerCase()) {
        throw new HttpError(409, "Confirmation email does not match this student.");
      }
      const [mainAccount] = await tx.select({
        prefix: networkAccounts.prefix,
        numericPart: networkAccounts.numericPart
      }).from(networkAccounts).where(and6(
        eq8(networkAccounts.ownerUserId, student.id),
        eq8(networkAccounts.isMainAccount, true)
      )).limit(1);
      const accountNumber = mainAccount ? `${mainAccount.prefix}${mainAccount.numericPart}` : "NO-ACCOUNT";
      const removedEmail = `removed-${student.id}@deleted.adil-academy.local`;
      const removedName = `Removed Student ${accountNumber}`;
      const now = /* @__PURE__ */ new Date();
      await tx.delete(sessions).where(eq8(sessions.userId, student.id));
      await tx.delete(notifications).where(eq8(notifications.userId, student.id));
      await tx.delete(quizAttempts).where(eq8(quizAttempts.userId, student.id));
      await tx.delete(certificates).where(eq8(certificates.userId, student.id));
      await tx.delete(enrollments).where(eq8(enrollments.userId, student.id));
      await tx.execute(sql3`DELETE FROM email_verification_codes WHERE user_id = ${student.id}`);
      await tx.execute(sql3`DELETE FROM support_tickets WHERE user_id = ${student.id}`);
      await tx.execute(sql3`DELETE FROM support_agent_presence WHERE user_id = ${student.id}`);
      await tx.execute(sql3`UPDATE support_conversations SET visitor_user_id = NULL, visitor_name = ${removedName}, visitor_email = NULL WHERE visitor_user_id = ${student.id}`);
      await tx.execute(sql3`UPDATE consultant_student_registrations SET first_name = 'Removed', last_name = 'Student', email = ${removedEmail}, phone = 'REMOVED', date_of_birth = 'REMOVED', nic_or_passport = NULL, address_line_1 = 'REMOVED', address_line_2 = NULL, province = 'REMOVED', district = 'REMOVED', city = 'REMOVED', updated_at = ${now} WHERE lower(email) = lower(${student.email})`);
      await tx.execute(sql3`UPDATE payment_reference_ids SET email = ${removedEmail} WHERE lower(email) = lower(${student.email})`);
      await tx.update(networkAccounts).set({ status: "SUSPENDED" }).where(eq8(networkAccounts.ownerUserId, student.id));
      await tx.update(users).set({
        email: removedEmail,
        displayName: removedName,
        phone: null,
        nicOrPassport: null,
        address: null,
        dateOfBirth: null,
        isActive: false,
        learningPortalEnabled: false,
        emailVerifiedAt: null,
        passwordSetAt: null,
        profilePhotoObjectKey: null,
        profilePhotoMimeType: null,
        removedAt: now,
        removalReason: input.reason || "Removed by administrator",
        updatedAt: now
      }).where(eq8(users.id, student.id));
      await tx.insert(auditLogs).values({
        actorUserId: admin.id,
        action: "STUDENT_SAFELY_REMOVED",
        entityType: "user",
        entityId: student.id,
        metadata: { accountNumber, financialHistoryRetained: true }
      });
      return { accountNumber };
    });
    response.json({
      message: `${result.accountNumber} removed. The original email can now register again.`,
      accountNumber: result.accountNumber
    });
  })
);
platformRouter.get(
  "/admin/audit-logs",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["admin"]);
    const db = requireDatabase();
    const logs = await db.select().from(auditLogs).orderBy(desc6(auditLogs.createdAt)).limit(250);
    response.json({ logs });
  })
);

// server/modules/support/routes.ts
import crypto7 from "node:crypto";
import { and as and7, desc as desc7, eq as eq9, gt as gt4, inArray as inArray6, isNull as isNull4, or } from "drizzle-orm";
import { Router as Router6 } from "express";
import { z as z6 } from "zod";
var supportRouter = Router6();
var tokenHash = (token) => crypto7.createHash("sha256").update(token).digest("hex");
var createInput = z6.object({ mode: z6.enum(["FAQ", "HUMAN"]), name: z6.string().trim().max(100).optional(), email: z6.string().trim().email().max(200).optional() });
var messageInput = z6.object({ token: z6.string().min(32).max(200), message: z6.string().trim().min(1).max(1500) });
var tokenInput = z6.object({ token: z6.string().min(32).max(200) });
var rate = /* @__PURE__ */ new Map();
function limit(request) {
  const key2 = request.ip || "unknown";
  const now = Date.now();
  const value = rate.get(key2);
  if (!value || value.resets < now) {
    rate.set(key2, { count: 1, resets: now + 6e4 });
    return;
  }
  if (value.count >= 30) throw new HttpError(429, "\u0D9A\u0DBB\u0DD4\u0DAB\u0DCF\u0D9A\u0DBB \u0DB8\u0DD2\u0DB1\u0DD2\u0DAD\u0DCA\u0DAD\u0DD4\u0DC0\u0D9A\u0DA7 \u0DB4\u0DC3\u0DD4 \u0DB1\u0DD0\u0DC0\u0DAD \u0D8B\u0DAD\u0DCA\u0DC3\u0DCF\u0DC4 \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.");
  value.count += 1;
}
async function optionalUser(request) {
  const token = readCookie(request.headers.cookie, "adil_session");
  return token ? await getUserForSession(token).catch(() => null) : null;
}
var FAQS = [
  { id: "greeting", phrases: ["hello", "hi", "hey", "\u0DC4\u0DD9\u0DBD\u0DDD", "\u0D86\u0DBA\u0DD4\u0DB6\u0DDD\u0DC0\u0DB1\u0DCA", "kohomada"], answer: "\u0D86\u0DBA\u0DD4\u0DB6\u0DDD\u0DC0\u0DB1\u0DCA! \u0DB8\u0DB8 Adil Academy \u0DC3\u0DD2\u0D82\u0DC4\u0DBD FAQ \u0DC3\u0DC4\u0DCF\u0DBA\u0D9A\u0DBA\u0DCF. \u0DB4\u0DCF\u0DA8\u0DB8\u0DCF\u0DBD\u0DCF, registration, payment, Pay ID, OTP, login, Student Portal, CCO, points, commission \u0DC4\u0DDD payout \u0D9C\u0DD0\u0DB1 \u0D85\u0DC4\u0DB1\u0DCA\u0DB1." },
  { id: "courses", phrases: ["course", "courses", "\u0DB4\u0DCF\u0DA8\u0DB8\u0DCF\u0DBD", "class", "\u0DB4\u0DB1\u0DCA\u0DAD\u0DD2\u0DBA", "\u0D89\u0D9C\u0DD9\u0DB1", "learn"], answer: "Home page \u0D91\u0D9A\u0DDA Courses \u0D9A\u0DDC\u0DA7\u0DC3\u0DD9\u0DB1\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7 publish \u0D9A\u0DBB \u0D87\u0DAD\u0DD2 \u0DB4\u0DCF\u0DA8\u0DB8\u0DCF\u0DBD\u0DCF, \u0DB8\u0DD2\u0DBD \u0DC3\u0DC4 \u0D9A\u0DD9\u0DA7\u0DD2 \u0DC0\u0DD2\u0DC3\u0DCA\u0DAD\u0DBB \u0DB6\u0DBD\u0DB1\u0DCA\u0DB1 \u0DB4\u0DD4\u0DC5\u0DD4\u0DC0\u0DB1\u0DCA. Admission Form \u0D91\u0D9A\u0DDA \u0DB8\u0DD4\u0DBD\u0DD2\u0DB1\u0DCA\u0DB8 \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA \u0DB4\u0DCF\u0DA8\u0DB8\u0DCF\u0DBD\u0DCF\u0DC0 \u0DAD\u0DDD\u0DBB\u0DCF \u0D91\u0DBA\u0DA7 \u0D85\u0DAF\u0DCF\u0DC5 application \u0D91\u0D9A submit \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." },
  { id: "register", phrases: ["register", "registration", "admission", "apply", "\u0DBD\u0DD2\u0DBA\u0DCF\u0DB4\u0DAF\u0DD2\u0D82\u0DA0\u0DD2", "\u0D85\u0DBA\u0DAF\u0DD4\u0DB8\u0DCA"], answer: "Admission Form \u0D91\u0D9A\u0DD9\u0DB1\u0DCA course \u0D91\u0D9A \u0DAD\u0DDD\u0DBB\u0DCF \u0DB1\u0DB8, phone, NIC/Passport, email, Pay ID/bank reference \u0DC3\u0DC4 payment slip \u0DBD\u0DB6\u0DCF\u0DAF\u0DD3 submit \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. Consultant \u0D9A\u0DD9\u0DB1\u0DD9\u0D9A\u0DD4 \u0DC4\u0DBB\u0DC4\u0DCF \u0D91\u0DB1\u0DC0\u0DCF \u0DB1\u0DB8\u0DCA \u0D94\u0DC4\u0DD4/\u0D87\u0DBA \u0DBD\u0DB6\u0DCF\u0DAF\u0DD4\u0DB1\u0DCA Pay ID \u0D91\u0D9A \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." },
  { id: "payid", phrases: ["pay id", "payid", "payment id", "reference id", "bank reference"], answer: "Pay ID \u0D91\u0D9A payment \u0D91\u0D9A \u0DB1\u0DD2\u0DC0\u0DD0\u0DBB\u0DAF\u0DD2 student/application \u0D91\u0D9A\u0DA7 \u0DC4\u0DB3\u0DD4\u0DB1\u0DCF\u0D9C\u0DD0\u0DB1\u0DD3\u0DB8\u0DA7 \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB\u0DB1 unique reference \u0D91\u0D9A\u0DBA\u0DD2. Bank transfer \u0D9A\u0DBB\u0DB1 \u0DC0\u0DD2\u0DA7 reference field \u0D91\u0D9A\u0DA7 \u0D91\u0DBA \u0DC0\u0DD9\u0DB1\u0DC3\u0DCA \u0DB1\u0DDC\u0D9A\u0DBB \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. \u0D91\u0D9A\u0DB8 Pay ID \u0D91\u0D9A \u0DC0\u0DD9\u0DB1\u0DAD\u0DCA \u0D9A\u0DD9\u0DB1\u0DD9\u0D9A\u0DD4\u0DA7 \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0DB1\u0DDC\u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." },
  { id: "payment", phrases: ["payment", "pay", "\u0D9C\u0DD9\u0DC0", "\u0DB8\u0DD4\u0DAF\u0DBD", "bank transfer", "slip", "receipt"], answer: "Payment \u0D9A\u0DC5 \u0DB4\u0DC3\u0DD4 \u0DB1\u0DD2\u0DC0\u0DD0\u0DBB\u0DAF\u0DD2 Pay ID/reference \u0DC3\u0DC4 \u0DB4\u0DD0\u0DC4\u0DD0\u0DAF\u0DD2\u0DBD\u0DD2 bank slip \u0D91\u0D9A Admission Form \u0D91\u0D9A\u0DD9\u0DB1\u0DCA upload \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. Status \u0D91\u0D9A Under Review \u0DBD\u0DD9\u0DC3 \u0DB4\u0DD9\u0DB1\u0DCA\u0DC0\u0DBA\u0DD2. Admin bank transaction \u0D91\u0D9A \u0DB4\u0DBB\u0DD3\u0D9A\u0DCA\u0DC2\u0DCF \u0D9A\u0DBB approve \u0D9A\u0DC5 \u0DB4\u0DC3\u0DD4 email OTP \u0D91\u0D9A \u0DBD\u0DD0\u0DB6\u0DDA." },
  { id: "payment_pending", phrases: ["pending", "under review", "approve \u0DB1\u0DD0", "approve n", "\u0DB4\u0DBB\u0DD3\u0D9A\u0DCA\u0DC2\u0DCF", "\u0DAD\u0DC0\u0DB8 approve"], answer: "Under Review/Pending \u0D9A\u0DD2\u0DBA\u0DB1\u0DCA\u0DB1\u0DDA payment \u0D91\u0D9A Admin \u0DC0\u0DD2\u0DC3\u0DD2\u0DB1\u0DCA \u0DAD\u0DC0\u0DB8 verify \u0D9A\u0DBB\u0DB8\u0DD2\u0DB1\u0DCA \u0DC3\u0DD2\u0DA7\u0DD2\u0DB1 \u0DB6\u0DC0\u0DBA\u0DD2. Pay ID, amount \u0DC3\u0DC4 slip \u0D91\u0D9A \u0DB4\u0DD0\u0DC4\u0DD0\u0DAF\u0DD2\u0DBD\u0DD2\u0DAF \u0DB6\u0DBD\u0DB1\u0DCA\u0DB1. \u0DB6\u0DDC\u0DC4\u0DDD \u0DC0\u0DDA\u0DBD\u0DCF\u0DC0\u0D9A\u0DCA \u0DC0\u0DD9\u0DB1\u0DC3\u0D9A\u0DCA \u0DB1\u0DD0\u0DAD\u0DCA\u0DB1\u0DB8\u0DCA Payment ID \u0D91\u0D9A \u0DC3\u0DB8\u0D9F Human Support \u0D85\u0DB8\u0DAD\u0DB1\u0DCA\u0DB1." },
  { id: "otp", phrases: ["otp", "verification code", "verify code", "\u0D9A\u0DDA\u0DAD", "code \u0D91\u0DB1\u0DCA\u0DB1", "code enna"], answer: "OTP \u0D91\u0D9A payment approve \u0D9A\u0DC5 \u0DB4\u0DC3\u0DD4 application email \u0D91\u0D9A\u0DA7 \u0DBA\u0DC0\u0DBA\u0DD2. Inbox, Spam \u0DC3\u0DC4 Promotions folders \u0DB6\u0DBD\u0DB1\u0DCA\u0DB1. Email address \u0D91\u0D9A \u0DC0\u0DD0\u0DBB\u0DAF\u0DD2 \u0DB1\u0DB8\u0DCA Human Support \u0D85\u0DB8\u0DAD\u0DB1\u0DCA\u0DB1. OTP/password \u0D9A\u0DD2\u0DC3\u0DD2\u0DC0\u0DD9\u0D9A\u0DD4\u0DA7 share \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1 \u0D91\u0DB4\u0DCF." },
  { id: "email_spam", phrases: ["spam", "email \u0DB1\u0DD0", "email na", "mail \u0DB1\u0DD0", "mail awe na", "promotions"], answer: "Email \u0D91\u0D9A Inbox \u0D91\u0D9A\u0DDA \u0DB1\u0DD0\u0DAD\u0DCA\u0DB1\u0DB8\u0DCA Spam/Junk/Promotions folder \u0DC3\u0DC4 search box \u0D91\u0D9A\u0DDA \u2018Adil Academy\u2019 \u0DB6\u0DBD\u0DB1\u0DCA\u0DB1. \u0DAD\u0DC0\u0DB8 \u0DB1\u0DD0\u0DAD\u0DCA\u0DB1\u0DB8\u0DCA application \u0D91\u0D9A\u0DDA email address \u0D91\u0D9A \u0DB1\u0DD2\u0DC0\u0DD0\u0DBB\u0DAF\u0DD2\u0DAF \u0DB4\u0DBB\u0DD3\u0D9A\u0DCA\u0DC2\u0DCF \u0D9A\u0DBB Human Support \u0DC0\u0DD9\u0DAD Payment ID \u0D91\u0D9A \u0DBA\u0DC0\u0DB1\u0DCA\u0DB1." },
  { id: "password", phrases: ["password", "\u0DB8\u0DD4\u0DBB\u0DB4\u0DAF", "forgot", "reset password", "pass word"], answer: "\u0DB4\u0DC5\u0DB8\u0DD4 OTP verification \u0D91\u0D9A\u0DDA \u0D94\u0DB6\u0DB8 permanent password \u0D91\u0D9A\u0D9A\u0DCA \u0DAD\u0DDD\u0DBB\u0DB1\u0DCA\u0DB1. Uppercase, lowercase \u0DC3\u0DC4 number \u0D91\u0D9A\u0D9A\u0DCA \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0DC1\u0D9A\u0DCA\u0DAD\u0DD2\u0DB8\u0DAD\u0DCA password \u0D91\u0D9A\u0D9A\u0DCA \u0DBA\u0DDC\u0DAF\u0DB1\u0DCA\u0DB1. Password \u0D85\u0DB8\u0DAD\u0D9A \u0DB1\u0DB8\u0DCA Human Support \u0DB8\u0D9C\u0DD2\u0DB1\u0DCA identity verify \u0D9A\u0DBB reset \u0DC3\u0DC4\u0DCF\u0DBA \u0DBD\u0DB6\u0DCF\u0D9C\u0DB1\u0DCA\u0DB1." },
  { id: "login", phrases: ["login", "log in", "sign in", "\u0D87\u0DAD\u0DD4\u0DBD\u0DCA", "open wenne", "\u0DBD\u0DDC\u0D9C\u0DCA"], answer: "Payment approve \u0D9A\u0DBB OTP verify \u0D9A\u0DC5 email \u0D91\u0D9A \u0DC3\u0DC4 \u0D94\u0DB6 \u0DAD\u0DDD\u0DBB\u0DCF\u0D9C\u0DAD\u0DCA password \u0D91\u0D9A\u0DD9\u0DB1\u0DCA Login \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. Account inactive/locked \u0DBD\u0DD9\u0DC3 \u0DB4\u0DD9\u0DB1\u0DCA\u0DC0\u0DB1\u0DCA\u0DB1\u0DDA \u0DB1\u0DB8\u0DCA Admin approval \u0DC4\u0DDD payment status \u0D91\u0D9A Human Support \u0DC3\u0DB8\u0D9F \u0DB4\u0DBB\u0DD3\u0D9A\u0DCA\u0DC2\u0DCF \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." },
  { id: "student_portal", phrases: ["student portal", "dashboard", "my course", "lesson", "video", "progress", "quiz"], answer: "Student Portal \u0DAD\u0DD4\u0DC5 My Course, lessons, progress, quizzes, certificates \u0DC3\u0DC4 payments \u0DB4\u0DD9\u0DB1\u0DCA\u0DC0\u0DBA\u0DD2. \u0D85\u0DBD\u0DD4\u0DAD\u0DCA account \u0D91\u0D9A\u0D9A progress 0% \u0DC3\u0DD2\u0DA7 \u0D86\u0DBB\u0DB8\u0DCA\u0DB7 \u0DC0\u0DD2\u0DBA \u0DBA\u0DD4\u0DAD\u0DD4\u0DBA\u0DD2. Course locked \u0DB1\u0DB8\u0DCA enrollment/payment approval \u0D91\u0D9A \u0DB4\u0DBB\u0DD3\u0D9A\u0DCA\u0DC2\u0DCF \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." },
  { id: "certificate", phrases: ["certificate", "\u0DC3\u0DC4\u0DAD\u0DD2\u0D9A", "completion"], answer: "\u0D85\u0DAF\u0DCF\u0DC5 \u0DB4\u0DCF\u0DA8\u0DB8\u0DCF\u0DBD\u0DCF\u0DC0\u0DDA \u0DC3\u0DD2\u0DBA\u0DBD\u0DD4 required lessons \u0DC3\u0DC4 quizzes \u0DC3\u0DB8\u0DCA\u0DB4\u0DD6\u0DBB\u0DCA\u0DAB \u0D9A\u0DBB \u0D85\u0DC0\u0DB8 quiz requirement \u0D91\u0D9A \u0DBD\u0DB6\u0DCF\u0D9C\u0DAD\u0DCA \u0DB4\u0DC3\u0DD4 certificate eligibility \u0DBD\u0DD0\u0DB6\u0DDA. Certificates tab \u0D91\u0D9A\u0DD9\u0DB1\u0DCA status \u0D91\u0D9A \u0DB6\u0DBD\u0DB1\u0DCA\u0DB1." },
  { id: "consultant", phrases: ["consultant", "cco", "cn number", "cn account", "\u0D8B\u0DB4\u0DAF\u0DDA\u0DC1\u0D9A"], answer: "CCO/Consultant access \u0DBD\u0DB6\u0DCF\u0DAF\u0DD9\u0DB1\u0DCA\u0DB1\u0DDA interview \u0DC3\u0DC4 Admin approval \u0D91\u0D9A\u0DD9\u0DB1\u0DCA \u0DB4\u0DB8\u0DAB\u0DBA\u0DD2. Approve \u0DC0\u0DD6 student account \u0D91\u0D9A\u0DDA Consultant Portal enable \u0DC0\u0DDA; \u0D85\u0DC0\u0DC3\u0DBB \u0DAD\u0DD2\u0DB6\u0DDA \u0DB1\u0DB8\u0DCA Student Portal \u0DC3\u0DC4 Consultant Portal \u0D85\u0DAD\u0DBB switch \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1 \u0DB4\u0DD4\u0DC5\u0DD4\u0DC0\u0DB1\u0DCA." },
  { id: "cco_activation", phrases: ["cco activation", "account buy", "reserved account", "trial account", "30 day", "active account"], answer: "Consultant Portal \u2192 CCO Activation \u0DAD\u0DD4\u0DC5 \u0D8A\u0DC5\u0D9F available reserved CN account \u0D91\u0D9A \u0DB4\u0DB8\u0DAB\u0D9A\u0DCA \u0DAD\u0DDD\u0DBB\u0DCF full activation \u0DC4\u0DDD \u0DBD\u0DB6\u0DCF\u0DAF\u0DD3 \u0D87\u0DAD\u0DD2 trial option \u0D91\u0D9A\u0DD9\u0DB1\u0DCA request \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. Bank slip submit \u0D9A\u0DC5 \u0DB4\u0DC3\u0DD4 Admin verify \u0D9A\u0DBB account \u0D91\u0D9A activate \u0D9A\u0DBB\u0DBA\u0DD2." },
  { id: "points", phrases: ["point", "points", "left side", "right side", "service account", "\u0DB4\u0DDC\u0DBA\u0DD2\u0DB1\u0DCA\u0DA7\u0DCA"], answer: "Verified full-payment admission \u0D91\u0D9A placement \u0DC0\u0DD6 service account side \u0D91\u0D9A\u0DA7 point \u0D91\u0D9A\u0D9A\u0DCA \u0DBD\u0DD9\u0DC3 record \u0DC0\u0DDA. Network structure \u0D85\u0DB1\u0DD4\u0DC0 \u0D91\u0DBA \u0D85\u0DAF\u0DCF\u0DC5 \u0D89\u0DC4\u0DC5 accounts \u0DC0\u0DD9\u0DAD propagate \u0DC0\u0DD2\u0DBA \u0DC4\u0DD0\u0D9A. Half payment \u0D91\u0D9A\u0D9A\u0DA7 qualification point \u0D91\u0D9A \u0DB1\u0DDC\u0DBD\u0DD0\u0DB6\u0DDA." },
  { id: "cycles", phrases: ["1:1", "2:2", "3:3", "cycle", "flush"], answer: "\u0DC3\u0DD1\u0DB8 active service account \u0D91\u0D9A\u0D9A\u0DA7\u0DB8 1:1 cycle \u0D91\u0D9A \u0D91\u0D9A\u0DCA \u0DC0\u0DBB\u0D9A\u0DCA Rs.2,500 \u0DC3\u0DC4 2:2 cycle \u0D91\u0D9A \u0D91\u0D9A\u0DCA \u0DC0\u0DBB\u0D9A\u0DCA Rs.5,000 \u0DC0\u0DDA. \u0D89\u0DB1\u0DCA\u0DB4\u0DC3\u0DD4 eligible 3:3 cycle \u0D91\u0D9A\u0D9A\u0DA7 Rs.8,000 \u0DB6\u0DD0\u0D9C\u0DD2\u0DB1\u0DCA repeat \u0DC0\u0DDA. Settlement \u0D91\u0D9A\u0DDA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DC5 points flush \u0DC0\u0DD3 \u0D89\u0DAD\u0DD2\u0DBB\u0DD2 points carry \u0DC0\u0DDA." },
  { id: "commission", phrases: ["commission", "income", "earning", "\u0D9A\u0DDC\u0DB8\u0DD2\u0DC3\u0DCA", "\u0D86\u0DAF\u0DCF\u0DBA", "direct income"], answer: "Approved direct admission \u0D91\u0D9A\u0D9A\u0DA7 direct income record \u0DC0\u0DDA. Service-group income eligible left/right points settle \u0DC0\u0DD6 \u0DB4\u0DC3\u0DD4 \u0DB4\u0DB8\u0DAB\u0D9A\u0DCA wallet \u0D91\u0D9A\u0DA7 \u0DB4\u0DD9\u0DB1\u0DCA\u0DC0\u0DBA\u0DD2. Income tab \u0D91\u0D9A\u0DDA available balance, ledger \u0DC3\u0DC4 payout status \u0DB6\u0DBD\u0DB1\u0DCA\u0DB1." },
  { id: "friday", phrases: ["friday", "sikurada", "\u0DC3\u0DD2\u0D9A\u0DD4\u0DBB\u0DCF\u0DAF\u0DCF", "12:30", "5:30", "weekly settlement", "payout"], answer: "\u0DC1\u0DCA\u200D\u0DBB\u0DD3 \u0DBD\u0D82\u0D9A\u0DCF \u0DC0\u0DDA\u0DBD\u0DCF\u0DC0\u0DD9\u0DB1\u0DCA \u0DC3\u0DD1\u0DB8 \u0DC3\u0DD2\u0D9A\u0DD4\u0DBB\u0DCF\u0DAF\u0DCF\u0DB8 12:30 PM eligible points settle \u0D9A\u0DBB commission wallet \u0D91\u0D9A\u0DA7 add \u0DC0\u0DDA. Admin manual bank payouts \u0DC3\u0DD2\u0D9A\u0DD4\u0DBB\u0DCF\u0DAF\u0DCF 5:30 PM \u0DAF\u0D9A\u0DCA\u0DC0\u0DCF process \u0D9A\u0DBB\u0DBA\u0DD2; bank processing time \u0D85\u0DB1\u0DD4\u0DC0 credit \u0DC0\u0DD3\u0DB8 \u0DB4\u0DCA\u200D\u0DBB\u0DB8\u0DCF\u0DAF \u0DC0\u0DD2\u0DBA \u0DC4\u0DD0\u0D9A." },
  { id: "bank_details", phrases: ["bank details", "account number", "bank account", "branch", "\u0DB6\u0DD0\u0D82\u0D9A\u0DD4 \u0DC0\u0DD2\u0DC3\u0DCA\u0DAD\u0DBB"], answer: "Consultant payout \u0DBD\u0DB6\u0DCF\u0D9C\u0DD0\u0DB1\u0DD3\u0DB8\u0DA7 My Profile/Income \u0DC3\u0DB8\u0DCA\u0DB6\u0DB1\u0DCA\u0DB0 bank details form \u0D91\u0D9A\u0DDA account holder name, bank, branch \u0DC3\u0DC4 account number \u0DB1\u0DD2\u0DC0\u0DD0\u0DBB\u0DAF\u0DD2\u0DC0 save \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. \u0DC0\u0DD0\u0DBB\u0DAF\u0DD2 bank details \u0DB1\u0DD2\u0DC3\u0DCF transfer fail \u0DC0\u0DD2\u0DBA \u0DC4\u0DD0\u0D9A." },
  { id: "suspend", phrases: ["suspend", "disabled", "inactive", "blocked", "lock", "\u0D85\u0D9A\u0DCA\u200D\u0DBB\u0DD3\u0DBA"], answer: "Account \u0D91\u0D9A suspended/disabled \u0DB1\u0DB8\u0DCA access \u0DAD\u0DCF\u0DC0\u0D9A\u0DCF\u0DBD\u0DD2\u0D9A\u0DC0 \u0DB1\u0DC0\u0DAD\u0DD3. Trial expiry, payment issue, security review \u0DC4\u0DDD Admin action \u0DC4\u0DDA\u0DAD\u0DD4\u0DC0\u0D9A\u0DCA \u0DC0\u0DD2\u0DBA \u0DC4\u0DD0\u0D9A. SR/CN number \u0D91\u0D9A \u0DC3\u0DB8\u0D9F Human Support \u0D85\u0DB8\u0DAD\u0DB1\u0DCA\u0DB1." },
  { id: "security", phrases: ["hack", "security", "safe", "scam", "otp share", "\u0D86\u0DBB\u0D9A\u0DCA\u0DC2\u0DCF"], answer: "Password \u0DC3\u0DC4 OTP \u0D9A\u0DD2\u0DC3\u0DD2\u0DC0\u0DD9\u0D9A\u0DD4\u0DA7 share \u0DB1\u0DDC\u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. Payment \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1 Adil Academy \u0DBD\u0DB6\u0DCF\u0DAF\u0DD9\u0DB1 verified bank details \u0DB4\u0DB8\u0DAB\u0D9A\u0DCA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1. \u0DC3\u0DD0\u0D9A \u0DC3\u0DC4\u0DD2\u0DAD message/link \u0D91\u0D9A\u0D9A\u0DCA \u0DBD\u0DD0\u0DB6\u0DD4\u0DAB\u0DDC\u0DAD\u0DCA payment \u0DB1\u0DDC\u0D9A\u0DBB Human Support \u0DC0\u0DD9\u0DAD screenshot \u0D91\u0D9A \u0DBA\u0DC0\u0DB1\u0DCA\u0DB1." },
  { id: "human", phrases: ["human", "person", "agent", "personal guide", "support", "admin \u0D91\u0D9A\u0DCA\u0D9A", "\u0D9A\u0DD9\u0DB1\u0DD9\u0D9A\u0DCA \u0D91\u0D9A\u0DCA\u0D9A"], answer: "Customer Care \u0D91\u0D9A \u0DB1\u0DD0\u0DC0\u0DAD \u0DC0\u0DD2\u0DC0\u0DD8\u0DAD \u0D9A\u0DBB Personal Guide \u0DAD\u0DDD\u0DBB\u0DB1\u0DCA\u0DB1. Online consultant/Admin \u0D9A\u0DD9\u0DB1\u0DD9\u0D9A\u0DCA I CAN HELP \u0DAD\u0DDD\u0DBB\u0DCF\u0D9C\u0DAD\u0DCA \u0DC0\u0DD2\u0DA7 live chat \u0D91\u0D9A \u0D86\u0DBB\u0DB8\u0DCA\u0DB7 \u0DC0\u0DDA. \u0D9A\u0DC0\u0DD4\u0DBB\u0DD4\u0DAD\u0DCA online \u0DB1\u0DD0\u0DAD\u0DCA\u0DB1\u0DB8\u0DCA \u0D94\u0DB6\u0D9C\u0DDA Payment ID/SR/CN number \u0DC3\u0DB8\u0D9F message \u0D91\u0D9A \u0DAD\u0DB6\u0DB1\u0DCA\u0DB1." }
];
function normalizeFaqText(value) {
  return value.toLocaleLowerCase().normalize("NFKC").replace(/[?!.(),/\\:_-]+/g, " ").replace(/\s+/g, " ").trim();
}
function faqAnswer(question) {
  const normalized = normalizeFaqText(question);
  const words = new Set(normalized.split(" ").filter((word) => word.length > 1));
  const ranked = FAQS.map((item) => {
    const score = item.phrases.reduce((total, phrase) => {
      const key2 = normalizeFaqText(phrase);
      if (normalized.includes(key2)) return total + (key2.includes(" ") ? 5 : 3);
      const parts = key2.split(" ");
      return total + parts.filter((part) => words.has(part)).length;
    }, 0);
    return { item, score };
  }).sort((a, b) => b.score - a.score);
  if (ranked[0]?.score >= 3) return ranked[0].item.answer;
  return "\u0D94\u0DB6\u0D9C\u0DDA \u0DB4\u0DCA\u200D\u0DBB\u0DC1\u0DCA\u0DB1\u0DBA \u0DB8\u0DA7 \u0DAD\u0DC0\u0DB8 \u0DB1\u0DD2\u0DC0\u0DD0\u0DBB\u0DAF\u0DD2\u0DC0 \u0DC4\u0DB3\u0DD4\u0DB1\u0DCF\u0D9C\u0DAD \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A. Payment ID, OTP, login, course, Student Portal, CCO, points, commission \u0DC4\u0DDD payout \u0DBA\u0DB1 \u0DB8\u0DCF\u0DAD\u0DD8\u0D9A\u0DCF\u0DC0 \u0DC3\u0DB3\u0DC4\u0DB1\u0DCA \u0D9A\u0DBB \u0DB1\u0DD0\u0DC0\u0DAD \u0D9A\u0DD9\u0DA7\u0DD2\u0DBA\u0DD9\u0DB1\u0DCA \u0D85\u0DC4\u0DB1\u0DCA\u0DB1. \u0D91\u0DC3\u0DDA \u0DB1\u0DD0\u0DAD\u0DCA\u0DB1\u0DB8\u0DCA Customer Care \u2192 Personal Guide \u0DAD\u0DDD\u0DBB\u0DCF Human Support \u0DBD\u0DB6\u0DCF\u0D9C\u0DB1\u0DCA\u0DB1.";
}
supportRouter.get("/public/support/availability", asyncRoute(async (_request, response) => {
  const db = requireDatabase();
  const since = new Date(Date.now() - 6e4);
  const online = await db.select({ id: users.id }).from(supportAgentPresence).innerJoin(users, eq9(users.id, supportAgentPresence.userId)).where(and7(gt4(supportAgentPresence.lastSeenAt, since), eq9(users.isActive, true), inArray6(users.role, ["consultant", "staff", "admin"]))).limit(1);
  response.json({ humanOnline: online.length > 0 });
}));
supportRouter.post("/public/support/conversations", asyncRoute(async (request, response) => {
  limit(request);
  const input = createInput.parse(request.body);
  const db = requireDatabase();
  const rawToken = crypto7.randomBytes(32).toString("hex");
  const current = await optionalUser(request);
  const since = new Date(Date.now() - 6e4);
  const onlineAgents = input.mode === "HUMAN" ? await db.select({ id: users.id }).from(supportAgentPresence).innerJoin(users, eq9(users.id, supportAgentPresence.userId)).where(and7(gt4(supportAgentPresence.lastSeenAt, since), eq9(users.isActive, true), inArray6(users.role, ["consultant", "staff", "admin"]))) : [];
  const humanOnline = onlineAgents.length > 0;
  const channel = input.mode === "HUMAN" && humanOnline ? "HUMAN" : "FAQ";
  const status = channel === "HUMAN" ? "WAITING" : "BOT";
  const [conversation] = await db.insert(supportConversations).values({ publicTokenHash: tokenHash(rawToken), channel, status, visitorName: input.name, visitorEmail: input.email, visitorUserId: current?.id }).returning();
  const welcome = input.mode === "HUMAN" && !humanOnline ? "\u0DAF\u0DD0\u0DB1\u0DA7 Human Support team \u0D91\u0D9A online \u0DB1\u0DD0\u0DC4\u0DD0. \u0D94\u0DB6\u0DA7 \u0D89\u0D9A\u0DCA\u0DB8\u0DB1\u0DD2\u0DB1\u0DCA \u0D8B\u0DAF\u0DC0\u0DCA \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8\u0DA7 FAQ Bot \u0D91\u0D9A \u0DC3\u0DB8\u0DCA\u0DB6\u0DB1\u0DCA\u0DB0 \u0D9A\u0DC5\u0DCF." : channel === "HUMAN" ? "\u0D94\u0DB6\u0D9C\u0DDA request \u0D91\u0D9A online support team \u0D91\u0D9A\u0DA7 \u0DBA\u0DD0\u0DC0\u0DCA\u0DC0\u0DCF. \u0DB4\u0DC5\u0DB8\u0DD4 available Personal Guide \u0D94\u0DB6 \u0DC3\u0DB8\u0D9F \u0DC3\u0DB8\u0DCA\u0DB6\u0DB1\u0DCA\u0DB0 \u0DC0\u0DDA." : "\u0D86\u0DBA\u0DD4\u0DB6\u0DDD\u0DC0\u0DB1\u0DCA! \u0D94\u0DB6\u0D9C\u0DDA \u0DB4\u0DCA\u200D\u0DBB\u0DC1\u0DCA\u0DB1\u0DBA \u0DC3\u0DD2\u0D82\u0DC4\u0DBD\u0DD9\u0DB1\u0DCA \u0DC4\u0DDD English \u0DC0\u0DBD\u0DD2\u0DB1\u0DCA \u0D9A\u0DD9\u0DA7\u0DD2\u0DBA\u0DD9\u0DB1\u0DCA \u0DBD\u0DD2\u0DBA\u0DB1\u0DCA\u0DB1.";
  await db.insert(supportMessages).values({ conversationId: conversation.id, senderType: "SYSTEM", body: welcome });
  if (channel === "HUMAN" && onlineAgents.length) await db.insert(notifications).values(onlineAgents.map((agent) => ({ userId: agent.id, type: "SUPPORT_WAITING", title: "Customer needs human support", message: `${input.name || "Visitor"} \u0DC3\u0DB8\u0D9F chat \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8\u0DA7 I CAN HELP \u0D94\u0DB6\u0DB1\u0DCA\u0DB1.` })));
  response.status(201).json({ id: conversation.id, token: rawToken, status, humanOnline, message: welcome });
}));
supportRouter.post("/public/support/conversations/:id/messages", asyncRoute(async (request, response) => {
  limit(request);
  const input = messageInput.parse(request.body);
  const db = requireDatabase();
  const [conversation] = await db.select().from(supportConversations).where(and7(eq9(supportConversations.id, String(request.params.id)), eq9(supportConversations.publicTokenHash, tokenHash(input.token)))).limit(1);
  if (!conversation) throw new HttpError(404, "Support chat \u0D91\u0D9A \u0DC3\u0DDC\u0DBA\u0DCF\u0D9C\u0DAD \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A.");
  if (conversation.status === "CLOSED") throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 chat \u0D91\u0D9A \u0D85\u0DC0\u0DC3\u0DB1\u0DCA \u0D9A\u0DBB \u0D87\u0DAD.");
  const [sent] = await db.insert(supportMessages).values({ conversationId: conversation.id, senderType: "VISITOR", body: input.message }).returning();
  await db.update(supportConversations).set({ lastMessageAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq9(supportConversations.id, conversation.id));
  let bot = null;
  if (conversation.channel === "FAQ") {
    [bot] = await db.insert(supportMessages).values({ conversationId: conversation.id, senderType: "BOT", body: faqAnswer(input.message) }).returning();
  }
  response.status(201).json({ message: sent, bot });
}));
supportRouter.get("/public/support/conversations/:id", asyncRoute(async (request, response) => {
  limit(request);
  const input = tokenInput.parse(request.query);
  const db = requireDatabase();
  const [conversation] = await db.select().from(supportConversations).where(and7(eq9(supportConversations.id, String(request.params.id)), eq9(supportConversations.publicTokenHash, tokenHash(input.token)))).limit(1);
  if (!conversation) throw new HttpError(404, "Support chat \u0D91\u0D9A \u0DC3\u0DDC\u0DBA\u0DCF\u0D9C\u0DAD \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A.");
  const messages = await db.select().from(supportMessages).where(eq9(supportMessages.conversationId, conversation.id)).orderBy(supportMessages.createdAt);
  let agentName = null;
  if (conversation.assignedTo) {
    const [agent] = await db.select({ name: users.displayName }).from(users).where(eq9(users.id, conversation.assignedTo));
    agentName = agent?.name ?? null;
  }
  response.json({ conversation: { ...conversation, publicTokenHash: void 0, agentName }, messages });
}));
supportRouter.post("/support/heartbeat", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]);
  const db = requireDatabase();
  await db.insert(supportAgentPresence).values({ userId: user.id, lastSeenAt: /* @__PURE__ */ new Date() }).onConflictDoUpdate({ target: supportAgentPresence.userId, set: { lastSeenAt: /* @__PURE__ */ new Date() } });
  response.status(204).end();
}));
supportRouter.get("/support/queue", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]);
  const db = requireDatabase();
  const rows = await db.select().from(supportConversations).where(or(eq9(supportConversations.status, "WAITING"), and7(eq9(supportConversations.assignedTo, user.id), inArray6(supportConversations.status, ["CLAIMED", "OPEN"])))).orderBy(desc7(supportConversations.lastMessageAt)).limit(100);
  response.json({ conversations: rows.map(({ publicTokenHash: _secret, ...row }) => ({ ...row, visitorEmail: row.assignedTo === user.id || user.role === "admin" ? row.visitorEmail : null })) });
}));
supportRouter.post("/support/conversations/:id/claim", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]);
  const db = requireDatabase();
  const [claimed] = await db.update(supportConversations).set({ assignedTo: user.id, status: "CLAIMED", claimedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(and7(eq9(supportConversations.id, String(request.params.id)), eq9(supportConversations.status, "WAITING"), isNull4(supportConversations.assignedTo))).returning();
  if (!claimed) throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 customer\u0DA7 \u0DC0\u0DD9\u0DB1\u0DAD\u0DCA guide \u0D9A\u0DD9\u0DB1\u0DD9\u0D9A\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0D8B\u0DAF\u0DC0\u0DCA \u0D9A\u0DBB\u0DBA\u0DD2.");
  await db.insert(supportMessages).values({ conversationId: claimed.id, senderType: "SYSTEM", body: `${user.name} Personal Guide \u0DBD\u0DD9\u0DC3 chat \u0D91\u0D9A\u0DA7 \u0DC3\u0DB8\u0DCA\u0DB6\u0DB1\u0DCA\u0DB0 \u0DC0\u0DD2\u0DBA.` });
  response.json({ conversation: claimed });
}));
supportRouter.get("/support/conversations/:id/messages", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]);
  const db = requireDatabase();
  const id = String(request.params.id);
  const [conversation] = await db.select().from(supportConversations).where(eq9(supportConversations.id, id));
  if (!conversation || user.role !== "admin" && conversation.assignedTo !== user.id) throw new HttpError(403, "\u0DB8\u0DD9\u0DB8 chat \u0D91\u0D9A\u0DA7 access \u0DB1\u0DD0\u0DC4\u0DD0.");
  const messages = await db.select().from(supportMessages).where(eq9(supportMessages.conversationId, id)).orderBy(supportMessages.createdAt);
  response.json({ conversation, messages });
}));
supportRouter.post("/support/conversations/:id/messages", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]);
  const body = z6.object({ message: z6.string().trim().min(1).max(1500) }).parse(request.body);
  const db = requireDatabase();
  const id = String(request.params.id);
  const [conversation] = await db.select().from(supportConversations).where(eq9(supportConversations.id, id));
  if (!conversation || user.role !== "admin" && conversation.assignedTo !== user.id) throw new HttpError(403, "\u0DB8\u0DD9\u0DB8 chat \u0D91\u0D9A\u0DA7 access \u0DB1\u0DD0\u0DC4\u0DD0.");
  const [message] = await db.insert(supportMessages).values({ conversationId: id, senderType: "AGENT", senderUserId: user.id, body: body.message }).returning();
  await db.update(supportConversations).set({ lastMessageAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq9(supportConversations.id, id));
  response.status(201).json({ message });
}));
supportRouter.post("/support/conversations/:id/close", asyncRoute(async (request, response) => {
  const user = await requireRole(request, ["consultant", "staff", "admin"]);
  const db = requireDatabase();
  const id = String(request.params.id);
  const [closed] = await db.update(supportConversations).set({ status: "CLOSED", closedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(and7(eq9(supportConversations.id, id), user.role === "admin" ? or(eq9(supportConversations.assignedTo, user.id), isNull4(supportConversations.assignedTo)) : eq9(supportConversations.assignedTo, user.id))).returning();
  if (!closed) throw new HttpError(403, "\u0DB8\u0DD9\u0DB8 chat \u0D91\u0D9A close \u0D9A\u0DC5 \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A.");
  await db.insert(supportMessages).values({ conversationId: id, senderType: "SYSTEM", body: "Support chat \u0D91\u0D9A \u0D85\u0DC0\u0DC3\u0DB1\u0DCA \u0D9A\u0DBB \u0D87\u0DAD. \u0D94\u0DB6\u0DA7 \u0DB1\u0DD0\u0DC0\u0DAD \u0D8B\u0DAF\u0DC0\u0DCA \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA \u0DB1\u0DB8\u0DCA \u0D85\u0DBD\u0DD4\u0DAD\u0DCA chat \u0D91\u0D9A\u0D9A\u0DCA \u0D86\u0DBB\u0DB8\u0DCA\u0DB7 \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." });
  response.json({ conversation: closed });
}));

// server/modules/cco-main/routes.ts
import crypto8 from "node:crypto";
import argon22 from "argon2";
import express4, { Router as Router7 } from "express";
import { and as and8, desc as desc8, eq as eq10, gt as gt5, isNull as isNull5, sql as sql4 } from "drizzle-orm";
import { z as z7 } from "zod";
var ccoMainRouter = Router7();
var issueSchema = z7.object({
  name: z7.string().trim().min(2).max(120),
  email: z7.string().trim().email(),
  phone: z7.string().trim().min(7).max(30),
  amount: z7.coerce.number().min(1).max(1e6).default(5e3)
});
var submitSchema = z7.object({
  payId: z7.string().trim().min(8).max(80),
  firstName: z7.string().trim().min(2).max(80),
  lastName: z7.string().trim().min(1).max(80),
  email: z7.string().trim().email(),
  phone: z7.string().trim().min(7).max(30),
  dateOfBirth: z7.string().trim().min(4).max(20),
  nicOrPassport: z7.string().trim().min(4).max(40),
  addressLine1: z7.string().trim().min(3).max(240),
  addressLine2: z7.string().trim().max(240).optional().default(""),
  province: z7.string().trim().min(2).max(80),
  district: z7.string().trim().min(2).max(80),
  city: z7.string().trim().min(2).max(80),
  transactionReference: z7.string().trim().min(3).max(120)
});
var reviewSchema = z7.object({ status: z7.enum(["APPROVED", "REJECTED"]), note: z7.string().trim().max(500).optional() });
function tokenHash2(value) {
  return crypto8.createHash("sha256").update(value).digest("hex");
}
function makePayId() {
  const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "");
  return `CCO-${day}-${crypto8.randomBytes(4).toString("hex").toUpperCase()}`;
}
ccoMainRouter.post("/admin/cco-main/pay-ids", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const input = issueSchema.parse(request.body);
  const email = input.email.toLowerCase();
  const db = requireDatabase();
  const [existingUser] = await db.select({ id: users.id }).from(users).where(eq10(users.email, email)).limit(1);
  if (existingUser) throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA account \u0D91\u0D9A\u0D9A\u0DCA \u0DAD\u0DD2\u0DB6\u0DDA.");
  const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1e3);
  const [payId] = await db.insert(ccoMainPayIds).values({
    code: makePayId(),
    intendedName: input.name,
    intendedEmail: email,
    intendedPhone: input.phone,
    amount: String(input.amount),
    expiresAt,
    createdBy: admin.id
  }).returning();
  let emailSent = false;
  try {
    await sendCcoMainPayId(email, input.name, payId.code, input.amount, expiresAt);
    emailSent = true;
  } catch (error) {
    console.error("CCO main Pay ID email failed", error);
  }
  await db.insert(auditLogs).values({ actorUserId: admin.id, action: "CCO_MAIN_PAY_ID_ISSUED", entityType: "cco_main_pay_id", entityId: payId.id, metadata: { email, amount: input.amount } });
  response.json({ payId: payId.code, expiresAt, emailSent });
}));
ccoMainRouter.post("/public/cco-main/validate", asyncRoute(async (request, response) => {
  const code = z7.string().trim().min(8).parse(request.body?.payId).toUpperCase();
  const db = requireDatabase();
  const [payId] = await db.select().from(ccoMainPayIds).where(and8(eq10(ccoMainPayIds.code, code), isNull5(ccoMainPayIds.claimedAt), isNull5(ccoMainPayIds.cancelledAt), gt5(ccoMainPayIds.expiresAt, /* @__PURE__ */ new Date()))).limit(1);
  if (!payId) throw new HttpError(400, "Pay ID \u0D91\u0D9A invalid, expired \u0DC4\u0DDD \u0D9A\u0DBD\u0DD2\u0DB1\u0DCA \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB \u0D87\u0DAD.");
  response.json({ valid: true, name: payId.intendedName, email: payId.intendedEmail, phone: payId.intendedPhone, amount: Number(payId.amount) });
}));
ccoMainRouter.post("/public/cco-main/applications", asyncRoute(async (request, response) => {
  const input = submitSchema.parse(request.body);
  const db = requireDatabase();
  const code = input.payId.toUpperCase();
  const email = input.email.toLowerCase();
  const registrationToken = crypto8.randomBytes(32).toString("base64url");
  const result = await db.transaction(async (tx) => {
    const [payId] = await tx.update(ccoMainPayIds).set({ claimedAt: /* @__PURE__ */ new Date() }).where(and8(
      eq10(ccoMainPayIds.code, code),
      eq10(ccoMainPayIds.intendedEmail, email),
      isNull5(ccoMainPayIds.claimedAt),
      isNull5(ccoMainPayIds.cancelledAt),
      gt5(ccoMainPayIds.expiresAt, /* @__PURE__ */ new Date())
    )).returning();
    if (!payId) throw new HttpError(409, "Pay ID \u0D91\u0D9A invalid, expired, \u0DC0\u0DD9\u0DB1\u0DAD\u0DCA email \u0D91\u0D9A\u0D9A\u0DA7 \u0D85\u0DAF\u0DCF\u0DC5 \u0DC4\u0DDD \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD \u0D9A\u0DBB \u0D87\u0DAD.");
    if (input.transactionReference.toUpperCase() !== code) throw new HttpError(400, "Bank reference \u0D91\u0D9A special Pay ID \u0D91\u0D9A\u0DA7 \u0DC3\u0DB8\u0DCF\u0DB1 \u0DC0\u0DD2\u0DBA \u0DBA\u0DD4\u0DAD\u0DD4\u0DBA\u0DD2.");
    const [existing] = await tx.select({ id: users.id }).from(users).where(eq10(users.email, email)).limit(1);
    if (existing) throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA account \u0D91\u0D9A\u0D9A\u0DCA \u0DAD\u0DD2\u0DB6\u0DDA.");
    const [user] = await tx.insert(users).values({
      email,
      displayName: `${input.firstName} ${input.lastName}`.trim(),
      phone: input.phone,
      nicOrPassport: input.nicOrPassport,
      dateOfBirth: input.dateOfBirth,
      address: [input.addressLine1, input.addressLine2, input.city, input.district, input.province].filter(Boolean).join(", "),
      passwordHash: await argon22.hash(crypto8.randomBytes(32).toString("hex"), { type: argon22.argon2id }),
      role: "consultant",
      isActive: false,
      learningPortalEnabled: false
    }).returning();
    await tx.insert(accountNumberSequence).values({ id: 1, nextNumber: 527694 }).onConflictDoNothing();
    const [highest] = await tx.select({ numericPart: networkAccounts.numericPart }).from(networkAccounts).orderBy(desc8(networkAccounts.numericPart)).limit(1);
    const nextBlock = nextStudentAccountNumber(highest?.numericPart);
    const [sequence] = await tx.update(accountNumberSequence).set({
      nextNumber: sql4`GREATEST(${accountNumberSequence.nextNumber}, ${nextBlock}) + ${ACCOUNT_BLOCK_SIZE}`,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq10(accountNumberSequence.id, 1)).returning({ nextNumber: accountNumberSequence.nextNumber });
    const [account] = await tx.insert(networkAccounts).values({
      ownerUserId: user.id,
      prefix: "CN",
      numericPart: sequence.nextNumber - ACCOUNT_BLOCK_SIZE,
      status: "RESERVED",
      isMainAccount: true
    }).returning();
    const [application] = await tx.insert(ccoMainApplications).values({
      payIdId: payId.id,
      userId: user.id,
      accountId: account.id,
      firstName: input.firstName,
      lastName: input.lastName,
      email,
      phone: input.phone,
      dateOfBirth: input.dateOfBirth,
      nicOrPassport: input.nicOrPassport,
      addressLine1: input.addressLine1,
      addressLine2: input.addressLine2 || null,
      province: input.province,
      district: input.district,
      city: input.city,
      transactionReference: code,
      registrationTokenHash: tokenHash2(registrationToken)
    }).returning();
    return { application, account };
  });
  response.json({ applicationId: result.application.id, registrationToken, accountNumber: `CN${result.account.numericPart}` });
}));
ccoMainRouter.put("/public/cco-main/applications/:id/proof", express4.raw({ type: ["image/jpeg", "image/png", "image/webp", "application/pdf"], limit: "8mb" }), asyncRoute(async (request, response) => {
  const token = String(request.headers["x-registration-token"] || "");
  const db = requireDatabase();
  const [application] = await db.select().from(ccoMainApplications).where(eq10(ccoMainApplications.id, z7.string().uuid().parse(request.params.id))).limit(1);
  if (!application || !matchesRegistrationToken(token, application.registrationTokenHash)) throw new HttpError(403, "Application token invalid.");
  const mime = String(request.headers["content-type"] || "").split(";")[0];
  const extensions = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "application/pdf": "pdf" };
  if (!extensions[mime] || !Buffer.isBuffer(request.body) || request.body.length < 1) throw new HttpError(400, "JPG, PNG, WebP \u0DC4\u0DDD PDF slip \u0D91\u0D9A\u0D9A\u0DCA upload \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.");
  const objectKey = `cco-main-proofs/${application.userId}/${application.id}.${extensions[mime]}`;
  await uploadPrivateFile(objectKey, request.body);
  await db.update(ccoMainApplications).set({ proofObjectKey: objectKey, proofMimeType: mime, status: "UNDER_REVIEW", registrationTokenHash: null, updatedAt: /* @__PURE__ */ new Date() }).where(eq10(ccoMainApplications.id, application.id));
  const admins = await db.select({ id: users.id }).from(users).where(eq10(users.role, "admin"));
  if (admins.length) await db.insert(notifications).values(admins.map((admin) => ({ userId: admin.id, type: "CCO_MAIN_APPLICATION", title: "New CCO Main application", message: `${application.firstName} ${application.lastName} \u2022 ${application.email}` })));
  let emailSent = false;
  try {
    await sendCcoMainApplicationReceived(application.email, `${application.firstName} ${application.lastName}`);
    emailSent = true;
  } catch (error) {
    console.error("CCO main confirmation email failed", error);
  }
  response.json({ message: "CCO Main application submitted successfully.", emailSent });
}));
ccoMainRouter.get("/admin/cco-main/applications", asyncRoute(async (request, response) => {
  await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const rows = await db.select({ application: ccoMainApplications, payId: ccoMainPayIds, account: networkAccounts }).from(ccoMainApplications).innerJoin(ccoMainPayIds, eq10(ccoMainPayIds.id, ccoMainApplications.payIdId)).innerJoin(networkAccounts, eq10(networkAccounts.id, ccoMainApplications.accountId)).orderBy(desc8(ccoMainApplications.createdAt));
  response.json({ applications: rows.map(({ application, payId, account }) => ({ ...application, payId: payId.code, amount: Number(payId.amount), accountNumber: `${account.prefix}${account.numericPart}` })) });
}));
ccoMainRouter.get("/admin/cco-main/applications/:id/proof", asyncRoute(async (request, response) => {
  await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const [application] = await db.select().from(ccoMainApplications).where(eq10(ccoMainApplications.id, z7.string().uuid().parse(request.params.id))).limit(1);
  if (!application?.proofObjectKey) throw new HttpError(404, "Payment proof \u0D91\u0D9A\u0D9A\u0DCA \u0DB1\u0DD0\u0DC4\u0DD0.");
  const file = await downloadPrivateFile(application.proofObjectKey);
  response.type(application.proofMimeType || "application/octet-stream").send(file);
}));
ccoMainRouter.post("/admin/cco-main/applications/:id/review", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const input = reviewSchema.parse(request.body);
  const db = requireDatabase();
  const result = await db.transaction(async (tx) => {
    const [application] = await tx.select().from(ccoMainApplications).where(eq10(ccoMainApplications.id, z7.string().uuid().parse(request.params.id))).limit(1);
    if (!application) throw new HttpError(404, "Application \u0D91\u0D9A \u0DC4\u0DB8\u0DD4 \u0DB1\u0DDC\u0DC0\u0DD3\u0DBA.");
    if (application.status !== "UNDER_REVIEW") throw new HttpError(409, "\u0DB8\u0DD9\u0DB8 application \u0D91\u0D9A review \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8\u0DA7 \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A.");
    await tx.update(ccoMainApplications).set({ status: input.status, reviewNote: input.note || null, reviewedBy: admin.id, reviewedAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() }).where(eq10(ccoMainApplications.id, application.id));
    if (input.status === "APPROVED") {
      await tx.update(networkAccounts).set({ status: "ACTIVE", activatedAt: /* @__PURE__ */ new Date() }).where(eq10(networkAccounts.id, application.accountId));
      await tx.insert(notifications).values({ userId: application.userId, type: "CCO_MAIN_APPROVED", title: "CCO Main payment approved", message: "OTP \u0D91\u0D9A email \u0DC0\u0DD9\u0DAD \u0DBA\u0DC0\u0DCF \u0D87\u0DAD. Verify OTP \u0D9A\u0DBB password \u0D91\u0D9A \u0DC3\u0D9A\u0DC3\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." });
    }
    await tx.insert(auditLogs).values({ actorUserId: admin.id, action: `CCO_MAIN_${input.status}`, entityType: "cco_main_application", entityId: application.id, metadata: { note: input.note || null } });
    return application;
  });
  let otpEmailSent = false;
  if (input.status === "APPROVED") {
    try {
      await createAndSendVerificationCode(result.userId);
      otpEmailSent = true;
    } catch (error) {
      console.error("CCO main OTP email failed", error);
    }
  }
  response.json({ message: input.status === "APPROVED" ? "CCO Main approved." : "CCO Main rejected.", otpEmailSent });
}));
ccoMainRouter.post("/admin/cco-main/applications/:id/undo", asyncRoute(async (request, response) => {
  const admin = await requireRole(request, ["admin"]);
  const db = requireDatabase();
  const [updated] = await db.update(ccoMainApplications).set({ status: "UNDER_REVIEW", reviewNote: null, reviewedBy: null, reviewedAt: null, updatedAt: /* @__PURE__ */ new Date() }).where(and8(eq10(ccoMainApplications.id, z7.string().uuid().parse(request.params.id)), eq10(ccoMainApplications.status, "REJECTED"))).returning();
  if (!updated) throw new HttpError(409, "Rejected application \u0D91\u0D9A\u0D9A\u0DCA \u0DB4\u0DB8\u0DAB\u0D9A\u0DCA undo \u0D9A\u0DC5 \u0DC4\u0DD0\u0D9A.");
  await db.insert(auditLogs).values({ actorUserId: admin.id, action: "CCO_MAIN_REJECTION_UNDONE", entityType: "cco_main_application", entityId: updated.id });
  response.json({ message: "Rejection undone. Application \u0DB1\u0DD0\u0DC0\u0DAD review \u0D9A\u0DC5 \u0DC4\u0DD0\u0D9A." });
}));

// server/index.ts
var __dirname = path.dirname(fileURLToPath(import.meta.url));
var app = express5();
var port = Number(process.env.PORT ?? 3e3);
var isProduction = process.env.NODE_ENV === "production";
var demoLoginEnabled = process.env.ENABLE_DEMO_LOGIN === "true";
app.disable("x-powered-by");
app.use(express5.json({ limit: "1mb" }));
var overview = {
  course: {
    title: "Crypto Trading \u2014 Zero to Pro",
    language: "\u0DC3\u0DD2\u0D82\u0DC4\u0DBD",
    modules: 6,
    access: "Lifetime course access"
  },
  features: [
    "Spot & Futures Trading",
    "Technical Analysis",
    "Risk Management",
    "Progress Tracking",
    "Consultant Network",
    "Weekly Commission Reports"
  ],
  paymentMethods: ["Bank Transfer", "Binance Pay / USDT"]
};
var demoUsers = {
  student: {
    id: "demo-student",
    name: "Nimal Perera",
    email: "student@adilacademy.demo",
    role: "student",
    accountNumber: "SR527694"
  },
  consultant: {
    id: "demo-consultant",
    name: "Kasun Silva",
    email: "consultant@adilacademy.demo",
    role: "consultant",
    accountNumber: "CN527695"
  },
  staff: {
    id: "demo-staff",
    name: "Academy Staff",
    email: "staff@adilacademy.demo",
    role: "staff"
  },
  admin: {
    id: "demo-admin",
    name: "Super Admin",
    email: "admin@adilacademy.demo",
    role: "admin"
  }
};
var demoSessions = /* @__PURE__ */ new Map();
var demoLoginSchema = z8.object({
  role: z8.enum(["student", "consultant", "staff", "admin"])
});
var registerSchema = z8.object({
  displayName: z8.string().trim().min(2).max(100),
  email: z8.string().trim().email().max(200),
  phone: z8.string().trim().min(7).max(30).optional(),
  password: z8.string().min(8).max(128).regex(/[A-Z]/, "Password needs an uppercase letter.").regex(/[a-z]/, "Password needs a lowercase letter.").regex(/[0-9]/, "Password needs a number.")
});
var admissionSchema = z8.object({
  displayName: z8.string().trim().min(2).max(100),
  email: z8.string().trim().email().max(200),
  phone: z8.string().trim().min(7).max(30),
  nicOrPassport: z8.string().trim().min(5).max(50),
  courseId: z8.string().uuid(),
  transactionReference: z8.string().trim().min(2).max(200),
  payId: z8.string().trim().min(10).max(80)
});
var verificationSchema = z8.object({
  email: z8.string().trim().email().max(200),
  code: z8.string().regex(/^\d{6}$/),
  password: z8.string().min(8).max(128).regex(/[A-Z]/).regex(/[a-z]/).regex(/[0-9]/)
});
var payIdRequestSchema = z8.object({ email: z8.string().trim().email().max(200) });
var loginSchema = z8.object({
  email: z8.string().trim().email().max(200),
  password: z8.string().min(1).max(128)
});
function authCookieOptions(expiresAt) {
  return {
    httpOnly: true,
    sameSite: "lax",
    secure: isProduction,
    ...expiresAt ? { expires: expiresAt } : { maxAge: 1e3 * 60 * 60 * 8 }
  };
}
function readCookie2(cookieHeader, name) {
  if (!cookieHeader) return void 0;
  for (const part of cookieHeader.split(";")) {
    const [key2, ...value] = part.trim().split("=");
    if (key2 === name) return decodeURIComponent(value.join("="));
  }
  return void 0;
}
app.get("/api/health", (_request, response) => {
  response.json({
    status: "ok",
    service: "adil-academy-lms",
    environment: process.env.NODE_ENV ?? "development",
    databaseConfigured: Boolean(process.env.DATABASE_URL)
  });
});
app.get("/api/public/overview", (_request, response) => {
  response.json(overview);
});
app.post("/api/pay-ids", async (request, response) => {
  const parsed = payIdRequestSchema.safeParse(request.body);
  if (!parsed.success) return void response.status(400).json({ message: "Valid email address \u0D91\u0D9A\u0D9A\u0DCA \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." });
  const email = parsed.data.email.toLowerCase();
  try {
    const db = requireDatabase();
    const [recent] = await db.select().from(paymentReferenceIds).where(and9(
      eq11(paymentReferenceIds.email, email),
      gt6(paymentReferenceIds.createdAt, new Date(Date.now() - 48 * 60 * 60 * 1e3))
    )).orderBy(desc9(paymentReferenceIds.createdAt)).limit(1);
    if (recent) {
      const availableAt = new Date(recent.createdAt.getTime() + 48 * 60 * 60 * 1e3);
      return void response.status(429).json({
        message: `\u0DB8\u0DD9\u0DB8 email \u0D91\u0D9A\u0DA7 Pay ID \u0D91\u0D9A\u0D9A\u0DCA \u0DAF\u0DD0\u0DB1\u0DA7\u0DB8\u0DAD\u0DCA \u0DB1\u0DD2\u0D9A\u0DD4\u0DAD\u0DCA \u0D9A\u0DBB \u0D87\u0DAD. \u0D85\u0DBD\u0DD4\u0DAD\u0DCA Pay ID \u0D91\u0D9A\u0D9A\u0DCA \u0DBD\u0DB6\u0DCF\u0D9C\u0DAD \u0DC4\u0DD0\u0D9A\u0DCA\u0D9A\u0DDA ${availableAt.toLocaleString("en-LK", { timeZone: "Asia/Colombo" })} \u0DB4\u0DC3\u0DD4\u0DC0\u0DBA\u0DD2.`
      });
    }
    const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replaceAll("-", "");
    const code = `ADIL-PAY-${day}-${crypto9.randomBytes(3).toString("hex").toUpperCase()}`;
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1e3);
    const [created] = await db.insert(paymentReferenceIds).values({ code, email, expiresAt }).returning();
    try {
      await sendPayId(email, code, expiresAt);
    } catch (emailError) {
      await db.delete(paymentReferenceIds).where(eq11(paymentReferenceIds.id, created.id));
      throw emailError;
    }
    response.status(201).json({ message: "Pay ID \u0D91\u0D9A \u0D94\u0DB6\u0D9C\u0DDA email \u0D91\u0D9A\u0DA7 \u0DBA\u0DC0\u0DCF \u0D87\u0DAD." });
  } catch (error) {
    console.error("Pay ID email failed", error);
    response.status(503).json({ message: "Pay ID email \u0D91\u0D9A \u0DBA\u0DD0\u0DC0\u0DD3\u0DB8\u0DA7 \u0DB1\u0DDC\u0DC4\u0DD0\u0D9A\u0DD2 \u0DC0\u0DD2\u0DBA. EMAIL_APP_PASSWORD check \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." });
  }
});
app.post("/api/auth/demo-login", (request, response) => {
  if (!demoLoginEnabled) {
    response.status(404).json({ message: "Demo login is disabled." });
    return;
  }
  const parsed = demoLoginSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ message: "Invalid role." });
    return;
  }
  const token = crypto9.randomBytes(32).toString("hex");
  const user = demoUsers[parsed.data.role];
  demoSessions.set(token, user);
  response.cookie("adil_session", token, authCookieOptions());
  response.json({ user });
});
app.post("/api/auth/apply", async (request, response) => {
  const parsed = admissionSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({
      message: "Application details are invalid.",
      issues: parsed.error.issues.map((issue) => issue.message)
    });
    return;
  }
  try {
    const application = await createAdmissionApplication(parsed.data);
    response.status(201).json(application);
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    if (code === "EMAIL_ALREADY_EXISTS") {
      response.status(409).json({ message: "Email already registered." });
      return;
    }
    if (code === "DATABASE_NOT_CONFIGURED") {
      response.status(503).json({
        message: "Database is not configured. Add Replit PostgreSQL first."
      });
      return;
    }
    if (code === "COURSE_NOT_FOUND") return void response.status(404).json({ message: "Course not found." });
    if (code === "FULL_PAYMENT_REQUIRED") return void response.status(400).json({ message: "Full course payment is required." });
    if (code === "INVALID_PAY_ID") return void response.status(400).json({ message: "Pay ID \u0D91\u0D9A invalid, expired, already used, email \u0D91\u0D9A\u0DA7 \u0DB1\u0DDC\u0D9C\u0DD0\u0DC5\u0DB4\u0DD9\u0DB1 \u0DC4\u0DDD bank reference \u0D91\u0D9A\u0DA7 \u0DB1\u0DDC\u0D9C\u0DD0\u0DC5\u0DB4\u0DDA." });
    console.error("Application failed", error);
    response.status(500).json({ message: "Application failed." });
  }
});
app.put("/api/auth/applications/:id/proof", express5.raw({
  type: ["image/jpeg", "image/png", "image/webp", "application/pdf"],
  limit: "8mb"
}), async (request, response) => {
  try {
    const token = String(request.headers["x-registration-token"] || "");
    const db = requireDatabase();
    const [payment] = await db.select().from(paymentRequests).where(eq11(paymentRequests.id, String(request.params.id))).limit(1);
    if (!payment || !matchesRegistrationToken(token, payment.registrationTokenHash)) return void response.status(403).json({ message: "Invalid application token." });
    const mime = String(request.headers["content-type"] || "").split(";")[0];
    const extensions = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "application/pdf": "pdf" };
    if (!extensions[mime] || !Buffer.isBuffer(request.body) || request.body.length < 1) return void response.status(400).json({ message: "Upload a JPG, PNG, WebP, or PDF proof." });
    const objectKey = `payment-proofs/${payment.userId}/${payment.id}.${extensions[mime]}`;
    await uploadPrivateFile(objectKey, request.body);
    await db.update(paymentRequests).set({ proofObjectKey: objectKey, proofMimeType: mime, status: "UNDER_REVIEW", registrationTokenHash: null }).where(eq11(paymentRequests.id, payment.id));
    if (payment.payIdId) await db.update(paymentReferenceIds).set({ usedAt: /* @__PURE__ */ new Date() }).where(and9(eq11(paymentReferenceIds.id, payment.payIdId), isNull6(paymentReferenceIds.usedAt)));
    const [[student], [account], admins] = await Promise.all([
      db.select({ name: users.displayName, email: users.email }).from(users).where(eq11(users.id, payment.userId)).limit(1),
      db.select({ prefix: networkAccounts.prefix, numericPart: networkAccounts.numericPart }).from(networkAccounts).where(and9(eq11(networkAccounts.ownerUserId, payment.userId), eq11(networkAccounts.isMainAccount, true))).limit(1),
      db.select({ id: users.id }).from(users).where(eq11(users.role, "admin"))
    ]);
    const accountNumber = account ? `${account.prefix}${account.numericPart}` : "SR pending";
    if (admins.length) await db.insert(notifications).values(admins.map((admin) => ({
      userId: admin.id,
      type: "NEW_STUDENT_APPLICATION",
      title: "New student payment submitted",
      message: `${student?.name ?? "Student"} \u2022 ${accountNumber} \u2022 ${payment.paymentCode}`
    })));
    let confirmationEmailSent = false;
    if (student) {
      try {
        await sendApplicationReceived(student.email, student.name, payment.paymentCode);
        confirmationEmailSent = true;
      } catch (emailError) {
        console.error("Application saved but confirmation email failed", emailError);
      }
    }
    response.json({ message: "Application and payment proof submitted.", confirmationEmailSent });
  } catch (error) {
    console.error("Application proof failed", error);
    response.status(500).json({ message: "Payment proof upload failed." });
  }
});
app.post("/api/auth/verify", async (request, response) => {
  const parsed = verificationSchema.safeParse(request.body);
  if (!parsed.success) return void response.status(400).json({ message: "OTP or password is invalid." });
  try {
    const session = await verifyCodeAndSetPassword(parsed.data);
    response.cookie("adil_session", session.token, authCookieOptions(session.expiresAt));
    response.json({ user: session.user });
  } catch {
    response.status(400).json({ message: "OTP is incorrect or expired." });
  }
});
app.post("/api/auth/resend-otp", async (request, response) => {
  const email = z8.string().email().safeParse(request.body?.email);
  if (!email.success) return void response.status(400).json({ message: "Valid email is required." });
  try {
    const db = requireDatabase();
    const normalizedEmail = email.data.toLowerCase();
    const [courseApproval] = await db.select({ userId: users.id }).from(users).innerJoin(paymentRequests, eq11(paymentRequests.userId, users.id)).where(and9(eq11(users.email, normalizedEmail), eq11(paymentRequests.status, "APPROVED"))).limit(1);
    const [ccoApproval] = courseApproval ? [] : await db.select({ userId: users.id }).from(users).innerJoin(ccoMainApplications, eq11(ccoMainApplications.userId, users.id)).where(and9(eq11(users.email, normalizedEmail), eq11(ccoMainApplications.status, "APPROVED"))).limit(1);
    const record = courseApproval ?? ccoApproval;
    if (!record) return void response.status(400).json({ message: "Payment approval is still pending." });
    await createAndSendVerificationCode(record.userId);
    response.json({ message: "A new OTP was sent." });
  } catch (error) {
    console.error("OTP resend failed", error);
    response.status(500).json({ message: "OTP email could not be sent." });
  }
});
app.post("/api/auth/login", async (request, response) => {
  const parsed = loginSchema.safeParse(request.body);
  if (!parsed.success) {
    response.status(400).json({ message: "Invalid email or password." });
    return;
  }
  try {
    const session = await loginUser(parsed.data);
    response.cookie(
      "adil_session",
      session.token,
      authCookieOptions(session.expiresAt)
    );
    response.json({ user: session.user });
  } catch (error) {
    const code = error instanceof Error ? error.message : "";
    if (code === "INVALID_CREDENTIALS") {
      response.status(401).json({ message: "Invalid email or password." });
      return;
    }
    if (code === "DATABASE_NOT_CONFIGURED") {
      response.status(503).json({
        message: "Database is not configured. Use platform preview for now."
      });
      return;
    }
    console.error("Login failed", error);
    response.status(500).json({ message: "Login failed." });
  }
});
app.get("/api/auth/me", async (request, response) => {
  const token = readCookie2(request.headers.cookie, "adil_session");
  const demoUser = token ? demoSessions.get(token) : void 0;
  if (demoUser) {
    response.json({ user: demoUser });
    return;
  }
  if (!token) {
    response.status(401).json({ message: "Not authenticated." });
    return;
  }
  try {
    const user = await getUserForSession(token);
    if (!user) {
      response.status(401).json({ message: "Not authenticated." });
      return;
    }
    response.json({ user });
  } catch (error) {
    if (error instanceof Error && error.message === "DATABASE_NOT_CONFIGURED") {
      response.status(401).json({ message: "Not authenticated." });
      return;
    }
    console.error("Session lookup failed", error);
    response.status(500).json({ message: "Session lookup failed." });
  }
});
app.post("/api/auth/logout", async (request, response) => {
  const token = readCookie2(request.headers.cookie, "adil_session");
  if (token) {
    if (demoSessions.has(token)) {
      demoSessions.delete(token);
    } else {
      try {
        await deletePersistentSession(token);
      } catch (error) {
        if (!(error instanceof Error) || error.message !== "DATABASE_NOT_CONFIGURED") {
          console.error("Session deletion failed", error);
        }
      }
    }
  }
  response.clearCookie("adil_session");
  response.status(204).end();
});
app.use("/api", courseRouter);
app.use("/api", paymentRouter);
app.use("/api", consultantRouter);
app.use("/api", commissionRouter);
app.use("/api", platformRouter);
app.use("/api", supportRouter);
app.use("/api", ccoMainRouter);
app.use("/api", (_request, response) => {
  response.status(404).json({ message: "API route not found. Latest build \u0D91\u0D9A install \u0D9A\u0DBB app \u0D91\u0D9A restart \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1." });
});
app.use("/api", apiErrorHandler);
async function attachFrontend() {
  if (!isProduction && process.env.SERVE_STATIC !== "true") {
    const { createServer } = await import("vite");
    const vite = await createServer({
      root: path.resolve(process.cwd(), "client"),
      server: { middlewareMode: true, allowedHosts: true, hmr: false },
      appType: "spa"
    });
    app.use(vite.middlewares);
    return;
  }
  const distPath = path.resolve(__dirname, "../dist");
  app.use(express5.static(distPath));
  app.use((_request, response) => {
    response.sendFile(path.join(distPath, "index.html"));
  });
}
await attachFrontend();
app.listen(port, "0.0.0.0", () => {
  console.log("Adil Academy LMS running on port " + port);
  startFridayCommissionScheduler();
});
