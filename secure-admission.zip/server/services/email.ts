import nodemailer from "nodemailer";

const senderEmail = process.env.EMAIL_FROM?.trim() || "adilacademy65@gmail.com";

export function emailConfigured() {
  return Boolean(process.env.EMAIL_APP_PASSWORD);
}

export async function sendVerificationCode(email: string, code: string) {
  const password = process.env.EMAIL_APP_PASSWORD;
  if (!password) throw new Error("EMAIL_NOT_CONFIGURED");

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: senderEmail, pass: password }
  });

  await transporter.sendMail({
    from: `Adil Academy <${senderEmail}>`,
    to: email,
    subject: "Adil Academy email verification code",
    text: `Your Adil Academy verification code is ${code}. It expires in 10 minutes. Do not share this code.`,
    html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:28px;background:#07110c;color:#fff;border-radius:16px"><p style="color:#7cff4f;font-weight:700;letter-spacing:2px">ADIL ACADEMY</p><h2>Email verification</h2><p>ඔබගේ payment එක approve කර ඇත. Account එක activate කිරීමට පහත OTP code එක භාවිත කරන්න.</p><div style="font-size:34px;font-weight:800;letter-spacing:8px;margin:24px 0;color:#7cff4f">${code}</div><p style="color:#9aa59f">මෙම code එක විනාඩි 10කින් expire වේ. වෙනත් කෙනෙකුට ලබා නොදෙන්න.</p></div>`
  });
}
