import crypto from "node:crypto";
import { and, count, desc, eq, sql } from "drizzle-orm";
import express, { Router } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import {
  accountNumberSequence,
  accountPointBalances,
  auditLogs,
  coupons,
  couponUses,
  courses,
  enrollments,
  networkAccounts,
  networkPlacements,
  notifications,
  paymentRequests,
  pointEvents
} from "../../../db/schema";
import {
  HttpError,
  requireAuthenticatedUser,
  requireRole
} from "../../lib/auth";
import { asyncRoute } from "../../lib/http";
import {
  downloadPrivateFile,
  uploadPrivateFile
} from "../../services/storage";

export const paymentRouter = Router();

const createPaymentInput = z.object({
  courseId: z.string().uuid(),
  method: z.enum(["BANK_TRANSFER", "BINANCE_PAY", "USDT"]),
  paidAmount: z.coerce.number().positive(),
  transactionReference: z.string().trim().min(2).max(200),
  receivingAccountId: z.string().uuid().optional(),
  requestedParentAccountId: z.string().uuid().optional(),
  requestedSide: z.enum(["LEFT", "RIGHT"]).optional(),
  couponCode: z.string().trim().min(2).max(50).optional()
});

const reviewInput = z.object({
  status: z.enum(["APPROVED", "PARTIAL", "REJECTED"]),
  note: z.string().trim().max(1000).optional()
});

const proofMimeExtensions: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "application/pdf": "pdf"
};

function paymentCode() {
  const day = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  return "PAY-" + day + "-" + crypto.randomBytes(4).toString("hex").toUpperCase();
}

paymentRouter.post(
  "/payments",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const input = createPaymentInput.parse(request.body);
    if (
      Boolean(input.requestedParentAccountId) !== Boolean(input.requestedSide)
    ) {
      throw new HttpError(
        400,
        "Parent account and LEFT/RIGHT side must be selected together."
      );
    }

    const db = requireDatabase();
    const [course] = await db
      .select()
      .from(courses)
      .where(
        and(eq(courses.id, input.courseId), eq(courses.isPublished, true))
      )
      .limit(1);
    if (!course) throw new HttpError(404, "Course not found.");

    let coupon: typeof coupons.$inferSelect | undefined;
    let totalAmount = Number(course.price);
    if (input.couponCode) {
      [coupon] = await db
        .select()
        .from(coupons)
        .where(
          and(
            eq(coupons.code, input.couponCode.toUpperCase()),
            eq(coupons.isActive, true)
          )
        )
        .limit(1);
      const now = new Date();
      if (
        !coupon ||
        (coupon.courseId && coupon.courseId !== course.id) ||
        (coupon.startsAt && coupon.startsAt > now) ||
        (coupon.expiresAt && coupon.expiresAt < now)
      ) {
        throw new HttpError(400, "Coupon is invalid or expired.");
      }
      if (coupon.maxUses) {
        const [{ uses }] = await db
          .select({ uses: count() })
          .from(couponUses)
          .where(eq(couponUses.couponId, coupon.id));
        if (uses >= coupon.maxUses) {
          throw new HttpError(400, "Coupon usage limit has been reached.");
        }
      }
      const value = Number(coupon.discountValue);
      totalAmount =
        coupon.discountType === "PERCENT"
          ? totalAmount * (1 - Math.min(value, 100) / 100)
          : Math.max(0, totalAmount - value);
    }

    if (input.receivingAccountId) {
      const [receiving] = await db
        .select({ id: networkAccounts.id })
        .from(networkAccounts)
        .where(
          and(
            eq(networkAccounts.id, input.receivingAccountId),
            eq(networkAccounts.status, "ACTIVE")
          )
        )
        .limit(1);
      if (!receiving) {
        throw new HttpError(400, "Receiving account is not active.");
      }
    }

    const [created] = await db
      .insert(paymentRequests)
      .values({
        paymentCode: paymentCode(),
        userId: user.id,
        courseId: course.id,
        method: input.method,
        totalAmount: totalAmount.toFixed(2),
        paidAmount: input.paidAmount.toFixed(2),
        transactionReference: input.transactionReference,
        couponId: coupon?.id,
        receivingAccountId: input.receivingAccountId,
        requestedParentAccountId: input.requestedParentAccountId,
        requestedSide: input.requestedSide
      })
      .returning();
    response.status(201).json({ payment: created });
  })
);

paymentRouter.put(
  "/payments/:id/proof",
  express.raw({
    type: ["image/jpeg", "image/png", "image/webp", "application/pdf"],
    limit: "8mb"
  }),
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const paymentId = String(request.params.id);
    const [payment] = await db
      .select()
      .from(paymentRequests)
      .where(
        and(
          eq(paymentRequests.id, paymentId),
          eq(paymentRequests.userId, user.id)
        )
      )
      .limit(1);
    if (!payment) throw new HttpError(404, "Payment request not found.");
    if (!["PENDING", "UNDER_REVIEW", "PARTIAL"].includes(payment.status)) {
      throw new HttpError(409, "Payment proof is locked.");
    }

    const mimeType = String(request.headers["content-type"] ?? "").split(";")[0];
    const extension = proofMimeExtensions[mimeType];
    if (!extension || !Buffer.isBuffer(request.body) || request.body.length < 1) {
      throw new HttpError(400, "Upload a JPG, PNG, WebP, or PDF proof file.");
    }

    const objectKey =
      "payment-proofs/" +
      user.id +
      "/" +
      payment.id +
      "-" +
      crypto.randomBytes(6).toString("hex") +
      "." +
      extension;
    await uploadPrivateFile(objectKey, request.body);
    const [updated] = await db
      .update(paymentRequests)
      .set({
        proofObjectKey: objectKey,
        proofMimeType: mimeType,
        status: "UNDER_REVIEW"
      })
      .where(eq(paymentRequests.id, payment.id))
      .returning();
    response.json({ payment: updated });
  })
);

paymentRouter.get(
  "/student/payments",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const items = await db
      .select()
      .from(paymentRequests)
      .where(eq(paymentRequests.userId, user.id))
      .orderBy(desc(paymentRequests.createdAt));
    response.json({
      payments: items.map(({ proofObjectKey: proof, ...payment }) => ({
        ...payment,
        hasProof: Boolean(proof)
      }))
    });
  })
);

paymentRouter.get(
  "/admin/payments",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const status = z
      .enum([
        "PENDING",
        "UNDER_REVIEW",
        "PARTIAL",
        "APPROVED",
        "REJECTED",
        "REFUNDED"
      ])
      .optional()
      .parse(request.query.status);
    const items = status
      ? await db
          .select()
          .from(paymentRequests)
          .where(eq(paymentRequests.status, status))
          .orderBy(desc(paymentRequests.createdAt))
      : await db
          .select()
          .from(paymentRequests)
          .orderBy(desc(paymentRequests.createdAt));
    response.json({
      payments: items.map(({ proofObjectKey: proof, ...payment }) => ({
        ...payment,
        hasProof: Boolean(proof)
      }))
    });
  })
);

paymentRouter.get(
  "/admin/payments/:id/proof",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const [payment] = await db
      .select({
        proofObjectKey: paymentRequests.proofObjectKey,
        proofMimeType: paymentRequests.proofMimeType
      })
      .from(paymentRequests)
      .where(eq(paymentRequests.id, String(request.params.id)))
      .limit(1);
    if (!payment?.proofObjectKey) {
      throw new HttpError(404, "Payment proof not found.");
    }
    const bytes = await downloadPrivateFile(payment.proofObjectKey);
    response.type(payment.proofMimeType ?? "application/octet-stream");
    response.send(bytes);
  })
);

paymentRouter.post(
  "/admin/payments/:id/review",
  asyncRoute(async (request, response) => {
    const reviewer = await requireRole(request, ["staff", "admin"]);
    const input = reviewInput.parse(request.body);
    const db = requireDatabase();
    const paymentId = String(request.params.id);

    const result = await db.transaction(async (tx) => {
      const [payment] = await tx
        .select()
        .from(paymentRequests)
        .where(eq(paymentRequests.id, paymentId))
        .limit(1);
      if (!payment) throw new HttpError(404, "Payment request not found.");
      if (["APPROVED", "REJECTED", "REFUNDED"].includes(payment.status)) {
        throw new HttpError(409, "Payment request is already finalized.");
      }
      if (input.status === "APPROVED") {
        if (!payment.proofObjectKey) {
          throw new HttpError(400, "Payment proof is required.");
        }
        if (Number(payment.paidAmount) < Number(payment.totalAmount)) {
          throw new HttpError(400, "Full payment is required for approval.");
        }
      }

      const [updatedPayment] = await tx
        .update(paymentRequests)
        .set({
          status: input.status,
          reviewNote: input.note,
          reviewedBy: reviewer.id,
          reviewedAt: new Date()
        })
        .where(eq(paymentRequests.id, payment.id))
        .returning();

      if (input.status !== "APPROVED" || !payment.courseId) {
        await tx.insert(auditLogs).values({
          actorUserId: reviewer.id,
          action: "PAYMENT_" + input.status,
          entityType: "payment_request",
          entityId: payment.id,
          metadata: { note: input.note ?? null }
        });
        return { payment: updatedPayment, account: null };
      }

      await tx
        .insert(enrollments)
        .values({
          userId: payment.userId,
          courseId: payment.courseId,
          status: "ACTIVE"
        })
        .onConflictDoNothing({
          target: [enrollments.userId, enrollments.courseId]
        });

      let [account] = await tx
        .select()
        .from(networkAccounts)
        .where(
          and(
            eq(networkAccounts.ownerUserId, payment.userId),
            eq(networkAccounts.isMainAccount, true)
          )
        )
        .limit(1);

      if (!account) {
        await tx
          .insert(accountNumberSequence)
          .values({ id: 1, nextNumber: 527694 })
          .onConflictDoNothing();
        const [sequence] = await tx
          .update(accountNumberSequence)
          .set({
            nextNumber: sql.raw("next_number + 1"),
            updatedAt: new Date()
          })
          .where(eq(accountNumberSequence.id, 1))
          .returning({ nextNumber: accountNumberSequence.nextNumber });
        const allocatedNumber = sequence.nextNumber - 1;
        [account] = await tx
          .insert(networkAccounts)
          .values({
            ownerUserId: payment.userId,
            prefix: "SR",
            numericPart: allocatedNumber,
            status: "ACTIVE",
            isMainAccount: true,
            activatedAt: new Date()
          })
          .returning();

        if (payment.requestedParentAccountId && payment.requestedSide) {
          await tx.insert(networkPlacements).values({
            accountId: account.id,
            parentAccountId: payment.requestedParentAccountId,
            side: payment.requestedSide,
            placedByUserId: reviewer.id
          });
        }
      }

      const [course] = await tx
        .select({ points: courses.points })
        .from(courses)
        .where(eq(courses.id, payment.courseId))
        .limit(1);

      if (
        course?.points &&
        course.points > 0 &&
        payment.requestedParentAccountId &&
        payment.requestedSide
      ) {
        let beneficiaryAccountId: string | null =
          payment.requestedParentAccountId;
        let side: "LEFT" | "RIGHT" = payment.requestedSide;
        let depth = 0;

        while (beneficiaryAccountId && depth < 100) {
          const idempotencyKey =
            "payment:" +
            payment.id +
            ":account:" +
            beneficiaryAccountId;
          await tx
            .insert(pointEvents)
            .values({
              idempotencyKey,
              sourcePaymentId: payment.id,
              beneficiaryAccountId,
              side,
              points: course.points,
              eventType: "FULL_ADMISSION"
            })
            .onConflictDoNothing({
              target: pointEvents.idempotencyKey
            });

          const leftPoints = side === "LEFT" ? course.points : 0;
          const rightPoints = side === "RIGHT" ? course.points : 0;
          await tx
            .insert(accountPointBalances)
            .values({
              accountId: beneficiaryAccountId,
              leftAvailable: leftPoints,
              rightAvailable: rightPoints,
              lifetimeLeft: leftPoints,
              lifetimeRight: rightPoints,
              lastQualifiedActivityAt: new Date()
            })
            .onConflictDoUpdate({
              target: accountPointBalances.accountId,
              set: {
                leftAvailable: sql.raw(
                  "left_available + " + String(leftPoints)
                ),
                rightAvailable: sql.raw(
                  "right_available + " + String(rightPoints)
                ),
                lifetimeLeft: sql.raw(
                  "lifetime_left + " + String(leftPoints)
                ),
                lifetimeRight: sql.raw(
                  "lifetime_right + " + String(rightPoints)
                ),
                lastQualifiedActivityAt: new Date(),
                updatedAt: new Date()
              }
            });

          const [parentPlacement] = await tx
            .select({
              parentAccountId: networkPlacements.parentAccountId,
              side: networkPlacements.side
            })
            .from(networkPlacements)
            .where(eq(networkPlacements.accountId, beneficiaryAccountId))
            .limit(1);
          beneficiaryAccountId = parentPlacement?.parentAccountId ?? null;
          if (parentPlacement) side = parentPlacement.side;
          depth += 1;
        }
      }

      await tx.insert(notifications).values({
        userId: payment.userId,
        type: "PAYMENT_APPROVED",
        title: "Payment approved",
        message: "Your course access and student account are now active."
      });
      if (payment.couponId) {
        await tx
          .insert(couponUses)
          .values({
            couponId: payment.couponId,
            userId: payment.userId,
            paymentRequestId: payment.id
          })
          .onConflictDoNothing({ target: couponUses.paymentRequestId });
      }
      await tx.insert(auditLogs).values({
        actorUserId: reviewer.id,
        action: "PAYMENT_APPROVED",
        entityType: "payment_request",
        entityId: payment.id,
        metadata: {
          enrollmentCourseId: payment.courseId,
          accountId: account.id
        }
      });
      return { payment: updatedPayment, account };
    });

    response.json(result);
  })
);
