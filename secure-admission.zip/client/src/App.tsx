import {
  useEffect,
  useState,
  type FormEvent,
  type ReactNode
} from "react";
import {
  ArrowRight,
  Award,
  BarChart3,
  Bell,
  BookOpen,
  Check,
  ChevronRight,
  CircleDollarSign,
  CreditCard,
  GraduationCap,
  LayoutDashboard,
  LockKeyhole,
  LogOut,
  Menu,
  Network,
  Play,
  Settings,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserCheck,
  Users,
  Wallet,
  X
} from "lucide-react";
import {
  Link,
  Navigate,
  Route,
  Routes,
  useNavigate
} from "react-router-dom";
import type {
  DemoUser,
  PlatformOverview,
  StudentDashboardSummary,
  UserRole
} from "../../shared/platform";

const courseModules = [
  {
    number: "01",
    title: "Crypto Foundations",
    text: "Blockchain, wallets, exchanges සහ Binance account security."
  },
  {
    number: "02",
    title: "Spot Trading",
    text: "Market orders, limit orders සහ disciplined trade execution."
  },
  {
    number: "03",
    title: "Technical Analysis",
    text: "Market structure, candlesticks, indicators සහ entry planning."
  },
  {
    number: "04",
    title: "Risk Management",
    text: "Position sizing, stop loss සහ capital protection systems."
  },
  {
    number: "05",
    title: "Futures Trading",
    text: "Leverage, margin, liquidation සහ controlled futures strategies."
  },
  {
    number: "06",
    title: "Trading Psychology",
    text: "Consistency, journal keeping සහ professional decision making."
  }
];

const defaultOverview: PlatformOverview = {
  course: {
    title: "Crypto Trading — Zero to Pro",
    language: "සිංහල",
    modules: 6,
    access: "Lifetime course access"
  },
  features: [],
  paymentMethods: ["Bank Transfer", "Binance Pay / USDT"]
};

function Logo() {
  return (
    <Link className="brand" to="/" aria-label="Adil Academy home">
      <span className="brand-mark">
        <span>A</span>
      </span>
      <span className="brand-copy">
        <strong>ADIL</strong>
        <small>ACADEMY</small>
      </span>
    </Link>
  );
}

function PublicHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="public-header">
      <div className="nav-shell">
        <Logo />
        <button
          className="menu-button"
          type="button"
          aria-label="Toggle menu"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
        <nav className={open ? "nav-links nav-open" : "nav-links"}>
          <a href="#course" onClick={() => setOpen(false)}>
            පාඨමාලාව
          </a>
          <a href="#platform" onClick={() => setOpen(false)}>
            වේදිකාව
          </a>
          <Link to="/login" className="nav-login" onClick={() => setOpen(false)}>
            Login
          </Link>
          <Link
            to="/login"
            className="button button-small"
            onClick={() => setOpen(false)}
          >
            දැන් ආරම්භ කරන්න
          </Link>
        </nav>
      </div>
    </header>
  );
}

type PublicCourseDetail = {
  course: { title: string; shortDescription: string; price: string; currency: string; language: string };
  enrolledStudents: number;
  sections: Array<{ id: string; title: string; lessons: Array<{ id: string; title: string }> }>;
};

function HeroCourseCard({ detail }: { detail: PublicCourseDetail | null }) {
  return (
    <div className="hero-preview" aria-label="Course enrollment information">
      <div className="preview-glow" />
      <div className="preview-top">
        <div>
          <span className="eyebrow">ADIL ACADEMY COURSE</span>
          <h3>{detail?.course.title ?? "Crypto Trading — Zero to Pro"}</h3>
        </div>
        <span className="avatar"><GraduationCap size={20} /></span>
      </div>
      <div className="progress-card">
        <div className="progress-card-copy">
          <span>SINHALA TRADING LEARNING PATH</span>
          <strong>{detail?.course.shortDescription ?? "Beginner සිට disciplined trader කෙනෙක් දක්වා."}</strong>
        </div>
        <Link to="/login" className="continue-button"><ArrowRight size={15} /> දැන් ලියාපදිංචි වන්න</Link>
      </div>
      <div className="preview-stats">
        <div>
          <Users size={19} /><span>Enrolled students</span><strong>{detail?.enrolledStudents ?? 0}</strong>
        </div>
        <div>
          <ShieldCheck size={19} /><span>Student portal</span><strong>Secure</strong>
        </div>
        <div>
          <Award size={19} /><span>Learning</span><strong>Progress tracked</strong>
        </div>
      </div>
    </div>
  );
}

function HomePage() {
  const [overview, setOverview] =
    useState<PlatformOverview>(defaultOverview);
  const [courseDetail, setCourseDetail] = useState<PublicCourseDetail | null>(null);

  useEffect(() => {
    fetch("/api/public/overview")
      .then((response) => response.json())
      .then(setOverview)
      .catch(() => undefined);
    fetch("/api/courses/crypto-trading-zero-to-pro-sinhala")
      .then((response) => response.ok ? response.json() : null)
      .then((data) => setCourseDetail(data as PublicCourseDetail | null))
      .catch(() => undefined);
  }, []);

  return (
    <div className="site">
      <PublicHeader />
      <main>
        <section className="hero">
          <div className="hero-grid" />
          <div className="hero-orb hero-orb-one" />
          <div className="hero-orb hero-orb-two" />
          <div className="section-shell hero-layout">
            <div className="hero-copy">
              <span className="pill">
                <Sparkles size={15} />
                SRI LANKA'S SINHALA CRYPTO LEARNING PLATFORM
              </span>
              <h1>
                Trade කරන්න කලින්
                <span>හරියට ඉගෙනගන්න.</span>
              </h1>
              <p>
                Crypto Trading ගැන කිසිම දැනුමක් නැති තැනින්, disciplined
                trader කෙනෙක් දක්වා යන සම්පූර්ණ learning path එක සරල
                සිංහලෙන්.
              </p>
              <div className="hero-actions">
                <Link to="/login" className="button button-primary">
                  පාඨමාලාව ආරම්භ කරන්න
                  <ArrowRight size={18} />
                </Link>
                <a className="button button-ghost" href="#course">
                  <BookOpen size={17} />
                  Course Details
                </a>
              </div>
              <div className="trust-row">
                <span>
                  <Check size={15} /> Sinhala-first learning
                </span>
                <span>
                  <Check size={15} /> {overview.course.language}
                </span>
                <span>
                  <Check size={15} /> {overview.course.access}
                </span>
              </div>
            </div>
            <HeroCourseCard detail={courseDetail} />
          </div>
        </section>

        <section className="proof-strip">
          <div className="section-shell proof-grid">
            <div>
              <strong>Zero → Pro</strong>
              <span>Structured learning path</span>
            </div>
            <div>
              <strong>Secure</strong>
              <span>Paid student access</span>
            </div>
            <div>
              <strong>24/7</strong>
              <span>Student dashboard access</span>
            </div>
            <div>
              <strong>100%</strong>
              <span>Sinhala explanations</span>
            </div>
          </div>
        </section>

        <section className="section course-section" id="course">
          <div className="section-shell">
            <div className="section-heading">
              <span className="eyebrow">COMPLETE LEARNING PATH</span>
              <h2>අනුමාන නොකර, පිළිවෙළට ඉගෙනගන්න.</h2>
              <p>
                Beginner knowledge සිට professional risk discipline දක්වා,
                අවශ්‍ය සෑම කොටසක්ම එක learning system එකකින්.
              </p>
            </div>
            <div className="module-grid">
              {courseModules.map((module) => (
                <article className="module-card" key={module.number}>
                  <span className="module-number">{module.number}</span>
                  <div className="module-icon">
                    {module.number === "01" && <GraduationCap />}
                    {module.number === "02" && <BarChart3 />}
                    {module.number === "03" && <TrendingUp />}
                    {module.number === "04" && <ShieldCheck />}
                    {module.number === "05" && <CircleDollarSign />}
                    {module.number === "06" && <Sparkles />}
                  </div>
                  <h3>{module.title}</h3>
                  <p>{module.text}</p>
                  <span className="card-link">
                    Module details <ChevronRight size={16} />
                  </span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section platform-section" id="platform">
          <div className="section-shell platform-layout">
            <div className="platform-copy">
              <span className="eyebrow">MORE THAN A VIDEO COURSE</span>
              <h2>ඔබේ සම්පූර්ණ learning journey එක එකම dashboard එකක.</h2>
              <p>
                Lessons බලන්න, progress track කරන්න, payments සහ certificates
                manage කරන්න—mobile හෝ desktop ඕනෑම device එකකින්.
              </p>
              <div className="feature-list">
                {[
                  "Secure student-only video lessons",
                  "Lesson progress සහ quiz tracking",
                  "Bank Transfer / Binance Pay verification",
                  "Completion certificates සහ notifications"
                ].map((feature) => (
                  <div key={feature}>
                    <span>
                      <Check size={16} />
                    </span>
                    {feature}
                  </div>
                ))}
              </div>
              <Link to="/login" className="text-link">
                Dashboard preview බලන්න <ArrowRight size={17} />
              </Link>
            </div>
            <div className="platform-panel">
              <div className="panel-sidebar">
                <Logo />
                <span className="active-line">
                  <LayoutDashboard size={17} /> Overview
                </span>
                <span>
                  <BookOpen size={17} /> My Course
                </span>
                <span>
                  <Award size={17} /> Certificates
                </span>
                <span>
                  <CreditCard size={17} /> Payments
                </span>
              </div>
              <div className="panel-main">
                <span className="mini-label">WEEKLY ACTIVITY</span>
                <div className="chart-bars">
                  {[34, 58, 43, 76, 61, 88, 72].map((height, index) => (
                    <span key={index} style={{ height: height + "%" }} />
                  ))}
                </div>
                <div className="panel-course-row">
                  <span className="course-play">
                    <Play size={16} fill="currentColor" />
                  </span>
                  <div>
                    <strong>Risk Management Formula</strong>
                    <span>Module 04 • Lesson 03</span>
                  </div>
                  <span className="course-time">18 min</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section cta-section">
          <div className="section-shell">
            <div className="cta-card">
              <div>
                <span className="eyebrow">START WITH KNOWLEDGE</span>
                <h2>ඔබේ Crypto learning journey එක අදම ආරම්භ කරන්න.</h2>
                <p>
                  Learn with structure. Trade with discipline. Protect your
                  capital.
                </p>
              </div>
              <Link to="/login" className="button button-light">
                Student Dashboard
                <ArrowRight size={18} />
              </Link>
            </div>
          </div>
        </section>
      </main>
      <footer className="site-footer">
        <div className="section-shell footer-grid">
          <div>
            <Logo />
            <p>
              සිංහලෙන් Crypto Trading ඉගෙනගන්න විශ්වාසදායක learning platform
              එක.
            </p>
          </div>
          <div>
            <strong>Platform</strong>
            <a href="#course">Course</a>
            <Link to="/login">Student Login</Link>
            <a href="#network">Consultants</a>
          </div>
          <div>
            <strong>Support</strong>
            <a href="#platform">How it works</a>
            <a href="#course">FAQ</a>
            <a href="mailto:support@adilacademy.com">Contact</a>
          </div>
          <div>
            <strong>Legal</strong>
            <span>Terms & Conditions</span>
            <span>Privacy Policy</span>
            <span>Risk Disclosure</span>
          </div>
        </div>
        <div className="section-shell footer-bottom">
          <span>© 2026 Adil Academy. All rights reserved.</span>
          <span>Education only. Trading profits are not guaranteed.</span>
        </div>
      </footer>
    </div>
  );
}

const roleOptions: {
  role: UserRole;
  title: string;
  description: string;
  icon: ReactNode;
}[] = [
  {
    role: "student",
    title: "Student",
    description: "Course, progress සහ certificates",
    icon: <GraduationCap />
  },
  {
    role: "consultant",
    title: "Consultant",
    description: "Accounts, network සහ income",
    icon: <Network />
  },
  {
    role: "staff",
    title: "Staff",
    description: "Payments සහ students",
    icon: <UserCheck />
  },
  {
    role: "admin",
    title: "Super Admin",
    description: "Complete platform control",
    icon: <ShieldCheck />
  }
];

function LoginPage({ onLogin }: { onLogin: (user: DemoUser) => void }) {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "register" | "verify">(
    "login"
  );
  const [busyRole, setBusyRole] = useState<UserRole | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [proof, setProof] = useState<File | null>(null);
  const [courses, setCourses] = useState<{ id: string; title: string; price: string; currency: string }[]>([]);
  const [form, setForm] = useState({
    displayName: "",
    email: "",
    phone: "",
    password: "",
    nicOrPassport: "",
    address: "",
    dateOfBirth: "",
    courseId: "",
    method: "BANK_TRANSFER",
    paidAmount: "",
    transactionReference: "",
    otp: ""
  });

  useEffect(() => {
    fetch("/api/courses").then((response) => response.json()).then((data: { courses?: typeof courses }) => {
      const items = data.courses ?? [];
      setCourses(items);
      if (items[0]) setForm((current) => ({ ...current, courseId: items[0].id, paidAmount: items[0].price }));
    }).catch(() => setCourses([]));
  }, []);

  async function enterDemo(role: UserRole) {
    setBusyRole(role);
    setError("");
    try {
      const response = await fetch("/api/auth/demo-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role })
      });
      if (!response.ok) throw new Error("Preview login failed.");
      const data = (await response.json()) as { user: DemoUser };
      onLogin(data.user);
      navigate("/dashboard");
    } catch {
      setError("Preview එක විවෘත කළ නොහැක. Server එක නැවත run කරන්න.");
    } finally {
      setBusyRole(null);
    }
  }

  async function submitAccount(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      if (mode === "register") {
        if (!proof) throw new Error("Payment slip එක තෝරන්න.");
        const response = await fetch("/api/auth/apply", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            displayName: form.displayName, email: form.email, phone: form.phone,
            nicOrPassport: form.nicOrPassport, address: form.address,
            dateOfBirth: form.dateOfBirth, courseId: form.courseId,
            method: form.method, paidAmount: form.paidAmount,
            transactionReference: form.transactionReference
          })
        });
        const application = await response.json() as { applicationId?: string; registrationToken?: string; paymentCode?: string; message?: string };
        if (!response.ok || !application.applicationId || !application.registrationToken) throw new Error(application.message || "Application failed.");
        const upload = await fetch(`/api/auth/applications/${application.applicationId}/proof`, {
          method: "PUT", headers: { "Content-Type": proof.type, "X-Registration-Token": application.registrationToken }, body: proof
        });
        const uploadData = await upload.json() as { message?: string };
        if (!upload.ok) throw new Error(uploadData.message || "Payment proof upload failed.");
        setNotice(`Application එක සාර්ථකයි (${application.paymentCode}). Admin payment approve කළ පසු email OTP එක ලැබේ.`);
        setMode("verify");
        return;
      }
      const response = await fetch(mode === "verify" ? "/api/auth/verify" : "/api/auth/login", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mode === "verify" ? { email: form.email, code: form.otp, password: form.password } : { email: form.email, password: form.password })
      });
      const data = (await response.json()) as {
        user?: DemoUser;
        message?: string;
      };
      if (!response.ok || !data.user) {
        throw new Error(data.message || "Account request failed.");
      }
      onLogin(data.user);
      navigate("/dashboard");
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Account request failed."
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function resendOtp() {
    setError("");
    const response = await fetch("/api/auth/resend-otp", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: form.email }) });
    const data = await response.json() as { message?: string };
    if (!response.ok) setError(data.message || "OTP resend failed.");
    else setNotice(data.message || "OTP sent.");
  }

  return (
    <div className="login-page">
      <div className="login-brand-panel">
        <Link to="/" className="login-back">
          <ArrowRight size={17} /> Home වෙත
        </Link>
        <Logo />
        <div className="login-brand-copy">
          <span className="pill">
            <LockKeyhole size={15} /> SECURE LEARNING PLATFORM
          </span>
          <h1>Learn. Grow. Lead.</h1>
          <p>
            Student learning සිට consultant business management දක්වා Adil
            Academy එකම digital platform එකක.
          </p>
        </div>
        <div className="login-quote">
          <ShieldCheck />
          <div>
            <strong>Protected access</strong>
            <span>Role-based dashboards සහ secure student content.</span>
          </div>
        </div>
      </div>
      <div className="login-form-panel">
        <div className="login-card">
          <div className="auth-tabs">
            {[
              ["login", "Login"],
              ["register", "Apply"],
              ["verify", "Verify OTP"]
            ].map(([value, label]) => (
              <button
                key={value}
                type="button"
                className={mode === value ? "active" : ""}
                onClick={() => {
                  setMode(value as typeof mode);
                  setError("");
                  setNotice("");
                }}
              >
                {label}
              </button>
            ))}
          </div>
          <>
              <span className="eyebrow">
                {mode === "register" ? "STUDENT ADMISSION" : mode === "verify" ? "EMAIL VERIFICATION" : "WELCOME BACK"}
              </span>
              <h2>
                {mode === "register" ? "Admission form එක" : mode === "verify" ? "OTP verify කරන්න" : "Login වෙන්න"}
              </h2>
              <p>
                {mode === "register"
                  ? "Details සහ payment proof submit කරන්න. Admin approval පසු OTP email එක ලැබේ."
                  : mode === "verify"
                    ? "Payment approve වූ පසු email එකට ලැබුණු OTP එක දමා permanent password එක සකස් කරන්න."
                  : "ඔබගේ Adil Academy account එකට secure ලෙස ඇතුළු වෙන්න."}
              </p>
              <form className="auth-form" onSubmit={submitAccount}>
                {mode === "register" && (
                  <>
                    <label>
                      සම්පූර්ණ නම
                      <input
                        required
                        minLength={2}
                        value={form.displayName}
                        onChange={(event) =>
                          setForm({ ...form, displayName: event.target.value })
                        }
                        placeholder="ඔබගේ නම"
                        autoComplete="name"
                      />
                    </label>
                    <label>
                      දුරකථන අංකය
                      <input
                        value={form.phone}
                        onChange={(event) =>
                          setForm({ ...form, phone: event.target.value })
                        }
                        placeholder="+94 7X XXX XXXX"
                        autoComplete="tel"
                      />
                    </label>
                    <label>NIC / Passport<input required value={form.nicOrPassport} onChange={(event) => setForm({ ...form, nicOrPassport: event.target.value })} placeholder="NIC හෝ Passport අංකය" /></label>
                    <label>උපන් දිනය<input required type="date" value={form.dateOfBirth} onChange={(event) => setForm({ ...form, dateOfBirth: event.target.value })} /></label>
                    <label className="auth-wide">ලිපිනය<textarea required value={form.address} onChange={(event) => setForm({ ...form, address: event.target.value })} placeholder="සම්පූර්ණ ලිපිනය" /></label>
                    <label className="auth-wide">පාඨමාලාව<select required value={form.courseId} onChange={(event) => { const course = courses.find((item) => item.id === event.target.value); setForm({ ...form, courseId: event.target.value, paidAmount: course?.price ?? "" }); }}><option value="">Course එක තෝරන්න</option>{courses.map((course) => <option key={course.id} value={course.id}>{course.title} — {course.currency} {Number(course.price).toLocaleString()}</option>)}</select></label>
                    <label>Payment method<select value={form.method} onChange={(event) => setForm({ ...form, method: event.target.value })}><option value="BANK_TRANSFER">Bank Transfer</option><option value="BINANCE_PAY">Binance Pay</option><option value="USDT">USDT</option></select></label>
                    <label>ගෙවූ මුදල<input required type="number" min="1" value={form.paidAmount} onChange={(event) => setForm({ ...form, paidAmount: event.target.value })} /></label>
                    <label className="auth-wide">Transaction reference<input required value={form.transactionReference} onChange={(event) => setForm({ ...form, transactionReference: event.target.value })} placeholder="Bank/transaction reference" /></label>
                    <label className="auth-wide">Payment slip<input required type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={(event) => setProof(event.target.files?.[0] ?? null)} /></label>
                  </>
                )}
                <label>
                  Email
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={(event) =>
                      setForm({ ...form, email: event.target.value })
                    }
                    placeholder="name@example.com"
                    autoComplete="email"
                  />
                </label>
                {mode === "verify" && <label className="auth-wide">OTP code<input required inputMode="numeric" pattern="[0-9]{6}" maxLength={6} value={form.otp} onChange={(event) => setForm({ ...form, otp: event.target.value.replace(/\D/g, "") })} placeholder="6-digit OTP" /></label>}
                {mode !== "register" && <label>
                  Password
                  <input
                    required
                    minLength={8}
                    type="password"
                    value={form.password}
                    onChange={(event) =>
                      setForm({ ...form, password: event.target.value })
                    }
                    placeholder="••••••••"
                    autoComplete={
                      mode === "verify" ? "new-password" : "current-password"
                    }
                  />
                </label>}
                {mode === "verify" && (
                  <small className="password-hint">
                    අකුරු 8+, uppercase, lowercase සහ number එකක් අවශ්‍යයි.
                  </small>
                )}
                {mode === "verify" && <button className="otp-resend" type="button" onClick={() => void resendOtp()}>OTP එක නැවත යවන්න</button>}
                <button
                  type="submit"
                  className="button button-primary auth-submit"
                  disabled={submitting}
                >
                  {submitting
                    ? "Please wait..."
                    : mode === "register"
                      ? "Application submit කරන්න"
                      : mode === "verify" ? "Verify කර Login වෙන්න" : "Login"}
                  {!submitting && <ArrowRight size={17} />}
                </button>
              </form>
            </>
          {notice && <p className="form-success">{notice}</p>}
          {error && <p className="form-error">{error}</p>}
          <div className="login-note">
            <LockKeyhole size={15} />
            Password සහ session data secure server-side authentication එකකින්
            ආරක්ෂා වේ.
          </div>
        </div>
      </div>
    </div>
  );
}

const dashboardNav: Record<
  UserRole,
  { label: string; icon: ReactNode }[]
> = {
  student: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "My Course", icon: <BookOpen /> },
    { label: "Progress", icon: <BarChart3 /> },
    { label: "Certificates", icon: <Award /> },
    { label: "Payments", icon: <CreditCard /> }
  ],
  consultant: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "My Students", icon: <Users /> },
    { label: "My Accounts", icon: <UserCheck /> },
    { label: "Binary Tree", icon: <Network /> },
    { label: "Income", icon: <Wallet /> }
  ],
  staff: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "Payments", icon: <CreditCard /> },
    { label: "Students", icon: <Users /> },
    { label: "Consultants", icon: <UserCheck /> },
    { label: "Reports", icon: <BarChart3 /> }
  ],
  admin: [
    { label: "Overview", icon: <LayoutDashboard /> },
    { label: "Course", icon: <BookOpen /> },
    { label: "Students", icon: <Users /> },
    { label: "Payments", icon: <CreditCard /> },
    { label: "Network", icon: <Network /> },
    { label: "Commissions", icon: <CircleDollarSign /> },
    { label: "Settings", icon: <Settings /> }
  ]
};

function MetricCard({
  label,
  value,
  note,
  icon
}: {
  label: string;
  value: string;
  note: string;
  icon: ReactNode;
}) {
  return (
    <article className="metric-card">
      <span className="metric-icon">{icon}</span>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{note}</small>
    </article>
  );
}

function StudentDashboard() {
  const [summary, setSummary] = useState<StudentDashboardSummary | null>(null);
  const [loadError, setLoadError] = useState(false);
  useEffect(() => {
    fetch("/api/student/dashboard-summary")
      .then(async (response) => {
        if (!response.ok) throw new Error("Summary request failed");
        return response.json() as Promise<StudentDashboardSummary>;
      })
      .then(setSummary)
      .catch(() => setLoadError(true));
  }, []);

  if (loadError) {
    return <section className="dash-card"><h3>Dashboard data load කළ නොහැක</h3><p>Page එක refresh කරන්න.</p></section>;
  }
  if (!summary) {
    return <section className="dash-card"><h3>Dashboard loading...</h3></section>;
  }
  const enrolled = summary.enrollmentStatus !== "NOT_ENROLLED";
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Course Progress"
          value={`${summary.progressPercent}%`}
          note={`${summary.completedLessons} of ${summary.totalLessons} lessons`}
          icon={<TrendingUp />}
        />
        <MetricCard
          label="Learning Streak"
          value={summary.completedLessons ? "Active" : "0 days"}
          note={summary.completedLessons ? "Learning started" : "No activity yet"}
          icon={<Sparkles />}
        />
        <MetricCard
          label="Quiz Average"
          value={summary.quizAverage === null ? "—" : `${summary.quizAverage}%`}
          note={summary.quizAverage === null ? "No quiz attempts" : "Quiz performance"}
          icon={<Award />}
        />
        <MetricCard
          label="Account"
          value={summary.accountNumber ?? "Not assigned"}
          note={summary.accountStatus ?? "Payment pending"}
          icon={<UserCheck />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card dash-course-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">{enrolled ? "CONTINUE LEARNING" : "COURSE ACCESS LOCKED"}</span>
              <h3>{summary.courseTitle ?? "Payment approval required"}</h3>
            </div>
            <span>{summary.progressPercent}%</span>
          </div>
          <div className="course-visual">
            <span className="course-visual-icon">
              <ShieldCheck />
            </span>
            <div>
              <span>{enrolled ? "YOUR COURSE" : "NOT ENROLLED"}</span>
              <strong>{enrolled ? "ඔබ නතර කළ තැනින් ඉගෙනීම දිගටම කරගෙන යන්න" : "Full payment එක Admin approve කළ පසු lessons unlock වේ"}</strong>
            </div>
            <button type="button" disabled={!enrolled}>
              <Play fill="currentColor" />
            </button>
          </div>
          <div className="progress-track large">
            <span style={{ width: `${summary.progressPercent}%` }} />
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>Recent activity</h3>
            <button type="button">View all</button>
          </div>
          <div className="activity-list">
            {summary.recentActivity.length ? summary.recentActivity.map((activity) => (
              <div key={`${activity.title}-${activity.detail}`}>
                <span className="activity-dot completed"><Check /></span>
                <p><strong>{activity.title}</strong><small>{activity.detail}</small></p>
              </div>
            )) : <p>No learning activity yet.</p>}
          </div>
        </section>
      </div>
    </>
  );
}

function ConsultantDashboard() {
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Weekly Income"
          value="Rs. 7,500"
          note="Current cycle"
          icon={<Wallet />}
        />
        <MetricCard
          label="Direct Students"
          value="18"
          note="+3 this month"
          icon={<Users />}
        />
        <MetricCard
          label="Left Points"
          value="18,500"
          note="Carry forward active"
          icon={<ArrowRight />}
        />
        <MetricCard
          label="Right Points"
          value="15,000"
          note="3,500 pair gap"
          icon={<ArrowRight />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">BINARY NETWORK</span>
              <h3>CN527695</h3>
            </div>
            <button type="button">Full tree</button>
          </div>
          <div className="mini-tree">
            <div className="mini-tree-root">CN527695</div>
            <div className="mini-tree-branches">
              <div>
                <span>LEFT</span>
                <strong>SR527701</strong>
              </div>
              <div>
                <span>RIGHT</span>
                <strong>SR527702</strong>
              </div>
            </div>
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>My accounts</h3>
            <button type="button">Manage</button>
          </div>
          <div className="account-list">
            <div>
              <span className="account-badge">MAIN</span>
              <p>
                <strong>CN527695</strong>
                <small>Active • 18 students</small>
              </p>
              <span className="status-badge success">Active</span>
            </div>
            <div>
              <span className="account-badge">02</span>
              <p>
                <strong>CN527706</strong>
                <small>Active • 7 students</small>
              </p>
              <span className="status-badge success">Active</span>
            </div>
            <div>
              <span className="account-badge muted">03</span>
              <p>
                <strong>Available slot</strong>
                <small>Up to 7 accounts</small>
              </p>
              <span className="status-badge">Empty</span>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

type AdminOverviewData = {
  students: number;
  consultants: number;
  pendingPayments: number;
  pendingApplications: number;
  activeAccounts: number;
  commissionCycleCount: number;
};

type AdminPaymentView = StudentPaymentView & { userId: string; createdAt: string };

function AdminDashboard() {
  const [overview, setOverview] = useState<AdminOverviewData | null>(null);
  const [payments, setPayments] = useState<AdminPaymentView[]>([]);
  useEffect(() => {
    Promise.all([fetch("/api/admin/overview"), fetch("/api/admin/payments")])
      .then(async ([overviewResponse, paymentResponse]) => {
        if (!overviewResponse.ok || !paymentResponse.ok) throw new Error("Admin data failed");
        setOverview(await overviewResponse.json() as AdminOverviewData);
        const data = await paymentResponse.json() as { payments: AdminPaymentView[] };
        setPayments(data.payments);
      }).catch(() => undefined);
  }, []);
  if (!overview) return <section className="dash-card"><h3>Admin data loading...</h3></section>;
  return (
    <>
      <div className="metrics-grid">
        <MetricCard label="Total Students" value={String(overview.students)} note="Registered student accounts" icon={<Users />} />
        <MetricCard label="Pending Payments" value={String(overview.pendingPayments)} note="Needs verification" icon={<CreditCard />} />
        <MetricCard label="Consultants" value={String(overview.consultants)} note={`${overview.pendingApplications} applications pending`} icon={<Network />} />
        <MetricCard label="Active Accounts" value={String(overview.activeAccounts)} note="Active SR/CN accounts" icon={<UserCheck />} />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading"><div><span className="eyebrow">REAL-TIME DATA</span><h3>Latest payments</h3></div></div>
          <div className="payment-table">
            <div className="table-head"><span>Payment ID</span><span>Method</span><span>Amount</span><span>Status</span></div>
            {payments.slice(0, 5).map((item) => (
              <div className="table-row" key={item.id}>
                <span>{item.paymentCode}</span><span>{item.method.replaceAll("_", " ")}</span>
                <strong>Rs. {Number(item.paidAmount).toLocaleString()}</strong><span className="status-badge">{item.status.replaceAll("_", " ")}</span>
              </div>
            ))}
            {!payments.length && <p>No payment requests yet.</p>}
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading"><h3>Platform status</h3></div>
          <div className="activity-list">
            <div><span className="activity-dot completed"><Check /></span><p><strong>{overview.activeAccounts} active accounts</strong><small>Database verified</small></p></div>
            <div><span className="activity-dot"><CircleDollarSign /></span><p><strong>{overview.commissionCycleCount} commission cycles</strong><small>Recorded cycles</small></p></div>
          </div>
        </section>
      </div>
    </>
  );
}

function OperationsDashboard({ role }: { role: "staff" | "admin" }) {
  const isAdmin = role === "admin";
  return (
    <>
      <div className="metrics-grid">
        <MetricCard
          label="Total Students"
          value="1,248"
          note="+64 this month"
          icon={<Users />}
        />
        <MetricCard
          label="Pending Payments"
          value="18"
          note="Needs review"
          icon={<CreditCard />}
        />
        <MetricCard
          label={isAdmin ? "Active Consultants" : "Open Tickets"}
          value={isAdmin ? "126" : "12"}
          note={isAdmin ? "+8 this month" : "4 high priority"}
          icon={isAdmin ? <Network /> : <Bell />}
        />
        <MetricCard
          label="Course Completion"
          value="72%"
          note="Across all students"
          icon={<GraduationCap />}
        />
      </div>
      <div className="dashboard-grid">
        <section className="dash-card">
          <div className="dash-card-heading">
            <div>
              <span className="eyebrow">ACTION REQUIRED</span>
              <h3>Payment verification</h3>
            </div>
            <button type="button">View queue</button>
          </div>
          <div className="payment-table">
            <div className="table-head">
              <span>Student</span>
              <span>Method</span>
              <span>Amount</span>
              <span>Status</span>
            </div>
            {[
              ["Sahan Jay", "Bank", "Rs. 50,000", "Review"],
              ["Ishara M.", "USDT", "154 USDT", "Review"],
              ["Dulani K.", "Bank", "Rs. 25,000", "Partial"]
            ].map((row) => (
              <div className="table-row" key={row[0]}>
                <span>{row[0]}</span>
                <span>{row[1]}</span>
                <strong>{row[2]}</strong>
                <span
                  className={
                    row[3] === "Partial"
                      ? "status-badge warning"
                      : "status-badge"
                  }
                >
                  {row[3]}
                </span>
              </div>
            ))}
          </div>
        </section>
        <section className="dash-card">
          <div className="dash-card-heading">
            <h3>{isAdmin ? "Friday commission cycle" : "Student activity"}</h3>
            <button type="button">Details</button>
          </div>
          {isAdmin ? (
            <div className="cycle-card">
              <span className="cycle-icon">
                <CircleDollarSign />
              </span>
              <strong>2026-W29</strong>
              <p>126 accounts ready for calculation</p>
              <div className="cycle-progress">
                <span>
                  <small>Estimated payout</small>
                  <strong>Rs. 684,500</strong>
                </span>
                <span className="status-badge success">Scheduled</span>
              </div>
              <button type="button" className="button button-primary full">
                Review cycle
              </button>
            </div>
          ) : (
            <div className="activity-list">
              <div>
                <span className="activity-dot completed">
                  <Check />
                </span>
                <p>
                  <strong>32 lessons completed</strong>
                  <small>Today across all students</small>
                </p>
              </div>
              <div>
                <span className="activity-dot">
                  <Users />
                </span>
                <p>
                  <strong>8 new registrations</strong>
                  <small>Waiting for payments</small>
                </p>
              </div>
            </div>
          )}
        </section>
      </div>
    </>
  );
}

const workspaceData: Record<
  string,
  {
    title: string;
    description: string;
    action: string;
    rows: [string, string, string][];
  }
> = {
  "student:My Course": {
    title: "Crypto Trading — Zero to Pro",
    description: "ඔබට active course lessons සහ learning resources.",
    action: "Continue lesson",
    rows: [
      ["Module 01", "Crypto Foundations", "Completed"],
      ["Module 02", "Spot Trading", "Completed"],
      ["Module 03", "Technical Analysis", "86%"],
      ["Module 04", "Risk Management", "In progress"],
      ["Module 05", "Futures Trading", "Locked"],
      ["Module 06", "Trading Psychology", "Locked"]
    ]
  },
  "student:Progress": {
    title: "Learning Progress",
    description: "Lessons, quizzes සහ course completion summary.",
    action: "View report",
    rows: [
      ["Lessons completed", "24 of 36", "68%"],
      ["Quiz average", "86 points", "Good"],
      ["Learning time", "18h 42m", "This course"],
      ["Current streak", "12 days", "Active"]
    ]
  },
  "student:Certificates": {
    title: "Certificates",
    description: "Course requirements complete වූ පසු certificate නිකුත් වේ.",
    action: "Requirements",
    rows: [
      ["Crypto Trading — Zero to Pro", "68% complete", "Not issued"],
      ["Required quiz average", "Minimum 70%", "Passed"],
      ["All lessons", "24 of 36", "Pending"]
    ]
  },
  "student:Payments": {
    title: "Payment History",
    description: "Bank Transfer සහ USDT payment verification status.",
    action: "New payment",
    rows: [
      ["PAY-20260716-A31F", "Bank Transfer", "Approved"],
      ["Course access", "Rs. 50,000", "Active"],
      ["Payment proof", "bank-slip.webp", "Verified"]
    ]
  },
  "consultant:My Students": {
    title: "My Students",
    description: "ඔබ තෝරාගත් CN account හරහා පැමිණි admissions.",
    action: "Register student",
    rows: [
      ["Sahan Jay", "SR527701 • LEFT", "Active"],
      ["Ishara M.", "SR527702 • RIGHT", "Active"],
      ["Dulani K.", "Payment pending", "Review"],
      ["Nuwan P.", "SR527710 • LEFT", "Active"]
    ]
  },
  "consultant:My Accounts": {
    title: "SR/CN Accounts",
    description: "Main account සහ purchased consultant accounts.",
    action: "Account details",
    rows: [
      ["CN527695", "Main account", "Active"],
      ["CN527706", "Account 02", "Active"],
      ["Available accounts", "2 of 7 used", "5 slots"]
    ]
  },
  "consultant:Binary Tree": {
    title: "Binary Network",
    description: "LEFT/RIGHT placements සහ account ownership view.",
    action: "Expand tree",
    rows: [
      ["CN527695", "Main account", "Root"],
      ["SR527701", "Direct LEFT", "18,500 PV"],
      ["SR527702", "Direct RIGHT", "15,000 PV"],
      ["Carry forward", "Left 3,500", "Active"]
    ]
  },
  "consultant:Income": {
    title: "Income & Wallet",
    description: "Weekly commissions, wallet ledger සහ payout requests.",
    action: "Request payout",
    rows: [
      ["Available balance", "Rs. 22,500", "Ready"],
      ["Current weekly cycle", "Rs. 7,500", "Calculated"],
      ["Last payout", "Rs. 15,000", "Paid"],
      ["Next release", "Friday", "Scheduled"]
    ]
  },
  "staff:Payments": {
    title: "Payment Verification Queue",
    description: "Payment proof බලලා approve, partial හෝ reject කරන්න.",
    action: "Open queue",
    rows: [
      ["PAY-20260716-F29A", "Bank • Rs. 50,000", "Review"],
      ["PAY-20260716-C11B", "USDT • 154", "Review"],
      ["PAY-20260715-92AC", "Bank • Rs. 25,000", "Partial"]
    ]
  },
  "staff:Students": {
    title: "Student Management",
    description: "Accounts, enrollments, course access සහ status.",
    action: "Add student",
    rows: [
      ["Active students", "1,248", "Current"],
      ["New this month", "64", "+12%"],
      ["Pending admission", "18", "Review"],
      ["Suspended", "3", "Attention"]
    ]
  },
  "staff:Consultants": {
    title: "Consultant Applications",
    description: "Interviews සහ approval preparation.",
    action: "Review applications",
    rows: [
      ["Pending applications", "14", "New"],
      ["Interview stage", "6", "Scheduled"],
      ["Approved this month", "8", "Complete"]
    ]
  },
  "staff:Reports": {
    title: "Operations Reports",
    description: "Students, payments සහ course activity reports.",
    action: "Export report",
    rows: [
      ["Monthly admissions", "64 students", "July"],
      ["Approved revenue", "Rs. 3,200,000", "July"],
      ["Completion rate", "72%", "Current"]
    ]
  },
  "admin:Students": {
    title: "All Students",
    description: "Complete student and access administration.",
    action: "Manage students",
    rows: [
      ["Total students", "1,248", "Active platform"],
      ["Paid enrollments", "1,106", "88.6%"],
      ["Course completed", "798", "64%"]
    ]
  },
  "admin:Payments": {
    title: "Payments & Admissions",
    description: "Verification, approvals, refunds සහ audit records.",
    action: "Payment queue",
    rows: [
      ["Pending review", "18", "Action required"],
      ["Approved today", "12", "Rs. 600,000"],
      ["Partial payments", "7", "No points"],
      ["Rejected", "2", "Proof mismatch"]
    ]
  },
  "admin:Network": {
    title: "Network Administration",
    description: "SR/CN ownership, placement integrity සහ point balances.",
    action: "Open network",
    rows: [
      ["Active SR accounts", "1,122", "Students"],
      ["Active CN accounts", "184", "Consultants"],
      ["Unplaced accounts", "0", "Healthy"],
      ["90-day resets", "4", "This month"]
    ]
  },
  "admin:Commissions": {
    title: "Commissions & Payouts",
    description: "Friday cycles, approvals, wallets සහ payout ledger.",
    action: "Calculate cycle",
    rows: [
      ["Current cycle", "2026-W29", "Scheduled"],
      ["Estimated payout", "Rs. 684,500", "126 accounts"],
      ["Payout requests", "21", "Pending"],
      ["Ledger integrity", "No duplicates", "Healthy"]
    ]
  },
  "admin:Settings": {
    title: "Platform Settings",
    description: "Business rules, account limits සහ system configuration.",
    action: "Save settings",
    rows: [
      ["Account sequence", "Next 527711", "Protected"],
      ["Max CN accounts", "7 per consultant", "Configurable"],
      ["Commission day", "Friday", "Asia/Colombo"],
      ["Inactivity reset", "90 days", "Enabled"]
    ]
  }
};

type StudentPaymentView = {
  id: string;
  paymentCode: string;
  method: string;
  totalAmount: string;
  paidAmount: string;
  status: string;
  hasProof: boolean;
};

type StudentCertificateView = {
  courseTitle: string;
  certificate: {
    certificateCode: string;
    issuedAt: string;
    revokedAt: string | null;
  };
};

function StudentFeatureWorkspace({ module }: { module: string }) {
  const [summary, setSummary] = useState<StudentDashboardSummary | null>(null);
  const [payments, setPayments] = useState<StudentPaymentView[]>([]);
  const [certificates, setCertificates] = useState<StudentCertificateView[]>([]);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    Promise.all([
      fetch("/api/student/dashboard-summary"),
      fetch("/api/student/payments"),
      fetch("/api/student/certificates")
    ]).then(async ([summaryResponse, paymentsResponse, certificatesResponse]) => {
      if (!summaryResponse.ok || !paymentsResponse.ok || !certificatesResponse.ok) {
        throw new Error("Student workspace request failed");
      }
      const summaryData = await summaryResponse.json() as StudentDashboardSummary;
      const paymentData = await paymentsResponse.json() as { payments: StudentPaymentView[] };
      const certificateData = await certificatesResponse.json() as { certificates: StudentCertificateView[] };
      setSummary(summaryData);
      setPayments(paymentData.payments);
      setCertificates(certificateData.certificates);
    }).catch(() => setFailed(true)).finally(() => setLoading(false));
  }, []);

  if (loading) return <section className="dash-card workspace-card"><h3>Loading...</h3></section>;
  if (failed || !summary) return <section className="dash-card workspace-card"><h3>Data load කළ නොහැක</h3><p>Page එක refresh කරන්න.</p></section>;

  let title = module;
  let description = "ඔබගේ සැබෑ account data සහ course activity.";
  let rows: [string, string, string][] = [];
  if (module === "My Course") {
    title = summary.courseTitle ?? "Course access pending";
    description = summary.enrollmentStatus === "NOT_ENROLLED"
      ? "Full payment එක Admin approve කළ පසු course lessons unlock වේ."
      : "ඔබගේ active course modules සහ progress.";
    rows = summary.modules.length
      ? summary.modules.map((item, index) => [
          `Module ${String(index + 1).padStart(2, "0")}`,
          item.title,
          item.progressPercent === 100 ? "Completed" : item.progressPercent ? `${item.progressPercent}%` : "Not started"
        ])
      : [["Course access", "Payment approval required", "Locked"]];
  } else if (module === "Progress") {
    title = "Learning Progress";
    rows = [
      ["Lessons completed", `${summary.completedLessons} of ${summary.totalLessons}`, `${summary.progressPercent}%`],
      ["Quiz average", summary.quizAverage === null ? "No attempts" : `${summary.quizAverage}%`, summary.quizAverage === null ? "Not started" : "Recorded"],
      ["Recent activity", summary.recentActivity.length ? `${summary.recentActivity.length} updates` : "No activity", summary.recentActivity.length ? "Active" : "Not started"],
      ["Course access", summary.courseTitle ?? "Not enrolled", summary.enrollmentStatus]
    ];
  } else if (module === "Certificates") {
    title = "Certificates";
    description = "සියලු lessons සහ required quizzes complete කළ පසු certificate නිකුත් වේ.";
    rows = certificates.length
      ? certificates.map((item) => [item.courseTitle, item.certificate.certificateCode, item.certificate.revokedAt ? "Revoked" : "Issued"])
      : [
          [summary.courseTitle ?? "Crypto Trading — Zero to Pro", `${summary.progressPercent}% complete`, "Not issued"],
          ["All lessons", `${summary.completedLessons} of ${summary.totalLessons}`, summary.progressPercent === 100 ? "Completed" : "Pending"],
          ["Quiz result", summary.quizAverage === null ? "No attempts" : `${summary.quizAverage}%`, summary.quizAverage !== null && summary.quizAverage >= 70 ? "Passed" : "Pending"]
        ];
  } else if (module === "Payments") {
    title = "Payment History";
    description = "ඔබ submit කළ Bank Transfer සහ USDT payments පමණක් මෙහි පෙන්වයි.";
    rows = payments.length
      ? payments.map((item) => [
          item.paymentCode,
          `${item.method.replaceAll("_", " ")} • Rs. ${Number(item.paidAmount).toLocaleString()}`,
          item.status.replaceAll("_", " ")
        ])
      : [["No payments", "Payment request එකක් තවම submit කර නැහැ", "Empty"]];
  }

  return (
    <section className="dash-card workspace-card">
      <div className="workspace-heading">
        <div>
          <span className="eyebrow">ADIL ACADEMY STUDENT PORTAL</span>
          <h2>{title}</h2>
          <p>{description}</p>
        </div>
      </div>
      <div className="workspace-list">
        <div className="workspace-list-head"><span>Item</span><span>Details</span><span>Status</span></div>
        {rows.map((row, index) => (
          <div className="workspace-list-row" key={`${row[0]}-${index}`}>
            <strong>{row[0]}</strong><span>{row[1]}</span><span className="status-badge success">{row[2]}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

type AdminStudentView = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  nicOrPassport: string | null;
  address: string | null;
  dateOfBirth: string | null;
  isActive: boolean;
  emailVerifiedAt: string | null;
  passwordSetAt: string | null;
  createdAt: string;
  enrollment: { status: string; courseTitle: string } | null;
  account: { number: string; status: string } | null;
  latestPayment: { status: string; paidAmount: string; totalAmount: string; paymentCode: string } | null;
};

type AdminCourseView = {
  id: string; title: string; slug: string; shortDescription: string; description: string | null;
  price: string; currency: string; points: number; isPublished: boolean;
  sections: Array<{ id: string; title: string; position: number; lessons: Array<{
    id: string; title: string; position: number; videoProvider: string | null; videoId: string | null; content: string | null;
  }> }>;
};

function CourseManagementWorkspace() {
  const [courses, setCourses] = useState<AdminCourseView[]>([]);
  const [message, setMessage] = useState("");
  const [sectionTitle, setSectionTitle] = useState("");
  const [lesson, setLesson] = useState({ sectionId: "", title: "", videoProvider: "youtube", videoId: "", content: "" });
  const course = courses[0];
  async function load() {
    const response = await fetch("/api/admin/courses");
    if (response.ok) setCourses(((await response.json()) as { courses: AdminCourseView[] }).courses);
  }
  useEffect(() => { void load(); }, []);
  async function saveCourse(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!course) return;
    const form = new FormData(event.currentTarget);
    const response = await fetch(`/api/admin/courses/${course.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: String(form.get("title")), shortDescription: String(form.get("shortDescription")),
        description: String(form.get("description")), price: Number(form.get("price")),
        isPublished: form.get("isPublished") === "on"
      })
    });
    setMessage(response.ok ? "Course details saved." : "Course save failed.");
    if (response.ok) await load();
  }
  async function addSection(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!course || !sectionTitle.trim()) return;
    const response = await fetch("/api/admin/course-sections", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ courseId: course.id, title: sectionTitle, position: course.sections.length + 1 }) });
    setMessage(response.ok ? "Module added." : "Module add failed."); setSectionTitle(""); if (response.ok) await load();
  }
  async function addLesson(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!lesson.sectionId || !lesson.title.trim()) return;
    const section = course?.sections.find((item) => item.id === lesson.sectionId);
    const response = await fetch("/api/admin/lessons", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
      sectionId: lesson.sectionId, title: lesson.title, videoProvider: lesson.videoId ? lesson.videoProvider : undefined,
      videoId: lesson.videoId || undefined, content: lesson.content || undefined, durationSeconds: 0,
      position: (section?.lessons.length ?? 0) + 1, isPreview: false
    }) });
    setMessage(response.ok ? "Lesson added." : "Lesson add failed.");
    if (response.ok) { setLesson({ sectionId: lesson.sectionId, title: "", videoProvider: "youtube", videoId: "", content: "" }); await load(); }
  }
  async function renameSection(section: AdminCourseView["sections"][number]) {
    const title = window.prompt("Module title", section.title); if (!title?.trim()) return;
    const response = await fetch(`/api/admin/course-sections/${section.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title }) });
    if (response.ok) await load();
  }
  async function editLesson(item: AdminCourseView["sections"][number]["lessons"][number]) {
    const title = window.prompt("Lesson title", item.title); if (!title?.trim()) return;
    const videoId = window.prompt("YouTube/Vimeo Video ID (හිස්ව තැබිය හැක)", item.videoId ?? "");
    const response = await fetch(`/api/admin/lessons/${item.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title, videoId: videoId || undefined, videoProvider: videoId ? (item.videoProvider ?? "youtube") : undefined }) });
    if (response.ok) await load();
  }
  if (!course) return <section className="dash-card workspace-card"><h3>Course data loading...</h3></section>;
  return <section className="dash-card workspace-card course-manager">
    <div className="workspace-heading"><div><span className="eyebrow">COURSE MANAGEMENT</span><h2>Course Content & Videos</h2><p>Code edit නොකර course, modules, lessons සහ video IDs manage කරන්න.</p></div></div>
    {message && <p className="form-error">{message}</p>}
    <form className="course-admin-form" onSubmit={saveCourse}>
      <label>Course title<input name="title" defaultValue={course.title} required /></label>
      <label>Price (LKR)<input name="price" type="number" defaultValue={course.price} required /></label>
      <label className="wide">Short description<input name="shortDescription" defaultValue={course.shortDescription} required /></label>
      <label className="wide">Full description<textarea name="description" defaultValue={course.description ?? ""} /></label>
      <label className="check-label"><input name="isPublished" type="checkbox" defaultChecked={course.isPublished} /> Public sales page එකේ publish කරන්න</label>
      <button className="button button-primary" type="submit">Save course</button>
    </form>
    <form className="course-inline-form" onSubmit={addSection}><input value={sectionTitle} onChange={(e) => setSectionTitle(e.target.value)} placeholder="New module title" required /><button className="button button-primary" type="submit">Add module</button></form>
    <form className="course-admin-form" onSubmit={addLesson}>
      <label>Module<select value={lesson.sectionId} onChange={(e) => setLesson({ ...lesson, sectionId: e.target.value })} required><option value="">Select module</option>{course.sections.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
      <label>Lesson title<input value={lesson.title} onChange={(e) => setLesson({ ...lesson, title: e.target.value })} required /></label>
      <label>Video provider<select value={lesson.videoProvider} onChange={(e) => setLesson({ ...lesson, videoProvider: e.target.value })}><option value="youtube">YouTube</option><option value="vimeo">Vimeo</option></select></label>
      <label>Video ID<input value={lesson.videoId} onChange={(e) => setLesson({ ...lesson, videoId: e.target.value })} placeholder="පසුව add කළ හැක" /></label>
      <label className="wide">Lesson notes<textarea value={lesson.content} onChange={(e) => setLesson({ ...lesson, content: e.target.value })} /></label>
      <button className="button button-primary" type="submit">Add lesson</button>
    </form>
    <div className="course-content-list">{course.sections.map((section) => <div key={section.id} className="course-module-admin"><div><strong>{section.title}</strong><button type="button" onClick={() => void renameSection(section)}>Rename</button></div>{section.lessons.map((item) => <button type="button" key={item.id} onClick={() => void editLesson(item)}><span>{item.title}</span><small>{item.videoId ? `${item.videoProvider}: ${item.videoId}` : "Video not added"}</small></button>)}{!section.lessons.length && <p>No lessons yet.</p>}</div>)}</div>
  </section>;
}

function AdminFeatureWorkspace({ module }: { module: string }) {
  const [students, setStudents] = useState<AdminStudentView[]>([]);
  const [payments, setPayments] = useState<AdminPaymentView[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  async function refresh() {
    setLoading(true);
    try {
      const [studentResponse, paymentResponse] = await Promise.all([
        fetch("/api/admin/students"), fetch("/api/admin/payments")
      ]);
      if (!studentResponse.ok || !paymentResponse.ok) throw new Error("Admin workspace failed");
      setStudents(((await studentResponse.json()) as { students: AdminStudentView[] }).students);
      setPayments(((await paymentResponse.json()) as { payments: AdminPaymentView[] }).payments);
    } catch {
      setMessage("Admin data load කළ නොහැක.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void refresh(); }, []);

  async function setStudentStatus(student: AdminStudentView) {
    const response = await fetch(`/api/admin/students/${student.id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !student.isActive })
    });
    setMessage(response.ok ? `Student ${student.isActive ? "suspended" : "activated"}.` : "Student status update failed.");
    if (response.ok) await refresh();
  }

  async function reviewPayment(payment: AdminPaymentView, status: "APPROVED" | "PARTIAL" | "REJECTED") {
    const response = await fetch(`/api/admin/payments/${payment.id}/review`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
    const result = await response.json() as { message?: string; otpEmailSent?: boolean };
    setMessage(response.ok ? (status === "APPROVED" ? `Payment approved. ${result.otpEmailSent ? "OTP email sent." : "OTP email failed—check EMAIL_APP_PASSWORD."}` : `Payment ${status.toLowerCase()}.`) : result.message ?? "Payment review failed.");
    if (response.ok) await refresh();
  }

  async function openProof(payment: AdminPaymentView) {
    const response = await fetch(`/api/admin/payments/${payment.id}/proof`);
    if (!response.ok) { setMessage("Payment proof එකක් නැහැ."); return; }
    const url = URL.createObjectURL(await response.blob());
    window.open(url, "_blank", "noopener,noreferrer");
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }

  if (loading) return <section className="dash-card workspace-card"><h3>Admin data loading...</h3></section>;
  if (module === "Students") {
    return <section className="dash-card workspace-card">
      <div className="workspace-heading"><div><span className="eyebrow">REAL STUDENT DATA</span><h2>Student Management</h2><p>Registered accounts, payments, enrollment සහ SR status.</p></div></div>
      {message && <p className="form-error">{message}</p>}
      <div className="workspace-list">
        <div className="workspace-list-head"><span>Student</span><span>Access & account</span><span>Action</span></div>
        {students.map((student) => <div className="workspace-list-row" key={student.id}>
          <strong>{student.name}<small>{student.email}<br />{student.phone ?? "No phone"} • {student.nicOrPassport ?? "No NIC"}<br />{student.dateOfBirth ?? "No DOB"} • {student.address ?? "No address"}</small></strong>
          <span>{student.account?.number ?? "No SR"}<br />{student.emailVerifiedAt ? "EMAIL VERIFIED" : student.latestPayment?.status === "APPROVED" ? "AWAITING OTP" : student.latestPayment?.status ?? "PAYMENT PENDING"}</span>
          <button type="button" className={`status-badge ${student.isActive ? "warning" : "success"}`} onClick={() => void setStudentStatus(student)}>{student.isActive ? "Suspend" : "Activate"}</button>
        </div>)}
        {!students.length && <p>No students registered.</p>}
      </div>
    </section>;
  }
  if (module === "Payments") {
    return <section className="dash-card workspace-card">
      <div className="workspace-heading"><div><span className="eyebrow">PAYMENT VERIFICATION</span><h2>Payments & Admissions</h2><p>Proof බලලා full payment පමණක් approve කරන්න.</p></div></div>
      {message && <p className="form-error">{message}</p>}
      <div className="workspace-list">
        <div className="workspace-list-head"><span>Payment</span><span>Amount</span><span>Actions</span></div>
        {payments.map((payment) => <div className="workspace-list-row" key={payment.id}>
          <strong>{payment.paymentCode}<small>{payment.method.replaceAll("_", " ")} • {payment.status}</small></strong>
          <span>Rs. {Number(payment.paidAmount).toLocaleString()} / {Number(payment.totalAmount).toLocaleString()}</span>
          <span className="admin-row-actions">
            <button type="button" onClick={() => void openProof(payment)}>Proof</button>
            {!['APPROVED','REJECTED','REFUNDED'].includes(payment.status) && <>
              <button type="button" onClick={() => void reviewPayment(payment, "APPROVED")}>Approve</button>
              <button type="button" onClick={() => void reviewPayment(payment, "PARTIAL")}>Partial</button>
              <button type="button" onClick={() => void reviewPayment(payment, "REJECTED")}>Reject</button>
            </>}
          </span>
        </div>)}
        {!payments.length && <p>No payment requests.</p>}
      </div>
    </section>;
  }
  return <FeatureWorkspace role="admin" module={module} />;
}

function FeatureWorkspace({
  role,
  module
}: {
  role: UserRole;
  module: string;
}) {
  if (role === "student") return <StudentFeatureWorkspace module={module} />;
  if (role === "admin" && module === "Course") return <CourseManagementWorkspace />;
  if (role === "admin" && ["Students", "Payments"].includes(module)) return <AdminFeatureWorkspace module={module} />;
  const data = workspaceData[role + ":" + module];
  if (!data) {
    return (
      <section className="dash-card workspace-empty">
        <Settings />
        <h3>{module}</h3>
        <p>මෙම module එක සඳහා permissions අනුව content load වේ.</p>
      </section>
    );
  }
  return (
    <section className="dash-card workspace-card">
      <div className="workspace-heading">
        <div>
          <span className="eyebrow">ADIL ACADEMY CONTROL PANEL</span>
          <h2>{data.title}</h2>
          <p>{data.description}</p>
        </div>
        <button type="button" className="button button-primary">
          {data.action}
          <ArrowRight size={16} />
        </button>
      </div>
      <div className="workspace-list">
        <div className="workspace-list-head">
          <span>Item</span>
          <span>Details</span>
          <span>Status</span>
        </div>
        {data.rows.map((row) => (
          <div className="workspace-list-row" key={row[0]}>
            <strong>{row[0]}</strong>
            <span>{row[1]}</span>
            <span className="status-badge success">{row[2]}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function Dashboard({
  user,
  onLogout
}: {
  user: DemoUser;
  onLogout: () => void;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeModule, setActiveModule] = useState("Overview");
  const roleTitle = {
    student: "Student Dashboard",
    consultant: "Consultant Control Panel",
    staff: "Staff Operations",
    admin: "Super Admin Control"
  }[user.role];

  return (
    <div className="dashboard-shell">
      <aside className={sidebarOpen ? "dashboard-sidebar sidebar-open" : "dashboard-sidebar"}>
        <div className="sidebar-top">
          <Logo />
          <button
            type="button"
            className="sidebar-close"
            onClick={() => setSidebarOpen(false)}
          >
            <X />
          </button>
        </div>
        <span className="sidebar-section-label">MAIN MENU</span>
        <nav>
          {dashboardNav[user.role].map((item) => (
            <button
              type="button"
              className={activeModule === item.label ? "active" : ""}
              key={item.label}
              onClick={() => {
                setActiveModule(item.label);
                setSidebarOpen(false);
              }}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="sidebar-support">
          <ShieldCheck />
          <strong>Need help?</strong>
          <span>Adil Academy support team</span>
          <button type="button">Contact support</button>
        </div>
        <button className="logout-button" type="button" onClick={onLogout}>
          <LogOut />
          Logout
        </button>
      </aside>
      <main className="dashboard-main">
        <header className="dashboard-header">
          <button
            className="dashboard-menu"
            type="button"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu />
          </button>
          <div>
            <span className="eyebrow">{roleTitle}</span>
            <h1>ආයුබෝවන්, {user.name.split(" ")[0]}</h1>
          </div>
          <div className="header-actions">
            <button type="button" aria-label="Notifications">
              <Bell />
              <span />
            </button>
            <div className="dashboard-user">
              <span>{user.name.slice(0, 2).toUpperCase()}</span>
              <div>
                <strong>{user.name}</strong>
                <small>{user.accountNumber ?? roleTitle}</small>
              </div>
            </div>
          </div>
        </header>
        <div className="dashboard-content">
          <div className="dashboard-welcome">
            <div>
              <h2>{roleTitle}</h2>
              <p>ඔබගේ අද දින platform summary එක මෙන්න.</p>
            </div>
            <span className="live-status">
              <i /> System Online
            </span>
          </div>
          {activeModule === "Overview" ? (
            <>
              {user.role === "student" && <StudentDashboard />}
              {user.role === "consultant" && <ConsultantDashboard />}
              {user.role === "staff" && <OperationsDashboard role="staff" />}
              {user.role === "admin" && <AdminDashboard />}
            </>
          ) : (
            <FeatureWorkspace role={user.role} module={activeModule} />
          )}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<DemoUser | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then(async (response) => {
        if (!response.ok) return null;
        return (await response.json()) as { user: DemoUser };
      })
      .then((data) => setUser(data?.user ?? null))
      .finally(() => setAuthChecked(true));
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setUser(null);
  }

  if (!authChecked) {
    return (
      <div className="app-loading">
        <Logo />
        <span />
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage onLogin={setUser} />} />
      <Route
        path="/dashboard"
        element={
          user ? (
            <Dashboard user={user} onLogout={logout} />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
