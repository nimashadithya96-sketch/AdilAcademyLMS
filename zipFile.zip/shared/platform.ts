export type UserRole = "student" | "consultant" | "staff" | "admin";

export type DemoUser = {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  accountNumber?: string;
};

export type PlatformOverview = {
  course: {
    title: string;
    language: string;
    modules: number;
    access: string;
  };
  features: string[];
  paymentMethods: string[];
};
