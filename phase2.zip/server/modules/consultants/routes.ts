import crypto from "node:crypto";
import { and, desc, eq, gt, inArray } from "drizzle-orm";
import { Router } from "express";
import { z } from "zod";
import { requireDatabase } from "../../../db/client";
import {
  accountPointBalances,
  auditLogs,
  commissionEntries,
  consultantApplications,
  consultantStudentRegistrations,
  courses,
  networkAccounts,
  networkPlacements,
  notifications,
  payoutRequests,
  paymentReferenceIds,
  users,
  walletLedger,
  wallets
} from "../../../db/schema";
import {
  HttpError,
  requireAuthenticatedUser,
  requireRole
} from "../../lib/auth";
import { asyncRoute } from "../../lib/http";
import { sendPayId } from "../../services/email";

export const consultantRouter = Router();

const studentRegistrationInput = z.object({
  firstName: z.string().trim().min(2).max(60), lastName: z.string().trim().min(2).max(60),
  email: z.string().trim().email().max(200), phone: z.string().trim().min(7).max(30),
  dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  nicOrPassport: z.string().trim().max(50).optional(), withoutNic: z.boolean().default(false),
  addressLine1: z.string().trim().min(3).max(250), addressLine2: z.string().trim().max(250).optional(),
  province: z.string().trim().min(2).max(80), district: z.string().trim().min(2).max(80), city: z.string().trim().min(2).max(80),
  courseId: z.string().uuid(), parentAccountId: z.string().uuid(), side: z.enum(["LEFT", "RIGHT"])
}).superRefine((value, context) => {
  if (!value.withoutNic && (!value.nicOrPassport || value.nicOrPassport.length < 5)) context.addIssue({ code: "custom", path: ["nicOrPassport"], message: "NIC / Passport එක අවශ්‍යයි." });
});

consultantRouter.post("/consultant/student-registrations", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const input = studentRegistrationInput.parse(request.body);
  const db = requireDatabase();
  const email = input.email.toLowerCase();
  const [[account], [course], [existingUser], [recentPayId]] = await Promise.all([
    db.select().from(networkAccounts).where(and(eq(networkAccounts.id, input.parentAccountId), eq(networkAccounts.ownerUserId, consultant.id), eq(networkAccounts.prefix, "CN"), eq(networkAccounts.status, "ACTIVE"))).limit(1),
    db.select().from(courses).where(and(eq(courses.id, input.courseId), eq(courses.isPublished, true))).limit(1),
    db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1),
    db.select().from(paymentReferenceIds).where(and(eq(paymentReferenceIds.email, email), gt(paymentReferenceIds.createdAt, new Date(Date.now() - 48 * 60 * 60 * 1000)))).orderBy(desc(paymentReferenceIds.createdAt)).limit(1)
  ]);
  if (!account) throw new HttpError(400, "Active consultant CN account එකක් තෝරන්න.");
  if (!course) throw new HttpError(404, "Course එක හමු නොවීය.");
  if (existingUser) throw new HttpError(409, "මෙම email එකට account එකක් දැනටමත් ඇත.");
  if (recentPayId) throw new HttpError(429, "මෙම email එකට පැය 48 ඇතුළත Pay ID එකක් නිකුත් කර ඇත.");
  const [occupied] = await db.select({ id: networkPlacements.id }).from(networkPlacements).where(and(eq(networkPlacements.parentAccountId, account.id), eq(networkPlacements.side, input.side))).limit(1);
  if (occupied) throw new HttpError(409, `${input.side} placement එක දැනටමත් භාවිත කර ඇත.`);
  const day = new Date().toISOString().slice(0, 10).replaceAll("-", "");
  const code = `ADIL-PAY-${day}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
  const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
  const result = await db.transaction(async (tx) => {
    const [payId] = await tx.insert(paymentReferenceIds).values({ code, email, expiresAt }).returning();
    const [registration] = await tx.insert(consultantStudentRegistrations).values({
      consultantUserId: consultant.id, parentAccountId: account.id, payIdId: payId.id, courseId: course.id,
      firstName: input.firstName, lastName: input.lastName, email, phone: input.phone, dateOfBirth: input.dateOfBirth,
      nicOrPassport: input.withoutNic ? null : input.nicOrPassport, addressLine1: input.addressLine1,
      addressLine2: input.addressLine2, province: input.province, district: input.district, city: input.city, side: input.side
    }).returning();
    return { registration, payId };
  });
  try { await sendPayId(email, code, expiresAt); }
  catch {
    await db.delete(consultantStudentRegistrations).where(eq(consultantStudentRegistrations.id, result.registration.id));
    await db.delete(paymentReferenceIds).where(eq(paymentReferenceIds.id, result.payId.id));
    throw new HttpError(503, "Pay ID email එක යැවීමට නොහැකි විය.");
  }
  response.status(201).json({ registration: { id: result.registration.id, status: result.registration.status }, payIdSent: true, expiresAt });
}));

consultantRouter.get("/consultant/student-registrations", asyncRoute(async (request, response) => {
  const consultant = await requireRole(request, ["consultant"]);
  const db = requireDatabase();
  const rows = await db.select({ registration: consultantStudentRegistrations, payId: paymentReferenceIds.code, courseTitle: courses.title })
    .from(consultantStudentRegistrations).innerJoin(paymentReferenceIds, eq(paymentReferenceIds.id, consultantStudentRegistrations.payIdId))
    .innerJoin(courses, eq(courses.id, consultantStudentRegistrations.courseId))
    .where(eq(consultantStudentRegistrations.consultantUserId, consultant.id)).orderBy(desc(consultantStudentRegistrations.createdAt));
  response.json({ registrations: rows.map(({ registration, payId, courseTitle }) => ({ ...registration, payId, courseTitle })) });
}));

consultantRouter.get(
  "/consultant/cco-dashboard",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant"]);
    const db = requireDatabase();
    const accountRows = await db.select({
      account: networkAccounts,
      balance: accountPointBalances
    }).from(networkAccounts)
      .leftJoin(accountPointBalances, eq(accountPointBalances.accountId, networkAccounts.id))
      .where(eq(networkAccounts.ownerUserId, user.id))
      .orderBy(desc(networkAccounts.isMainAccount));

    const accountIds = accountRows.map((row) => row.account.id);
    const [wallet] = await db.select().from(wallets)
      .where(eq(wallets.userId, user.id)).limit(1);
    const [entries, placements, ledger, payouts] = await Promise.all([
      accountIds.length
        ? db.select().from(commissionEntries)
          .where(inArray(commissionEntries.accountId, accountIds))
          .orderBy(desc(commissionEntries.createdAt))
        : Promise.resolve([]),
      accountIds.length
        ? db.select().from(networkPlacements)
          .where(inArray(networkPlacements.parentAccountId, accountIds))
        : Promise.resolve([]),
      wallet
        ? db.select().from(walletLedger).where(eq(walletLedger.walletId, wallet.id))
          .orderBy(desc(walletLedger.createdAt)).limit(20)
        : Promise.resolve([]),
      wallet
        ? db.select().from(payoutRequests).where(eq(payoutRequests.walletId, wallet.id))
          .orderBy(desc(payoutRequests.createdAt))
        : Promise.resolve([])
    ]);

    const main = accountRows.find((row) => row.account.isMainAccount)?.account ?? accountRows[0]?.account;
    const activeByNumber = new Map(accountRows.map((row) => [row.account.numericPart, row.account]));
    const slots = main ? Array.from({ length: 7 }, (_, index) => {
      const numericPart = main.numericPart + index;
      const active = activeByNumber.get(numericPart);
      return {
        position: index + 1,
        numericPart,
        number: active ? `${active.prefix}${numericPart}` : `CN${numericPart}`,
        status: active?.status ?? "RESERVED_SLOT",
        isMain: index === 0,
        accountId: active?.id ?? null
      };
    }) : [];
    const accountSummaries = accountRows.map(({ account, balance }) => {
      const accountIncome = entries.filter((entry) => entry.accountId === account.id)
        .reduce((sum, entry) => sum + Number(entry.amount), 0);
      const left = balance?.leftAvailable ?? 0;
      const right = balance?.rightAvailable ?? 0;
      return {
        id: account.id,
        number: `${account.prefix}${account.numericPart}`,
        status: account.status,
        isMain: account.isMainAccount,
        leftAvailable: left,
        rightAvailable: right,
        lifetimeLeft: balance?.lifetimeLeft ?? 0,
        lifetimeRight: balance?.lifetimeRight ?? 0,
        stageOneAchieved: balance?.stageOneAchieved ?? false,
        stageTwoAchieved: balance?.stageTwoAchieved ?? false,
        nextStage: !(balance?.stageOneAchieved) ? "1:1" : !(balance?.stageTwoAchieved) ? "2:2" : "3:3",
        nextPayout: !(balance?.stageOneAchieved) ? 2500 : !(balance?.stageTwoAchieved) ? 5000 : 8000,
        income: accountIncome
      };
    });

    response.json({
      mainAccountNumber: main ? `${main.prefix}${main.numericPart}` : null,
      totalIncome: entries.reduce((sum, entry) => sum + Number(entry.amount), 0),
      totalPaid: payouts.filter((item) => item.status === "PAID").reduce((sum, item) => sum + Number(item.amount), 0),
      upcomingIncome: Number(wallet?.pendingBalance ?? 0),
      availableBalance: Number(wallet?.availableBalance ?? 0),
      directStudents: new Set(placements.map((item) => item.accountId)).size,
      leftPoints: accountSummaries.reduce((sum, item) => sum + item.leftAvailable, 0),
      rightPoints: accountSummaries.reduce((sum, item) => sum + item.rightAvailable, 0),
      accounts: accountSummaries,
      slots,
      recentLedger: ledger
    });
  })
);

const applicationInput = z.object({
  motivation: z.string().trim().min(10).max(3000)
});

const reviewInput = z.object({
  status: z.enum(["INTERVIEW", "APPROVED", "REJECTED"]),
  interviewNote: z.string().trim().max(3000).optional()
});

consultantRouter.post(
  "/consultant-applications",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    if (user.role !== "student") {
      throw new HttpError(409, "Only students can apply to become consultants.");
    }
    const input = applicationInput.parse(request.body);
    const db = requireDatabase();
    const [existing] = await db
      .select()
      .from(consultantApplications)
      .where(
        and(
          eq(consultantApplications.userId, user.id),
          inArray(consultantApplications.status, ["PENDING", "INTERVIEW"])
        )
      )
      .limit(1);
    if (existing) {
      throw new HttpError(409, "A consultant application is already active.");
    }
    const [created] = await db
      .insert(consultantApplications)
      .values({ userId: user.id, motivation: input.motivation })
      .returning();
    response.status(201).json({ application: created });
  })
);

consultantRouter.get(
  "/consultant-applications/me",
  asyncRoute(async (request, response) => {
    const user = await requireAuthenticatedUser(request);
    const db = requireDatabase();
    const [application] = await db
      .select()
      .from(consultantApplications)
      .where(eq(consultantApplications.userId, user.id))
      .orderBy(desc(consultantApplications.createdAt))
      .limit(1);
    response.json({ application: application ?? null });
  })
);

consultantRouter.get(
  "/admin/consultant-applications",
  asyncRoute(async (request, response) => {
    await requireRole(request, ["staff", "admin"]);
    const db = requireDatabase();
    const applications = await db
      .select({
        application: consultantApplications,
        student: {
          id: users.id,
          displayName: users.displayName,
          email: users.email,
          phone: users.phone
        }
      })
      .from(consultantApplications)
      .innerJoin(users, eq(consultantApplications.userId, users.id))
      .orderBy(desc(consultantApplications.createdAt));
    response.json({ applications });
  })
);

consultantRouter.post(
  "/admin/consultant-applications/:id/review",
  asyncRoute(async (request, response) => {
    const reviewer = await requireRole(request, ["staff", "admin"]);
    const input = reviewInput.parse(request.body);
    if (input.status === "APPROVED" && reviewer.role !== "admin") {
      throw new HttpError(403, "Super Admin approval is required.");
    }
    const db = requireDatabase();
    const result = await db.transaction(async (tx) => {
      const [application] = await tx
        .select()
        .from(consultantApplications)
        .where(eq(consultantApplications.id, String(request.params.id)))
        .limit(1);
      if (!application) {
        throw new HttpError(404, "Consultant application not found.");
      }
      if (["APPROVED", "REJECTED"].includes(application.status)) {
        throw new HttpError(409, "Application is already finalized.");
      }

      const [updated] = await tx
        .update(consultantApplications)
        .set({
          status: input.status,
          interviewNote: input.interviewNote,
          reviewedBy: reviewer.id,
          reviewedAt: new Date()
        })
        .where(eq(consultantApplications.id, application.id))
        .returning();

      let mainAccount = null;
      if (input.status === "APPROVED") {
        [mainAccount] = await tx
          .select()
          .from(networkAccounts)
          .where(
            and(
              eq(networkAccounts.ownerUserId, application.userId),
              eq(networkAccounts.isMainAccount, true),
              eq(networkAccounts.status, "ACTIVE")
            )
          )
          .limit(1);
        if (!mainAccount) {
          throw new HttpError(
            409,
            "An active paid SR account is required before consultant approval."
          );
        }
        if (mainAccount.prefix === "SR") {
          [mainAccount] = await tx
            .update(networkAccounts)
            .set({ prefix: "CN" })
            .where(eq(networkAccounts.id, mainAccount.id))
            .returning();
        }
        await tx
          .update(users)
          .set({ role: "consultant", updatedAt: new Date() })
          .where(eq(users.id, application.userId));
        await tx
          .insert(wallets)
          .values({ userId: application.userId })
          .onConflictDoNothing({ target: wallets.userId });
      }

      await tx.insert(notifications).values({
        userId: application.userId,
        type: "CONSULTANT_APPLICATION_" + input.status,
        title:
          input.status === "APPROVED"
            ? "Consultant account approved"
            : "Consultant application updated",
        message:
          input.status === "APPROVED"
            ? "Your SR main account is now an active CN consultant account."
            : "Your consultant application status is now " + input.status + "."
      });
      await tx.insert(auditLogs).values({
        actorUserId: reviewer.id,
        action: "CONSULTANT_APPLICATION_" + input.status,
        entityType: "consultant_application",
        entityId: application.id,
        metadata: {
          userId: application.userId,
          accountId: mainAccount?.id ?? null
        }
      });
      return { application: updated, account: mainAccount };
    });
    response.json(result);
  })
);

consultantRouter.get(
  "/consultant/accounts",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant", "admin"]);
    const db = requireDatabase();
    const accounts = await db
      .select({
        account: networkAccounts,
        balance: accountPointBalances
      })
      .from(networkAccounts)
      .leftJoin(
        accountPointBalances,
        eq(accountPointBalances.accountId, networkAccounts.id)
      )
      .where(eq(networkAccounts.ownerUserId, user.id))
      .orderBy(desc(networkAccounts.isMainAccount));
    response.json({ accounts, maxAccounts: 7 });
  })
);

consultantRouter.get(
  "/consultant/network",
  asyncRoute(async (request, response) => {
    const user = await requireRole(request, ["consultant", "admin"]);
    const db = requireDatabase();
    const owned = await db
      .select()
      .from(networkAccounts)
      .where(eq(networkAccounts.ownerUserId, user.id));
    if (owned.length === 0) {
      response.json({ roots: [], accounts: [], placements: [] });
      return;
    }

    const allAccounts = await db.select().from(networkAccounts);
    const allPlacements = await db.select().from(networkPlacements);
    const accountMap = new Map(
      allAccounts.map((account) => [account.id, account])
    );
    const children = new Map<
      string,
      { side: "LEFT" | "RIGHT"; accountId: string }[]
    >();
    for (const placement of allPlacements) {
      const list = children.get(placement.parentAccountId) ?? [];
      list.push({ side: placement.side, accountId: placement.accountId });
      children.set(placement.parentAccountId, list);
    }

    const visibleIds = new Set<string>();
    const queue = owned.map((account) => account.id);
    while (queue.length && visibleIds.size < 2000) {
      const current = queue.shift()!;
      if (visibleIds.has(current)) continue;
      visibleIds.add(current);
      for (const child of children.get(current) ?? []) {
        queue.push(child.accountId);
      }
    }

    response.json({
      roots: owned.map((account) => account.id),
      accounts: [...visibleIds]
        .map((id) => accountMap.get(id))
        .filter(Boolean),
      placements: allPlacements.filter(
        (placement) =>
          visibleIds.has(placement.accountId) &&
          visibleIds.has(placement.parentAccountId)
      )
    });
  })
);
